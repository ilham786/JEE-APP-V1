<!-- BEGIN:nextjs-agent-rules -->
# This is NOT the Next.js you know

This version has breaking changes — APIs, conventions, and file structure may all differ from your training data. Read the relevant guide in `node_modules/next/dist/docs/` before writing any code. Heed deprecation notices.
<!-- END:nextjs-agent-rules -->

# FocusForge — AI Agent Guide & Workspace Navigation Hub

Welcome to FocusForge. This document acts as the core onboarding and working guide for AI coding assistants. Use it to navigate the codebase, understand the technical layout, gather contextual files in priority order, and align modifications with established project conventions.

---

## 🔒 1. Context Priority & Reference Index

Before initiating any codebase analysis, design updates, or logic changes, gather project context by reading the reference documents in the following order:

1.  **[docs/AI_CONTEXT.md](file:///c:/Users/Lenovo/Desktop/JEE/docs/AI_CONTEXT.md)**: Standard coding patterns, files to protect, and active technical debt checklist.
2.  **[docs/PROJECT_OVERVIEW.md](file:///c:/Users/Lenovo/Desktop/JEE/docs/PROJECT_OVERVIEW.md)**: Product goals, target student personas (IIT-JEE), and product design philosophy.
3.  **[docs/ARCHITECTURE.md](file:///c:/Users/Lenovo/Desktop/JEE/docs/ARCHITECTURE.md)**: Systems architecture details, data flows, and state configurations.
4.  **[docs/COMPONENTS.md](file:///c:/Users/Lenovo/Desktop/JEE/docs/COMPONENTS.md)**: Interface layout shells, prop signatures, and UI primitives catalog.
5.  **[docs/STYLING_GUIDE.md](file:///c:/Users/Lenovo/Desktop/JEE/docs/STYLING_GUIDE.md)**: CSS architecture, Tailwind v4 theme variables, and visual tokens.
6.  **[docs/DEVELOPMENT_GUIDE.md](file:///c:/Users/Lenovo/Desktop/JEE/docs/DEVELOPMENT_GUIDE.md)**: Route addition tutorials, component structures, store updates, and hydration guards.
7.  **[docs/CHANGELOG.md](file:///c:/Users/Lenovo/Desktop/JEE/docs/CHANGELOG.md)**: History of updates, current version stats, and roadmap.

*Note: Legacy reference sheets [docs/COMPONENT_MAP.md](file:///c:/Users/Lenovo/Desktop/JEE/docs/COMPONENT_MAP.md) and [docs/DESIGN_SYSTEM.md](file:///c:/Users/Lenovo/Desktop/JEE/docs/DESIGN_SYSTEM.md) contain redirects pointing to the updated consolidated documents.*

---

## 🗺️ 2. Project Directory Navigation

Refer to this visual map to locate code modules quickly:

| Directory | Purpose | Core Files |
| :--- | :--- | :--- |
| **`src/app/`** | Next.js App Router Feature Pages | [globals.css](file:///c:/Users/Lenovo/Desktop/JEE/src/app/globals.css) (v4 Theme Config), [layout.tsx](file:///c:/Users/Lenovo/Desktop/JEE/src/app/layout.tsx) (Fonts/Meta), Page folders (`/login`, `/dashboard`, `/study`, `/mistakes`, etc.) |
| **`src/components/3d/`**| Real-Time 3D WebGL Canvas | [RobotScene.tsx](file:///c:/Users/Lenovo/Desktop/JEE/src/components/3d/RobotScene.tsx) (Three.js PBR Baymax-inspired robot & particle scene) |
| **`src/components/`** | Structural App Shell Elements | [workspace-layout.tsx](file:///c:/Users/Lenovo/Desktop/JEE/src/components/workspace-layout.tsx) (App shell), [sidebar.tsx](file:///c:/Users/Lenovo/Desktop/JEE/src/components/sidebar.tsx), [header.tsx](file:///c:/Users/Lenovo/Desktop/JEE/src/components/header.tsx), [sound-player.tsx](file:///c:/Users/Lenovo/Desktop/JEE/src/components/sound-player.tsx) (Web Audio synth) |
| **`src/components/ui/`** | Reusable Design System Primitives | [card.tsx](file:///c:/Users/Lenovo/Desktop/JEE/src/components/ui/card.tsx) (Translucent panels), [controls.tsx](file:///c:/Users/Lenovo/Desktop/JEE/src/components/ui/controls.tsx) (Standard buttons, progress bars) |
| **`src/store/`** | Zustand Persisted State Layer | [use-study-store.ts](file:///c:/Users/Lenovo/Desktop/JEE/src/store/use-study-store.ts) (Timer/Blocker stats), [use-mistake-store.ts](file:///c:/Users/Lenovo/Desktop/JEE/src/store/use-mistake-store.ts) (Syllabus/Mistakes logs) |
| **`src/hooks/`** | Helper Event Controllers | [use-keyboard-shortcuts.ts](file:///c:/Users/Lenovo/Desktop/JEE/src/hooks/use-keyboard-shortcuts.ts) (Alt navigation keys), [use-is-client.ts](file:///c:/Users/Lenovo/Desktop/JEE/src/hooks/use-is-client.ts) (Hydration guard) |
| **`src/lib/`** | Analytical and Algorithmic Logic | [spaced-rep.ts](file:///c:/Users/Lenovo/Desktop/JEE/src/lib/spaced-rep.ts) (SuperMemo spaced rep), [coach-logic.ts](file:///c:/Users/Lenovo/Desktop/JEE/src/lib/coach-logic.ts) (Advisory heuristics) |
| **`server.js` & `vite.config.js`** | Backend Server & Asset Bundler | [server.js](file:///c:/Users/Lenovo/Desktop/JEE/server.js) (Express static host & auth APIs), [vite.config.js](file:///c:/Users/Lenovo/Desktop/JEE/vite.config.js) (Vite bundler config) |
| **`prisma/`** | Relational Database Scaffolding | [schema.prisma](file:///c:/Users/Lenovo/Desktop/JEE/prisma/schema.prisma) (SQLite database maps, currently unwired from UI) |

---

## 🔄 Global 4-Way Data Sync Engine

FocusForge operates on a real-time, unified 4-way data synchronization engine powered by client-side Zustand store persistence (`useStudyStore` & `useMistakeStore`). Any activity logged across focus sessions, mistake entries, or revision queues instantly updates syllabus completion, weak topic tags, and analytics across all pages:

```
       [ Study Session ]  ------->  Completes focus session: +20% completion & +1 revision cycle
              │
       [ Mistake Journal ] ------>  Logs mistake: auto-tags weak topic into syllabus
              │                     Revises mistake: +15% completion & advances spaced repetition
              ▼
    ┌──────────────────┐
    │  Zustand Store   │  ------->  Real-time state persistence across all pages
    └──────────────────┘
              ▲
              │
       [ Revision Plan ]  ------->  Executes due revision: completes spaced cycle & awards +100 XP
              │
       [  JEE Tracker  ]  ------->  Displays live overall completion %, completed cards & weak topics
```

---

## ⚙️ 3. Operational Guidelines for AI Coding Agents

When working on this repository, you **must** follow these engineering standards:

### Context Checking
*   Always inspect the priority context files in the `docs/` folder before suggesting additions.
*   Verify logic constraints: do not write direct database calls inside page routes—data transactions are governed exclusively by client-side Zustand store states today.

### Component Reusability & Minimal Change
*   Do not rewrite or duplicate visual panels. Check [docs/COMPONENTS.md](file:///c:/Users/Lenovo/Desktop/JEE/docs/COMPONENTS.md) and reuse existing primitives from `src/components/ui/`.
*   Maintain targeted changes: keep edits scoped tightly to the assigned issue. Avoid sweeping refactoring loops unless explicitly directed.

### Styling & Theme Adherence
*   Never use hardcoded hex styles or introduce ad-hoc color palettes. Utilize Tailwind v4 colors (`text-physics`, `bg-accent-purple`) configured inside the `@theme` block in `globals.css`.
*   Maintain the dark, high-focus glassmorphic style. Ensure cards use the `.glass-panel` utilities and maintain Framer Motion hover presets.

### Safe Areas & Protected Files
*   **Do Not Modify**: Spaced repetition logic (`spaced-rep.ts`), synthetic audio synthesisers (`sound-player.tsx`), or database schema structure maps (`schema.prisma`) without explicit instructions.
*   **Safe to Modify**: Feature page layouts (`src/app/`), primitive visual elements (`src/components/ui/`), and CSS customization properties.

### Mandatory Default UI/UX Skill: Impeccable (`impeccable`)
AI agents MUST apply **`impeccable`** (by Paul Bakaus) by default for all frontend UI/UX design, auditing, component shaping, refinement, and visual craft:
*   **Out-of-Distribution Craft**: Approach all UI tasks with award-winning creative direction, production-grade code, and zero shortcuts.
*   **Design Context Initialization**: Run `node .agents/skills/impeccable/scripts/context.mjs --target <path>` or load `PRODUCT.md` and `DESIGN.md` for context-aware styling.
*   **Commands Suite Available**:
    *   `craft`, `shape`: Plan and architect UI/UX before coding.
    *   `audit`, `critique`: Technical (a11y, perf, responsive) and UX design reviews.
    *   `polish`, `bolder`, `quieter`, `distill`, `harden`, `onboard`: Targeted UI refinement passes.
    *   `animate`, `colorize`, `typeset`, `layout`, `delight`, `overdrive`, `clarify`: Visual & copy enhancement passes.

### Mandatory Default UI Skill: Taste Skill (`taste-skill` / `design-taste-frontend`)
AI agents MUST apply **`taste-skill`** by default whenever working on frontend UI, layout, styling, or component development:
*   **0. Brief Inference**: Output a one-line "Design Read" before generating any UI code (`Reading this as: <page kind> for <audience>, with a <vibe> language, leaning toward <design system>`).
*   **1. The Three Dials**: Infer `DESIGN_VARIANCE` (1-10), `MOTION_INTENSITY` (1-10), and `VISUAL_DENSITY` (1-10) based on context.
*   **Anti-Default Discipline**: Explicitly avoid generic LLM slop (e.g. AI-purple gradients, dark mesh centered heroes, generic glassmorphism on everything).
*   **Sub-skills Suite**: Includes `minimalist-skill`, `soft-skill`, `brutalist-skill`, `stitch-skill`, `redesign-skill`, `brandkit`, `image-to-code-skill`, and `output-skill`.

### Installed Design & Animation Skills (Emil Kowalski & GSAP)
The workspace and global environment (`.agents/skills/` and `~/.gemini/config/skills/`) have been configured with Emil Kowalski's design engineering skills and the **Official GSAP Skills Suite**:
*   **`gsap-core` & `gsap-frameworks`**: GSAP core engine best practices (`gsap.to()`, `from()`, `fromTo()`, easing, stagger, responsive `gsap.matchMedia()`).
*   **`gsap-react`**: GSAP integration with React/Next.js (`useGSAP()` hook, scope cleanup, ref bindings).
*   **`gsap-scrolltrigger`**: Scroll-driven animations, pinned containers, scrubbing, and scroll triggers.
*   **`gsap-timeline`**: Coordinated multi-step timeline sequencing and playback control.
*   **`gsap-plugins`**: GSAP plugins usage (Flip, Draggable, MotionPath, ScrollTo, SplitText, etc.).
*   **`gsap-performance`**: Hardware acceleration, transform optimizations, and zero-jank animation rules.
*   **`gsap-utils`**: GSAP utility functions (`clamp`, `mapRange`, `interpolate`, `pipe`, `wrap`).
*   **`emil-design-eng`**: Core design engineering philosophy on UI polish, component feel, easing, and micro-interactions.
*   **`animation-vocabulary`**: Animation terminology guide for requesting specific motion styles and transitions.
*   **`apple-design`**: Apple's UI principles for fluid motion and interface design translated for web applications.
*   **`find-animation-opportunities`**: Identifies optimal UI areas that benefit from animation while highlighting what NOT to animate.
*   **`improve-animations`**: Audits codebase animations and generates prioritized, self-contained improvement plans.
*   **`pick-ui-library`**: Evaluates and selects trusted UI component libraries and packages for specific tasks.
*   **`review-animations`**: Performs strict rule-based animation reviews with Before/After comparison tables.

> **MANDATORY DIRECTIVE FOR AI AGENTS**: When reading context or README files, AI coding agents MUST load and build according to the installed GSAP skills (`.agents/skills/gsap-*`) by default whenever creating or editing animations, transitions, UI motion, timelines, or interactive components.

### Document Maintenance
*   Always maintain documentation synchronization. If you add routes, components, or store mutations, update the corresponding guides under `docs/` (`COMPONENTS.md`, `STYLING_GUIDE.md`, etc.) and append change descriptions to `docs/CHANGELOG.md`.
*   **Routing Engine**: Always use Agent Reach routing (`agent-reach doctor --json` / upstream CLIs) to research topics, search social platforms (Twitter/X, Reddit, Bilibili, XiaoHongShu, YouTube, V2EX, GitHub, Exa), or read web URLs.
*   **Zero-Config Channels Active**: Jina Reader (`curl https://r.jina.ai/<URL>`), YouTube (`yt-dlp`), V2EX, RSS/Atom, Bilibili search, and Exa neural search.
*   **Safety & Environment**: Never store tokens in git. Executables reside in `~/.agent-reach-venv/Scripts`.

### Document Maintenance
*   Always maintain documentation synchronization. If you add routes, components, or store mutations, update the corresponding guides under `docs/` (`COMPONENTS.md`, `STYLING_GUIDE.md`, etc.) and append change descriptions to `docs/CHANGELOG.md`.
