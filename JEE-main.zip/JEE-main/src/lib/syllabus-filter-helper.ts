import { getSyllabusForSubject } from "@/data/syllabus";
import { SelectOption } from "@/components/ui/select";
import { SUBJECT_COLORS, DEFAULT_SUBJECT_COLORS, SubjectColorTokens } from "@/theme/subjectColors";
import { ExamType } from "@/lib/exam-config";

/**
 * Returns dynamic dependent chapter options for the Select dropdown.
 * - Multi-exam aware: works for both JEE (Physics, Chemistry, Maths) and NEET (Physics, Chemistry, Botany, Zoology)
 * - If All Subjects selected: returns grouped sections with emoji headers
 */
export function getDependentChapterOptions(
  selectedSubject: string,
  includeAllOption: boolean = true,
  examType: ExamType = "JEE"
): SelectOption[] {
  const normSub = selectedSubject?.trim() || "";

  if (normSub) {
    const chapters = getSyllabusForSubject(normSub, examType);
    const options: SelectOption[] = [];
    if (includeAllOption) {
      options.push({
        value: "",
        label: `All ${normSub} Chapters`,
        subject: normSub,
      });
    }
    chapters.forEach((ch) => {
      options.push({
        value: ch.name,
        label: ch.name,
        description: `[ Weight: ${ch.weightage}% • ${ch.classLevel} ]`,
        subject: normSub,
      });
    });
    return options;
  }

  // ALL SUBJECTS MODE: Grouped sections with headers
  const options: SelectOption[] = [];

  if (includeAllOption) {
    options.push({
      value: "",
      label: "All Chapters",
    });
  }

  if (examType === "NEET") {
    const neetSubjects: Array<{ name: string; label: string; icon: string }> = [
      { name: "Physics", label: "📘 Physics Chapters", icon: "📘" },
      { name: "Chemistry", label: "🧪 Chemistry Chapters", icon: "🧪" },
      { name: "Botany", label: "🌿 Botany Chapters", icon: "🌿" },
      { name: "Zoology", label: "🦁 Zoology Chapters", icon: "🦁" },
    ];

    neetSubjects.forEach((sub) => {
      const chapters = getSyllabusForSubject(sub.name, "NEET");
      if (chapters.length > 0) {
        options.push({
          value: `header-${sub.name.toLowerCase()}`,
          label: sub.label,
          isHeader: true,
          subject: sub.name,
        });
        chapters.forEach((ch) => {
          options.push({
            value: ch.name,
            label: ch.name,
            description: `[ ${sub.name} • ${ch.weightage}% ]`,
            subject: sub.name,
          });
        });
      }
    });

    return options;
  }

  // Default JEE Subjects
  const jeeSubjects: Array<{ name: string; label: string }> = [
    { name: "Physics", label: "📘 Physics Chapters" },
    { name: "Chemistry", label: "🧪 Chemistry Chapters" },
    { name: "Maths", label: "📐 Mathematics Chapters" },
  ];

  jeeSubjects.forEach((sub) => {
    const chapters = getSyllabusForSubject(sub.name, "JEE");
    if (chapters.length > 0) {
      options.push({
        value: `header-${sub.name.toLowerCase()}`,
        label: sub.label,
        isHeader: true,
        subject: sub.name,
      });
      chapters.forEach((ch) => {
        options.push({
          value: ch.name,
          label: ch.name,
          description: `[ ${sub.name === "Maths" ? "Mathematics" : sub.name} • ${ch.weightage}% ]`,
          subject: sub.name,
        });
      });
    }
  });

  return options;
}

/**
 * Validates if a chapter belongs to the currently selected subject.
 * Used for auto-resetting dependent chapter dropdown state.
 */
export function isValidChapterForSubject(
  selectedSubject: string,
  selectedChapter: string,
  examType: ExamType = "JEE"
): boolean {
  if (!selectedChapter || !selectedSubject) return true;
  const list = getSyllabusForSubject(selectedSubject, examType);
  return list.some((ch) => ch.name.toLowerCase() === selectedChapter.toLowerCase());
}

/**
 * Map subject string to component variant token
 */
export function getSubjectVariant(
  subject: string
): "physics" | "chemistry" | "maths" | "botany" | "zoology" | "biology" | "glass" {
  const norm = subject?.toLowerCase().trim();
  if (norm === "physics") return "physics";
  if (norm === "chemistry") return "chemistry";
  if (norm === "maths" || norm === "mathematics") return "maths";
  if (norm === "botany") return "botany";
  if (norm === "zoology") return "zoology";
  if (norm === "biology") return "biology";
  return "glass";
}

/**
 * Fetch subject color system tokens
 */
export function getSubjectColorTokens(subject: string): SubjectColorTokens {
  return SUBJECT_COLORS[subject] || DEFAULT_SUBJECT_COLORS;
}

