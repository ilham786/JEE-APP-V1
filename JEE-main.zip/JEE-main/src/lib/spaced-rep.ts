/**
 * Spaced Repetition & SuperMemo-2 Algorithm
 * Calculates optimal revision dates, memory strength, and recall probability.
 */

export interface RevisionSchedule {
  cycle: number;
  daysUntilNextReview: number;
  nextReviewDate: Date;
  efFactor: number; // Ease factor for SuperMemo-2
}

/**
 * Standard spaced repetition intervals in days
 * Cycle: 0->1 day, 1->3 days, 2->7 days, 3->15 days, 4->30 days, 5->60 days
 */
export const STANDARD_INTERVALS_DAYS = [1, 3, 7, 15, 30, 60];

/**
 * Calculate next review date using SuperMemo-2 algorithm
 * @param currentCycle The current revision cycle (0-indexed)
 * @param quality Quality rating (0: Forgot, 3: Hard, 4: Medium, 5: Easy)
 * @param initialEF Ease factor (default: 2.5)
 */
export function calculateNextReviewDate(
  currentCycle: number = 0,
  quality: number = 4,
  initialEF: number = 2.5
): RevisionSchedule {
  let efFactor = initialEF;

  // SuperMemo-2 formula for ease factor: EF' = EF + (0.1 - (5 - q) * (0.08 + (5 - q) * 0.02))
  efFactor = efFactor + (0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02));
  if (efFactor < 1.3) efFactor = 1.3;

  let nextCycle = currentCycle;
  let daysUntilNextReview = 1;

  if (quality < 3) {
    // If forgotten or hard failure, reset cycle back to 0 (review tomorrow or today)
    nextCycle = 0;
    daysUntilNextReview = 1;
  } else {
    // Success: advance cycle
    nextCycle = currentCycle + 1;
    if (currentCycle === 0) {
      daysUntilNextReview = 1;
    } else if (currentCycle === 1) {
      daysUntilNextReview = 3;
    } else {
      const baseDays = STANDARD_INTERVALS_DAYS[currentCycle] || 30;
      daysUntilNextReview = Math.round(baseDays * efFactor);
    }
  }

  const nextReviewDate = new Date();
  nextReviewDate.setDate(nextReviewDate.getDate() + daysUntilNextReview);

  return {
    cycle: Math.min(nextCycle, STANDARD_INTERVALS_DAYS.length - 1),
    daysUntilNextReview,
    nextReviewDate,
    efFactor: parseFloat(efFactor.toFixed(2)),
  };
}

/**
 * Calculate Memory Retention Percentage & Recall Probability
 * Ebbinghaus Forgetting Curve formula: R = e^(-t / S)
 * where t = days since last revision, S = memory stability (cycle * EF)
 */
export function calculateMemoryStrength(
  lastRevisedAt: string | Date,
  timesRevised: number = 1,
  efFactor: number = 2.5
): { retentionPct: number; recallProbability: number; status: "Strong" | "Moderate" | "Fading" | "Critical" } {
  const lastDate = new Date(lastRevisedAt);
  const now = new Date();
  const diffDays = Math.max(0, (now.getTime() - lastDate.getTime()) / (1000 * 60 * 60 * 24));
  
  const stability = Math.max(1, (timesRevised + 1) * 2 * (efFactor / 2.5));
  const retention = Math.exp(-diffDays / (stability * 3));
  const retentionPct = Math.min(100, Math.max(10, Math.round(retention * 100)));

  let status: "Strong" | "Moderate" | "Fading" | "Critical" = "Strong";
  if (retentionPct < 40) status = "Critical";
  else if (retentionPct < 65) status = "Fading";
  else if (retentionPct < 85) status = "Moderate";

  return {
    retentionPct,
    recallProbability: parseFloat(retention.toFixed(2)),
    status,
  };
}

/**
 * Check if a mistake/revision is overdue for review
 */
export function isOverdue(scheduledDate: Date | string): boolean {
  return new Date() > new Date(scheduledDate);
}

/**
 * Get all mistakes/revisions due for today or overdue
 */
export function getOverdueItems<T extends { nextRevisionAt: string }>(
  items: T[]
): T[] {
  return items.filter((item) => isOverdue(item.nextRevisionAt));
}

/**
 * Get mistakes/revisions due within N days
 */
export function getUpcomingItems<T extends { nextRevisionAt: string }>(
  items: T[],
  daysAhead: number = 7
): T[] {
  const cutoffDate = new Date();
  cutoffDate.setDate(cutoffDate.getDate() + daysAhead);

  return items.filter((item) => {
    const itemDate = new Date(item.nextRevisionAt);
    return itemDate <= cutoffDate && !isOverdue(itemDate);
  });
}
