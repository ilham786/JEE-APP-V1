/**
 * Utility module to calculate and validate JEE examination years dynamically.
 * 
 * JEE Main is typically conducted in Session 1 (Jan/Feb) and Session 2 (April).
 * JEE Advanced is conducted in late May or early June.
 * Therefore, starting from June (month index >= 5 in JavaScript 0-indexed Dates),
 * the current calendar year's JEE examination cycle has concluded.
 * In this case, the earliest upcoming target year is (currentYear + 1).
 */

export function getUpcomingJeeYears(count = 4): number[] {
  const now = new Date();
  const currentYear = now.getFullYear();
  // Month is 0-indexed: 0=Jan, 4=May, 5=June, etc.
  // Past May (June or later), the current year's JEE cycle has passed.
  const hasCurrentYearExamPassed = now.getMonth() >= 5;
  const startYear = hasCurrentYearExamPassed ? currentYear + 1 : currentYear;

  const years: number[] = [];
  for (let i = 0; i < count; i++) {
    years.push(startYear + i);
  }
  return years;
}

export function isPastJeeYear(year: number | string | null | undefined): boolean {
  if (!year) return false;
  const parsed = typeof year === "string" ? parseInt(year.replace(/\D/g, ""), 10) : year;
  if (isNaN(parsed) || parsed <= 0) return false;

  const now = new Date();
  const currentYear = now.getFullYear();
  const hasCurrentYearExamPassed = now.getMonth() >= 5;
  const earliestUpcoming = hasCurrentYearExamPassed ? currentYear + 1 : currentYear;

  return parsed < earliestUpcoming;
}

export interface JeeExamOption {
  value: string;
  label: string;
  year: number;
}

export function getJeeExamOptions(targetYear?: number | string): JeeExamOption[] {
  const years = getUpcomingJeeYears(4);
  const selectedYear = targetYear
    ? typeof targetYear === "string"
      ? parseInt(targetYear.replace(/\D/g, ""), 10) || years[0]
      : targetYear
    : years[0];

  // Primary options based on selected target year
  return [
    {
      value: `JEE Main & Advanced ${selectedYear}`,
      label: `JEE Main & Advanced ${selectedYear}`,
      year: selectedYear,
    },
    {
      value: `JEE Main ${selectedYear}`,
      label: `JEE Main ${selectedYear} (NIT/IIIT Focus)`,
      year: selectedYear,
    },
    {
      value: `JEE Advanced ${selectedYear}`,
      label: `JEE Advanced ${selectedYear} (IIT Focus)`,
      year: selectedYear,
    },
  ];
}

export function getAllUpcomingExamOptions(): JeeExamOption[] {
  const years = getUpcomingJeeYears(4);
  return years.flatMap((year) => [
    {
      value: `JEE Main & Advanced ${year}`,
      label: `JEE Main & Advanced ${year}`,
      year,
    },
  ]);
}
