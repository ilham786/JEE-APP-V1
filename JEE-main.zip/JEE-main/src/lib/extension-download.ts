/**
 * FocusForge Chrome Extension Download Specification
 * Canonical Single Source of Truth for extension package metadata and client-side downloads.
 */

export const EXTENSION_VERSION = "1.2.0";
export const EXTENSION_FILENAME = `FocusForge-Extension-v${EXTENSION_VERSION}.zip`;
export const EXTENSION_FALLBACK_FILENAME = "FocusForge-Extension.zip";
export const EXTENSION_DOWNLOAD_URL = "/api/download-extension";

/**
 * Initiates a download of the verified extension ZIP archive.
 * Gracefully handles browsers, mobile fallbacks, and triggers native download behavior.
 */
export function downloadExtension(filename: string = EXTENSION_FILENAME): void {
  if (typeof window === "undefined") return;

  const downloadUrl = `${EXTENSION_DOWNLOAD_URL}?filename=${encodeURIComponent(filename)}`;
  const link = document.createElement("a");
  link.href = downloadUrl;
  link.download = filename;
  link.rel = "noopener noreferrer";
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
