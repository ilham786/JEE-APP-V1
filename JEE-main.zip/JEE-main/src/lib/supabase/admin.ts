import { createClient } from "@supabase/supabase-js";

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || "https://your-supabase-project.supabase.co";
const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY || "";

/**
 * Privileged server-only Supabase client using Service Role Key.
 * NEVER import or execute this file in client-side code!
 */
export const supabaseAdmin = createClient(
  supabaseUrl,
  serviceRoleKey || "fallback-key-do-not-use-in-production",
  {
    auth: {
      autoRefreshToken: false,
      persistSession: false,
    },
  }
);
