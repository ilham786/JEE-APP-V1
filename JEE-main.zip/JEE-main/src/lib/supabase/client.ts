import { createBrowserClient } from "@supabase/ssr";

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || "https://yhcowzmcvlsmcffbqryb.supabase.co";
const supabaseAnonKey =
  process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY ||
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ||
  "sb_publishable_F20ljth7U20W5cxupHPQiw_btbZuvGk";

/**
 * Singleton Supabase Browser Client for client components and service modules
 */
export const supabase = createBrowserClient(supabaseUrl, supabaseAnonKey);

export function getSupabaseBrowserClient() {
  return supabase;
}

let activeAuthenticatedUid: string | null = null;

export function setActiveUserId(uid: string | null): void {
  activeAuthenticatedUid = uid && isValidUuid(uid) ? uid : null;
  if (typeof window !== "undefined") {
    if (activeAuthenticatedUid) {
      localStorage.setItem("focusforge_active_uid", activeAuthenticatedUid);
    } else {
      localStorage.removeItem("focusforge_active_uid");
    }
  }
}

export function clearActiveUserId(): void {
  activeAuthenticatedUid = null;
  if (typeof window !== "undefined") {
    localStorage.removeItem("focusforge_active_uid");
    localStorage.removeItem("focusforge_guest_uid");
  }
}

export function clearGuestSession(): void {
  if (typeof window !== "undefined") {
    localStorage.removeItem("focusforge_guest_uid");
  }
}

/**
 * Helper to get active user ID from verified authenticated session or explicit guest storage
 */
export function getCurrentUserId(): string | null {
  if (activeAuthenticatedUid && isValidUuid(activeAuthenticatedUid)) {
    return activeAuthenticatedUid;
  }
  if (typeof window === "undefined") return null;

  // 1. Check explicit authenticated user ID in localStorage
  const explicitUid = localStorage.getItem("focusforge_active_uid");
  if (explicitUid && isValidUuid(explicitUid)) {
    activeAuthenticatedUid = explicitUid;
    return explicitUid;
  }

  // 2. Fallback to guest local session if no real account is authenticated
  const guestUid = localStorage.getItem("focusforge_guest_uid");
  if (guestUid) return guestUid;

  return null;
}

export const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Validates whether a given string is a valid Postgres UUID (and not a guest placeholder)
 */
export function isValidUuid(id?: unknown): boolean {
  if (!id || typeof id !== "string") return false;
  if (id === "guest" || id.startsWith("guest_") || id.startsWith("guest")) return false;
  return UUID_REGEX.test(id);
}

/**
 * Returns active user ID ONLY if it is an authenticated, valid UUID.
 * Returns null for guests and unauthenticated sessions to prevent invalid UUID database calls.
 */
export function getAuthenticatedUserId(): string | null {
  const uid = getCurrentUserId();
  return isValidUuid(uid) ? uid : null;
}

