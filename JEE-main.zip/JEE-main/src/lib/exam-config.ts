/**
 * FocusForge — Centralized Exam Configuration Engine
 * 
 * Defines authoritative types, configurations, subjects, dynamic upcoming years,
 * and exam-specific design tokens for both JEE and NEET preparation tracks.
 */

export type ExamType = "JEE" | "NEET";

export type JEESubject = "Physics" | "Chemistry" | "Mathematics";
export type NEETSubject = "Physics" | "Chemistry" | "Botany" | "Zoology";
export type Subject = JEESubject | NEETSubject;

export interface ExamSubjectConfig {
  id: string;
  name: string;
  displayName: string;
  parentCategory?: "Biology";
  color: string;
  icon: string; // Lucide icon identifier
  shortCode: string;
}

export interface ExamConfig {
  id: ExamType;
  name: string;
  displayName: string;
  shortName: string;
  tagline: string;
  targetRankTerm: string;
  defaultGoal: string;
  defaultSyllabusVersion: string;
  subjects: ExamSubjectConfig[];
  hasBiologyDivision: boolean;
  trackerTitle: string;
  syllabusTitle: string;
  weightageTitle: string;
  weightageDisclaimer: string;
  resourceVaultTitle: string;
  resourceVaultSubtitle: string;
  mistakeTypes: string[];
  badgeAccent: string;
  examDateText: string;
}

/**
 * Dynamically computes upcoming exam years based on current date.
 * For calendar year 2026, the 2026 cycles are concluded, so the earliest
 * target year is 2027. Returns [2027, 2028, 2029, 2030].
 */
export function getUpcomingExamYears(count = 4): number[] {
  const now = new Date();
  const currentYear = now.getFullYear();
  // Month is 0-indexed: 0=Jan, 4=May (NEET is early May, JEE Adv is late May)
  // Past May (month >= 5), current year exam has passed.
  const hasCurrentYearExamPassed = now.getMonth() >= 5;
  const startYear = hasCurrentYearExamPassed ? currentYear + 1 : currentYear;

  const years: number[] = [];
  for (let i = 0; i < count; i++) {
    years.push(startYear + i);
  }
  return years;
}

export function isPastExamYear(year: number | string | null | undefined): boolean {
  if (!year) return false;
  const parsed = typeof year === "string" ? parseInt(year.replace(/\D/g, ""), 10) : year;
  if (isNaN(parsed) || parsed <= 0) return false;

  const upcoming = getUpcomingExamYears(4);
  return parsed < upcoming[0];
}

export interface ExamTargetOption {
  value: string;
  label: string;
  year: number;
  examType: ExamType;
}

export function getExamTargetOptions(examType: ExamType, targetYear?: number | string): ExamTargetOption[] {
  const years = getUpcomingExamYears(4);
  const selectedYear = targetYear
    ? typeof targetYear === "string"
      ? parseInt(targetYear.replace(/\D/g, ""), 10) || years[0]
      : targetYear
    : years[0];

  if (examType === "NEET") {
    return [
      {
        value: `NEET UG ${selectedYear}`,
        label: `NEET UG ${selectedYear} (MBBS / BDS Target)`,
        year: selectedYear,
        examType: "NEET",
      },
      {
        value: `NEET UG ${selectedYear} (AIIMS Focus)`,
        label: `NEET UG ${selectedYear} (AIIMS / Top Medical College)`,
        year: selectedYear,
        examType: "NEET",
      },
    ];
  }

  // JEE Options
  return [
    {
      value: `JEE Main & Advanced ${selectedYear}`,
      label: `JEE Main & Advanced ${selectedYear}`,
      year: selectedYear,
      examType: "JEE",
    },
    {
      value: `JEE Main ${selectedYear}`,
      label: `JEE Main ${selectedYear} (NIT / IIIT Focus)`,
      year: selectedYear,
      examType: "JEE",
    },
    {
      value: `JEE Advanced ${selectedYear}`,
      label: `JEE Advanced ${selectedYear} (IIT Focus)`,
      year: selectedYear,
      examType: "JEE",
    },
  ];
}

export const EXAM_CONFIG: Record<ExamType, ExamConfig> = {
  JEE: {
    id: "JEE",
    name: "JEE",
    displayName: "IIT-JEE Main & Advanced",
    shortName: "JEE",
    tagline: "The Study Operating System for IIT-JEE Main & Advanced Aspirants",
    targetRankTerm: "AIR 1 / Top 100 IIT",
    defaultGoal: "6 Hours Daily",
    defaultSyllabusVersion: "JEE-2027",
    subjects: [
      { id: "Physics", name: "Physics", displayName: "Physics", color: "#06B6D4", icon: "Atom", shortCode: "PHY" },
      { id: "Chemistry", name: "Chemistry", displayName: "Chemistry", color: "#10B981", icon: "FlaskConical", shortCode: "CHEM" },
      { id: "Maths", name: "Mathematics", displayName: "Mathematics", color: "#F59E0B", icon: "Calculator", shortCode: "MATH" },
    ],
    hasBiologyDivision: false,
    trackerTitle: "JEE Tracker",
    syllabusTitle: "JEE Main & Advanced Syllabus",
    weightageTitle: "JEE Chapter Weightage & Trends",
    weightageDisclaimer: "Historical question trend analysis based on past JEE Main & Advanced papers.",
    resourceVaultTitle: "Formula Vault",
    resourceVaultSubtitle: "High-yield equations, derivations, and mathematical shortcuts",
    mistakeTypes: [
      "Calculation Error",
      "Conceptual Gap",
      "Silly Mistake",
      "Time Pressure",
      "Question Reading",
      "Formula Forgotten",
    ],
    badgeAccent: "text-purple-400 bg-purple-500/10 border-purple-500/20",
    examDateText: "Exam Date: TBA",
  },
  NEET: {
    id: "NEET",
    name: "NEET",
    displayName: "NEET UG (Medical Entrance)",
    shortName: "NEET",
    tagline: "The High-Yield Study Operating System for NEET UG Aspirants",
    targetRankTerm: "720/720 / Top AIIMS",
    defaultGoal: "7 Hours Daily",
    defaultSyllabusVersion: "NEET-UG-2026-NMC",
    subjects: [
      { id: "Physics", name: "Physics", displayName: "Physics", color: "#06B6D4", icon: "Atom", shortCode: "PHY" },
      { id: "Chemistry", name: "Chemistry", displayName: "Chemistry", color: "#10B981", icon: "FlaskConical", shortCode: "CHEM" },
      { id: "Botany", name: "Botany", displayName: "Botany", parentCategory: "Biology", color: "#22C55E", icon: "Leaf", shortCode: "BOT" },
      { id: "Zoology", name: "Zoology", displayName: "Zoology", parentCategory: "Biology", color: "#8B5CF6", icon: "Dna", shortCode: "ZOO" },
    ],
    hasBiologyDivision: true,
    trackerTitle: "NEET Tracker",
    syllabusTitle: "NEET UG Official Syllabus (NMC/NTA)",
    weightageTitle: "NEET Chapter Weightage & Historical Trends",
    weightageDisclaimer: "Historical Trend (2019–2025 PYQ Analysis). NTA does not publish an official chapter-wise weightage schedule.",
    resourceVaultTitle: "NCERT Fact & Vault",
    resourceVaultSubtitle: "NCERT lines, definitions, diagrams, reactions, and exceptions",
    mistakeTypes: [
      "Conceptual Gap",
      "NCERT Fact / Recall",
      "Calculation Error",
      "Reaction / Reagent",
      "Diagram / Labeling",
      "Statement / Assertion-Reason",
      "Careless Error",
      "Time Pressure",
    ],
    badgeAccent: "text-emerald-400 bg-emerald-500/10 border-emerald-500/20",
    examDateText: "Exam Date: TBA",
  },
};

export function getExamConfig(examType?: string | null): ExamConfig {
  if (examType === "NEET") return EXAM_CONFIG.NEET;
  return EXAM_CONFIG.JEE;
}

export function detectExamTypeFromTarget(targetExam?: string | null): ExamType {
  if (!targetExam) return "JEE";
  const upper = targetExam.toUpperCase();
  if (upper.includes("NEET") || upper.includes("MBBS") || upper.includes("AIIMS") || upper.includes("MEDICAL")) {
    return "NEET";
  }
  return "JEE";
}
