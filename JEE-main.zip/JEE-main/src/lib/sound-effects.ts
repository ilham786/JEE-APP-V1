"use client";

import confetti from "canvas-confetti";
import { soundManager } from "@/lib/sound-manager";

/**
 * Prime audio context on any user interaction to comply with browser autoplay policies.
 */
export function initAudioOnUserGesture() {
  soundManager.unlock().catch(() => {});
}

/**
 * Play semantic focus session start cue ('start').
 */
export function playTimerStartSound(_volume?: number) {
  soundManager.play("start");
}

/**
 * Play a polite warning cue when 30 seconds remain ('warning').
 */
export function playWarning30sSound(_volume?: number) {
  soundManager.play("warning");
}

/**
 * Play countdown checkpoint ping ('checkpoint').
 */
export function playCountdown5sSound(_secondNumber: number = 5, _volume?: number) {
  soundManager.playThrottled("checkpoint", 180);
}

/**
 * Play triumphant completion sound ('complete').
 */
export function playTimerCompleteSound(_volume?: number) {
  soundManager.play("complete");
}

/**
 * Triggers a celebratory confetti explosion and reward sound.
 */
export function triggerConfetti() {
  if (typeof window === "undefined" || typeof document === "undefined") return;
  try {
    soundManager.play("reward");
    confetti({
      particleCount: 160,
      spread: 80,
      origin: { y: 0.6 },
      colors: ["#8b5cf6", "#3b82f6", "#10b981", "#f59e0b", "#ec4899"],
    });
  } catch (e) {
    console.warn("Failed to trigger confetti:", e);
  }
}

/**
 * Play semantic error alert ('error').
 */
export function playErrorSound(_volume?: number) {
  soundManager.play("error");
}

