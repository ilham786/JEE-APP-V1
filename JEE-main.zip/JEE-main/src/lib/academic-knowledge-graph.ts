/**
 * FocusForge Academic Intelligence Engine — Knowledge Graph
 * 
 * Version: 2026.1
 * Curricula:
 *   - JEE Main & JEE Advanced (Physics, Chemistry, Mathematics)
 *   - NEET UG (Physics, Chemistry, Biology)
 *   - CBSE Class 12 (Physics, Chemistry, Mathematics, Biology, English Core)
 *   - NCERT Canonical Textbook Structure
 */

export const TAXONOMY_VERSION = "2026.2";
export const CLASSIFIER_VERSION = "v3.0-focusforge-guard";

export type AcademicSubject = "Physics" | "Chemistry" | "Mathematics" | "Biology" | "English" | "General Academic";

export type TargetExam = "JEE Main" | "JEE Advanced" | "NEET" | "CBSE Class 12" | "CBSE Boards" | "NCERT";

export interface AcademicSubtopicNode {
  name: string;
  aliases: string[];
  keywords: string[];
}

export interface AcademicTopicNode {
  id: string;
  name: string;
  aliases: string[];
  keywords: string[];
  subtopics: AcademicSubtopicNode[];
}

export interface AcademicChapterNode {
  id: string;
  name: string;
  aliases: string[];
  unit: string;
  classLevel: "Class 11" | "Class 12";
  exams: TargetExam[];
  ncertChapterNumber?: number;
  topics: AcademicTopicNode[];
}

export interface AcademicSubjectGraph {
  subject: AcademicSubject;
  chapters: AcademicChapterNode[];
}

// ====================================================================
// 1. PHYSICS KNOWLEDGE GRAPH (JEE Main/Adv, NEET, CBSE 11 & 12)
// ====================================================================

const PHYSICS_CHAPTERS: AcademicChapterNode[] = [
  // Class 11
  {
    id: "phy-units-measurement",
    name: "Units and Measurements",
    aliases: ["units and dimensions", "dimensional analysis", "errors in measurement", "significant figures", "vernier calipers", "screw gauge"],
    unit: "Mechanics",
    classLevel: "Class 11",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 1,
    topics: [
      {
        id: "phy-dim-analysis",
        name: "Dimensional Analysis",
        aliases: ["dimensions", "dimensional formula", "principle of homogeneity"],
        keywords: ["dimensions of physical quantities", "dimensional equation", "checking correctness of equations", "deriving formula by dimensions"],
        subtopics: [
          { name: "Principle of Homogeneity", aliases: ["homogeneity of dimensions"], keywords: ["homogeneity", "powers of fundamental units"] },
          { name: "Error Propagation", aliases: ["percentage error", "relative error", "absolute error"], keywords: ["propagation of errors", "least count", "screw gauge reading", "vernier caliper reading"] },
        ],
      },
    ],
  },
  {
    id: "phy-vectors",
    name: "Vectors",
    aliases: ["vector algebra in physics", "vector mathematics", "scalar and vector quantities", "resolution of vectors"],
    unit: "Mechanics",
    classLevel: "Class 11",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Boards"],
    topics: [
      {
        id: "phy-vec-ops",
        name: "Vector Operations",
        aliases: ["dot product", "cross product", "scalar product", "unit vector", "triangle law of vectors", "parallelogram law"],
        keywords: ["dot product", "cross product", "unit vector", "orthogonal vectors", "resultant vector", "direction cosines in physics"],
        subtopics: [
          { name: "Dot and Cross Product", aliases: ["scalar and vector products"], keywords: ["a dot b", "a cross b", "angle between vectors"] },
        ],
      },
    ],
  },
  {
    id: "phy-kinematics-1d-2d",
    name: "Kinematics",
    aliases: ["motion in a straight line", "motion in a plane", "projectile motion", "rectilinear motion", "relative motion"],
    unit: "Mechanics",
    classLevel: "Class 11",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 2,
    topics: [
      {
        id: "phy-rectilinear",
        name: "Motion in a Straight Line",
        aliases: ["1D motion", "equations of motion", "velocity time graph", "acceleration time graph"],
        keywords: ["equations of motion", "v = u + at", "s = ut + half at squared", "displacement time graph", "instantaneous velocity", "motion under gravity"],
        subtopics: [
          { name: "Uniformly Accelerated Motion", aliases: ["motion under gravity"], keywords: ["free fall", "stopping distance", "reaction time"] },
          { name: "Graphs of Kinematics", aliases: ["x-t graph", "v-t graph", "a-t graph"], keywords: ["slope of velocity time graph", "area under v-t graph"] },
        ],
      },
      {
        id: "phy-projectile",
        name: "Motion in a Plane & Projectile Motion",
        aliases: ["2D motion", "projectile on inclined plane", "horizontal projectile", "relative velocity in 2D", "river boat problem", "rain man problem"],
        keywords: ["time of flight", "maximum height", "horizontal range", "equation of trajectory", "relative velocity in 2d", "river swimmer", "rain umbrella problem"],
        subtopics: [
          { name: "Ground to Ground Projectile", aliases: ["oblique projectile"], keywords: ["range of projectile", "maximum height of projectile", "trajectory equation"] },
          { name: "Relative Motion in 2D", aliases: ["river boat", "rain man", "shortest path"], keywords: ["river boat problem", "rain problem", "relative acceleration"] },
        ],
      },
    ],
  },
  {
    id: "phy-laws-of-motion",
    name: "Laws of Motion",
    aliases: ["nlm", "newton laws of motion", "friction", "circular motion dynamics", "pseudo force", "pulley problems", "wedge constraint"],
    unit: "Mechanics",
    classLevel: "Class 11",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 4,
    topics: [
      {
        id: "phy-nlm-principles",
        name: "Newton's Laws & Constraint Motion",
        aliases: ["free body diagram", "fbd", "newton's second law", "pseudo force", "inertial frame", "non inertial frame", "pulley system"],
        keywords: ["free body diagram", "fbd", "normal reaction", "tension in string", "pulley block system", "pseudo force in accelerated frame", "wedge constraints"],
        subtopics: [
          { name: "Free Body Diagram Analysis", aliases: ["fbd solving"], keywords: ["normal force", "string tension", "pulley problem", "accelerated frame"] },
          { name: "Friction", aliases: ["static friction", "kinetic friction", "angle of repose", "coefficient of friction"], keywords: ["limiting friction", "two block problem", "angle of friction", "banking of road"] },
          { name: "Circular Motion Dynamics", aliases: ["centripetal force", "centrifugal force", "vertical circular motion"], keywords: ["centripetal acceleration", "conical pendulum", "loop the loop", "tension at top and bottom"] },
        ],
      },
    ],
  },
  {
    id: "phy-work-energy-power",
    name: "Work, Energy and Power",
    aliases: ["wep", "work energy theorem", "conservation of mechanical energy", "potential energy curves", "conservative forces", "work and power", "work energy and power", "collisions in physics"],
    unit: "Mechanics",
    classLevel: "Class 11",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 5,
    topics: [
      {
        id: "phy-wep-theorems",
        name: "Work Energy Theorem and Conservation",
        aliases: ["work done by variable force", "kinetic energy", "spring potential energy", "work energy theorem"],
        keywords: ["work done by spring", "work energy theorem", "conservative force", "potential energy function", "equilibrium types stable unstable"],
        subtopics: [
          { name: "Work-Energy Theorem", aliases: ["w = delta ke"], keywords: ["work done by friction", "work done by gravity", "net work equals change in ke"] },
          { name: "Power and Mechanical Advantage", aliases: ["instantaneous power", "f dot v"], keywords: ["power delivered", "average power", "efficiency"] },
          { name: "Collisions in 1D and 2D", aliases: ["elastic collision", "inelastic collision", "coefficient of restitution"], keywords: ["coefficient of restitution e", "conservation of linear momentum", "oblique collision"] },
        ],
      },
    ],
  },
  {
    id: "phy-rotation",
    name: "Rotational Motion",
    aliases: ["rotational dynamics", "rotation", "rigid body dynamics", "rbd", "moment of inertia", "moi", "torque and angular momentum", "rolling motion"],
    unit: "Mechanics",
    classLevel: "Class 11",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 6,
    topics: [
      {
        id: "phy-rot-moi",
        name: "Moment of Inertia and Theorems",
        aliases: ["parallel axis theorem", "perpendicular axis theorem", "radius of gyration", "moment of inertia of disc ring rod cylinder sphere"],
        keywords: ["moment of inertia", "parallel axis theorem", "perpendicular axis theorem", "radius of gyration", "moi of sphere", "moi of cylinder"],
        subtopics: [
          { name: "Calculation of Moment of Inertia", aliases: ["moi integration"], keywords: ["moi of uniform rod", "moi of ring", "moi of disc", "moi of hollow and solid sphere"] },
        ],
      },
      {
        id: "phy-rot-dynamics",
        name: "Torque, Angular Momentum & Rolling",
        aliases: ["torque about a point", "angular momentum conservation", "pure rolling", "rolling without slipping", "rolling on inclined plane", "toppling"],
        keywords: ["torque equals i alpha", "conservation of angular momentum", "pure rolling condition v = r omega", "kinetic energy of rolling body", "angular impulse", "toppling condition"],
        subtopics: [
          { name: "Conservation of Angular Momentum", aliases: ["l = i omega conservation"], keywords: ["aerialist spin", "angular momentum about axis", "external torque zero"] },
          { name: "Pure Rolling on Inclined Plane", aliases: ["rolling dynamics"], keywords: ["acceleration in pure rolling", "friction in rolling", "rolling without slipping"] },
        ],
      },
    ],
  },
  {
    id: "phy-gravitation",
    name: "Gravitation",
    aliases: ["universal law of gravitation", "gravitational field", "gravitational potential", "escape velocity", "orbital velocity", "kepler laws"],
    unit: "Mechanics",
    classLevel: "Class 11",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 7,
    topics: [
      {
        id: "phy-grav-field",
        name: "Gravitational Fields, Potential & Satellites",
        aliases: ["acceleration due to gravity with depth and height", "gravitational potential energy", "escape speed", "geostationary satellite"],
        keywords: ["kepler third law", "variation of g with altitude", "variation of g with depth", "escape velocity root 2gr", "orbital speed", "time period of satellite"],
        subtopics: [
          { name: "Gravitational Potential & Escape Velocity", aliases: ["escape speed"], keywords: ["escape velocity from earth", "binding energy of satellite", "potential of solid sphere"] },
        ],
      },
    ],
  },
  {
    id: "phy-fluids-solids",
    name: "Mechanical Properties of Solids and Fluids",
    aliases: ["elasticity", "viscosity", "fluid mechanics", "bernoulli theorem", "surface tension", "capillarity", "stokes law", "terminal velocity"],
    unit: "Properties of Matter",
    classLevel: "Class 11",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Boards", "NCERT"],
    topics: [
      {
        id: "phy-elasticity",
        name: "Elasticity & Hooke's Law",
        aliases: ["young's modulus", "bulk modulus", "modulus of rigidity", "stress strain curve", "poisson ratio"],
        keywords: ["stress strain graph", "young modulus", "elastic potential energy in stretched wire", "bulk modulus", "hooke law"],
        subtopics: [{ name: "Stress-Strain Behavior", aliases: ["elastic limit"], keywords: ["yield point", "tensile stress", "wire elongation"] }],
      },
      {
        id: "phy-fluids",
        name: "Fluid Dynamics & Surface Tension",
        aliases: ["bernoulli equation", "equation of continuity", "torricelli law", "venturi meter", "excess pressure in bubble", "capillary rise"],
        keywords: ["bernoulli theorem", "equation of continuity", "terminal velocity stokes law", "excess pressure in soap bubble", "surface energy", "angle of contact"],
        subtopics: [
          { name: "Bernoulli's Principle", aliases: ["conservation of fluid energy"], keywords: ["venturimeter", "torricelli theorem", "dynamic lift"] },
          { name: "Surface Tension and Capillarity", aliases: ["surface energy"], keywords: ["capillary ascent formula", "excess pressure drop bubble", "surface tension calculation"] },
        ],
      },
    ],
  },
  {
    id: "phy-thermal-thermo",
    name: "Thermal Physics & Thermodynamics",
    aliases: ["calorimetry", "thermal expansion", "heat transfer", "first law of thermodynamics", "second law of thermodynamics", "carnot engine", "ktg", "kinetic theory of gases"],
    unit: "Thermodynamics",
    classLevel: "Class 11",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Boards", "NCERT"],
    topics: [
      {
        id: "phy-thermodynamics-laws",
        name: "Laws of Thermodynamics & Heat Engines",
        aliases: ["isothermal process", "adiabatic process", "isobaric process", "isochoric process", "carnot cycle", "efficiency of heat engine", "molar heat capacity"],
        keywords: ["first law of thermodynamics delta q = delta u + w", "work done in adiabatic process", "work done in isothermal process", "pv diagram", "carnot engine efficiency", "cp minus cv equals r"],
        subtopics: [
          { name: "Thermodynamic Processes", aliases: ["pv indicator diagram"], keywords: ["adiabatic expansion", "isothermal compression", "cyclic process work done"] },
          { name: "Kinetic Theory of Gases (KTG)", aliases: ["rms speed", "degrees of freedom"], keywords: ["vrms formula", "mean free path", "equipartition of energy", "maxwell distribution"] },
        ],
      },
    ],
  },
  {
    id: "phy-shm-waves",
    name: "Oscillations and Waves",
    aliases: ["shm", "simple harmonic motion", "spring mass system", "simple pendulum", "wave motion", "standing waves", "organ pipe", "doppler effect", "beats"],
    unit: "Oscillations & Waves",
    classLevel: "Class 11",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Boards", "NCERT"],
    topics: [
      {
        id: "phy-shm",
        name: "Simple Harmonic Motion",
        aliases: ["equation of shm", "phase difference in shm", "energy of shm", "spring combination", "time period of pendulum"],
        keywords: ["time period of simple pendulum", "spring mass time period", "kinetic and potential energy in shm", "angular frequency omega", "acceleration in shm -omega^2 x"],
        subtopics: [{ name: "Kinematics & Dynamics of SHM", aliases: ["phase in shm"], keywords: ["displacement velocity acceleration in shm", "amplitude phase constant"] }],
      },
      {
        id: "phy-wave-optics-sound",
        name: "Sound Waves & Doppler Effect",
        aliases: ["speed of sound in gases", "standing waves in strings", "closed and open organ pipes", "resonance tube", "beats frequency", "doppler shift"],
        keywords: ["speed of sound newton laplace", "standing wave nodes antinodes", "fundamental frequency organ pipe", "beat frequency f1 minus f2", "doppler effect for sound"],
        subtopics: [
          { name: "Organ Pipes & Resonance", aliases: ["standing sound waves"], keywords: ["closed organ pipe harmonics", "open organ pipe harmonics", "end correction"] },
          { name: "Doppler Effect", aliases: ["doppler frequency shift"], keywords: ["apparent frequency when source moves", "observer moving towards source"] },
        ],
      },
    ],
  },

  // Class 12 (Official CBSE 2026-27 Structure)
  {
    id: "phy-electrostatics-1",
    name: "Electric Charges and Fields",
    aliases: ["electrostatics chapter 1", "coulomb's law", "electric field intensity", "electric flux", "gauss law", "electric dipole"],
    unit: "Electrostatics",
    classLevel: "Class 12",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 1,
    topics: [
      {
        id: "phy-coulomb-gauss",
        name: "Coulomb's Law and Gauss's Law",
        aliases: ["coulomb law in vector form", "superposition principle in electrostatics", "electric field of continuous charge distribution", "gauss theorem applications"],
        keywords: ["coulomb law", "electric field due to point charge", "electric flux integral e dot da", "gauss law application infinite wire", "electric field of infinite plane sheet", "field of spherical shell"],
        subtopics: [
          { name: "Gauss's Law Applications", aliases: ["flux through closed surface"], keywords: ["gauss theorem", "field of uniformly charged thin spherical shell", "infinite line charge field"] },
          { name: "Electric Dipole", aliases: ["dipole in uniform field"], keywords: ["dipole moment p = q(2a)", "axial and equatorial electric field of dipole", "torque on dipole tau = p cross e"] },
        ],
      },
    ],
  },
  {
    id: "phy-electrostatics-2",
    name: "Electrostatic Potential and Capacitance",
    aliases: ["electrostatics chapter 2", "electric potential", "potential difference", "equipotential surfaces", "capacitance", "parallel plate capacitor", "dielectrics", "combination of capacitors"],
    unit: "Electrostatics",
    classLevel: "Class 12",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 2,
    topics: [
      {
        id: "phy-pot-cap",
        name: "Electric Potential and Capacitors",
        aliases: ["potential due to point charge", "potential energy of system of charges", "capacitance of parallel plate capacitor with dielectric", "energy stored in capacitor"],
        keywords: ["electric potential v", "relation between field and potential e = -dv/dr", "equipotential surface properties", "parallel plate capacitor formula c = epsilon0 a / d", "dielectric constant effect", "energy stored half cv squared", "combination of capacitors in series and parallel"],
        subtopics: [
          { name: "Equipotential Surfaces & Potential Energy", aliases: ["potential gradient"], keywords: ["equipotential surfaces", "work done on charge in field", "electrostatic potential energy"] },
          { name: "Parallel Plate Capacitors & Dielectrics", aliases: ["dielectric insertion"], keywords: ["capacitance with dielectric slab", "energy density in electric field", "sharing of charge between capacitors"] },
        ],
      },
    ],
  },
  {
    id: "phy-current-electricity",
    name: "Current Electricity",
    aliases: ["ohm's law", "drift velocity", "kirchhoff laws", "wheatstone bridge", "meter bridge", "potentiometer", "internal resistance", "cells in series and parallel"],
    unit: "Current Electricity",
    classLevel: "Class 12",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 3,
    topics: [
      {
        id: "phy-curr-circuits",
        name: "Ohm's Law, Drift Velocity & Circuit Analysis",
        aliases: ["drift velocity formula", "resistivity and conductivity", "temperature coefficient of resistance", "kirchhoff current law", "kirchhoff voltage law", "wheatstone bridge condition"],
        keywords: ["drift velocity v_d = eE tau / m", "relation between current and drift velocity i = neav_d", "kirchhoff first and second law", "wheatstone bridge balanced condition p/q = r/s", "meter bridge experiment", "potentiometer comparison of emf", "terminal potential difference of cell"],
        subtopics: [
          { name: "Drift Velocity and Ohm's Law Derivation", aliases: ["relaxation time"], keywords: ["drift velocity", "mobility of charge carriers", "vector form of ohm law j = sigma e"] },
          { name: "Kirchhoff's Laws and Bridge Circuits", aliases: ["kcl and kvl"], keywords: ["loop rule", "junction rule", "solving complex circuit with kirchhoff laws", "wheatstone bridge"] },
        ],
      },
    ],
  },
  {
    id: "phy-moving-charges-magnetism",
    name: "Moving Charges and Magnetism",
    aliases: ["biot savart law", "ampere circuital law", "lorentz magnetic force", "magnetic field of circular coil", "solenoid and toroid", "moving coil galvanometer", "cyclotron"],
    unit: "Magnetic Effects of Current",
    classLevel: "Class 12",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 4,
    topics: [
      {
        id: "phy-mag-fields",
        name: "Biot-Savart Law and Ampere's Law",
        aliases: ["field of straight wire", "field on axis of circular loop", "force on current carrying conductor in magnetic field", "force between two parallel currents", "conversion of galvanometer to ammeter voltmeter"],
        keywords: ["biot savart law formula", "ampere circuital law integral b dot dl", "magnetic field inside long solenoid", "lorentz force f = q(v cross b)", "radius of circular orbit in magnetic field r = mv/qb", "force between parallel wires", "galvanometer to ammeter shunt resistance", "galvanometer to voltmeter series resistance"],
        subtopics: [
          { name: "Biot-Savart and Ampere's Law Applications", aliases: ["magnetic field calculations"], keywords: ["magnetic field at center of circular coil", "field on axis of current loop", "ampere law applications"] },
          { name: "Magnetic Force and Galvanometer", aliases: ["moving coil galvanometer"], keywords: ["torque on rectangular loop tau = niab sin theta", "current sensitivity", "voltage sensitivity of galvanometer"] },
        ],
      },
    ],
  },
  {
    id: "phy-magnetism-matter",
    name: "Magnetism and Matter",
    aliases: ["bar magnet as equivalent solenoid", "earth magnetic field components", "angle of dip", "magnetic declination", "diamagnetic paramagnetic ferromagnetic", "hysteresis loop", "curie law"],
    unit: "Magnetic Effects of Current",
    classLevel: "Class 12",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 5,
    topics: [
      {
        id: "phy-mag-materials",
        name: "Magnetic Properties and Earth Magnetism",
        aliases: ["magnetic dipole moment of bar magnet", "elements of earth's magnetic field", "magnetic susceptibility", "permeability", "ferromagnetism and domain theory"],
        keywords: ["magnetic dipole moment m", "earth magnetic field horizontal component bh", "angle of dip delta", "diamagnetism susceptibility negative", "paramagnetism curie law", "ferromagnetism hysteresis curve", "retentivity and coercivity"],
        subtopics: [{ name: "Classification of Magnetic Materials", aliases: ["dia para ferro"], keywords: ["curie temperature", "relative magnetic permeability", "properties of ferromagnetic substances"] }],
      },
    ],
  },
  {
    id: "phy-emi",
    name: "Electromagnetic Induction",
    aliases: ["emi", "faraday's laws of induction", "lenz's law", "induced emf", "motional emf", "eddy currents", "self induction", "mutual induction"],
    unit: "Electromagnetic Induction & AC",
    classLevel: "Class 12",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 6,
    topics: [
      {
        id: "phy-emi-laws",
        name: "Faraday's Laws, Lenz's Law & Inductance",
        aliases: ["induced electric field", "motional emf blv", "self inductance of solenoid", "mutual inductance of co-axial solenoids", "energy stored in inductor"],
        keywords: ["magnetic flux phi = b dot a", "faraday law e = -dphi/dt", "lenz law direction of induced current", "motional emf e = bvl", "self inductance l", "mutual inductance m", "energy stored half l i squared"],
        subtopics: [
          { name: "Faraday & Lenz Law Dynamics", aliases: ["induced emf problems"], keywords: ["motional emf in rotating rod", "eddy currents applications", "lenz law conservation of energy"] },
          { name: "Inductors in Circuits", aliases: ["rl circuit transient"], keywords: ["self inductance formula", "growth and decay of current in rl circuit", "coefficient of coupling"] },
        ],
      },
    ],
  },
  {
    id: "phy-ac",
    name: "Alternating Current",
    aliases: ["ac", "ac circuits", "rms value of current", "peak value", "lcr series circuit", "resonance in lcr", "quality factor", "power in ac circuit", "wattless current", "transformer", "ac generator"],
    unit: "Electromagnetic Induction & AC",
    classLevel: "Class 12",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 7,
    topics: [
      {
        id: "phy-lcr-circuits",
        name: "LCR Series Circuit & Power in AC",
        aliases: ["phasor diagram", "inductive reactance xl", "capacitive reactance xc", "impedance z", "resonance frequency 1/2pi root lc", "power factor cos phi", "step up step down transformer"],
        keywords: ["rms current i0/root 2", "inductive reactance xl = omega l", "capacitive reactance xc = 1/omega c", "impedance z = root r^2 + (xl-xc)^2", "resonant frequency in series lcr", "q factor of resonance", "power in ac circuit vrms irms cos phi", "transformer turns ratio vs/vp = ns/np"],
        subtopics: [
          { name: "Resonance in Series LCR", aliases: ["q factor sharpness"], keywords: ["series resonance condition xl = xc", "bandwidth and quality factor", "phasor analysis of ac"] },
          { name: "Transformers and Generators", aliases: ["transformer efficiency"], keywords: ["step up transformer", "step down transformer", "losses in transformer", "ac dynamo working"] },
        ],
      },
    ],
  },
  {
    id: "phy-em-waves",
    name: "Electromagnetic Waves",
    aliases: ["em waves", "displacement current", "maxwell equations in optics", "electromagnetic spectrum", "properties of em waves", "speed of light c = 1/root mu0 eps0"],
    unit: "Electromagnetic Waves",
    classLevel: "Class 12",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 8,
    topics: [
      {
        id: "phy-em-spec",
        name: "Displacement Current & EM Spectrum",
        aliases: ["maxwell displacement current", "transverse nature of em waves", "energy density of em wave", "radio waves microwaves infrared visible ultraviolet x rays gamma rays"],
        keywords: ["displacement current id = eps0 dphi_e/dt", "speed of em wave formula", "relation between electric and magnetic field amplitudes e0/b0 = c", "uses of em spectrum frequencies", "wavelength ranges of gamma x rays uv infrared"],
        subtopics: [{ name: "EM Spectrum and Applications", aliases: ["wavelength frequency table"], keywords: ["microwaves radar", "infrared night vision", "ultraviolet sterilisation", "x-rays medical imaging"] }],
      },
    ],
  },
  {
    id: "phy-ray-optics",
    name: "Ray Optics and Optical Instruments",
    aliases: ["geometrical optics", "ray optics", "reflection at spherical mirrors", "refraction at spherical surfaces", "lens maker's formula", "thin lens formula", "combination of thin lenses", "prism formula", "total internal reflection", "tir", "compound microscope", "astronomical telescope"],
    unit: "Optics",
    classLevel: "Class 12",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 9,
    topics: [
      {
        id: "phy-lenses-mirrors",
        name: "Refraction, Lenses and Prisms",
        aliases: ["snell's law", "critical angle", "optical fibre", "lens maker equation 1/f = (mu-1)(1/r1 - 1/r2)", "refraction through a prism angle of minimum deviation", "dispersion without deviation"],
        keywords: ["total internal reflection conditions", "lens maker formula", "refraction at single spherical surface mu2/v - mu1/u = (mu2-mu1)/r", "prism formula mu = sin(a+dm/2)/sin(a/2)", "power of lens p = 1/f", "combination of lenses in contact"],
        subtopics: [
          { name: "Total Internal Reflection & Prisms", aliases: ["tir and prism dispersion"], keywords: ["critical angle formula sin c = 1/mu", "dispersion of light by prism", "minimum deviation curve"] },
          { name: "Optical Instruments", aliases: ["microscope and telescope magnification"], keywords: ["magnifying power of simple microscope", "compound microscope tube length", "astronomical telescope normal adjustment"] },
        ],
      },
    ],
  },
  {
    id: "phy-wave-optics",
    name: "Wave Optics",
    aliases: ["wave optics", "huygens principle", "interference of light", "young's double slit experiment", "ydse", "fringe width", "coherent sources", "diffraction of light", "single slit diffraction", "resolving power", "polarisation of light", "brewster's law", "malus law"],
    unit: "Optics",
    classLevel: "Class 12",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 10,
    topics: [
      {
        id: "phy-ydse-diffraction",
        name: "Interference (YDSE) and Diffraction",
        aliases: ["conditions for constructive and destructive interference", "ydse path difference", "fringe width beta = lambda d / d", "diffraction central maxima width", "polarising angle tan ip = mu"],
        keywords: ["huygens wavefront secondary wavelets", "ydse intensity formula i = 4i0 cos^2(delta/2)", "fringe width derivation", "shift in fringes due to thin transparent sheet", "single slit diffraction minima condition a sin theta = n lambda", "brewster law", "malus law i = i0 cos^2 theta"],
        subtopics: [
          { name: "Young's Double Slit Experiment (YDSE)", aliases: ["ydse derivation problems"], keywords: ["path difference in ydse", "bright fringe position", "dark fringe position", "fringe width formula"] },
          { name: "Diffraction & Polarization", aliases: ["single slit diffraction"], keywords: ["angular width of central maximum", "difference between interference and diffraction", "polarisation by reflection"] },
        ],
      },
    ],
  },
  {
    id: "phy-dual-nature",
    name: "Dual Nature of Radiation and Matter",
    aliases: ["modern physics", "photoelectric effect", "work function", "threshold frequency", "einstein's photoelectric equation", "stopping potential", "de broglie wavelength", "matter waves", "davisson germer experiment"],
    unit: "Modern Physics",
    classLevel: "Class 12",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 11,
    topics: [
      {
        id: "phy-photoelectric",
        name: "Photoelectric Effect and Matter Waves",
        aliases: ["einstein photoelectric equation hv = phi + kmax", "stopping potential graph with frequency", "de broglie wavelength lambda = h/p = h/root(2mE)", "wavelength of electron"],
        keywords: ["photoelectric emission laws", "work function phi0", "threshold frequency nu0", "stopping potential v0", "einstein equation derivation", "de broglie relation for accelerated charge lambda = 12.27/root(v) angstrom"],
        subtopics: [
          { name: "Photoelectric Effect Graphs", aliases: ["stopping potential vs frequency"], keywords: ["slope gives h/e", "intercept on potential axis", "effect of intensity and frequency on photocurrent"] },
        ],
      },
    ],
  },
  {
    id: "phy-atoms-nuclei",
    name: "Atoms and Nuclei",
    aliases: ["modern physics atoms nuclei", "rutherford model", "bohr's model of hydrogen atom", "bohr radius", "energy levels of hydrogen", "spectral series lyman balmer paschen brackett pfund", "mass defect", "binding energy per nucleon", "nuclear fission", "nuclear fusion", "radioactivity"],
    unit: "Modern Physics",
    classLevel: "Class 12",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 12,
    topics: [
      {
        id: "phy-bohr-model",
        name: "Bohr Model and Hydrogen Spectra",
        aliases: ["radius of nth bohr orbit rn proportional to n^2/z", "velocity of electron in nth orbit", "energy of electron en = -13.6 z^2/n^2 ev", "rydberg formula 1/lambda = r(1/n1^2 - 1/n2^2)"],
        keywords: ["bohr postulates angular momentum mvr = nh/2pi", "radius of bohr orbit derivation", "total energy of electron in hydrogen", "lyman series ultraviolet", "balmer series visible region", "paschen series infrared", "rydberg constant"],
        subtopics: [{ name: "Hydrogen Spectrum Lines", aliases: ["series limit"], keywords: ["shortest wavelength in balmer", "longest wavelength in lyman", "excitation energy ionisation potential"] }],
      },
      {
        id: "phy-nuclear-physics",
        name: "Nuclei, Binding Energy and Reactions",
        aliases: ["size of nucleus r = r0 a^(1/3)", "mass defect delta m", "binding energy curve per nucleon", "nuclear fission in reactor", "nuclear fusion in stars", "half life and decay constant in physics"],
        keywords: ["nuclear density independent of mass number", "mass defect delta m = (z mp + (a-z) mn) - m_nucleus", "einstein mass energy relation e = mc^2", "binding energy per nucleon peak at fe-56", "q value of nuclear reaction"],
        subtopics: [{ name: "Nuclear Binding Energy Curve", aliases: ["be/a stability"], keywords: ["stability of nucleus", "energy release in fission and fusion", "liquid drop model"] }],
      },
    ],
  },
  {
    id: "phy-semiconductors",
    name: "Semiconductor Electronics: Materials, Devices and Simple Circuits",
    aliases: ["semiconductor devices", "p-n junction diode", "forward and reverse bias", "i-v characteristics of diode", "diode as rectifier half wave full wave", "zener diode as voltage regulator", "logic gates and or not nand nor"],
    unit: "Electronic Devices",
    classLevel: "Class 12",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 14,
    topics: [
      {
        id: "phy-pn-junction-gates",
        name: "P-N Junction, Rectifiers & Logic Gates",
        aliases: ["intrinsic and extrinsic semiconductors", "n-type and p-type dopants", "depletion layer and barrier potential", "half wave and full wave rectifier with filter", "truth table of logic gates", "demorgan's laws in physics"],
        keywords: ["intrinsic carrier concentration", "energy band gap metals conductors insulators", "p-n junction forward and reverse bias characteristics", "full wave bridge rectifier efficiency", "zener breakdown voltage", "truth tables for and or not nand nor xor"],
        subtopics: [
          { name: "P-N Junction Diode & Rectifiers", aliases: ["rectifier circuits"], keywords: ["depletion layer width in forward/reverse bias", "ripple factor", "centre tapped transformer rectifier"] },
          { name: "Logic Gates & Truth Tables", aliases: ["boolean algebra"], keywords: ["universal gates nand and nor", "logic circuit simplification", "truth table identification"] },
        ],
      },
    ],
  },
  {
    id: "phy-center-of-mass",
    name: "Center of Mass and System of Particles",
    aliases: [
      "center of mass",
      "centre of mass",
      "com",
      "collision mechanics",
      "conservation of linear momentum",
      "elastic collision in one dimension",
      "inelastic collision",
      "continuous bodies center of mass",
      "center of mass com",
    ],
    unit: "Mechanics",
    classLevel: "Class 11",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 7,
    topics: [
      {
        id: "phy-com-calc",
        name: "Center of Mass & Collision Mechanics",
        aliases: ["center of mass calculation", "two particle system com", "reduced mass", "coefficient of restitution e"],
        keywords: [
          "center of mass",
          "centre of mass",
          "com of continuous bodies",
          "collision mechanics",
          "elastic and inelastic collisions",
          "coefficient of restitution",
          "impulse momentum theorem",
          "motion of center of mass",
        ],
        subtopics: [
          { name: "COM Calculation", aliases: ["com of discrete and continuous bodies"], keywords: ["com formula sigma m_i r_i", "com of semicircular ring and disc", "com of cone and hemisphere"] },
          { name: "Collisions in 1D and 2D", aliases: ["head on collision oblique collision"], keywords: ["loss of kinetic energy in collision", "perfectly inelastic collision", "linear momentum conservation"] },
        ],
      },
    ],
  },
  {
    id: "phy-ktg-gases",
    name: "Kinetic Theory of Gases",
    aliases: [
      "kinetic theory of gases",
      "ktg",
      "maxwell boltzmann distribution",
      "degree of freedom",
      "law of equipartition of energy",
      "mean free path",
      "rms speed of gas molecules",
    ],
    unit: "Thermal Physics",
    classLevel: "Class 11",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 13,
    topics: [
      {
        id: "phy-ktg-laws",
        name: "Kinetic Theory & Gas Laws",
        aliases: ["pressure of ideal gas", "molar specific heat of gases cp cv", "adiabatic index gamma"],
        keywords: [
          "kinetic theory of gases",
          "ktg",
          "rms speed",
          "average speed and most probable speed",
          "degrees of freedom monoatomic diatomic",
          "equipartition of energy",
          "internal energy of ideal gas",
        ],
        subtopics: [
          { name: "Molecular Speeds & Pressure", aliases: ["vrms vavg vmp"], keywords: ["root mean square velocity", "gas pressure derivation", "boyle and charles law kinetic interpretation"] },
          { name: "Equipartition & Specific Heats", aliases: ["degrees of freedom cv cp"], keywords: ["cv = f/2 r", "gamma = 1 + 2/f", "internal energy u = f/2 nrt"] },
        ],
      },
    ],
  },
  {
    id: "phy-magnetism-matter",
    name: "Magnetism and Matter",
    aliases: [
      "magnetism and matter",
      "earth magnetic field",
      "earth's magnetic field",
      "magnetic dipole moment",
      "hysteresis loop",
      "ferromagnetism diamagnetism paramagnetism",
      "curie law",
      "magnetic susceptibility",
    ],
    unit: "Magnetism",
    classLevel: "Class 12",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 5,
    topics: [
      {
        id: "phy-magnetic-properties",
        name: "Earth's Magnetism & Magnetic Materials",
        aliases: ["elements of earth magnetic field dip declination", "dia para and ferromagnetic substances", "b-h curve and retentivity coercivity"],
        keywords: [
          "magnetism and matter",
          "earth's magnetic field",
          "angle of dip and magnetic declination",
          "magnetic dipole in uniform field",
          "hysteresis loop and b-h curve",
          "curie temperature and curie weiss law",
          "permeability and susceptibility",
        ],
        subtopics: [
          { name: "Earth's Magnetic Elements", aliases: ["horizontal component bh angle of dip"], keywords: ["magnetic meridian and geographic meridian", "tangent galvanometer", "dip circle"] },
          { name: "Classification of Magnetic Materials", aliases: ["dia para ferro materials"], keywords: ["domain theory of ferromagnetism", "permanent magnets and electromagnets", "retentivity and coercivity"] },
        ],
      },
    ],
  },

];

// ====================================================================
// 2. CHEMISTRY KNOWLEDGE GRAPH (JEE, NEET, CBSE Class 11 & 12)
// ====================================================================

const CHEMISTRY_CHAPTERS: AcademicChapterNode[] = [
  // Class 11 Chemistry
  {
    id: "chem-mole-concept",
    name: "Some Basic Concepts of Chemistry",
    aliases: [
      "mole concept",
      "stoichiometry",
      "mole concept & stoichiometry",
      "mole concept and stoichiometry",
      "mole concept & stoichiometry class 11",
      "molarity",
      "molality",
      "limiting reagent",
      "mole fraction",
      "percentage composition",
      "empirical formula",
      "molecular formula",
      "concentration terms",
    ],
    unit: "Physical Chemistry",
    classLevel: "Class 11",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 1,
    topics: [
      {
        id: "chem-mole-calculations",
        name: "Mole Concept, Molarity & Limiting Reagent",
        aliases: ["molarity molality limiting reagent", "stoichiometric calculations", "empirical and molecular formula"],
        keywords: ["mole concept", "stoichiometry", "molarity", "molality", "normality", "limiting reagent numericals", "mole fraction calculations", "percentage purity"],
        subtopics: [
          { name: "Concentration Terms", aliases: ["molarity and molality"], keywords: ["molarity formula", "molality temperature independent", "parts per million ppm"] },
          { name: "Stoichiometry & Limiting Reagent", aliases: ["limiting reactant problems"], keywords: ["limiting reagent identification", "theoretical yield", "excess reagent"] },
        ],
      },
    ],
  },
  {
    id: "chem-structure-atom",
    name: "Structure of Atom",
    aliases: [
      "structure of atom",
      "atomic structure",
      "bohr model of atom",
      "quantum numbers",
      "electronic configuration",
      "aufbau principle",
      "hund's rule",
      "pauli exclusion principle",
      "photoelectric effect in chemistry",
      "de broglie wavelength",
      "heisenberg uncertainty principle",
    ],
    unit: "Physical Chemistry",
    classLevel: "Class 11",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 2,
    topics: [
      {
        id: "chem-quantum-numbers",
        name: "Quantum Numbers & Electronic Configuration",
        aliases: ["bohr model quantum numbers", "principal azimuthal magnetic spin quantum numbers", "aufbau pauli hund rules"],
        keywords: ["bohr model", "quantum numbers", "electronic configuration aufbau", "orbital shapes s p d f", "node and antinode in orbitals", "radial nodes and angular nodes"],
        subtopics: [
          { name: "Quantum Numbers", aliases: ["n l m s values"], keywords: ["principal quantum number", "azimuthal quantum number", "magnetic quantum number", "spin quantum number"] },
          { name: "Electronic Rules", aliases: ["aufbau rule"], keywords: ["n+l rule", "half filled and fully filled stability", "chromium and copper configuration"] },
        ],
      },
    ],
  },
  {
    id: "chem-periodic-table",
    name: "Classification of Elements and Periodicity in Properties",
    aliases: [
      "periodic table & periodicity",
      "periodic table and periodicity",
      "periodic table",
      "periodicity in properties",
      "periodicity",
      "periodic classification",
      "modern periodic table",
      "ionization enthalpy",
      "electron gain enthalpy",
      "electronegativity",
      "atomic radius trends",
    ],
    unit: "Inorganic Chemistry",
    classLevel: "Class 11",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 3,
    topics: [
      {
        id: "chem-periodic-trends",
        name: "Periodic Trends in Properties",
        aliases: ["ionization enthalpy electron gain enthalpy trends", "electronegativity pauling scale", "shielding effect and effective nuclear charge zeff"],
        keywords: ["ionization enthalpy", "electron gain enthalpy trends", "ionization potential exceptions", "electronegativity trends", "atomic size lanthanoid contraction in d block"],
        subtopics: [
          { name: "Ionization Enthalpy", aliases: ["first second ionization enthalpy"], keywords: ["trend across period and down group", "beryllium vs boron anomaly", "nitrogen vs oxygen anomaly"] },
          { name: "Electron Gain Enthalpy", aliases: ["electron affinity"], keywords: ["chlorine higher than fluorine", "noble gas positive enthalpy"] },
        ],
      },
    ],
  },
  {
    id: "chem-redox",
    name: "Redox Reactions",
    aliases: [
      "redox reactions",
      "oxidation and reduction",
      "oxidation number concept",
      "balancing redox reactions",
      "ion electron method",
      "half reaction method",
      "oxidizing and reducing agents",
    ],
    unit: "Physical Chemistry",
    classLevel: "Class 11",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 8,
    topics: [
      {
        id: "chem-redox-balancing",
        name: "Balancing Redox Reactions & Oxidation Numbers",
        aliases: ["balancing by ion electron method", "oxidation number rules", "disproportionation reactions"],
        keywords: ["redox reactions", "balancing by ion-electron method", "oxidation number concept", "balancing in acidic and basic medium", "oxidation state rules", "disproportionation"],
        subtopics: [
          { name: "Ion-Electron Method", aliases: ["half reaction balancing"], keywords: ["balancing in acidic medium with h+", "balancing in basic medium with oh-", "electron transfer"] },
          { name: "Oxidation Numbers", aliases: ["oxidation states"], keywords: ["rules for assigning oxidation numbers", "fractional oxidation states", "paradox of fractional oxidation states"] },
        ],
      },
    ],
  },
  {
    id: "chem-chemical-bonding",
    name: "Chemical Bonding and Molecular Structure",
    aliases: [
      "chemical bonding",
      "vsepr theory",
      "hybridization",
      "molecular orbital theory",
      "mot",
      "dipole moment",
      "hydrogen bonding",
      "fajans rule",
      "resonance in chemistry",
      "lewis structures",
    ],
    unit: "Inorganic Chemistry",
    classLevel: "Class 11",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 4,
    topics: [
      {
        id: "chem-vsepr-mot",
        name: "VSEPR Theory, Hybridization & Molecular Orbital Theory",
        aliases: ["vsepr shapes of molecules", "sp sp2 sp3 sp3d sp3d2 hybridization", "mot bond order paramagnetic diamagnetic"],
        keywords: ["vsepr theory", "hybridization", "molecular orbital theory mot", "bond order formula", "dipole moment calculation", "hydrogen bonding types"],
        subtopics: [
          { name: "VSEPR & Hybridization", aliases: ["molecular geometry"], keywords: ["lone pair bond pair repulsion", "bent t-shape see-saw square planar", "hybrid orbitals"] },
          { name: "Molecular Orbital Theory", aliases: ["mot bond order"], keywords: ["bonding and antibonding molecular orbitals", "o2 paramagnetic nature", "n2 bond order 3"] },
        ],
      },
    ],
  },
  {
    id: "chem-thermodynamics-11",
    name: "Thermodynamics and Thermochemistry",
    aliases: [
      "chemical thermodynamics",
      "thermodynamics class 11",
      "first law of thermodynamics",
      "enthalpy of reaction",
      "hess's law",
      "entropy and spontaneity",
      "gibbs free energy delta g",
    ],
    unit: "Physical Chemistry",
    classLevel: "Class 11",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 5,
    topics: [
      {
        id: "chem-laws-thermo",
        name: "First & Second Law of Thermodynamics",
        aliases: ["delta u = q + w", "enthalpy changes delta h", "entropy change delta s", "gibbs helmholtz equation delta g = delta h - t delta s"],
        keywords: ["first law thermodynamics", "hess law constant heat summation", "standard enthalpy of formation combustion", "entropy increase of universe", "spontaneity condition delta g negative"],
        subtopics: [
          { name: "Hess's Law & Thermochemistry", aliases: ["bond energy calculations"], keywords: ["enthalpy of reaction from bond enthalpies", "calorimetry", "heat capacity cp cv"] },
          { name: "Gibbs Free Energy & Spontaneity", aliases: ["delta g criteria"], keywords: ["spontaneous process condition", "equilibrium delta g zero", "standard free energy change"] },
        ],
      },
    ],
  },
  {
    id: "chem-equilibrium-11",
    name: "Equilibrium (Chemical and Ionic)",
    aliases: [
      "chemical equilibrium",
      "ionic equilibrium",
      "le chatelier's principle",
      "law of chemical equilibrium kc and kp",
      "ph of solutions",
      "buffer solutions",
      "solubility product ksp",
      "common ion effect",
      "salt hydrolysis",
    ],
    unit: "Physical Chemistry",
    classLevel: "Class 11",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 6,
    topics: [
      {
        id: "chem-ionic-eq",
        name: "Ionic Equilibrium, pH & Buffer Solutions",
        aliases: ["ph buffer solutions ksp", "henderson hasselbalch equation", "solubility product precipitation", "common ion effect suppression"],
        keywords: ["chemical equilibrium kp = kc(rt)^deltang", "le chatelier principle temperature pressure catalyst", "ostwald dilution law", "ph calculations strong and weak acids", "buffer action acidic and basic buffers", "solubility product ksp numericals"],
        subtopics: [
          { name: "Le Chatelier's Principle", aliases: ["equilibrium shift factors"], keywords: ["effect of temperature on endothermic exothermic", "pressure effect on gas moles", "inert gas addition"] },
          { name: "Ionic Equilibria & pH", aliases: ["buffer and ksp"], keywords: ["henderson equation ph = pka + log(salt/acid)", "ksp and solubility s relation", "precipitation condition qsp > ksp"] },
        ],
      },
    ],
  },
  {
    id: "chem-goc-11",
    name: "Organic Chemistry: Basic Principles & Techniques (GOC)",
    aliases: [
      "goc",
      "general organic chemistry",
      "organic chemistry class 11",
      "organic chemistry named reactions",
      "named reactions in organic chemistry",
      "named reactions",
      "named reactions revision",
      "electronic effects in organic chemistry",
      "inductive effect",
      "resonance effect mesomeric effect",
      "hyperconjugation",
      "electromeric effect",
      "carbocation carbanion free radical stability",
      "isomerism structural and stereoisomerism",
      "iupac nomenclature of organic compounds",
    ],
    unit: "Organic Chemistry",
    classLevel: "Class 11",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 7,
    topics: [
      {
        id: "chem-electronic-effects",
        name: "Electronic Effects & Reaction Intermediates",
        aliases: ["inductive resonance hyperconjugation", "carbocation stability order 3 > 2 > 1", "carbanion stability", "electrophile and nucleophile types"],
        keywords: ["goc general organic chemistry", "inductive effect +i and -i groups", "resonance structures and resonance hybrid", "hyperconjugation baker nathan effect alpha hydrogen", "aromaticity huckel 4n+2 pi electrons rule", "iupac rules priority of functional groups"],
        subtopics: [
          { name: "Resonance & Aromaticity", aliases: ["mesomeric effect huckel rule"], keywords: ["resonance energy", "huckel rule 4n+2", "non-aromatic and anti-aromatic"] },
          { name: "Intermediates Stability", aliases: ["carbocation carbanion"], keywords: ["carbocation rearrangement hydride alkyl shift", "free radical stability", "acidic strength of carboxylic acids phenols goc"] },
        ],
      },
    ],
  },
  {
    id: "chem-hydrocarbons-11",
    name: "Hydrocarbons",
    aliases: [
      "hydrocarbons",
      "alkanes alkenes alkynes",
      "aromatic hydrocarbons benzene",
      "markovnikov rule and anti markovnikov",
      "ozonolysis of alkenes",
      "wurtz reaction",
      "friedel crafts reaction",
      "conformations of ethane staggered eclipsed",
    ],
    unit: "Organic Chemistry",
    classLevel: "Class 11",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 8,
    topics: [
      {
        id: "chem-alkenes-benzene",
        name: "Alkenes Addition Reactions & Benzene Chemistry",
        aliases: ["markovnikov addition of hbr", "peroxide effect kharasch effect", "ozonolysis reductive and oxidative", "electrophilic aromatic substitution of benzene"],
        keywords: ["hydrocarbons", "markovnikov rule addition of hx", "anti-markovnikov rule in presence of peroxide", "ozonolysis carbonyl products prediction", "friedel crafts alkylation and acylation anhydrous alcl3", "conformations of ethane newman projection"],
        subtopics: [
          { name: "Alkenes & Alkynes Reactions", aliases: ["addition reactions ozonolysis"], keywords: ["markovnikov carbocation intermediate", "ozonolysis zn h2o reductive cleavage", "acidity of terminal alkynes"] },
          { name: "Aromatic Substitution", aliases: ["benzene reactions electrophilic"], keywords: ["nitration of benzene conc hno3 h2so4", "halogenation mechanism arenium ion", "activators and deactivators ortho para directors"] },
        ],
      },
    ],
  },

  // Class 12 Chemistry
  {
    id: "chem-solutions",
    name: "Solutions",
    aliases: ["solutions class 12", "types of solutions", "henry's law", "raoult's law", "ideal and non-ideal solutions", "azeotropes", "colligative properties", "elevation in boiling point", "depression in freezing point", "osmotic pressure", "van't hoff factor"],
    unit: "Physical Chemistry",
    classLevel: "Class 12",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 1,
    topics: [
      {
        id: "chem-colligative-props",
        name: "Raoult's Law & Colligative Properties",
        aliases: ["relative lowering of vapour pressure rlvp", "elevation of boiling point delta tb = kb m", "depression of freezing point delta tf = kf m", "osmotic pressure pi = crt", "abnormal molecular mass van't hoff factor i"],
        keywords: ["henry law constant", "raoult law for volatile solutes", "positive and negative deviations from raoult law", "minimum and maximum boiling azeotropes", "ebullioscopic constant", "cryoscopic constant", "reverse osmosis and water purification", "degree of dissociation and association alpha"],
        subtopics: [
          { name: "Raoult's Law & Azeotropes", aliases: ["vapour pressure curves"], keywords: ["ideal solution enthalpy of mixing zero", "acetone chloroform negative deviation", "ethanol water positive deviation"] },
          { name: "Colligative Properties & Van't Hoff", aliases: ["van't hoff factor calculations"], keywords: ["molar mass determination", "isotonic hypertonic hypotonic solutions", "i = 1 + (n-1)alpha"] },
        ],
      },
    ],
  },
  {
    id: "chem-electrochemistry",
    name: "Electrochemistry",
    aliases: ["galvanic cell", "danielle cell", "electrochemical cell", "nernst equation", "standard electrode potential", "electrochemical series", "conductance of electrolytic solutions", "molar conductivity", "kohlrausch's law", "faraday's laws of electrolysis", "batteries fuel cells corrosion"],
    unit: "Physical Chemistry",
    classLevel: "Class 12",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 2,
    topics: [
      {
        id: "chem-nernst-kohlrausch",
        name: "Nernst Equation and Electrolytic Conductance",
        aliases: ["nernst equation cell emf ecell = e0cell - (0.0591/n) log q", "relation between gibbs free energy and cell potential delta g = -nfe", "equilibrium constant from nernst equation", "kohlrausch law of independent migration of ions", "lead storage battery reactions"],
        keywords: ["emf of a cell", "standard hydrogen electrode she", "nernst equation calculation", "specific conductance kappa", "molar conductance lambda_m", "variation of molar conductivity with concentration for strong and weak electrolytes", "faraday first and second law of electrolysis w = zit"],
        subtopics: [
          { name: "Nernst Equation & Thermodynamic Relations", aliases: ["cell potential calculations"], keywords: ["nernst equation at 298k", "gibbs free energy of cell", "concentration cells"] },
          { name: "Kohlrausch's Law & Electrolysis", aliases: ["ionic mobility and conductance"], keywords: ["limiting molar conductivity", "degree of dissociation of weak electrolyte lambda_m/lambda_0", "faraday constant 96500 coulombs"] },
        ],
      },
    ],
  },
  {
    id: "chem-chemical-kinetics",
    name: "Chemical Kinetics",
    aliases: ["rate of reaction", "rate law and specific rate constant", "order and molecularity of reaction", "integrated rate equations", "zero order and first order reactions", "half life of a reaction", "pseudo first order reaction", "arrhenius equation", "activation energy"],
    unit: "Physical Chemistry",
    classLevel: "Class 12",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 3,
    topics: [
      {
        id: "chem-kinetics-rate-laws",
        name: "Integrated Rate Equations & Arrhenius Theory",
        aliases: ["first order rate constant k = (2.303/t) log(a0/a)", "half life of first order t1/2 = 0.693/k", "arrhenius equation k = a e^(-ea/rt)", "plot of ln k vs 1/t slope -ea/r", "collision theory effective collisions"],
        keywords: ["differential and average rate of reaction", "order of reaction from rate law", "units of rate constant for zero first second order", "radioactive decay as first order kinetics", "activation energy calculation log(k2/k1) = ea/2.303r(1/t1 - 1/t2)", "catalyst effect on activation energy"],
        subtopics: [
          { name: "First Order Kinetics & Half Life", aliases: ["rate law numericals"], keywords: ["integrated rate expression", "time required for 99% completion", "half life independent of initial concentration"] },
          { name: "Temperature Dependence & Arrhenius Equation", aliases: ["activation energy problems"], keywords: ["arrhenius factor a", "threshold energy", "fraction of molecules having energy greater than ea"] },
        ],
      },
    ],
  },
  {
    id: "chem-d-f-block",
    name: "The d- and f-Block Elements",
    aliases: ["d and f block", "transition elements", "general properties of 3d transition series", "variable oxidation states", "colored ions due to d-d transition", "catalytic properties", "magnetic properties spin only formula", "potassium dichromate k2cr2o7", "potassium permanganate kmno4", "lanthanoid contraction"],
    unit: "Inorganic Chemistry",
    classLevel: "Class 12",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 4,
    topics: [
      {
        id: "chem-transition-elements",
        name: "Transition Elements & Lanthanoids",
        aliases: ["lanthanoid contraction causes and consequences", "preparation and properties of kmno4 and k2cr2o7", "spin only magnetic moment mu = root(n(n+2)) bm", "interstitial compounds and alloy formation"],
        keywords: ["electronic configuration of chromium and copper exceptions", "standard reduction potential trends in 3d series", "oxidising action of acidic kmno4 and k2cr2o7", "lanthanoid contraction radii of zr and hf identical", "actinoid contraction comparison with lanthanoids"],
        subtopics: [
          { name: "Lanthanoids & Actinoids", aliases: ["f block chemistry"], keywords: ["lanthanoid contraction", "mischmetal", "oxidation states of lanthanoids +3 dominant"] },
          { name: "Kmno4 and K2Cr2O7 Chemistry", aliases: ["redox titration inorganic"], keywords: ["structure of chromate and dichromate ion", "permanganate titrations with oxalate and fe2+"] },
        ],
      },
    ],
  },
  {
    id: "chem-coordination-compounds",
    name: "Coordination Compounds",
    aliases: ["coordination chemistry", "werner's theory of coordination compounds", "ligands unidentate bidentate polydentate chelating", "coordination number", "iupac nomenclature of coordination complexes", "isomerism in coordination compounds geometrical optical structural", "valence bond theory vbt", "crystal field theory cft", "spectrochemical series"],
    unit: "Inorganic Chemistry",
    classLevel: "Class 12",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 5,
    topics: [
      {
        id: "chem-cft-werner",
        name: "IUPAC, Isomerism & Crystal Field Theory (CFT)",
        aliases: ["crystal field splitting in octahedral and tetrahedral complexes delta0 and deltat", "high spin and low spin complexes", "cfse crystal field stabilisation energy", "fac-mer isomerism", "cis-trans isomerism", "synergic bonding in metal carbonyls"],
        keywords: ["werner primary and secondary valency", "iupac naming rules for coordination compounds", "geometrical and optical isomerism in ma2b2 ma2bc mabcd", "vbt inner and outer orbital complexes d2sp3 vs sp3d2", "cft t2g and eg orbital splitting", "spectrochemical series strong field vs weak field ligands", "magnetic behavior from d electron configuration"],
        subtopics: [
          { name: "Crystal Field Theory (CFT)", aliases: ["d-orbital splitting cft"], keywords: ["octahedral splitting delta0", "pairing energy vs crystal field splitting", "tetrahedral splitting deltat = 4/9 delta0", "color of complexes"] },
          { name: "Isomerism in Complexes", aliases: ["stereoisomerism coordination"], keywords: ["linkage isomerism", "coordination isomerism", "ionisation isomerism", "optical activity of [co(en)3]3+"] },
        ],
      },
    ],
  },
  {
    id: "chem-haloalkanes",
    name: "Haloalkanes and Haloarenes",
    aliases: ["alkyl halides", "aryl halides", "sn1 mechanism", "sn2 mechanism", "nucleophilic substitution", "e1 and e2 elimination reactions", "saytzeff rule", "grignard reagent", "wurtz reaction", "fittig reaction", "wurtz fittig", "sandmeyer reaction for aryl halides", "optical activity enantiomers"],
    unit: "Organic Chemistry",
    classLevel: "Class 12",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 6,
    topics: [
      {
        id: "chem-sn1-sn2",
        name: "SN1 vs SN2 Mechanisms & Stereochemistry",
        aliases: ["stereochemical aspects of nucleophilic substitution", "retention and inversion of configuration walden inversion", "racemic mixture", "carbocation stability in sn1", "steric hindrance in sn2", "nucleophilic aromatic substitution of haloarenes"],
        keywords: ["sn1 two step unimolecular mechanism via carbocation", "sn2 one step bimolecular mechanism with transition state", "reactivity order 3 > 2 > 1 for sn1 and 1 > 2 > 3 for sn2", "polar protic vs polar aprotic solvents", "saytzeff zaitsev elimination more substituted alkene", "swarts reaction and finkelstein reaction for halide exchange"],
        subtopics: [
          { name: "SN1 and SN2 Reaction Comparison", aliases: ["nucleophilic substitution mechanisms"], keywords: ["carbocation rearrangement in sn1", "inversion in sn2", "effect of leaving group"] },
        ],
      },
    ],
  },
  {
    id: "chem-alcohols-phenols-ethers",
    name: "Alcohols, Phenols and Ethers",
    aliases: ["preparation of alcohols", "hydration of alkenes", "hydroboration oxidation", "lucas test", "distinction between 1 2 3 alcohols", "acidic nature of phenol vs alcohol", "kolbe reaction", "reimer tiemann reaction", "williamson ether synthesis", "cleavage of ethers by hi"],
    unit: "Organic Chemistry",
    classLevel: "Class 12",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 7,
    topics: [
      {
        id: "chem-phenol-reactions",
        name: "Reactions of Phenol & Williamson Synthesis",
        aliases: ["kolbe synthesis of salicylic acid", "reimer tiemann reaction of phenol to salicylaldehyde", "electrophilic substitution of phenol bromination and nitration", "williamson ether synthesis sn2 on primary alkyl halide", "cleavage of ether with excess hi"],
        keywords: ["preparation of phenol from cumene", "lucas reagent conc hcl and zncl2 turbidity", "dehydration of alcohols mechanism", "phenoxide ion resonance stabilization", "picric acid preparation", "williamson synthesis mechanism sn2", "cleavage of anisole with hi to phenol and methyl iodide"],
        subtopics: [
          { name: "Reactions of Phenols", aliases: ["named reactions of phenol"], keywords: ["kolbe-schmitt reaction", "reimer-tiemann mechanism", "oxidation of phenol to benzoquinone", "bromine water test for phenol"] },
          { name: "Ether Reactions & Cleavage", aliases: ["williamson ether cleavage"], keywords: ["ether cleavage with hi mechanism", "unsymmetrical ether cleavage rule"] },
        ],
      },
    ],
  },
  {
    id: "chem-aldehydes-ketones-acids",
    name: "Aldehydes, Ketones and Carboxylic Acids",
    aliases: [
      "carbonyl compounds",
      "aldehydes and ketones",
      "carboxylic acids",
      "nucleophilic addition reactions",
      "aldol condensation",
      "cross aldol condensation",
      "cannizzaro reaction",
      "clemmensen reduction",
      "wolff kishner reduction",
      "tollens test",
      "fehling's test",
      "fehling test",
      "iodoform test",
      "haloform reaction",
      "distinction tests for organic compounds",
      "hell volhard zelinsky hvz reaction",
      "acidity of carboxylic acids",
    ],
    unit: "Organic Chemistry",
    classLevel: "Class 12",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 8,
    topics: [
      {
        id: "chem-aldol-cannizzaro",
        name: "Aldol, Cannizzaro & Carbonyl Condensations",
        aliases: [
          "mechanism of aldol condensation alpha hydrogen",
          "cannizzaro reaction disproportionation of benzaldehyde",
          "nucleophilic addition of hcn nahso3 grignard to carbonyl",
          "iodoform test for ch3co- and ch3ch(oh)- groups",
          "iodoform test and tollens test",
          "distinction tests for organic compounds class 12",
          "hvz reaction alpha halogenation of carboxylic acids",
        ],
        keywords: ["reactivity of aldehydes greater than ketones towards nucleophilic addition", "addition of ammonia derivatives 2 4 dnp semicarbazide", "clemmensen reduction zn-hg and hcl", "wolff kishner hydrazine and koh", "tollens reagent ammoniacal silver nitrate", "fehling solution a and b", "aldol and cross aldol product prediction", "cannizzaro reaction mechanism without alpha hydrogen"],
        subtopics: [
          { name: "Aldol & Cannizzaro Mechanisms", aliases: ["named carbonyl reactions"], keywords: ["aldol condensation alpha hydrogen enolate ion", "cross aldol four products", "cannizzaro hydride transfer"] },
          { name: "Distinction Tests & Reduction", aliases: ["tollens fehling iodoform", "distinction tests"], keywords: ["iodoform yellow precipitate chi3", "clemmensen vs wolff kishner", "acidity of substituted benzoic acids"] },
        ],
      },
    ],
  },
  {
    id: "chem-surface-chemistry",
    name: "Surface Chemistry",
    aliases: [
      "surface chemistry",
      "surface chemistry class 12",
      "adsorption",
      "physisorption",
      "chemisorption",
      "physisorption vs chemisorption",
      "adsorption isotherms",
      "freundlich adsorption isotherm",
      "catalysis",
      "colloids",
      "colloidal state",
      "lyophilic and lyophobic colloids",
      "tyndall effect",
      "brownian movement",
      "electrophoresis",
      "coagulation and hardy schulze rule",
      "emulsions",
    ],
    unit: "Physical Chemistry",
    classLevel: "Class 12",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 5,
    topics: [
      {
        id: "chem-adsorption-colloids",
        name: "Physisorption vs Chemisorption & Colloids Tyndall Effect",
        aliases: ["physisorption and chemisorption characteristics", "freundlich isotherm x/m = k p^(1/n)", "colloids tyndall effect brownian motion", "hardy schulze rule coagulation power"],
        keywords: ["surface chemistry", "physisorption vs chemisorption", "colloids tyndall effect", "hardy schulze rule", "micelles formation cmc", "peptization and dialysis"],
        subtopics: [
          { name: "Adsorption Types & Isotherm", aliases: ["physisorption chemisorption"], keywords: ["reversible physisorption", "chemical bond in chemisorption", "freundlich log plot"] },
          { name: "Colloids & Properties", aliases: ["tyndall brownian electrophoresis"], keywords: ["scattering of light tyndall", "zigzag brownian motion", "protective colloids gold number"] },
        ],
      },
    ],
  },
  {
    id: "chem-amines",
    name: "Amines",
    aliases: ["organic compounds containing nitrogen", "classification of amines", "gabriel phthalimide synthesis", "hoffmann bromamide degradation reaction", "basic character of amines in gas phase and aqueous solution", "hinsberg test for 1 2 3 amines", "carbylamine reaction isocyanide test", "diazonium salts preparation and synthetic applications", "sandmeyer reaction gattermann reaction coupling reaction azo dyes"],
    unit: "Organic Chemistry",
    classLevel: "Class 12",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 9,
    topics: [
      {
        id: "chem-amines-diazonium",
        name: "Basicity of Amines & Diazonium Chemistry",
        aliases: ["basicity order of aliphatic amines in water 2 > 1 > 3 or 2 > 3 > 1", "hoffmann bromamide degradation mechanism loss of carbonyl carbon", "carbylamine test for primary amines foul smell", "benzene diazonium chloride reactions sandmeyer gattermann azo coupling with phenol and aniline"],
        keywords: ["gabriel phthalimide synthesis for pure primary aliphatic amines", "hoffmann bromamide reaction rconh2 + br2 + 4naoh -> rnh2", "hinsberg reagent benzenesulphonyl chloride", "azo coupling reaction orange and yellow dyes", "diazotisation of aniline nano2 + hcl at 0 to 5 c"],
        subtopics: [
          { name: "Basicity of Amines & Distinction Tests", aliases: ["hinsberg carbylamine"], keywords: ["inductive steric solvation effects in basicity", "hinsberg separation of amines", "carbylamine isocyanide test"] },
          { name: "Diazonium Salt Synthetic Applications", aliases: ["azo dye coupling"], keywords: ["sandmeyer cu2cl2 reaction", "azo dye structure with phenol", "replacement of diazo group by f i cn oh h"] },
        ],
      },
    ],
  },
  {
    id: "chem-biomolecules",
    name: "Biomolecules",
    aliases: ["biomolecules in chemistry", "carbohydrates", "monosaccharides glucose and fructose structure", "reducing and non-reducing sugars", "cyclic structure of glucose pyranose haworth projection", "amino acids essential and non-essential", "peptide bond", "primary secondary tertiary quaternary structure of proteins", "denaturation of proteins", "nucleic acids dna rna components double helix", "vitamins classification deficiency diseases"],
    unit: "Organic Chemistry",
    classLevel: "Class 12",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 10,
    topics: [
      {
        id: "chem-sugars-proteins",
        name: "Carbohydrates, Amino Acids & Nucleic Acids",
        aliases: ["glucose reactions with hi hcn br2 water hno3 acetic anhydride", "mutarotation and anomers alpha and beta d glucose", "zwitter ion isoelectric point of amino acids", "alpha helix and beta pleated sheet secondary structure", "difference between dna and rna nucleotide nucleoside"],
        keywords: ["open chain structure of d-glucose evidence", "reducing sugars tollens fehling positive", "glycosidic linkage in maltose sucrose lactose", "inversion of cane sugar", "peptide linkage -co-nh-", "denaturation loss of secondary and tertiary structure", "dna adenine thymine guanine cytosine pairing hydrogen bonds"],
        subtopics: [
          { name: "Carbohydrate Structure & Reactions", aliases: ["glucose haworth projections"], keywords: ["chemical evidence for open chain glucose", "anomeric carbon", "glycogen starch cellulose structure"] },
          { name: "Proteins & Nucleic Acids", aliases: ["protein structures dna double helix"], keywords: ["zwitterion structure", "essential amino acids", "purines and pyrimidines", "phosphodiester linkage"] },
        ],
      },
    ],
  },
  {
    id: "chem-p-block",
    name: "p-Block Elements",
    aliases: [
      "p block elements",
      "p-block elements",
      "group 15 elements",
      "group 16 elements",
      "group 17 elements",
      "group 18 elements",
      "oxoacids of phosphorus",
      "oxoacids of sulphur",
      "interhalogen compounds",
      "noble gas compounds",
    ],
    unit: "Inorganic Chemistry",
    classLevel: "Class 12",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 7,
    topics: [
      {
        id: "chem-p-block-groups",
        name: "Group 15, 16, 17 & 18 Chemistry",
        aliases: ["nitrogen family", "oxygen family chalcogens", "halogens", "noble gases"],
        keywords: [
          "p-block elements class 12",
          "group 15 16 17 18 trends",
          "allotropes of phosphorus",
          "contact process for sulfuric acid",
          "interhalogens xx prime",
          "xenon fluorides xef2 xef4 xef6",
          "anomalous behavior of nitrogen and oxygen",
        ],
        subtopics: [
          { name: "Group 15 and 16 Elements", aliases: ["nitrogen and chalcogens"], keywords: ["haber process for ammonia", "nitric acid ostwald process", "ozone preparation and structure", "oxoacids of sulfur"] },
          { name: "Group 17 and 18 Elements", aliases: ["halogens and noble gases"], keywords: ["chlorine deacon process", "bleaching powder", "interhalogen structures", "xenon oxyfluorides"] },
        ],
      },
    ],
  },
  {
    id: "chem-solid-state",
    name: "The Solid State",
    aliases: [
      "solid state",
      "the solid state",
      "unit cell calculations",
      "packing efficiency",
      "bragg's law",
      "crystal lattice",
      "schottky defect",
      "frenkel defect",
    ],
    unit: "Physical Chemistry",
    classLevel: "Class 12",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 1,
    topics: [
      {
        id: "chem-solid-unit-cells",
        name: "Crystal Lattices & Unit Cell Calculations",
        aliases: ["cubic lattices simple fcc bcc", "voids tetrahedral and octahedral", "density of unit cell formula d = zM / a^3 NA"],
        keywords: [
          "solid state class 12",
          "unit cell calculations",
          "packing efficiency in fcc bcc",
          "bragg's law 2d sin theta = n lambda",
          "point defects stoichiometric and non stoichiometric",
          "f-centers color in crystals",
          "ferromagnetic antiferromagnetic ferrimagnetic",
        ],
        subtopics: [
          { name: "Unit Cell Geometry & Density", aliases: ["coordination number void fraction"], keywords: ["radius ratio rules", "density formula numericals", "packing fractions 74% 68% 52.4%"] },
          { name: "Crystal Defects & Properties", aliases: ["point defects"], keywords: ["schottky vs frenkel defect", "metal excess defect", "semiconductor doping"] },
        ],
      },
    ],
  },
  {
    id: "chem-polymers",
    name: "Polymers",
    aliases: [
      "polymers",
      "addition polymerization",
      "condensation polymerization",
      "bakelite",
      "nylon 6 6",
      "biodegradable polymers",
      "phbv",
      "natural rubber vulcanization",
    ],
    unit: "Organic Chemistry",
    classLevel: "Class 12",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 15,
    topics: [
      {
        id: "chem-poly-types",
        name: "Polymerization Mechanisms & Commercial Polymers",
        aliases: ["chain growth and step growth polymerization", "thermoplastic and thermosetting polymers", "copolymers and homopolymers"],
        keywords: [
          "polymers class 12",
          "addition vs condensation polymerization",
          "bakelite nylon 6,6",
          "polythene teflon pan",
          "dacron terylene",
          "vulcanization with sulfur crosslinks",
          "biodegradable polymers phbv nylon 2 nylon 6",
        ],
        subtopics: [
          { name: "Classification & Mechanisms", aliases: ["types of polymerization"], keywords: ["free radical addition mechanism", "polyesters and polyamides", "monomers of common polymers"] },
          { name: "Commercial & Biodegradable Polymers", aliases: ["commercial plastics"], keywords: ["melamine formaldehyde", "neoprene buna-s buna-n", "biodegradable packaging"] },
        ],
      },
    ],
  },
  {
    id: "chem-everyday-life",
    name: "Chemistry in Everyday Life",
    aliases: [
      "chemistry in everyday life",
      "drugs classification",
      "analgesics",
      "antibiotics",
      "antiseptics and disinfectants",
      "antacids and antihistamines",
      "artificial sweetening agents",
      "soaps and detergents",
    ],
    unit: "Applied Chemistry",
    classLevel: "Class 12",
    exams: ["JEE Main", "NEET", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 16,
    topics: [
      {
        id: "chem-drugs-chemicals",
        name: "Therapeutic Drugs & Cleansing Agents",
        aliases: ["drug target interaction", "enzymes as drug targets", "tranquilizers antimicrobials", "cleansing action of soaps micelles"],
        keywords: [
          "chemistry in everyday life",
          "drugs classification analgesics antibiotics antiseptics",
          "paracetamol aspirin ibuprofen",
          "bactericidal vs bacteriostatic antibiotics",
          "tincture of iodine dettol chloroxylenol",
          "saccharin aspartame sucralose alitame",
          "cationic anionic non-ionic detergents",
        ],
        subtopics: [
          { name: "Medicines & Drug Action", aliases: ["pharmacology basics"], keywords: ["agonist and antagonist drugs", "narcotic and non-narcotic analgesics", "broad spectrum antibiotics penicillin ampicillin"] },
          { name: "Chemicals in Food & Cleansing", aliases: ["soaps and food additives"], keywords: ["food preservatives sodium benzoate", "hydrophobic and hydrophilic soap ends", "biodegradable detergents"] },
        ],
      },
    ],
  },
  {
    id: "chem-metallurgy",
    name: "General Principles and Processes of Isolation of Elements (Metallurgy)",
    aliases: [
      "metallurgy",
      "isolation of elements",
      "ellingham diagram",
      "blast furnace",
      "extraction of iron",
      "extraction of copper",
      "extraction of aluminum",
      "froth floatation process",
      "hall heroult process",
    ],
    unit: "Inorganic Chemistry",
    classLevel: "Class 12",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 6,
    topics: [
      {
        id: "chem-extraction-processes",
        name: "Thermodynamic Principles & Extraction of Metals",
        aliases: ["pyrometallurgy electrometallurgy hydrometallurgy", "calcination and roasting", "refining methods zone refining van arkel mond process"],
        keywords: [
          "metallurgy class 12",
          "ellingham diagram",
          "extraction of iron copper and aluminum",
          "blast furnace reactions haematite",
          "hall-heroult electrolytic process bauxite",
          "froth floatation collectors and pine oil",
          "cyanide leaching process gold and silver",
        ],
        subtopics: [
          { name: "Thermodynamics & Pyrometallurgy", aliases: ["ellingham delta g curves"], keywords: ["feasibility of reduction delta g negative", "reducing agent carbon vs co", "flux and slag formation"] },
          { name: "Refining & Extraction of Key Metals", aliases: ["metal refining"], keywords: ["zone refining silicon germanium", "van arkel zirconium titanium", "mond process nickel", "copper matte bessemerization"] },
        ],
      },
    ],
  },
  {
    id: "chem-gaseous-state",
    name: "States of Matter: Gaseous and Liquid States",
    aliases: [
      "gaseous state",
      "states of matter",
      "real gases",
      "van der waals equation",
      "compressibility factor z",
      "boyle temperature",
      "critical constants tc pc vc",
      "liquefaction of gases",
    ],
    unit: "Physical Chemistry",
    classLevel: "Class 11",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 5,
    topics: [
      {
        id: "chem-real-gases",
        name: "Real Gases & Van der Waals Equation",
        aliases: ["ideal gas equation deviations", "intermolecular forces dispersion dipole hydrogen", "compressibility factor z = pv/nrt"],
        keywords: [
          "gaseous state class 11",
          "real gases and van der waals equation",
          "compressibility factor z",
          "pressure and volume correction factors a and b",
          "boyle temperature tb = a/rb",
          "critical temperature tc = 8a/27rb",
          "surface tension and viscosity in liquids",
        ],
        subtopics: [
          { name: "Van der Waals Equation & Corrections", aliases: ["real gas equations"], keywords: ["molecular attraction correction a/v^2", "effective molecular volume b", "units of van der waals constants a and b"] },
          { name: "Compressibility Factor & Critical State", aliases: ["z factor and liquefaction"], keywords: ["z vs p isotherms", "liquefaction of gases amagat experiment", "intermolecular forces london forces"] },
        ],
      },
    ],
  },
  {
    id: "chem-qualitative-analysis",
    name: "Practical Chemistry & Qualitative Analysis",
    aliases: [
      "inorganic qualitative analysis",
      "salt analysis",
      "cation and anion analysis",
      "group reagents for basic radicals",
      "confirmatory tests for anions",
      "brown ring test for nitrate",
      "flame test colors",
    ],
    unit: "Inorganic Chemistry",
    classLevel: "Class 12",
    exams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Class 12", "CBSE Boards", "NCERT"],
    topics: [
      {
        id: "chem-salt-tests",
        name: "Cation and Anion Group Reagents & Tests",
        aliases: ["systematic salt analysis", "group 0 to group 6 cations", "dilute h2so4 and conc h2so4 group anions"],
        keywords: [
          "inorganic qualitative analysis",
          "salt analysis cation and anion group reagents",
          "group 1 pb2+ group 2 cu2+ group 3 fe3+ al3+",
          "group reagents hcl h2s nh4oh nh4cl",
          "confirmatory tests sulfate chloride nitrate carbonate",
          "chromyl chloride test for chloride",
          "borax bead test colors",
        ],
        subtopics: [
          { name: "Cation Analysis Groups", aliases: ["basic radicals group reagents"], keywords: ["precipitation of sulfides in acidic vs basic medium", "solubility product ksp in group separation", "ksp and common ion effect in salt analysis"] },
          { name: "Anion Analysis Confirmatory Tests", aliases: ["acid radicals tests"], keywords: ["brown ring test feasibility", "lead acetate test for sulfide", "barium chloride test for sulfate"] },
        ],
      },
    ],
  },

];

// ====================================================================
// 3. MATHEMATICS KNOWLEDGE GRAPH (JEE Main/Adv, CBSE 11 & 12)
// ====================================================================

const MATHEMATICS_CHAPTERS: AcademicChapterNode[] = [
  // Class 11 Mathematics
  {
    id: "math-sets-relations-11",
    name: "Sets and Relations",
    aliases: ["sets", "types of sets", "subsets", "power set", "venn diagrams", "cartesian product of sets", "relations class 11"],
    unit: "Sets and Functions",
    classLevel: "Class 11",
    exams: ["JEE Main", "JEE Advanced", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 1,
    topics: [
      {
        id: "math-sets-venn",
        name: "Sets Operations & Venn Diagrams",
        aliases: ["union intersection complement difference of sets", "de morgan's laws sets", "cardinality of sets n(A U B)"],
        keywords: ["subsets power set formula 2^n", "venn diagrams word problems", "cartesian product a x b number of relations 2^(mn)"],
        subtopics: [{ name: "Set Operations", aliases: ["venn diagrams"], keywords: ["union intersection laws", "cardinality word problems"] }],
      },
    ],
  },
  {
    id: "math-quadratic-equations",
    name: "Quadratic Equations and Complex Numbers",
    aliases: [
      "quadratic equations",
      "quadratic equations and complex numbers",
      "nature of roots",
      "location of roots",
      "graphical analysis of quadratic",
      "graphical analysis",
      "discriminant",
      "complex numbers",
      "modulus and argument of complex numbers",
      "argand plane",
      "euler form",
      "de moivre theorem",
    ],
    unit: "Algebra",
    classLevel: "Class 11",
    exams: ["JEE Main", "JEE Advanced", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 4,
    topics: [
      {
        id: "math-quadratic-roots",
        name: "Nature of Roots, Location of Roots & Graphical Analysis",
        aliases: ["nature of roots location of roots", "location of roots conditions", "quadratic graph parabola upward downward", "maximum minimum value of quadratic -d/4a"],
        keywords: ["quadratic equations", "nature of roots", "location of roots", "graphical analysis", "discriminant d > 0 d = 0 d < 0", "sum and product of roots vieta relations", "common roots condition", "roots lie between k1 and k2"],
        subtopics: [
          { name: "Location of Roots", aliases: ["conditions on roots"], keywords: ["both roots greater than k", "roots separated by k", "both roots in interval"] },
          { name: "Complex Numbers Algebra", aliases: ["modulus argument polar form"], keywords: ["i = root -1 powers of iota", "conjugate properties", "triangle inequality in complex numbers"] },
        ],
      },
    ],
  },
  {
    id: "math-pnc",
    name: "Permutations and Combinations",
    aliases: [
      "permutations and combinations",
      "permutations and combinations pnc",
      "pnc",
      "p & c",
      "fundamental principle of counting",
      "permutations npr",
      "combinations ncr",
      "circular permutations",
      "group distribution",
      "division into groups",
      "derangements",
    ],
    unit: "Algebra",
    classLevel: "Class 11",
    exams: ["JEE Main", "JEE Advanced", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 6,
    topics: [
      {
        id: "math-pnc-advanced",
        name: "Combinatorics, Circular Permutations & Group Distribution",
        aliases: ["circular permutations (n-1)!", "division of objects into groups m+n! / m! n!", "rank of a word in dictionary", "beggar's method multiset combinations"],
        keywords: ["permutations and combinations pnc", "circular permutations", "group distribution", "fundamental counting principle addition multiplication", "npr and ncr formulas", "selection and arrangement problems", "gap method and tie method"],
        subtopics: [
          { name: "Circular Permutations & Grouping", aliases: ["necklace problems"], keywords: ["circular arrangement clockwise anticlockwise", "division into equal and unequal groups", "distribution of distinct objects"] },
          { name: "Multiset & Generating Principles", aliases: ["beggar method"], keywords: ["number of non-negative integer solutions", "derangement formula", "inclusion exclusion principle"] },
        ],
      },
    ],
  },
  {
    id: "math-binomial",
    name: "Binomial Theorem",
    aliases: [
      "binomial theorem",
      "binomial expansion",
      "general term in binomial expansion",
      "middle term in binomial expansion",
      "sum of binomial coefficients",
      "properties of binomial coefficients",
      "greatest binomial coefficient",
      "rational terms in binomial expansion",
    ],
    unit: "Algebra",
    classLevel: "Class 11",
    exams: ["JEE Main", "JEE Advanced", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 7,
    topics: [
      {
        id: "math-binomial-terms",
        name: "General Term, Middle Term & Binomial Coefficients",
        aliases: ["general term tr+1 = ncr x^(n-r) a^r", "middle term n even and odd", "c0 + c1 + c2 + ... + cn = 2^n", "term independent of x"],
        keywords: ["binomial theorem", "general term", "middle term", "sum of binomial coefficients", "term independent of x calculation", "series involving binomial coefficients differentiation integration method"],
        subtopics: [
          { name: "General & Middle Term", aliases: ["tr+1 formula"], keywords: ["finding coefficient of x^k", "middle term index n/2 or (n+1)/2", "greatest term in expansion"] },
          { name: "Coefficient Series", aliases: ["sum of c_r"], keywords: ["sum of odd and even coefficients", "differentiation of binomial identity", "multinomial expansion basics"] },
        ],
      },
    ],
  },
  {
    id: "math-sequences-series",
    name: "Sequences and Series",
    aliases: [
      "sequences and series",
      "arithmetic progression",
      "ap",
      "geometric progression",
      "gp",
      "harmonic progression",
      "hp",
      "agp",
      "arithmetico-geometric series",
      "arithmetico geometric progression",
      "sum to n terms of special series",
      "am gm inequality",
      "infinite gp sum a/(1-r)",
    ],
    unit: "Algebra",
    classLevel: "Class 11",
    exams: ["JEE Main", "JEE Advanced", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 8,
    topics: [
      {
        id: "math-ap-gp-agp",
        name: "AP, GP, HP and AGP Series Problems",
        aliases: ["arithmetic progression nth term sum", "geometric progression sum infinite gp", "arithmetico geometric series s = a + (a+d)r + (a+2d)r^2", "am >= gm inequality for positive numbers"],
        keywords: ["sequences and series", "ap gp hp and agp", "arithmetico-geometric series problems", "sum of first n natural numbers n(n+1)/2", "sum of squares n(n+1)(2n+1)/6", "am gm inequality optimization problems", "insertion of arithmetic and geometric means"],
        subtopics: [
          { name: "AP and GP Properties", aliases: ["common difference common ratio"], keywords: ["properties of ap numbers", "infinite geometric series condition |r| < 1", "sum of gp formula"] },
          { name: "AGP and Special Series", aliases: ["agp sum method"], keywords: ["method of differences", "multiplying by r and subtracting for agp", "am gm hm relation am * hm = gm^2"] },
        ],
      },
    ],
  },
  {
    id: "math-straight-lines",
    name: "Straight Lines",
    aliases: [
      "straight lines",
      "straight lines class 11",
      "coordinate geometry straight lines",
      "slope of a line",
      "point slope form",
      "slope intercept form",
      "intercept form",
      "normal form",
      "distance between parallel lines",
      "perpendicular distance of a point",
      "pair of lines",
      "pair of straight lines",
      "family of lines",
    ],
    unit: "Coordinate Geometry",
    classLevel: "Class 11",
    exams: ["JEE Main", "JEE Advanced", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 9,
    topics: [
      {
        id: "math-line-equations",
        name: "Point Slope Form, Distance Between Lines & Pair of Lines",
        aliases: ["point slope form y - y1 = m(x - x1)", "distance between parallel lines |c1-c2|/root(a^2+b^2)", "perpendicular distance |ax1+by1+c|/root(a^2+b^2)", "homogeneous equation of second degree ax^2+2hxy+by^2=0", "angle between pair of lines tan theta = 2root(h^2-ab)/(a+b)"],
        keywords: ["straight lines", "point slope form", "distance between parallel lines", "pair of lines", "equation of line through two points", "intercept form x/a + y/b = 1", "concurrency of three lines determinant zero", "family of lines l1 + lambda l2 = 0"],
        subtopics: [
          { name: "Forms of Line Equations", aliases: ["slope and intercept forms"], keywords: ["point-slope form", "symmetric form", "parametric equation of straight line"] },
          { name: "Distances & Pair of Lines", aliases: ["distance between parallel lines"], keywords: ["distance formula parallel lines", "homogeneous equation angle", "condition for perpendicularity a+b=0"] },
        ],
      },
    ],
  },
  {
    id: "math-circles",
    name: "Circles",
    aliases: [
      "circles",
      "circles coordinate geometry",
      "standard equation of circle",
      "general equation of circle x^2+y^2+2gx+2fy+c=0",
      "tangent to circle",
      "normal to circle",
      "chord of contact",
      "family of circles",
      "director circle",
      "length of tangent root s1",
    ],
    unit: "Coordinate Geometry",
    classLevel: "Class 11",
    exams: ["JEE Main", "JEE Advanced", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 10,
    topics: [
      {
        id: "math-circle-tangents",
        name: "Tangent to Circle, Chord of Contact & Family of Circles",
        aliases: ["tangent condition c = +- a root(1+m^2)", "equation of tangent t = 0", "chord of contact t = 0 from external point", "chord with given midpoint t = s1", "family of circles s + lambda l = 0 and s1 + lambda s2 = 0"],
        keywords: ["circles coordinate geometry", "tangent to circle", "chord of contact", "family of circles", "intercept on axes", "length of tangent from point", "common tangents to two circles direct and transverse"],
        subtopics: [
          { name: "Tangents & Normals to Circle", aliases: ["condition of tangency"], keywords: ["tangent formula t=0", "director circle radius root 2 a", "point of contact of tangent"] },
          { name: "Chords & Intersection of Circles", aliases: ["chord of contact"], keywords: ["chord with given midpoint", "orthogonal intersection of circles 2g1g2+2f1f2=c1+c2", "radical axis"] },
        ],
      },
    ],
  },
  {
    id: "math-conic-sections",
    name: "Conic Sections",
    aliases: [
      "conic sections",
      "parabola",
      "ellipse",
      "hyperbola",
      "standard equations of conics",
      "eccentricity",
      "parabola ellipse and hyperbola",
      "latus rectum of conics",
      "focus and directrix",
      "tangent and normal to parabola",
      "tangent and normal to ellipse",
      "tangent and normal to hyperbola",
      "rectangular hyperbola xy = c^2",
    ],
    unit: "Coordinate Geometry",
    classLevel: "Class 11",
    exams: ["JEE Main", "JEE Advanced", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 11,
    topics: [
      {
        id: "math-conics-equations",
        name: "Parabola, Ellipse and Hyperbola Standard Equations",
        aliases: ["parabola standard equations y^2 = 4ax", "ellipse standard equation x^2/a^2 + y^2/b^2 = 1 eccentricity e = root(1 - b^2/a^2)", "hyperbola x^2/a^2 - y^2/b^2 = 1 e = root(1 + b^2/a^2)", "parametric coordinates on conics", "focal distances of ellipse and hyperbola"],
        keywords: ["conic sections", "parabola ellipse and hyperbola standard equations", "eccentricity", "latus rectum length 4a or 2b^2/a", "focal chord properties of parabola", "auxiliary circle and eccentric angle of ellipse", "asymptotes of hyperbola y = +- b/a x"],
        subtopics: [
          { name: "Parabola Analysis", aliases: ["y^2 = 4ax properties"], keywords: ["focus (a,0) directrix x+a=0", "tangent in slope form y = mx + a/m", "normal in slope form y = mx - 2am - am^3"] },
          { name: "Ellipse and Hyperbola", aliases: ["eccentricity and standard equations"], keywords: ["foci (+-ae, 0) directrices x = +-a/e", "sum of focal distances 2a", "difference of focal distances 2a for hyperbola"] },
        ],
      },
    ],
  },
  {
    id: "math-limits-derivatives",
    name: "Limits, Continuity and Derivatives",
    aliases: [
      "limits and continuity",
      "limits",
      "calculus limits",
      "indeterminate forms",
      "indeterminate forms 0/0",
      "l'hopital's rule",
      "l hopital rule",
      "standard limits",
      "sandwich theorem",
      "squeeze theorem",
      "evaluation of limits",
      "left hand limit and right hand limit",
      "algebra of limits",
    ],
    unit: "Calculus",
    classLevel: "Class 11",
    exams: ["JEE Main", "JEE Advanced", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 12,
    topics: [
      {
        id: "math-limits-eval",
        name: "L'Hopital's Rule, Standard Limits & Indeterminate Forms",
        aliases: ["l'hopital rule indeterminate forms 0/0 infinity/infinity", "standard limits lim x->0 sin x / x = 1", "lim x->0 (e^x - 1)/x = 1 and (a^x - 1)/x = ln a", "lim x->0 (1+x)^(1/x) = e form 1^infinity"],
        keywords: ["limits and continuity", "l'hopital's rule", "standard limits", "indeterminate forms 0/0", "1^infinity form e^(lim (f-1)g)", "factorization and rationalization limits", "expansion series for sin x cos x e^x ln(1+x)"],
        subtopics: [
          { name: "Standard Limits & 1^Infinity Form", aliases: ["trigonometric and exponential limits"], keywords: ["lim sin x / x = 1", "1 to the power infinity shortcut e^(lim (f-1)g)", "algebraic limits rationalization"] },
          { name: "L'Hopital's Rule & Expansions", aliases: ["l hopital differentiation of numerator and denominator"], keywords: ["differentiating until form is eliminated", "taylor series expansions for limits", "sandwich theorem applications"] },
        ],
      },
    ],
  },

  // Class 12 Mathematics
  {
    id: "math-relations-functions",
    name: "Relations and Functions",
    aliases: ["types of relations", "reflexive symmetric transitive equivalence relation", "types of functions", "one-one onto bijective function", "composition of functions", "invertible functions"],
    unit: "Calculus / Algebra",
    classLevel: "Class 12",
    exams: ["JEE Main", "JEE Advanced", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 1,
    topics: [
      {
        id: "math-equiv-bijection",
        name: "Equivalence Relations and Bijective Functions",
        aliases: ["equivalence relation proof", "injective surjective bijective mapping", "domain and range of composite function gof fog", "finding inverse of bijective function"],
        keywords: ["reflexive relation a r a", "symmetric relation a r b implies b r a", "transitive relation a r b and b r c implies a r c", "one to one injective f(x1) = f(x2) implies x1 = x2", "onto surjective range equals codomain", "inverse function f^-1"],
        subtopics: [{ name: "Relations Classification", aliases: ["equivalence class"], keywords: ["number of equivalence relations", "equivalence classes", "reflexive symmetric transitive"] }],
      },
    ],
  },
  {
    id: "math-itf",
    name: "Inverse Trigonometric Functions",
    aliases: ["itf", "inverse trig functions", "principal value branch", "domain and range of inverse trig", "properties of inverse trigonometric functions", "simplification of inverse trig expressions"],
    unit: "Trigonometry / Calculus",
    classLevel: "Class 12",
    exams: ["JEE Main", "JEE Advanced", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 2,
    topics: [
      {
        id: "math-itf-properties",
        name: "Principal Values and ITF Identities",
        aliases: ["principal value branch table sin^-1 cos^-1 tan^-1", "tan^-1 x + tan^-1 y formula", "2 tan^-1 x formulas in terms of sin cos tan", "sin^-1(-x) and cos^-1(-x) = pi - cos^-1(x)"],
        keywords: ["principal value of inverse trigonometric functions", "domain and range of sin inverse -pi/2 to pi/2", "domain of cos inverse [0, pi]", "tan^-1 x + tan^-1 y = tan^-1((x+y)/(1-xy))", "substitution method in inverse trig simplification"],
        subtopics: [{ name: "Principal Value Evaluations", aliases: ["itf branch domains"], keywords: ["principal branch values", "graphs of inverse trig functions", "sum and difference formulas"] }],
      },
    ],
  },
  {
    id: "math-matrices-determinants",
    name: "Matrices and Determinants",
    aliases: ["matrices", "determinants", "matrix operations", "transpose of matrix", "symmetric and skew-symmetric matrices", "adjoint and inverse of a matrix", "properties of determinants", "cramer's rule", "system of linear equations using matrix method"],
    unit: "Algebra",
    classLevel: "Class 12",
    exams: ["JEE Main", "JEE Advanced", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 3,
    topics: [
      {
        id: "math-matrix-inverse-system",
        name: "Matrix Inverse & System of Linear Equations",
        aliases: ["a inverse = 1/|a| adj a", "properties of adjoint |adj a| = |a|^(n-1)", "orthogonal matrix", "consistent and inconsistent systems ax = b", "solving 3x3 system by matrix inversion", "area of triangle by determinants"],
        keywords: ["matrix multiplication conditions", "symmetric and skew symmetric matrix decomposition a = 1/2(a+at) + 1/2(a-at)", "determinant expansion along row column", "minors and cofactors", "adjoint of a matrix", "inverse of 3x3 matrix", "solving linear equations by matrix method ax = b"],
        subtopics: [
          { name: "Adjoint and Inverse Properties", aliases: ["adjoint formulas determinants"], keywords: ["adj(ab) = adj(b) adj(a)", "determinant of adjoint of adjoint", "inverse properties"] },
          { name: "Linear Systems (AX = B)", aliases: ["cramer rule consistency"], keywords: ["unique solution |a| != 0", "infinite solutions or no solution", "rank of matrix in jee advanced"] },
        ],
      },
    ],
  },
  {
    id: "math-continuity-diff",
    name: "Continuity and Differentiability",
    aliases: ["continuity of functions", "differentiability at a point", "derivatives", "chain rule", "implicit differentiation", "logarithmic differentiation", "parametric differentiation", "second order derivatives", "rolle's theorem and lmvt"],
    unit: "Calculus",
    classLevel: "Class 12",
    exams: ["JEE Main", "JEE Advanced", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 5,
    topics: [
      {
        id: "math-diff-techniques",
        name: "Differentiation Methods & Differentiability",
        aliases: ["left hand derivative and right hand derivative lhd rhd", "continuity condition lim x->a f(x) = f(a)", "derivative of implicit function f(x, y) = 0", "derivative of y = u(x)^v(x) by logs", "second order derivative d2y/dx2 in parametric form"],
        keywords: ["continuity of composite and trigonometric functions", "differentiability implies continuity proof", "chain rule dy/dx = dy/du * du/dx", "logarithmic differentiation for variable powers", "parametric differentiation dy/dx = (dy/dt)/(dx/dt)", "second derivative d2y/dx2 = d/dt(dy/dx) * dt/dx"],
        subtopics: [
          { name: "Continuity & Non-Differentiability Checks", aliases: ["corner sharp points"], keywords: ["modulus function non differentiable at zero", "step function discontinuities", "lhd and rhd equality"] },
          { name: "Higher Order Derivatives & Parametric", aliases: ["second derivative questions"], keywords: ["parametric second derivative trap", "successive differentiation", "implicit differentiation"] },
        ],
      },
    ],
  },
  {
    id: "math-aod",
    name: "Application of Derivatives",
    aliases: ["aod", "rate of change of quantities", "increasing and decreasing functions", "tangents and normals", "maxima and minima", "first derivative test", "second derivative test", "applied optimization problems"],
    unit: "Calculus",
    classLevel: "Class 12",
    exams: ["JEE Main", "JEE Advanced", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 6,
    topics: [
      {
        id: "math-maxima-minima",
        name: "Increasing/Decreasing & Maxima-Minima",
        aliases: ["monotonicity f'(x) > 0 strictly increasing", "critical points f'(x) = 0 or undefined", "local maxima and minima second derivative test", "global absolute maxima and minima in closed interval", "word problems in optimization cylinder cone sphere"],
        keywords: ["rate measure word problems", "slope of tangent dy/dx and normal -1/(dy/dx)", "intervals where function is increasing decreasing", "first and second derivative test for extrema", "maximum volume of cylinder inscribed in cone", "optimization word problems class 12"],
        subtopics: [
          { name: "Monotonicity and Critical Points", aliases: ["increasing decreasing intervals"], keywords: ["f'(x) >= 0 condition", "finding intervals of increase decrease", "point of inflection"] },
          { name: "Applied Maxima and Minima Word Problems", aliases: ["optimization problems aod"], keywords: ["mensuration optimization in aod", "perimeter fixed maximum area", "box made from sheet"] },
        ],
      },
    ],
  },
  {
    id: "math-integrals",
    name: "Integrals (Indefinite and Definite)",
    aliases: ["integration", "indefinite integrals", "definite integrals", "integration by substitution", "integration by parts", "integration by partial fractions", "properties of definite integrals", "king's rule", "queen's rule", "leibniz integral rule", "fundamental theorem of calculus"],
    unit: "Calculus",
    classLevel: "Class 12",
    exams: ["JEE Main", "JEE Advanced", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 7,
    topics: [
      {
        id: "math-definite-properties",
        name: "Definite Integral Properties & Kings Rule",
        aliases: ["integral 0 to a f(x) dx = integral 0 to a f(a-x) dx", "integral a to b f(x) dx = integral a to b f(a+b-x) dx kings property", "odd and even function integral -a to a f(x) dx", "integral 0 to 2a f(x) dx queens property", "leibniz differentiation under integral sign"],
        keywords: ["standard indefinite integral formulas", "integration by parts u v - integral v du ilate rule", "partial fractions linear and quadratic factors", "properties of definite integrals proof", "king property applications in trig integrals", "periodicity in definite integrals", "limit of sum definition of definite integral"],
        subtopics: [
          { name: "Definite Integral Properties (King/Queen)", aliases: ["kings rule integrals"], keywords: ["integral 0 to pi/2 log sin x dx = -pi/2 log 2", "a+b-x substitution", "even odd symmetry integrals"] },
          { name: "Indefinite Integration Methods", aliases: ["by parts partial fractions"], keywords: ["ilate rule", "partial fraction decomposition", "substitution method integrals"] },
        ],
      },
    ],
  },
  {
    id: "math-aoi",
    name: "Application of Integrals",
    aliases: ["area under curves", "aoi", "area bounded by curve and line", "area between two parabolas", "area of circle and ellipse using integration", "symmetrical areas"],
    unit: "Calculus",
    classLevel: "Class 12",
    exams: ["JEE Main", "JEE Advanced", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 8,
    topics: [
      {
        id: "math-area-curves",
        name: "Area Under Curves and Between Curves",
        aliases: ["area integral y dx or x dy", "area bounded by parabola y^2 = 4ax and line y = mx", "area between y = sin x and y = cos x", "intersection points of curves for limits of integration"],
        keywords: ["area between two curves integral (y_upper - y_lower) dx", "area bounded by circle and line", "area of ellipse pi a b integration proof", "sketching region of integration", "modulus functions area under curve"],
        subtopics: [{ name: "Bounded Region Integrations", aliases: ["area between standard curves"], keywords: ["parabola and straight line area", "area of standard ellipse and circle", "absolute value curves area"] }],
      },
    ],
  },
  {
    id: "math-differential-equations",
    name: "Differential Equations",
    aliases: ["order and degree of differential equation", "formation of differential equation", "solution of differential equations", "variable separable method", "homogeneous differential equations", "linear differential equations lde", "integrating factor if = e^integral p dx"],
    unit: "Calculus",
    classLevel: "Class 12",
    exams: ["JEE Main", "JEE Advanced", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 9,
    topics: [
      {
        id: "math-lde-homogeneous",
        name: "Variable Separable, Homogeneous & Linear DE",
        aliases: ["first order linear differential equation dy/dx + py = q", "integrating factor if = exp(integral p dx)", "solution y(if) = integral q(if) dx + c", "homogeneous de substitution y = vx", "order and degree polynomials in derivatives"],
        keywords: ["order is highest order derivative", "degree is power of highest derivative when free of radicals", "general and particular solutions of de", "variable separable f(x)dx = g(y)dy", "homogeneous function degree zero", "linear differential equations dy/dx + py = q and dx/dy + px = q"],
        subtopics: [
          { name: "Linear Differential Equations (LDE)", aliases: ["integrating factor lde"], keywords: ["finding integrating factor if", "standard solution form y * if", "particular solution using initial condition"] },
          { name: "Homogeneous and Separable DE", aliases: ["y = vx substitution"], keywords: ["variable separable method", "homogeneous differential equation check f(tx, ty) = t^n f(x, y)"] },
        ],
      },
    ],
  },
  {
    id: "math-vectors-3d",
    name: "Vector Algebra and Three-Dimensional Geometry",
    aliases: ["vectors in mathematics", "vector algebra", "dot product", "cross product", "scalar triple product stp", "three dimensional geometry", "3d geometry", "direction cosines and direction ratios", "equation of line in space", "angle between two lines", "shortest distance between two skew lines", "equation of plane", "coplanarity of lines"],
    unit: "Vectors and 3D",
    classLevel: "Class 12",
    exams: ["JEE Main", "JEE Advanced", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 10,
    topics: [
      {
        id: "math-3d-lines-planes",
        name: "3D Lines, Skew Lines & Shortest Distance",
        aliases: ["vector equation of line r = a + lambda b", "cartesian equation of line (x-x1)/a = (y-y1)/b = (z-z1)/c", "shortest distance between skew lines |(b1 cross b2) dot (a2 - a1)| / |b1 cross b2|", "angle between two lines cos theta = (b1 dot b2)/(|b1||b2|)", "equation of plane r dot n = d"],
        keywords: ["direction cosines l m n relation l^2 + m^2 + n^2 = 1", "direction ratios a b c", "vector and cartesian forms of line", "shortest distance between parallel lines", "coplanar lines condition [a2-a1, b1, b2] = 0", "vector triple product a cross (b cross c)"],
        subtopics: [
          { name: "Lines in 3D & Skew Distance", aliases: ["shortest distance lines 3d"], keywords: ["shortest distance between skew lines formula", "distance between parallel lines", "line passing through two points"] },
        ],
      },
    ],
  },
  {
    id: "math-probability",
    name: "Probability",
    aliases: ["probability class 12", "conditional probability p(a|b)", "multiplication theorem of probability", "independent events p(a cap b) = p(a)p(b)", "bayes' theorem", "total probability theorem", "random variable and probability distribution", "mean and variance of random variable", "binomial distribution"],
    unit: "Probability",
    classLevel: "Class 12",
    exams: ["JEE Main", "JEE Advanced", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 13,
    topics: [
      {
        id: "math-bayes-random-vars",
        name: "Bayes' Theorem & Probability Distribution",
        aliases: ["conditional probability p(a|b) = p(a cap b)/p(b)", "bayes theorem posterior probability p(e1|a)", "theorem of total probability", "probability distribution table mean sigma pi xi", "bernoulli trials and binomial distribution ncr p^r q^(n-r)"],
        keywords: ["conditional probability properties", "independent events proof", "bayes theorem formula p(ei|a) = p(ei)p(a|ei) / sum p(ej)p(a|ej)", "urn and bag problem with balls bayes theorem", "defective item manufacturing machine bayes theorem", "probability distribution of random variable"],
        subtopics: [
          { name: "Bayes' Theorem Applications", aliases: ["bayes theorem problems"], keywords: ["bag ball problems", "machine production defective items", "medical diagnosis bayes theorem"] },
          { name: "Random Variables and Distributions", aliases: ["expected value mean"], keywords: ["probability mass function", "sum of probabilities is 1", "mean of probability distribution"] },
        ],
      },
    ],
  },
  {
    id: "math-linear-programming",
    name: "Linear Programming",
    aliases: [
      "linear programming",
      "lpp",
      "linear programming class 12",
      "graphical feasible region",
      "corner point method",
      "objective function z = ax + by",
      "constraints linear inequalities",
      "bounded and unbounded feasible region",
      "optimization problems in lpp",
    ],
    unit: "Linear Programming",
    classLevel: "Class 12",
    exams: ["CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 12,
    topics: [
      {
        id: "math-lpp-graphical",
        name: "Graphical Feasible Region & Corner Point Method",
        aliases: ["corner point theorem optimal value occurs at vertex", "graphing linear inequality half planes", "unbounded region test ax+by > M or < m", "feasible region and infeasible problem"],
        keywords: ["linear programming class 12", "graphical feasible region", "corner point method", "maximizing or minimizing objective function", "decision variables x and y >= 0", "iso-profit iso-cost line method"],
        subtopics: [
          { name: "Feasible Region Determination", aliases: ["shading half planes"], keywords: ["finding boundary lines and intercepts", "intersection of inequalities", "corner points coordinates"] },
          { name: "Optimal Solution Calculation", aliases: ["corner point table"], keywords: ["table of corner points and z values", "unbounded feasible region verification", "multiple optimal solutions on line segment"] },
        ],
      },
    ],
  },
  {
    id: "math-mean-value-theorems",
    name: "Differentiability & Mean Value Theorems",
    aliases: [
      "differential calculus",
      "rolle's theorem",
      "rolles theorem",
      "lagrange's mean value theorem",
      "lagranges mean value theorem",
      "lmvt",
      "mean value theorems",
      "mean value theorem",
    ],
    unit: "Calculus",
    classLevel: "Class 12",
    exams: ["JEE Main", "JEE Advanced", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 5,
    topics: [
      {
        id: "math-mvt-rolles",
        name: "Rolle's & Lagrange's Mean Value Theorems",
        aliases: ["geometric interpretation of rolles theorem horizontal tangent", "lmvt tangent parallel to secant line", "cauchy's mean value theorem"],
        keywords: [
          "differential calculus",
          "rolle's theorem",
          "lagrange's mean value theorem lmvt",
          "continuity in closed interval a b",
          "differentiability in open interval a b",
          "f prime c equals zero",
          "f prime c equals f(b) minus f(a) over b minus a",
        ],
        subtopics: [
          { name: "Rolle's Theorem Verification", aliases: ["rolles theorem conditions"], keywords: ["polynomial and trigonometric functions continuity", "finding c where derivative vanishes"] },
          { name: "LMVT Verification & Applications", aliases: ["lagranges theorem secant slope"], keywords: ["proving inequalities using mean value theorem", "root separation using rolles theorem"] },
        ],
      },
    ],
  },
  {
    id: "math-statistics",
    name: "Statistics",
    aliases: [
      "statistics",
      "mean deviation",
      "variance",
      "standard deviation",
      "measures of dispersion",
      "coefficient of variation",
      "frequency distribution statistics",
    ],
    unit: "Statistics & Probability",
    classLevel: "Class 11",
    exams: ["JEE Main", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 15,
    topics: [
      {
        id: "math-stat-dispersion",
        name: "Measures of Dispersion, Variance & Standard Deviation",
        aliases: ["mean deviation about mean and median", "variance sigma squared formula", "standard deviation sigma root of variance", "short cut method for mean and variance"],
        keywords: [
          "statistics class 11",
          "mean deviation variance standard deviation",
          "sum of squared deviations",
          "variance of grouped data",
          "standard deviation of continuous frequency distribution",
          "variance invariant under change of origin",
          "effect of change of scale on variance sigma prime = c^2 sigma",
        ],
        subtopics: [
          { name: "Mean Deviation Calculation", aliases: ["mean deviation from median"], keywords: ["mean deviation formula 1/n sigma |x_i - mean|", "median for grouped frequency distribution"] },
          { name: "Variance & Standard Deviation", aliases: ["variance formulas"], keywords: ["shortcut formula 1/n sigma x_i^2 - (x_bar)^2", "combined variance of two groups", "coefficient of variation cv = sd/mean * 100"] },
        ],
      },
    ],
  },
  {
    id: "math-reasoning",
    name: "Mathematical Reasoning",
    aliases: [
      "mathematical reasoning",
      "truth tables",
      "negation",
      "tautology",
      "contradiction",
      "contrapositive",
      "converse and inverse",
      "compound statements",
    ],
    unit: "Mathematical Reasoning",
    classLevel: "Class 11",
    exams: ["JEE Main", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 14,
    topics: [
      {
        id: "math-reasoning-logic",
        name: "Propositional Logic, Truth Tables & Equivalences",
        aliases: ["conjunction and disjunction and or", "conditional p implies q", "biconditional p if and only if q", "demorgan laws for logic"],
        keywords: [
          "mathematical reasoning class 11",
          "truth tables negation tautology contrapositive",
          "contrapositive of p implies q is not q implies not p",
          "converse is q implies p",
          "inverse is not p implies not q",
          "tautology always true",
          "contradiction always false",
        ],
        subtopics: [
          { name: "Truth Tables & Connectives", aliases: ["logic truth tables"], keywords: ["truth value of conditional and biconditional", "negation of compound statements", "equivalence of propositions"] },
          { name: "Contrapositive & Duality", aliases: ["contrapositive statements"], keywords: ["writing contrapositive of mathematical statements", "direct vs indirect proof contrapositive method"] },
        ],
      },
    ],
  },
  {
    id: "math-heights-distances",
    name: "Heights and Distances",
    aliases: [
      "height and distances",
      "heights and distances",
      "angle of elevation",
      "angle of depression",
      "applications of trigonometry",
      "trigonometry word problems",
    ],
    unit: "Trigonometry",
    classLevel: "Class 11",
    exams: ["JEE Main", "CBSE Boards", "NCERT"],
    topics: [
      {
        id: "math-hd-applications",
        name: "Angles of Elevation & Depression in 2D and 3D",
        aliases: ["observer height and line of sight", "horizontal distance and tower heights", "two observer bearings and elevation angles"],
        keywords: [
          "height and distances",
          "angle of elevation and depression",
          "trigonometry word problems",
          "tangent of angle of elevation",
          "height of tower from two points",
          "shadow of flagstaff on tower",
          "3d height and distance problems with compass bearings",
        ],
        subtopics: [
          { name: "2D Triangulation", aliases: ["elevation and depression in plane"], keywords: ["right triangle trigonometry", "two equations in h and x", "speed of plane from changing angle of elevation"] },
          { name: "3D Spatial Problems", aliases: ["horizontal and vertical planes"], keywords: ["cosine rule in horizontal plane", "elevation from vertices of equilateral triangle"] },
        ],
      },
    ],
  },
  {
    id: "math-tangents-normals",
    name: "Tangents and Normals to Curves",
    aliases: [
      "tangent and normal",
      "tangents and normals",
      "slope of tangent",
      "slope of normal",
      "orthogonal curves",
      "angle between two curves",
      "length of subtangent and subnormal",
    ],
    unit: "Calculus",
    classLevel: "Class 12",
    exams: ["JEE Main", "JEE Advanced", "CBSE Class 12", "CBSE Boards", "NCERT"],
    topics: [
      {
        id: "math-tangent-derivatives",
        name: "Slope of Tangent & Orthogonal Intersections",
        aliases: ["equation of tangent y - y1 = m(x - x1)", "equation of normal y - y1 = -1/m(x - x1)", "condition for orthogonality m1 * m2 = -1"],
        keywords: [
          "tangent and normal to curves",
          "slope of tangent orthogonal curves class 12 calculus",
          "derivative dy/dx as slope of tangent",
          "tangents parallel to x-axis or y-axis",
          "angle of intersection between two curves tan theta = |m1 - m2 / (1 + m1 m2)|",
          "point of contact of tangent",
        ],
        subtopics: [
          { name: "Equations of Tangent and Normal", aliases: ["tangent lines"], keywords: ["differentiating parametric and implicit curves", "finding points on curve where tangent is parallel to given line"] },
          { name: "Orthogonality & Angles of Curves", aliases: ["orthogonal trajectories"], keywords: ["curves cutting at right angles", "finding value of parameter for orthogonal intersection"] },
        ],
      },
    ],
  },

];

// ====================================================================
// 4. BIOLOGY KNOWLEDGE GRAPH (NEET, CBSE Class 11 & 12)
// ====================================================================

const BIOLOGY_CHAPTERS: AcademicChapterNode[] = [
  // Class 11 Biology
  {
    id: "bio-cell-division",
    name: "Cell Cycle and Cell Division",
    aliases: [
      "cell cycle and cell division",
      "cell cycle and cell division class 11",
      "cell cycle",
      "mitosis",
      "meiosis",
      "mitosis and meiosis",
      "phases of cell cycle",
      "interphase g1 s g2 phase",
      "mitosis and meiosis phases",
      "mitosis and meiosis phases one shot",
      "crossing over in pachytene",
      "karyokinesis and cytokinesis",
      "chiasmata and synapsis",
    ],
    unit: "Cell Structure and Function",
    classLevel: "Class 11",
    exams: ["NEET", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 10,
    topics: [
      {
        id: "bio-mitosis-meiosis",
        name: "Mitosis and Meiosis Phases",
        aliases: ["mitosis equational division", "meiosis reductional division", "prophase 1 leptotene zygotene pachytene diplotene diakinesis", "synaptonemal complex and crossing over"],
        keywords: ["cell cycle and cell division", "mitosis and meiosis phases", "interphase s phase dna replication", "metaphase equatorial plate spindle fibers attach to kinetochore", "anaphase centromere split sister chromatids separate", "meiosis 1 reduction of chromosome number 2n to n", "recombinase enzyme in crossing over pachytene"],
        subtopics: [
          { name: "Phases of Mitosis", aliases: ["prophase metaphase anaphase telophase"], keywords: ["kinetochore attachment", "chromatin condensation", "cytokinesis cell plate vs furrow"] },
          { name: "Stages of Meiosis I & II", aliases: ["prophase 1 substages"], keywords: ["synapsis in zygotene", "crossing over in pachytene", "chiasmata dissolution diplotene"] },
        ],
      },
    ],
  },
  {
    id: "bio-photosynthesis",
    name: "Photosynthesis in Higher Plants",
    aliases: [
      "photosynthesis in higher plants",
      "photosynthesis",
      "plant physiology",
      "light reaction and dark reaction",
      "light reaction & calvin cycle",
      "calvin cycle c3 c4",
      "calvin cycle",
      "c3 and c4 pathways",
      "c4 pathway hatch and slack",
      "photorespiration",
      "krantz anatomy",
      "chemiosmotic hypothesis",
      "z scheme of light reaction",
    ],
    unit: "Plant Physiology",
    classLevel: "Class 11",
    exams: ["NEET", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 13,
    topics: [
      {
        id: "bio-light-calvin-cycle",
        name: "Light Reaction & Calvin Cycle C3 C4",
        aliases: ["z scheme photophosphorylation cyclic non cyclic", "calvin cycle carboxylation reduction regeneration rubisco", "c4 pathway pepcase oxaloacetic acid", "photorespiration c2 cycle"],
        keywords: ["photosynthesis in higher plants", "light reaction & calvin cycle c3 c4", "rubisco dual nature", "kranz anatomy in bundle sheath", "atp and nadph generation", "chemiosmotic hypothesis atp synthase"],
        subtopics: [
          { name: "Light Reactions & Photophosphorylation", aliases: ["z scheme cyclic non cyclic"], keywords: ["ps i and ps ii", "photolysis of water", "reaction centre p680 p700"] },
          { name: "Dark Reactions & C3/C4 Pathway", aliases: ["calvin cycle c4"], keywords: ["pga first stable product", "pep carboxylase", "lack of photorespiration in c4"] },
        ],
      },
    ],
  },
  {
    id: "bio-neural-control",
    name: "Neural Control and Coordination",
    aliases: [
      "neural control and coordination",
      "human physiology",
      "human nervous system",
      "nerve impulse conduction",
      "nerve impulse conduction synapse",
      "generation and conduction of nerve impulse",
      "transmission of impulses synapse",
      "action potential and resting membrane potential",
      "sodium potassium pump",
      "central nervous system cns brain and spinal cord",
      "reflex action and reflex arc",
    ],
    unit: "Human Physiology",
    classLevel: "Class 11",
    exams: ["NEET", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 21,
    topics: [
      {
        id: "bio-nerve-conduction-synapse",
        name: "Nerve Impulse Conduction & Synapse",
        aliases: ["resting potential -70mv depolarisation na+ influx repolarisation k+ efflux", "chemical synapse neurotransmitter acetylcholine synaptic cleft", "electrical synapse gap junctions"],
        keywords: ["neural control and coordination", "nerve impulse conduction synapse", "action potential generation", "synaptic vesicles releasing neurotransmitter", "myelinated and non-myelinated nerve fibers", "nodes of ranvier saltatory conduction"],
        subtopics: [
          { name: "Nerve Impulse Generation & Conduction", aliases: ["action potential saltatory"], keywords: ["polarised state resting membrane", "depolarisation sodium gate", "repolarisation potassium gate"] },
          { name: "Synaptic Transmission & CNS", aliases: ["chemical synapse neurotransmitters"], keywords: ["synaptic cleft receptors on postsynaptic membrane", "forebrain midbrain hindbrain", "hypothalamus pituitary link"] },
        ],
      },
    ],
  },

  // Class 12 Biology
  {
    id: "bio-reproduction-organisms",
    name: "Sexual Reproduction in Flowering Plants",
    aliases: ["plant reproduction", "sexual reproduction in angiosperms", "structure of stamen and microsporangium", "microsporogenesis and pollen grain", "structure of carpel and megasporangium ovule", "megasporogenesis and female gametophyte embryo sac", "types of pollination autogamy geitonogamy xenogamy", "agents of pollination", "outbreeding devices", "pollen pistil interaction", "double fertilization", "endosperm and embryo development", "seed and fruit formation", "apomixis and polyembryony"],
    unit: "Reproduction",
    classLevel: "Class 12",
    exams: ["NEET", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 1,
    topics: [
      {
        id: "bio-double-fert",
        name: "Gametophyte Development & Double Fertilization",
        aliases: ["microsporogenesis pollen formation", "megasporogenesis monosporic 7 celled 8 nucleate embryo sac", "double fertilization syngamy and triple fusion", "endosperm types free nuclear and cellular endosperm of coconut"],
        keywords: ["tapetum nourishing pollen grains", "sporopollenin in exine of pollen", "structure of anatropous ovule", "filiform apparatus in synergids", "anemophily hydrophily entomophily pollination adaptations", "double fertilization pen primary endosperm nucleus 3n", "embryo development in dicots and monocots", "apomixis seed production without fertilisation"],
        subtopics: [
          { name: "Micro- & Megasporogenesis", aliases: ["embryo sac development"], keywords: ["7 celled 8 nucleated structure", "pollen viability", "vegetative and generative cell"] },
          { name: "Double Fertilization & Post-Fertilization", aliases: ["syngamy and triple fusion"], keywords: ["triple fusion", "zygote and primary endosperm cell", "perisperm in black pepper"] },
        ],
      },
    ],
  },
  {
    id: "bio-human-reproduction",
    name: "Human Reproduction & Reproductive Health",
    aliases: ["human reproduction", "male reproductive system testes seminiferous tubules", "female reproductive system ovaries fallopian tube uterus", "gametogenesis", "spermatogenesis hormonal control", "oogenesis", "menstrual cycle phases follicular ovulatory luteal", "fertilization and implantation blastocyst", "pregnancy and placenta formation", "parturition and lactation", "reproductive health", "contraceptive methods", "medical termination of pregnancy mtp", "sexually transmitted infections stis", "infertility art ivf test tube baby"],
    unit: "Reproduction",
    classLevel: "Class 12",
    exams: ["NEET", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 2,
    topics: [
      {
        id: "bio-gameto-menstrual",
        name: "Spermatogenesis, Oogenesis & Menstrual Cycle",
        aliases: ["spermatogenesis vs oogenesis differences", "structure of sperm acrosome middle piece mitochondria", "graafian follicle and corpus luteum", "hormonal control lh fsh estrogen progesterone in menstrual cycle", "lh surge triggering ovulation on day 14", "cleavage morula blastocyst implantation in endometrium"],
        keywords: ["sertoli cells and leydig cells testosterone", "polar bodies in oogenesis", "phases of menstrual cycle menstrual proliferative secretory", "acrosomal reaction in fertilization", "hCG hPL relaxin pregnancy hormones", "parturition oxytocin neuroendocrine reflex foetal ejection reflex", "colostrum antibodies iga"],
        subtopics: [
          { name: "Menstrual Cycle & Hormones", aliases: ["lh surge ovulation"], keywords: ["estrogen and progesterone peaks", "corpus luteum role", "follicular development"] },
          { name: "Contraception and ART", aliases: ["ivf test tube baby"], keywords: ["iuds copper t", "oral contraceptive pills saheli", "ivf-et zift gift icsi art techniques"] },
        ],
      },
    ],
  },
  {
    id: "bio-genetics-variation",
    name: "Principles of Inheritance and Variation",
    aliases: ["genetics", "mendelian genetics", "mendel's laws of inheritance", "law of segregation", "law of independent assortment", "monohybrid cross and dihybrid cross", "incomplete dominance and codominance", "multiple alleles abo blood grouping", "pleiotropy and polygenic inheritance", "chromosomal theory of inheritance sutton and boveri", "linkage and recombination morgan drosophila", "sex determination in humans birds and honey bee", "pedigree analysis", "genetic disorders mendelian and chromosomal"],
    unit: "Genetics and Evolution",
    classLevel: "Class 12",
    exams: ["NEET", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 4,
    topics: [
      {
        id: "bio-mendel-linkage",
        name: "Mendelian Laws, Linkage & Genetic Disorders",
        aliases: ["monohybrid 3:1 phenotypic 1:2:1 genotypic ratio", "dihybrid 9:3:3:1 ratio", "incomplete dominance 1:2:1 in snapdragon antirrhinum", "codominance ia ib i alleles blood group ab", "morgan experiment linkage percentage on x chromosome in drosophila", "hemophilia color blindness sickle cell anemia thalassemia phenylketonuria", "down syndrome klinefelter syndrome turner syndrome"],
        keywords: ["test cross to determine genotype", "law of purity of gametes segregation", "independent assortment cross", "pleiotropic gene effect", "recombination frequency linkage map sturtevant", "sex linked recessive disorders pedigree", "sickle cell point mutation gag to gug valine substitution at 6th position beta chain", "aneuploidy trisomy 21 down syndrome xxy klinefelter xo turner"],
        subtopics: [
          { name: "Mendelian Non-Mendelian Ratios", aliases: ["incomplete dominance codominance"], keywords: ["abo blood group inheritance", "test cross 1:1 ratio", "polygenic skin color inheritance"] },
          { name: "Mendelian & Chromosomal Disorders", aliases: ["pedigree genetic diseases"], keywords: ["sickle cell anemia glutamate to valine", "hemophilia royal disease pedigree", "klinefelter xxy and turner xo"] },
        ],
      },
    ],
  },
  {
    id: "bio-molecular-inheritance",
    name: "Molecular Basis of Inheritance",
    aliases: ["molecular biology", "dna structure double helix watson and crick", "packaging of dna helix nucleosome histone octamer", "search for genetic material griffith transforming principle avery macleod mccarty hershey and chase bacteriophage experiment", "dna replication semiconservative meselson and stahl experiment", "transcription transcription unit promoter structural gene terminator", "types of rna mrna trna rrna", "genetic code features universal degenerate unambiguous", "translation protein synthesis initiation elongation termination", "regulation of gene expression lac operon jacob and monod", "human genome project hgp", "dna fingerprinting vntr"],
    unit: "Genetics and Evolution",
    classLevel: "Class 12",
    exams: ["NEET", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 5,
    topics: [
      {
        id: "bio-dna-replication-transcription",
        name: "Replication, Transcription & Genetic Code",
        aliases: ["meselson stahl n15 n14 density gradient centrifugation", "dna polymerase 5' to 3' replication leading and lagging strand okazaki fragments", "transcription in prokaryotes vs eukaryotes rna polymerase i ii iii splicing introns exons capping tailing", "genetic code 64 codons aug start codon uaa uag uga stop codons", "trna clover leaf model adapter molecule anticodon loop"],
        keywords: ["nucleosome core 200 bp dna histone octamer h1", "griffith experiment streptococcus pneumoniae transforming principle", "hershey chase p32 s35 radioactive bacteriophage blender", "dna ligase okazaki fragments", "promoter tata box sigma factor termination rho factor", "split gene arrangement in eukaryotes hnRNA processing", "genetic code degeneracy and wobble hypothesis"],
        subtopics: [
          { name: "DNA Replication & Experiments", aliases: ["meselson stahl hershey chase"], keywords: ["semiconservative replication", "leading and lagging strand synthesis", "dna proofreading"] },
          { name: "Transcription & Post-Transcriptional Processing", aliases: ["splicing capping tailing"], keywords: ["hnRNA to mRNA", "polyadenylation at 3' end", "methylguanosine triphosphate capping"] },
        ],
      },
      {
        id: "bio-translation-lac-operon",
        name: "Translation & Lac Operon Regulation",
        aliases: ["aminoacylation of trna charging", "ribosome peptide bond formation peptidyl transferase", "lac operon inducible operon regulator i promoter p operator o structural genes z y a", "beta galactosidase permease transacetylase", "allolactose inducer binding repressor protein", "dna fingerprinting vntr southern blotting probe hybridization"],
        keywords: ["initiation of translation with met", "ribosomal subunits 50s 30s prokaryotes 60s 40s eukaryotes", "lac operon switch on and switch off mechanism", "glucose vs lactose effect on lac operon catabolite repression", "dna fingerprinting alec jeffreys satellite dna variable number tandem repeats"],
        subtopics: [
          { name: "Lac Operon System", aliases: ["operon concept jacob monod"], keywords: ["repressor protein binding operator", "inducer allolactose", "z gene codes beta galactosidase"] },
          { name: "DNA Fingerprinting", aliases: ["vntr southern blot"], keywords: ["satellite dna polymorphism", "gel electrophoresis southern blotting", "forensic applications"] },
        ],
      },
    ],
  },
  {
    id: "bio-evolution",
    name: "Evolution",
    aliases: ["origin of life", "miller-urey experiment", "theories of biological evolution", "evidence for evolution homologous and analogous organs", "divergent and convergent evolution", "adaptive radiation darwin finches", "natural selection industrial melanism peppered moth", "hardy-weinberg principle p^2 + 2pq + q^2 = 1", "human evolution dryopithecus ramapithecus australopithecus homo habilis homo erectus neanderthal homo sapiens"],
    unit: "Genetics and Evolution",
    classLevel: "Class 12",
    exams: ["NEET", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 6,
    topics: [
      {
        id: "bio-natural-selection-hardy",
        name: "Natural Selection, Hardy-Weinberg & Human Evolution",
        aliases: ["hardy weinberg equilibrium factors affecting gene flow drift mutation recombination natural selection", "homologous organs divergent evolution vertebrate forelimbs thorns and tendrils of bougainvillea cucurbita", "analogous organs convergent evolution sweet potato and potato wings of butterfly and bird", "cranial capacity of homo habilis 650-800cc homo erectus 900cc neanderthal 1400cc"],
        keywords: ["miller spark discharge experiment amino acids formation ch4 nh3 h2 h2o", "embryological evidence recapitulation theory haeckel debunked von baer", "stabilizing directional and disruptive selection curves", "founder effect and genetic drift sewall wright effect in small populations", "sequence of human evolution stages with brain sizes"],
        subtopics: [
          { name: "Homology vs Analogy & Evolution Evidences", aliases: ["divergent convergent evolution"], keywords: ["homologous forelimbs of mammals", "convergent evolution of eye of octopus and mammals", "adaptive radiation marsupials of australia"] },
          { name: "Hardy-Weinberg & Human Ancestors", aliases: ["hardy weinberg calculation"], keywords: ["p^2 + 2pq + q^2 = 1 numericals", "homo habilis first tool maker", "neanderthal man buried dead"] },
        ],
      },
    ],
  },
  {
    id: "bio-human-health-disease",
    name: "Human Health and Disease",
    aliases: ["pathogens causing human diseases", "typhoid salmonella typhi widal test", "pneumonia streptococcus pneumoniae", "common cold rhinovirus", "malaria plasmodium vivax life cycle mosquito", "amoebiasis entamoeba histolytica", "ringworm fungal infection", "innate immunity and acquired immunity", "antibodies igg iga igm ige igd structure h2l2", "active and passive immunity vaccination", "aids hiv retrovirus reverse transcriptase elisa test", "cancer proto-oncogenes benign and malignant metastasis", "drugs and alcohol abuse opioids cannabinoids coca alkaloids"],
    unit: "Biology in Human Welfare",
    classLevel: "Class 12",
    exams: ["NEET", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 7,
    topics: [
      {
        id: "bio-immunity-malaria-aids",
        name: "Innate/Acquired Immunity, Malaria & HIV",
        aliases: ["plasmodium life cycle in human and anopheles mosquito sporozoite gametocyte", "innate immunity physical physiological cellular cytokine barriers interferons", "b cells humoral and t cells cell mediated immunity graft rejection", "hiv replication in macrophages and helper t cells cd4 count", "cancer oncogenes contact inhibition loss biopsy mri radiotherapy chemotherapy"],
        keywords: ["widal test for typhoid confirmation", "trophozoite hemozoin causing chills in malaria", "structure of antibody molecule two heavy two light chains h2l2", "primary vs secondary immune response anamnestic", "colostrum passive immunity iga", "reverse transcriptase of hiv viral dna integration", "opioids morphine heroin smack receptors in cns and gi tract"],
        subtopics: [
          { name: "Immunity & Antibodies", aliases: ["t cells b cells graft rejection"], keywords: ["cell mediated immunity organ transplant rejection", "antibody h2l2 structure", "autoimmune disease rheumatoid arthritis"] },
          { name: "Malaria & HIV Pathogenesis", aliases: ["plasmodium life cycle hiv"], keywords: ["sporozoite in liver cells", "hemozoin toxin in rbc rupture", "hiv attacking helper t lymphocytes"] },
        ],
      },
    ],
  },
  {
    id: "bio-biotech-principles",
    name: "Biotechnology: Principles and Processes",
    aliases: ["biotechnology", "recombinant dna technology rdna", "restriction enzymes molecular scissors sticky ends palindromic sequence", "cloning vectors pbr322 selectable markers oriac rop ampR tetR insertional inactivation", "competent host heat shock calcium chloride method", "polymerase chain reaction pcr denaturation annealing extension taq polymerase", "gel electrophoresis agarose gel ethidium bromide uv light", "bioreactors stirred tank sparged bioreactor downstream processing"],
    unit: "Biotechnology",
    classLevel: "Class 12",
    exams: ["NEET", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 9,
    topics: [
      {
        id: "bio-rdna-tools",
        name: "Restriction Endonucleases, Vectors & PCR",
        aliases: ["ecori restriction enzyme recognition site gaattc palindromic sequence", "pbr322 plasmid vector map restriction sites bamhi sali ecori clai hindiii pvui pvuii", "insertional inactivation of beta galactosidase blue white screening", "pcr steps denaturation 94c annealing 54c extension 72c thermus aquaticus taq polymerase", "agarose gel electrophoresis separation of dna fragments based on size"],
        keywords: ["restriction exonuclease vs endonuclease", "sticky ends vs blunt ends", "origin of replication ori controlling copy number", "selectable markers antibiotic resistance genes", "biolistics gene gun microinjection for animal cells", "taq polymerase thermostable enzyme", "chilled ethanol precipitation of purified dna"],
        subtopics: [
          { name: "Restriction Enzymes & Plasmid Vectors", aliases: ["pbr322 vector cloning"], keywords: ["palindromic sequence recognition", "insertional inactivation blue white colonies", "ligase joining sticky ends"] },
          { name: "PCR & Gel Electrophoresis", aliases: ["taq polymerase amplification"], keywords: ["three steps of pcr denaturation annealing extension", "agarose gel visualised under uv with etbr", "elution of dna bands"] },
        ],
      },
    ],
  },
  {
    id: "bio-biotech-applications",
    name: "Biotechnology and its Applications",
    aliases: ["applications of biotechnology", "bt crops bt cotton bacillus thuringiensis cry toxins", "rna interference rnai gene silencing meloidogyne incognita in tobacco plants", "genetically engineered insulin humulin a and b chains disulfide bonds proinsulin c peptide", "gene therapy adenosine deaminase ada deficiency", "molecular diagnosis pcr elisa recombinant dna probe", "transgenic animals rosie cow alpha lactalbumin", "biopiracy neem basmati rice patent ethics"],
    unit: "Biotechnology",
    classLevel: "Class 12",
    exams: ["NEET", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 10,
    topics: [
      {
        id: "bio-bt-insulin-gene-therapy",
        name: "Bt Cotton, Recombinant Insulin & Gene Therapy",
        aliases: ["cry1ac and cry2ab control cotton bollworms cry1ab controls corn borer", "rna interference using dicer and risc to silence mrna in nematodes", "eli lilly production of human insulin in e coli separate a and b chains", "ada deficiency treated by scid gene therapy using retrovirus on lymphocyte culture", "transgenic animals for vaccine safety polio testing on transgenic mice"],
        keywords: ["inactive protoxin converted to active toxin in alkaline gut of insects", "proinsulin contains extra c peptide removed during maturation", "first gene therapy 1990 4-year-old girl ada enzyme", "alpha-1-antitrypsin used to treat emphysema", "rosie transgenic cow produced protein enriched human milk 2.4 g/l", "biopiracy unauthorized exploitation of bioresources"],
        subtopics: [
          { name: "Bt Cotton & RNAi", aliases: ["cry toxins gene silencing"], keywords: ["alkaline ph of insect gut solubilises cry protein", "anti-sense and sense rna in tobacco plant", "resistance against nematode"] },
          { name: "Humulin & ADA Gene Therapy", aliases: ["insulin gene therapy"], keywords: ["disulfide bonds between a and b chains of insulin", "ada deficiency retroviral vector", "c-peptide absence in mature insulin"] },
        ],
      },
    ],
  },
  {
    id: "bio-ecology",
    name: "Organisms, Populations and Ecosystems",
    aliases: [
      "ecology",
      "organisms and populations",
      "ecosystems",
      "ecosystem",
      "population attributes",
      "population growth models",
      "verhulst pearl logistic growth",
      "population interactions",
      "mutualism",
      "predation",
      "commensalism",
      "amensalism",
      "parasitism",
      "ecological pyramids",
      "energy flow in ecosystem",
      "ten percent law",
    ],
    unit: "Ecology and Environment",
    classLevel: "Class 12",
    exams: ["NEET", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 11,
    topics: [
      {
        id: "bio-pop-eco-dynamics",
        name: "Population Dynamics & Ecosystem Energy Flow",
        aliases: ["verhulst pearl logistic growth curve s shaped sigmoid", "gause's competitive exclusion principle", "predation and prey control", "ecological pyramid of biomass numbers energy"],
        keywords: ["allen rule mammals", "kangaroo rat internal fat oxidation", "logistic growth equation dn/dt = rn(1 - n/k)", "epiphyte orchid commensalism", "lichen mutualism", "ten percent law of energy flow lindeman"],
        subtopics: [
          { name: "Population Growth & Interactions", aliases: ["growth curves mutualism competition"], keywords: ["carrying capacity k", "competition macarthur warblers", "commensalism vs amensalism"] },
          { name: "Ecosystem Energy Flow", aliases: ["ecological pyramids"], keywords: ["producers consumers decomposers", "trophic levels", "upright energy pyramid"] },
        ],
      },
    ],
  },
  {
    id: "bio-biodiversity-conservation",
    name: "Biodiversity and Conservation",
    aliases: [
      "biodiversity and conservation",
      "biodiversity",
      "conservation of biodiversity",
      "in-situ vs ex-situ conservation",
      "in-situ and ex-situ conservation",
      "in situ conservation",
      "ex situ conservation",
      "biodiversity hotspots",
      "latitudinal gradients of biodiversity",
      "species area relationship",
      "rivet popper hypothesis",
      "loss of biodiversity evil quartet",
      "iucn red list",
      "sacred groves",
    ],
    unit: "Ecology and Environment",
    classLevel: "Class 12",
    exams: ["NEET", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 12,
    topics: [
      {
        id: "bio-conservation-methods",
        name: "In-Situ vs Ex-Situ Conservation & Biodiversity Hotspots",
        aliases: ["in situ national parks wildlife sanctuaries biosphere reserves", "ex situ botanical gardens zoological parks seed banks cryopreservation", "34 terrestrial biodiversity hotspots", "species area curve alexander von humboldt"],
        keywords: ["biodiversity and conservation", "in-situ vs ex-situ conservation", "biodiversity hotspots", "endemic species high degree of endemism", "sacred groves khasi jaintia hills", "rivet popper hypothesis paul ehrlich", "habitat loss and fragmentation evil quartet"],
        subtopics: [
          { name: "In-Situ & Ex-Situ Strategies", aliases: ["conservation types"], keywords: ["biosphere reserves in india", "national parks", "cryopreservation of gametes", "pollen banks"] },
          { name: "Hotspots & Diversity Patterns", aliases: ["species richness"], keywords: ["34 biodiversity hotspots", "western ghats indo burma himalaya", "species area curve log s = log c + z log a"] },
        ],
      },
    ],
  },
  {
    id: "bio-endocrine-system",
    name: "Chemical Coordination and Integration (Endocrine System)",
    aliases: [
      "endocrine system",
      "endocrine system & hormones",
      "hormones",
      "pituitary gland",
      "thyroid gland",
      "adrenal glands",
      "pancreas hormones insulin glucagon",
      "mechanism of hormone action",
      "second messenger camp",
    ],
    unit: "Human Physiology",
    classLevel: "Class 11",
    exams: ["NEET", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 22,
    topics: [
      {
        id: "bio-hormone-glands",
        name: "Endocrine Glands, Secretions & Hormone Actions",
        aliases: ["hypothalamic hormones releasing and inhibiting", "anterior and posterior pituitary hormones", "thyroid thyroxine t3 t4 calcitonin", "adrenal cortex and medulla catecholamines"],
        keywords: [
          "endocrine system & hormones",
          "pituitary thyroid & adrenal glands",
          "hormones peptide steroid iodothyronines",
          "mechanism of hormone action membrane bound vs intracellular receptors",
          "secondary messengers camp ip3 calcium",
          "hypo and hyper secretion disorders gigantism dwarfism goitre addison disease",
        ],
        subtopics: [
          { name: "Pituitary, Thyroid & Parathyroid Glands", aliases: ["central endocrine glands"], keywords: ["growth hormone acth tsh fsh lh prolactin oxytocin adh", "thyroid follicular cells and cretinism", "parathyroid hormone pth hypercalcemic"] },
          { name: "Adrenal Gland & Pancreas", aliases: ["adrenal and islet hormones"], keywords: ["adrenal cortex mineralocorticoids glucocorticoids", "adrenal medulla adrenaline noradrenaline", "alpha cells glucagon beta cells insulin diabetes mellitus"] },
        ],
      },
    ],
  },
  {
    id: "bio-plant-respiration",
    name: "Respiration in Plants",
    aliases: [
      "respiration in plants",
      "glycolysis",
      "emp pathway",
      "krebs cycle",
      "tca cycle",
      "ets",
      "electron transport system",
      "oxidative phosphorylation",
      "respiratory quotient rq",
    ],
    unit: "Plant Physiology",
    classLevel: "Class 11",
    exams: ["NEET", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 14,
    topics: [
      {
        id: "bio-glycolysis-krebs",
        name: "Glycolysis, Krebs Cycle & Electron Transport System ETS",
        aliases: ["glucose phosphorylation to fructose 1 6 bisphosphate", "pyruvate oxidation acetyl coa", "citric acid cycle enzymes", "complex i to iv in mitochondrial membrane", "f0 f1 atp synthase"],
        keywords: [
          "respiration in plants",
          "glycolysis emp pathway",
          "krebs tca cycle",
          "ets complex i to iv",
          "chemiosmotic atp synthesis",
          "net atp yield 36 or 38 atp",
          "fermentation alcoholic and lactic acid",
          "respiratory quotient values for carbohydrates fats proteins",
        ],
        subtopics: [
          { name: "Glycolysis (EMP Pathway)", aliases: ["cytoplasmic respiration"], keywords: ["10 steps of glycolysis", "substrate level phosphorylation steps", "hexokinase phosphofructokinase enzymes"] },
          { name: "Krebs TCA Cycle & ETS Complexes", aliases: ["mitochondrial respiration"], keywords: ["oxaloacetate citrate cycle", "nadh fadh2 oxidation", "ubiquinone cytochrome c mobile carriers", "complex v atp synthase"] },
        ],
      },
    ],
  },
  {
    id: "bio-microbes-welfare",
    name: "Microbes in Human Welfare",
    aliases: [
      "microbes in human welfare",
      "sewage treatment plant",
      "sewage treatment plant stp",
      "biogas plant",
      "biogas production",
      "methanogens",
      "biofertilizers",
      "biocontrol agents",
      "microbes in household products",
    ],
    unit: "Biology and Human Welfare",
    classLevel: "Class 12",
    exams: ["NEET", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 10,
    topics: [
      {
        id: "bio-microbes-stp-biogas",
        name: "Sewage Treatment, Biogas Production & Biofertilizers",
        aliases: ["primary settling and secondary biological treatment bod", "activated sludge aeration tank flocs", "methanobacterium in anaerobic sludge digesters", "bacillus thuringiensis trichoderma baculoviruses"],
        keywords: [
          "microbes in human welfare",
          "sewage treatment plant stp",
          "biogas plant production",
          "biochemical oxygen demand bod indicator of organic pollution",
          "flocs bacteria and fungal filaments",
          "methanogens producing methane co2 and h2",
          "biofertilizers rhizobium azotobacter mycorrhiza glomus",
          "antibiotics penicillin fermented beverages saccharomyces",
        ],
        subtopics: [
          { name: "Sewage Treatment (STP)", aliases: ["primary and secondary wastewater treatment"], keywords: ["sedimentation and filtration", "aeration tank aerobic decomposition", "anaerobic sludge digestion biogas generation"] },
          { name: "Biogas, Biocontrol & Biofertilizers", aliases: ["sustainable agriculture microbes"], keywords: ["gobar gas plant structure floating gas holder", "bio insecticides npv virus", "cyanobacteria nostoc anabaena nitrogen fixation"] },
        ],
      },
    ],
  },
  {
    id: "bio-animal-kingdom",
    name: "Animal Kingdom",
    aliases: [
      "animal kingdom",
      "non chordates to chordates",
      "classification basis in animals",
      "coelomates pseudocoelomates acoelomates",
      "radial and bilateral symmetry",
      "porifera to chordata",
      "phylum arthropoda mollusca echinodermata",
      "vertebrata classes chondrichthyes osteichthyes amphibia reptilia aves mammalia",
    ],
    unit: "Diversity in the Living World",
    classLevel: "Class 11",
    exams: ["NEET", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 4,
    topics: [
      {
        id: "bio-animal-phyla",
        name: "Non-Chordate and Chordate Phyla Classification",
        aliases: ["basis of classification levels of organisation body plan", "diploblastic and triploblastic", "notochord in chordates", "diagnostic features of animal phyla"],
        keywords: [
          "animal kingdom",
          "non-chordates to chordates classification basis",
          "phylum porifera coelenterata ctenophora platyhelminthes aschelminthes annelida arthropoda mollusca echinodermata hemichordata",
          "flame cells malpighian tubules nephridia",
          "water vascular system in echinoderms",
          "urochordata cephalochordata vertebrata",
        ],
        subtopics: [
          { name: "Basis of Classification & Non-Chordates", aliases: ["invertebrate phyla"], keywords: ["levels of organisation cellular tissue organ system", "open and closed circulatory systems", "metameric segmentation annelids arthropods"] },
          { name: "Phylum Chordata & Vertebrate Classes", aliases: ["chordate classification"], keywords: ["dorsal hollow nerve cord and pharyngeal gill slits", "cartilaginous vs bony fishes operculum air bladder", "homeotherms aves mammals pneumatic bones"] },
        ],
      },
    ],
  },
  {
    id: "bio-morphology-plants",
    name: "Morphology of Flowering Plants",
    aliases: [
      "morphology of flowering plants",
      "root modifications",
      "stem modifications",
      "leaf modifications",
      "floral formula diagram",
      "types of inflorescence racemose cymose",
      "aestivation in flower petals",
      "placentation types marginal axile parietal",
      "plant families fabaceae solanaceae liliaceae",
    ],
    unit: "Structural Organisation in Animals and Plants",
    classLevel: "Class 11",
    exams: ["NEET", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 5,
    topics: [
      {
        id: "bio-plant-organs-flower",
        name: "Vegetative & Floral Morphology of Angiosperms",
        aliases: ["tap root and adventitious root modifications pneumatophores prop stilt roots", "stem tendrils thorns cladode phylloclade", "venation reticulate parallel phyllotaxy", "calyx corolla androecium gynoecium"],
        keywords: [
          "morphology of flowering plants",
          "root stem leaf modifications",
          "floral formula diagram",
          "hypogynous perigynous epigynous flowers ovary position",
          "valvate twisted imbricate vexillary aestivation",
          "placentation types marginal axile free central basal",
          "fruit types drupe mango pericarp",
        ],
        subtopics: [
          { name: "Vegetative Organs & Modifications", aliases: ["roots stems leaves"], keywords: ["pneumatophores rhizophora", "prop roots banyan stilt roots maize sugarcane", "runners stolons offsets suckers"] },
          { name: "Flower, Inflorescence & Families", aliases: ["floral morphology and families"], keywords: ["racemose vs cymose branching", "floral formula symbols", "solanaceae fabaceae characters economic importance"] },
        ],
      },
    ],
  },
  {
    id: "bio-excretion",
    name: "Excretory Products and Their Elimination",
    aliases: [
      "excretory products and their elimination",
      "nephron structure",
      "urine formation",
      "counter current mechanism",
      "glomerular filtration rate gfr",
      "renin angiotensin aldosterone system raas",
      "micturition",
      "hemodialysis artificial kidney",
    ],
    unit: "Human Physiology",
    classLevel: "Class 11",
    exams: ["NEET", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 19,
    topics: [
      {
        id: "bio-nephron-countercurrent",
        name: "Nephron Physiology & Urine Concentration Mechanism",
        aliases: ["bowman's capsule glomerulus ultrafiltration", "pct dct collecting duct selective reabsorption", "henle's loop and vasa recta counter current multiplier", "antidiuretic hormone adh vasopressin regulation"],
        keywords: [
          "excretory products and their elimination",
          "nephron structure & urine formation counter current",
          "ultrafiltration net filtration pressure nfp",
          "gfr 125 ml/min or 180 liters per day",
          "juxtaglomerular apparatus jga renin release",
          "atrial natriuretic factor anf vasodilator",
          "ureotelic ammonotelic uricotelic animals",
        ],
        subtopics: [
          { name: "Nephron Structure & Filtration", aliases: ["renal tubules"], keywords: ["malpighian body glomerulus bowman capsule", "pct 70-80% electrolyte water reabsorption", "tubular secretion h+ k+ ammonia ions"] },
          { name: "Urine Concentration & Hormonal Regulation", aliases: ["countercurrent and raas"], keywords: ["osmolarity gradient 300 to 1200 mosmol/l in medulla", "descending vs ascending loop of henle permeability", "raas pathway renin angiotensin ii aldosterone"] },
        ],
      },
    ],
  },
  {
    id: "bio-locomotion",
    name: "Locomotion and Movement",
    aliases: [
      "locomotion and movement",
      "sliding filament theory",
      "muscle contraction",
      "human skeleton",
      "axial and appendicular skeleton",
      "types of joints synovial fibrous cartilaginous",
      "sarcomere structure actin myosin",
      "myasthenia gravis tetany muscular dystrophy",
    ],
    unit: "Human Physiology",
    classLevel: "Class 11",
    exams: ["NEET", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 20,
    topics: [
      {
        id: "bio-muscle-skeletal-system",
        name: "Sliding Filament Mechanism & Human Skeletal Anatomy",
        aliases: ["striated skeletal muscle fiber myofibril", "thick filament myosin meromyosin cross bridge", "thin filament actin tropomyosin troponin", "calcium release from sarcoplasmic reticulum", "206 bones in adult human skeleton"],
        keywords: [
          "locomotion and movement",
          "sliding filament theory of muscle contraction",
          "human skeleton axial and appendicular",
          "sarcomere z disc a band i band h zone",
          "atp hydrolysis and power stroke cross bridge cycle",
          "synovial joints ball and socket hinge pivot gliding saddle",
          "disorders arthritis osteoporosis gout",
        ],
        subtopics: [
          { name: "Muscle Contraction Mechanism", aliases: ["sliding filament theory"], keywords: ["neuromuscular junction motor end plate", "action potential triggering calcium release", "troponin c binding calcium exposing myosin binding sites"] },
          { name: "Skeletal Framework & Joints", aliases: ["bones and joints"], keywords: ["skull 22 bones vertebral column 26 vertebrae", "ribs 12 pairs true false floating ribs", "pectoral and pelvic girdles limb bones"] },
        ],
      },
    ],
  },
  {
    id: "bio-cell-structure",
    name: "Cell: The Unit of Life",
    aliases: [
      "cell the unit of life",
      "cell the unit of life:",
      "fluid mosaic model",
      "plasma membrane",
      "endomembrane system",
      "prokaryotic vs eukaryotic cell",
      "ribosomes 70s 80s",
      "mitochondria and chloroplast semiautonomous",
      "nucleus chromatin chromosomes centromere",
    ],
    unit: "Cell Structure and Function",
    classLevel: "Class 11",
    exams: ["NEET", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 8,
    topics: [
      {
        id: "bio-membrane-organelles",
        name: "Plasma Membrane & Eukaryotic Organelles",
        aliases: ["singer and nicolson fluid mosaic model 1972", "phospholipid bilayer integral and peripheral proteins", "endoplasmic reticulum rough rer smooth ser", "golgi apparatus cis and trans face", "lysosomes suicidal bags hydrolytic enzymes"],
        keywords: [
          "cell the unit of life",
          "fluid mosaic model of plasma membrane",
          "endomembrane system er golgi lysosomes vacuoles",
          "chloroplast thylakoid grana stroma",
          "mitochondria cristae matrix 70s ribosome circular dna",
          "cytoskeleton microtubules microfilaments",
          "cilia and flagella 9+2 axoneme arrangement",
        ],
        subtopics: [
          { name: "Plasma Membrane & Cell Wall", aliases: ["membrane structure"], keywords: ["quasi fluid nature of lipids", "active and passive transport na+ k+ pump", "middle lamella calcium pectate plasmodesmata"] },
          { name: "Endomembrane System & Mitochondria", aliases: ["organelle structures"], keywords: ["rer protein synthesis ser lipid steroid synthesis", "golgi glycosylation of proteins and lipids", "mitochondrial endosymbiosis hypothesis"] },
        ],
      },
    ],
  },
  {
    id: "bio-repro-health",
    name: "Reproductive Health",
    aliases: [
      "reproductive health",
      "contraceptive methods",
      "amniocentesis",
      "assisted reproductive technologies art",
      "ivf test tube baby",
      "icsi",
      "gift zift",
      "sexually transmitted infections sti",
      "medical termination of pregnancy mtp",
    ],
    unit: "Reproduction",
    classLevel: "Class 12",
    exams: ["NEET", "CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 4,
    topics: [
      {
        id: "bio-contraception-art",
        name: "Contraceptive Methods, MTP & Infertility Technologies",
        aliases: ["natural barrier iud oral hormonal surgical sterilization methods", "copper t cu t cu 7 multiload 375", "saheli non steroidal oral contraceptive pill", "mtp act legal conditions", "ivf et in vitro fertilization embryo transfer"],
        keywords: [
          "reproductive health class 12",
          "contraceptive methods natural barrier iuds hormonal",
          "amniocentesis detection of genetic disorders chromosomal abnormalities",
          "art ivf icsi zift gift intrauterine transfer iut",
          "infertility causes and assisted reproductive technologies",
          "sexually transmitted diseases gonorrhoea syphilis genital herpes chlamydia",
        ],
        subtopics: [
          { name: "Contraceptive Methods & Population Control", aliases: ["birth control"], keywords: ["iud mechanisms phagocytosis of sperm cu ions suppress motility", "vasectomy and tubectomy surgical methods", "emergency contraceptives within 72 hours"] },
          { name: "Infertility & Assisted Reproductive Technologies (ART)", aliases: ["ivf and test tube baby"], keywords: ["zift transfer up to 8 blastomeres into fallopian tube", "iut transfer more than 8 blastomeres into uterus", "intra cytoplasmic sperm injection icsi"] },
        ],
      },
    ],
  },

];

// ====================================================================
// 5. ENGLISH CORE KNOWLEDGE GRAPH (CBSE Class 12 Official 2026-27)
// ====================================================================

const ENGLISH_CHAPTERS: AcademicChapterNode[] = [
  // Flamingo - Prose
  {
    id: "eng-last-lesson",
    name: "The Last Lesson",
    aliases: ["the last lesson class 12", "alphonse daudet", "franz and m hamel", "alsace and lorraine", "linguistic chauvinism", "french language chapter 1 flamingo"],
    unit: "Flamingo (Prose)",
    classLevel: "Class 12",
    exams: ["CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 1,
    topics: [
      {
        id: "eng-last-lesson-analysis",
        name: "Character Analysis & Themes",
        aliases: ["franz procrastination fear of ruler", "m hamel forty years of service green coat", "order from berlin prussian conquest", "importance of mother tongue key to prison", "vive la france"],
        keywords: ["franz dreading school test on participles", "blacksmith wachter at bulletin board", "old hauser holding primer", "m hamel wearing fine sunday clothes", "linguistic chauvinism theme", "vive la france written on blackboard", "extract based questions the last lesson", "central idea of the last lesson"],
        subtopics: [
          { name: "Theme of Linguistic Identity", aliases: ["alsace lorraine occupation"], keywords: ["loss of language loss of freedom", "mother tongue as a key to prison", "value of education"] },
          { name: "Character Sketch of M. Hamel and Franz", aliases: ["m hamel character sketch"], keywords: ["patriotic dedicated stern teacher", "repentance of franz", "change in franz attitude"] },
        ],
      },
    ],
  },
  {
    id: "eng-lost-spring",
    name: "Lost Spring: Stories of Stolen Childhood",
    aliases: ["lost spring class 12", "anees jung", "saheb-e-alam ragpicker seemapuri", "mukesh bangle maker firozabad", "child labour child exploitation", "promises made to the poor"],
    unit: "Flamingo (Prose)",
    classLevel: "Class 12",
    exams: ["CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 2,
    topics: [
      {
        id: "eng-lost-spring-analysis",
        name: "Themes of Poverty & Child Labour",
        aliases: ["saheb e alam meaning lord of the universe irony", "garbage to them is gold wrapped in wonder", "seemapuri transit camp from bangladesh 1971", "mukesh dreams of becoming a motor mechanic", "vicious circle of sahukars middlemen policemen bureaucrats politicians"],
        keywords: ["barefoot ragpickers tradition or poverty", "tea stall work saheb loses carefree look canister heavier than plastic bag", "glass bangles industry of firozabad dark hutments furnace blindness", "vicious circle of poverty and exploitation", "irony in saheb name", "lost spring question answers and summary"],
        subtopics: [
          { name: "Story 1: Saheb at Seemapuri", aliases: ["saheb ragpicker"], keywords: ["garbage wrapped in wonder for children", "survival in seemapuri means ragpicking", "steel canister vs plastic bag"] },
          { name: "Story 2: Mukesh at Firozabad", aliases: ["mukesh motor mechanic"], keywords: ["daring to dream in firozabad", "hazards of bangle making industry", "caste and karma trap"] },
        ],
      },
    ],
  },
  {
    id: "eng-deep-water",
    name: "Deep Water",
    aliases: ["deep water class 12", "william douglas", "conquering fear of water", "ymca swimming pool yakima", "childhood aversion to water california beach", "big bruiser boy throwing in deep end", "all we have to fear is fear itself"],
    unit: "Flamingo (Prose)",
    classLevel: "Class 12",
    exams: ["CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 3,
    topics: [
      {
        id: "eng-deep-water-analysis",
        name: "Psychology of Fear & Determination",
        aliases: ["nine feet deep felt like ninety feet", "panic and suffocation yellow water", "blackness swept over curtain of life fell", "swimming instructor piece by piece building swimmer", "testing himself in lake wentworth warm lake"],
        keywords: ["ymca pool safe shallow end two feet deep end nine feet", "eighteen year old bully thrown into water", "terror gripped him three attempts to spring up failed", "instructor put belt and rope to practice breathing and kicking", "roosevelt quotation all we have to fear is fear itself", "overcoming hydrophobia determination willpower"],
        subtopics: [
          { name: "Near Drowning Experience", aliases: ["ymca pool misadventure"], keywords: ["nine feet deep", "suffocation panic paralysis", "peaceful oblivion blackout"] },
          { name: "Process of Overcoming Fear", aliases: ["swimming instructor douglas"], keywords: ["building swimmer piece by piece", "testing in lake wentworth", "roosevelt quote on fear"] },
        ],
      },
    ],
  },
  {
    id: "eng-rattrap",
    name: "The Rattrap",
    aliases: ["the rattrap class 12", "selma lagerlof", "peddler vagabond", "crofter thirty kronor theft", "ramsjo ironworks ironmaster", "edla willmansson compassion kindness", "world is a big rattrap metaphor"],
    unit: "Flamingo (Prose)",
    classLevel: "Class 12",
    exams: ["CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 4,
    topics: [
      {
        id: "eng-rattrap-analysis",
        name: "Metaphor of the Rattrap & Redemption",
        aliases: ["philosophical thought of the peddler world as rattrap", "pork cheese baits riches joys shelter warmth", "old crofter hospitality cow milk thirty kronor in leather pouch", "confusion in the forest lost in maze of trees", "ironmaster mistaking peddler for captain nils olof", "edla kindness Christmas Eve redemption as captain"],
        keywords: ["the world is nothing but a big rattrap", "stealing thirty kronor from crofter", "ironworks forge master blacksmith", "edla intercedes for the stranger", "letter signed as captain von stahle leaving 30 kronor to return to crofter", "power of human kindness and empathy to reform"],
        subtopics: [
          { name: "The Rattrap Metaphor", aliases: ["world as rattrap bait"], keywords: ["cheese and pork baits", "getting trapped in the forest", "crofter thirty kronor"] },
          { name: "Edla's Transformative Kindness", aliases: ["redemption of peddler"], keywords: ["ironmaster mistaken identity", "edla compassion Christmas eve", "letter signed captain von stahle"] },
        ],
      },
    ],
  },
  {
    id: "eng-indigo",
    name: "Indigo",
    aliases: ["indigo class 12", "louis fischer", "the life of mahatma gandhi", "champaran bihar 1916", "rajkumar shukla sharecropper", "synthetic indigo germany", "first victory of civil disobedience in modern india"],
    unit: "Flamingo (Prose)",
    classLevel: "Class 12",
    exams: ["CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 5,
    topics: [
      {
        id: "eng-indigo-analysis",
        name: "Socio-Economic Awakening & Gandhi's Leadership",
        aliases: ["sharecropping system 15 percent indigo surrender to british landlords", "rajkumar shukla resolute poor illiterate peasant", "rajendra prasad j b kripalani lawyers", "motihari courtroom spontaneous demonstration of peasants", "gandhi disobedience of order to leave", "refund settlement 25 percent breaking prestige of planters", "social and cultural work in champaran villages doctors ashram schools"],
        keywords: ["champaran struggle for indigo farmers", "british landlords contract 15 percent land with indigo", "germany developed synthetic indigo compensation demanded", "spontaneous demonstration outside court officials powerless without gandhi help", "civil disobedience triumphed for the first time in india", "charles freer andrews self reliance lesson"],
        subtopics: [
          { name: "The Sharecropping Injustice", aliases: ["15 percent indigo agreement"], keywords: ["tinkathia system", "german synthetic indigo extortion", "rajkumar shukla tenacity"] },
          { name: "Gandhi's Method & 25% Refund", aliases: ["civil disobedience champaran"], keywords: ["moral victory over monetary refund", "breaking fear of peasants", "health sanitation schools in champaran"] },
        ],
      },
    ],
  },
  {
    id: "eng-poets-pancakes",
    name: "Poets and Pancakes",
    aliases: ["poets and pancakes class 12", "asokamitran", "gemini studios madras chennai", "pancakes brand of makeup", "kothamangalam subbu number 2", "office boy makeup department", "legal adviser lawyer story department", "stephen spender visit the god that failed"],
    unit: "Flamingo (Prose)",
    classLevel: "Class 12",
    exams: ["CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 6,
    topics: [
      {
        id: "eng-poets-pancakes-analysis",
        name: "Behind the Scenes of Gemini Studios",
        aliases: ["pancake makeup grease paint truck loads", "office boy frustration jealousy of subbu", "subbu multi faceted genius tailor-made for films obedient", "moral re armament mra army 200 people jotham valley", "english poet visit baffled listeners stephen spender mystery solved years later"],
        keywords: ["gemini studios s s vasan founder", "makeup room looked like hair cutting salon incandescent lights heat", "kothamangalam subbu poet actor problem solver", "legal adviser ruined aspiring actress career recording her outburst", "the god that failed essays on communism disillusionment stephen spender"],
        subtopics: [{ name: "Satire & Humor in Film Industry", aliases: ["gemini studio characters"], keywords: ["office boy in his forties", "subbu number two", "stephen spender visit to madras"] }],
      },
    ],
  },
  {
    id: "eng-the-interview",
    name: "The Interview",
    aliases: ["the interview class 12", "christopher silvester", "part 1 history and opinions on interview", "part 2 interview with umberto eco", "mukund padmanabhan the hindu", "the name of the rose novel", "semiotics and interstices"],
    unit: "Flamingo (Prose)",
    classLevel: "Class 12",
    exams: ["CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 7,
    topics: [
      {
        id: "eng-the-interview-analysis",
        name: "Media Ethics & Umberto Eco's Intellect",
        aliases: ["celebrity views on interview v s naipaul lewis carroll h g wells rudyard kipling", "kipling interview as assault cowardly vile crime", "umberto eco university professor author semiotics", "concept of interstices empty spaces in time", "the name of the rose medieval detective story sold 10 million copies"],
        keywords: ["interview invented over 130 years ago", "primitive belief interview steals soul", "umberto eco writing essays novels on sundays", "interstices working in empty spaces waiting for elevator", "mystery of the success of the name of the rose"],
        subtopics: [{ name: "Umberto Eco on Writing & Time", aliases: ["interstices concept"], keywords: ["working in empty intervals", "academic scholar vs novelist", "success of name of the rose"] }],
      },
    ],
  },
  {
    id: "eng-going-places",
    name: "Going Places",
    aliases: ["going places class 12", "a r barton", "sophie and jansie teenage daydreams", "danny casey irish football player", "geoff brother motorcycle mechanic", "adolescent fantasizing hero worship", "biscuit factory reality"],
    unit: "Flamingo (Prose)",
    classLevel: "Class 12",
    exams: ["CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 8,
    topics: [
      {
        id: "eng-going-places-analysis",
        name: "Adolescent Fantasizing vs Harsh Reality",
        aliases: ["sophie dreams of owning boutique becoming actress fashion designer", "jansie sensible realistic ear-marked for biscuit factory", "sophie imaginary meeting with danny casey at royce's arcade", "geoff silent introverted motorcycle mechanic", "waiting by the canal danny casey did not come disillusionment"],
        keywords: ["sophie working class background contrast with wild dreams", "hero worship of danny casey united football match", "father skepticism practical working man", "waiting by the canal wharf knowing he wouldn't come", "pain of unfulfilled teenage daydreams"],
        subtopics: [{ name: "Contrast Between Sophie and Jansie", aliases: ["daydreaming vs reality"], keywords: ["sophie romantic idealist", "jansie grounded realist", "danny casey imaginary rendezvous"] }],
      },
    ],
  },

  // Flamingo - Poetry
  {
    id: "eng-my-mother-sixty-six",
    name: "My Mother at Sixty-Six",
    aliases: ["my mother at sixty-six class 12", "kamala das", "ageing mother", "drive to cochin airport", "corpse comparison", "late winter's moon simile", "familiar ache childhood fear", "smile and smile and smile"],
    unit: "Flamingo (Poetry)",
    classLevel: "Class 12",
    exams: ["CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 1,
    topics: [
      {
        id: "eng-mother-poetic-devices",
        name: "Poetic Devices & Theme of Ageing",
        aliases: ["simile ashen like that of a corpse", "young trees sprinting metaphor personification", "merry children spilling out of homes contrast", "simile as a late winter's moon pale and wan", "repetition smile and smile and smile facade"],
        keywords: ["kamala das pen name madhavikutty", "driving from parent home to cochin airport on friday morning", "mother dozing open mouthed face ashen like corpse", "diverting mind by looking at young trees sprinting merry children", "airport security check few yards away mother pale late winter moon", "childhood fear of losing mother familiar ache", "parting words see you soon amma"],
        subtopics: [{ name: "Imagery & Similes", aliases: ["ashen corpse late winter moon"], keywords: ["contrast between youth and decay", "trees sprinting life vs stillness", "hiding grief behind smile"] }],
      },
    ],
  },
  {
    id: "eng-keeping-quiet",
    name: "Keeping Quiet",
    aliases: ["keeping quiet class 12", "pablo neruda", "counting up to twelve", "exotic moment of silence", "fishermen not harming whales", "man gathering salt looking at hurt hands", "green wars wars with gas wars with fire", "clean clothes walking with brothers", "life is what it is about not total inactivity", "earth can teach us when everything seems dead"],
    unit: "Flamingo (Poetry)",
    classLevel: "Class 12",
    exams: ["CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 2,
    topics: [
      {
        id: "eng-keeping-quiet-analysis",
        name: "Introspection, Universal Brotherhood & Peace",
        aliases: ["counting to twelve hours on clock months in year", "exotic moment without rush without engines", "anti-war message wars with no survivors", "clarification quietness is not total inactivity or death", "earth as teacher cycle of seasons life reborn from apparent death"],
        keywords: ["pablo neruda neftali ricardo reyes basoalto", "stopping all movement not speaking in any language", "fishermen in cold sea spare whales stop exploitation of nature", "man gathering salt looking at hurt self harm stop", "green wars environmental degradation chemical warfare", "put on clean clothes in shade of brotherhood", "earth teaches seed dormant in winter germinates in spring"],
        subtopics: [{ name: "Introspection vs Total Inactivity", aliases: ["silence and self reflection"], keywords: ["no truck with death", "interruption of sadness by silence", "earth metaphor of renewal"] }],
      },
    ],
  },
  {
    id: "eng-thing-of-beauty",
    name: "A Thing of Beauty",
    aliases: ["a thing of beauty class 12", "john keats", "endymion a poetic romance", "a thing of beauty is a joy forever", "loveliness increases never pass into nothingness", "bower quiet sweet dreams healthy breathing", "spite of despondence inhuman dearth of noble natures", "pall lifted from dark spirits", "simple sheep daffodils clear rills musk rose", "mighty dead immortal drink fountain"],
    unit: "Flamingo (Poetry)",
    classLevel: "Class 12",
    exams: ["CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 3,
    topics: [
      {
        id: "eng-beauty-keats-analysis",
        name: "Romantic Aesthetic & Transcendence",
        aliases: ["permanent joy vs transient worldly sorrows", "pall of sadness lifted by shape of beauty", "nature beautiful objects sun moon old young trees daffodils clear rills cooling covert", "grandeur of the dooms imagined for mighty dead heroic stories", "endless fountain of immortal drink pouring unto us from heaven's brink"],
        keywords: ["john keats romantic poet", "definition of beauty eternal indestructible", "inhuman dearth of noble natures gloomy days unhealthful ways", "simple sheep reference to mankind pastoral imagery", "cooling covert made by clear rills against hot season", "all lovely tales that we have heard or read", "immortal drink nectar of divine joy"],
        subtopics: [{ name: "List of Beautiful Objects", aliases: ["sun moon trees daffodils rills"], keywords: ["nature as soothing balm", "grandeur of mighty dead stories", "heavenly brink immortal drink"] }],
      },
    ],
  },
  {
    id: "eng-roadside-stand",
    name: "A Roadside Stand",
    aliases: ["a roadside stand class 12", "robert frost", "little old house with roadside stand", "traffic rushing past polished traffic", "selling wild berries golden squash", "plea for cash currency to expand life", "greedy good-doers beneficent beasts of prey", "soothing them out of their wits", "childish longing in vain open windows waiting", "sadness of rural poor squeal of brakes"],
    unit: "Flamingo (Poetry)",
    classLevel: "Class 12",
    exams: ["CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 4,
    topics: [
      {
        id: "eng-roadside-stand-analysis",
        name: "Rural-Urban Divide & False Philanthropy",
        aliases: ["contrast between rich city dwellers and poor rural sellers", "plea not for dole of bread but cash flow", "polished traffic passing with mind ahead or complaining about n and s signs turned wrong", "greedy good doers politicians promises to relocate villagers to villages with cinemas", "false promises destroying self-reliance putting them to sleep", "poet pain wishing one stroke could put them out of their pain"],
        keywords: ["robert frost rural new england setting", "little new shed in front at edge of road", "wild berries in wooden quarts golden squash with silver warts", "city cash that keeps the flower of cities from sinking", "party in power keeping benefits away from rural poor", "cars stopping only to turn around ask directions or ask for gallon of gas", "poet compassion for struggling villagers"],
        subtopics: [{ name: "Critique of Beneficent Beasts of Prey", aliases: ["false promises to rural poor"], keywords: ["greedy good doers oxymoron", "destruction of ancient rural lifestyle", "childish longing for customers"] }],
      },
    ],
  },
  {
    id: "eng-aunt-jennifer-tigers",
    name: "Aunt Jennifer's Tigers",
    aliases: ["aunt jennifer's tigers class 12", "adrienne rich", "embroidered tigers screen", "bright topaz denizens green world", "pace in sleek chivalric certainty", "fluttering fingers wool ivory needle", "massive weight of uncle's wedding band", "terrified hands ringed with ordeals", "tigers in the panel will go on prancing proud and unafraid"],
    unit: "Flamingo (Poetry)",
    classLevel: "Class 12",
    exams: ["CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 5,
    topics: [
      {
        id: "eng-aunt-jennifer-analysis",
        name: "Feminist Critique, Patriarchal Oppression & Art",
        aliases: ["tigers metaphor of freedom power chivalry fearless", "aunt jennifer victim of patriarchal marriage subjugation", "massive weight of uncle wedding band symbol of domestic oppression", "fluttering fingers unable to pull light ivory needle physical emotional trauma", "art outliving the artist tigers remain immortal proud unafraid"],
        keywords: ["adrienne rich feminist poet", "tigers do not fear men beneath the tree", "sleek chivalric certainty alliteration imagery", "wedding band sits heavily upon aunt jennifer hand", "ringed with ordeals pun on ring wedding ring and encircled by troubles", "immortality of artistic creation vs mortality of oppressed artist"],
        subtopics: [{ name: "Symbols: Tigers vs Wedding Band", aliases: ["feminist imagery adrienne rich"], keywords: ["chivalric certainty of tigers", "massive weight of wedding band oppression", "ringed with ordeals double meaning"] }],
      },
    ],
  },

  // Vistas - Supplementary Reader
  {
    id: "eng-third-level",
    name: "The Third Level",
    aliases: ["the third level class 12", "jack finney", "charley louisa", "grand central station new york", "psychiatrist friend sam weiner", "waking dream wish fulfillment", "escapism from modern world insecurity war fear", "year 1894 galesburg illinois", "first day cover letter from sam"],
    unit: "Vistas (Prose)",
    classLevel: "Class 12",
    exams: ["CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 1,
    topics: [
      {
        id: "eng-third-level-analysis",
        name: "Psychological Escapism, Time Travel & Nostalgia",
        aliases: ["grand central station two levels charley discovers third level", "architectural details gaslights spittoons derby hats handlebar moustaches", "buying two tickets to galesburg 1894 peaceful pre-world-war era", "exchanging modern currency for old style bills lost discount", "sam weiner disappearance first day cover found in stamp collection dated july 18 1894"],
        keywords: ["charley 31 year old narrator stamp collecting philately", "sam explains third level as waking dream wish fulfillment", "modern world full of insecurity fear war worry", "brass spittoons open flame gaslights locomotive with funnel shaped stack", "first day covers envelope mailed to oneself with blank paper", "letter from sam confirming third level is real inviting charley and louisa"],
        subtopics: [{ name: "The Escapist Metaphor", aliases: ["grand central as growing tree"], keywords: ["year 1894 peace before world wars", "sam diagnosis waking dream", "first day cover evidence"] }],
      },
    ],
  },
  {
    id: "eng-tiger-king",
    name: "The Tiger King",
    aliases: ["the tiger king class 12", "kalki", "maharaja of pratibandapuram", "jilani jung jung bahadur", "astrologer prediction death from hundredth tiger", "killing 99 tigers", "british officer durai tiger hunt tiger skin", "fifty diamond rings to duraisani", "hundredth tiger wooden toy tiger sliver infection death"],
    unit: "Vistas (Prose)",
    classLevel: "Class 12",
    exams: ["CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 2,
    topics: [
      {
        id: "eng-tiger-king-analysis",
        name: "Satire on Power, Vanity & Fate's Irony",
        aliases: ["ten day old infant speaks questioning astrologers", "tiger hunting banned for everyone except king in pratibandapuram", "bribing british high-ranking officer wife with 50 diamond rings three lakh rupees", "marrying in royal state with largest tiger population", "dewan hides old tiger from people park in madras", "hundredth tiger fainted from bullet wooden tiger quill causes fatal infection"],
        keywords: ["kalki satirical tone irony of fate", "jilani jung jung bahadur m.a.d. a.c.t.c.", "astrologer promise to cut tuft burn books if 100th tiger killed", "durai wanted photograph holding gun over tiger carcass", "wooden tiger cheap toy carver made poorly tiny silver quill pierced right hand", "suppuration spread death of tiger king destiny fulfilled"],
        subtopics: [{ name: "Dramatic Irony & Satire on Rulers", aliases: ["hundredth tiger wooden toy"], keywords: ["vanity of monarchs", "mass slaughter of wildlife for superstition", "ironic death by crude wooden toy"] }],
      },
    ],
  },
  {
    id: "eng-journey-end-earth",
    name: "Journey to the End of the Earth",
    aliases: ["journey to the end of the earth class 12", "tishani doshi", "antarctica expedition", "students on ice program geoff green", "russian research vessel akademik shokalskiy", "supercontinent gondwana 650 million years ago", "climate change global warming carbon records", "microscopic phytoplankton balance of oceans"],
    unit: "Vistas (Prose)",
    classLevel: "Class 12",
    exams: ["CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 3,
    topics: [
      {
        id: "eng-journey-earth-analysis",
        name: "Ecological Awareness & Climate Change",
        aliases: ["crossing nine time zones six checkpoints three water bodies", "gondwana centered around present day antarctica warm climate flora fauna", "india drifting northwards colliding with asia forming himalayas", "antarctica holds 90 percent of earth total ice volumes no human population", "phytoplankton single celled grasses of sea photosynthesis ozone depletion impact"],
        keywords: ["tishani doshi poet travel writer", "akademik shokalskiy vessel trapped in ice", "students on ice taking high school students to poles future policy makers", "ice cores half million year old carbon records", "take care of small things the big things will fall into place phytoplankton analogy", "profound realization of human impact on planet"],
        subtopics: [{ name: "Gondwana History & Ice Core Records", aliases: ["antarctica geological history"], keywords: ["drake passage opening", "ozone layer hole research", "phytoplankton as food chain foundation"] }],
      },
    ],
  },
  {
    id: "eng-the-enemy",
    name: "The Enemy",
    aliases: ["the enemy class 12", "pearl s buck", "dr sadao hoki and hana", "american pow prisoner of war tom", "world war ii japan america", "general takima assassin promise", "humanity above patriotism medical oath", "escape of prisoner on boat"],
    unit: "Vistas (Prose)",
    classLevel: "Class 12",
    exams: ["CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 4,
    topics: [
      {
        id: "eng-the-enemy-analysis",
        name: "Conflict of Duty: Humanity vs Nationalism",
        aliases: ["sadao medical training in america meeting hana at professor harley house", "wounded sailor washed ashore bleeding bullet wound near kidney", "moral dilemma turn him over to police or treat him as doctor", "servants yumi cook gardener rebelling and abandoning house", "general takima selfish negligence forgetting to send private assassins", "sadao arranges boat food flash light to send tom to nearby unpopulated island"],
        keywords: ["pearl s buck nobel laureate", "sadao father staunch traditional japanese", "hana washing wounded soldier herself when yumi refused", "operation bullet removed from back soldier survives", "sadao writing report in drawer leaving it incomplete", "general reliance on sadao for operation keeping secret", "final reflection why could i not kill him universal brotherhood"],
        subtopics: [{ name: "Doctor's Dilemma & General's Selfishness", aliases: ["sadao medical ethics vs patriotism"], keywords: ["saving enemy soldier life", "servants fear and rebellion", "general takima self-absorption"] }],
      },
    ],
  },
  {
    id: "eng-on-face-of-it",
    name: "On the Face of It",
    aliases: ["on the face of it class 12", "susan hill", "derry and mr lamb", "burnt face acid", "tin leg lamey-lamb", "crab apples garden", "isolation bitterness handicap", "bees buzzing vs singing", "mr lamb fall from ladder death"],
    unit: "Vistas (Prose)",
    classLevel: "Class 12",
    exams: ["CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 5,
    topics: [
      {
        id: "eng-on-face-analysis",
        name: "Psychological Trauma of Physical Impairment",
        aliases: ["derry 14 year old boy acid burnt half of face withdrew into shell", "mr lamb lost leg in war children call him lamey lamb open gates garden", "derry bitter about people stares hypocritical pity mother only kisses other side of face", "mr lamb positive philosophy weeds vs flowers bees humming vs singing", "story of man who locked himself in room for fear of death brick fell on head", "derry transformation returning to garden finding mr lamb dead"],
        keywords: ["susan hill play dialogue format", "derry climbed garden wall avoiding gate thinking house empty", "acid ate my face up ate me up", "mr lamb making jelly from crab apples keeping gate always open", "curtains in windows mr lamb hates shutting things out", "derry promises to come back defies his mother", "lamb falling from ladder with apples tragic end but lasting impact on derry"],
        subtopics: [{ name: "Contrasting Attitudes to Disability", aliases: ["derry bitterness vs lamb optimism"], keywords: ["alienation caused by society reactions", "beauty and the beast analogy", "lamb weed vs flower philosophy"] }],
      },
    ],
  },
  {
    id: "eng-memories-childhood",
    name: "Memories of Childhood",
    aliases: ["memories of childhood class 12", "part 1 the cutting of my long hair zitkala-sa", "part 2 we too are human beings bama", "carlisle indian school assimilation", "shingled hair coward culture", "untouchability caste discrimination", "annand advice education as weapon"],
    unit: "Vistas (Prose)",
    classLevel: "Class 12",
    exams: ["CBSE Class 12", "CBSE Boards", "NCERT"],
    ncertChapterNumber: 6,
    topics: [
      {
        id: "eng-memories-analysis",
        name: "Marginalization, Cultural Erasure & Caste Injustice",
        aliases: ["zitkala sa gertrude simmons bonnin native american oppression", "carlisle indian industrial school forced assimilation", "eating by formula bell dining room confusion", "judewin warnings friend who understood few words of english", "cutting long hair sign of mourners or cowards in native culture hiding under bed", "bama faustina mary fatima rani dalit writer", "innocent walk from school taking thirty minutes instead of ten street amusements", "elder of village carrying vadai packet by string without touching upper caste landlord", "annan advice study hard stand first people will come to you of their own accord"],
        keywords: ["zitkala sa loss of cultural identity felt like one of many animals driven by a herder", "stiff shoes tight fitting clothes iron bell ringing rules", "tied to chair scissors gnawing off thick braids", "bama watching snake charmer monkey show bazaar temple festival", "humiliation of dalit elder bowing before naicker landlord", "untouchability realization infuriating bama", "education as means of liberation and dignity"],
        subtopics: [
          { name: "Part 1: The Cutting of My Long Hair", aliases: ["zitkala sa carlisle school"], keywords: ["eating by formula", "cutting long hair trauma", "native american cultural erasure"] },
          { name: "Part 2: We Too Are Human Beings", aliases: ["bama untouchability annan"], keywords: ["packet carried by string", "caste discrimination in village", "education defeats untouchability"] },
        ],
      },
    ],
  },

  // English Core - Writing Skills & Reading Comprehension
  {
    id: "eng-writing-skills",
    name: "Writing Skills",
    aliases: ["cbse class 12 writing skills", "notice writing", "invitations and replies", "formal and informal invitations", "letter to the editor", "job application with biodata / resume", "article writing", "report writing"],
    unit: "Writing Skills",
    classLevel: "Class 12",
    exams: ["CBSE Class 12", "CBSE Boards"],
    topics: [
      {
        id: "eng-short-writing",
        name: "Notice Writing & Invitations",
        aliases: ["notice format name of institution date NOTICE heading body signatory in a box 50 words", "formal invitation card format single sentence 3rd person", "formal letter invitation for chief guest judges", "formal reply accepting declining invitation", "informal invitation and reply letter format 1st person"],
        keywords: ["notice writing format box 50 words", "date format for notices", "issuing authority designation", "formal invitation card layout", "rsvp details in card invitation", "regretting inability to attend due to prior engagement"],
        subtopics: [
          { name: "Notice Writing Format & Practice", aliases: ["notice in 50 words"], keywords: ["notice box format", "school cultural club notice", "lost and found notice"] },
          { name: "Invitations & Formal Replies", aliases: ["invitation card format rsvp"], keywords: ["card invitation 3rd person", "formal refusal letter", "informal letter invitation"] },
        ],
      },
      {
        id: "eng-long-writing",
        name: "Letters, Articles & Reports",
        aliases: ["letter to editor sender address date receiver address subject salutation body complimentary close", "job application cover letter with bio-data resume curriculum vitae references", "article writing title byline introduction cause effect solution conclusion", "report writing newspaper report school magazine report headline byline dateline factual account"],
        keywords: ["through the columns of your esteemed newspaper", "sensitizing authorities to civic and social issues", "job application post of pgt tgt accountant engineer", "biodata personal details educational qualifications work experience", "article format title byline 120-150 words", "report format headline reporter name date place factual account past tense"],
        subtopics: [
          { name: "Letter to Editor & Job Application", aliases: ["job application biodata format"], keywords: ["letter to editor format", "bio data format with table", "cover letter structure"] },
          { name: "Article & Report Writing", aliases: ["magazine and newspaper report"], keywords: ["report writing past tense", "article catchy title byline", "structure of balanced article"] },
        ],
      },
    ],
  },
  {
    id: "eng-syllabus-revision-samples",
    name: "Flamingo & Vistas Comprehensive Syllabus & Sample Papers",
    aliases: [
      "flamingo prose and poetry full syllabus",
      "cbse class 12 english sample paper",
      "english sample paper solved",
      "english core reading comprehension & writing",
      "reading comprehension unseen passage",
      "class 12 english full revision",
      "cbse class 12 english writing section",
    ],
    unit: "Comprehensive English Core",
    classLevel: "Class 12",
    exams: ["CBSE Class 12", "CBSE Boards", "NCERT"],
    topics: [
      {
        id: "eng-revision-sample-walkthrough",
        name: "Full Syllabus Revision & Sample Paper Walkthrough",
        aliases: ["class 12 english flamingo prose and poetry marathon", "cbse official sample question paper solutions reading and writing", "unseen factual and discursive passages analysis"],
        keywords: [
          "cbse class 12 english flamingo prose and poetry full syllabus one shot revision",
          "cbse class 12 english sample paper 2026 solved",
          "reading comprehension unseen passage answers",
          "writing section notice letter article report invitational replies",
          "marking scheme and question pattern for english core boards",
          "character analysis and central themes of flamingo and vistas",
        ],
        subtopics: [
          { name: "Full Syllabus Literature Revision", aliases: ["flamingo vistas marathon"], keywords: ["the last lesson to journey to end of earth", "poetic devices summary all poems", "long answer questions character sketches"] },
          { name: "Sample Paper & Writing Section Walkthrough", aliases: ["sample paper solutions"], keywords: ["reading comprehension answering strategy", "writing section format practice", "score 95 plus in class 12 english"] },
        ],
      },
    ],
  },

];

// ====================================================================
// 6. MASTER ACADEMIC KNOWLEDGE GRAPH ROOT
// ====================================================================

export const ACADEMIC_KNOWLEDGE_GRAPH: AcademicSubjectGraph[] = [
  { subject: "Physics", chapters: PHYSICS_CHAPTERS },
  { subject: "Chemistry", chapters: CHEMISTRY_CHAPTERS },
  { subject: "Mathematics", chapters: MATHEMATICS_CHAPTERS },
  { subject: "Biology", chapters: BIOLOGY_CHAPTERS },
  { subject: "English", chapters: ENGLISH_CHAPTERS },
];

// ====================================================================
// 7. TAXONOMY LOOKUP ENGINE & ALIAS DICTIONARY
// ====================================================================

export interface TaxonomyMatch {
  subject: AcademicSubject;
  chapter: string;
  topic: string;
  subtopic?: string;
  examRelevance: TargetExam[];
  academicLevel: string;
  matchedEntity: string;
  matchConfidence: number; // 0 to 1
}

/**
 * Standardize text: lowercase, remove punctuation, collapse extra spaces
 */
export function normalizeAcademicText(text: string): string {
  if (!text) return "";
  return text
    .toLowerCase()
    .replace(/[^\w\s\u0900-\u097F]/g, " ") // preserve alphanumeric and devanagari if present
    .replace(/\s+/g, " ")
    .trim();
}

/**
 * Common Coaching, Abbreviation, and Hinglish Canonical Dictionary
 */
export const CANONICAL_ACADEMIC_ALIASES: Record<string, string> = {
  // Physics Abbreviations
  nlm: "laws of motion",
  wep: "work energy power",
  com: "center of mass",
  moi: "moment of inertia",
  rbd: "rotational motion",
  shm: "simple harmonic motion",
  emi: "electromagnetic induction",
  ac: "alternating current",
  emw: "electromagnetic waves",
  ydse: "wave optics",
  itf: "inverse trigonometric functions",
  aod: "application of derivatives",
  de: "differential equations",
  pnc: "permutations and combinations",
  "p&c": "permutations and combinations",
  goc: "organic chemistry",
  iupac: "organic chemistry",
  cft: "coordination compounds",
  vbt: "coordination compounds",
  hgp: "molecular basis of inheritance",
  pcr: "biotechnology principles",
  rnai: "biotechnology applications",
  ada: "biotechnology applications",
  
  // Hinglish and Spoken Vernacular Forms
  "one shot": "lecture complete revision",
  oneshot: "lecture complete revision",
  "one-shot": "lecture complete revision",
  "ka revision": "revision lecture",
  "ka complete chapter": "complete lecture",
  "ke numericals": "numerical problem solving",
  "numericals in hindi": "numerical problem solving",
  "ka full chapter": "complete lecture",
  "physics ka chapter": "physics lecture",
  "chemistry ka revision": "chemistry revision lecture",
  "maths ke questions": "mathematics problem practice",
  "bio ke important questions": "biology important questions",
  "12th physics": "class 12 physics",
  "board ke numericals": "cbse board numericals",
  "ncert se explanation": "ncert explanation",
  "chapter samjha do": "chapter explanation",
  "questions karwao": "problem solving practice",
  "numericals karao": "numerical problem solving",
  "numericals karaye": "numerical problem solving",
  "pyq solving": "previous year questions",
  "important questions": "problem practice",
  "ncert line by line": "ncert explanation",
  "ncert solutions": "ncert textbook explanation",
  "derivation class 12": "derivation proof",
  "board booster": "cbse board revision",
  "crash course": "rapid revision course",
};

function escapeRegex(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

/**
 * Validates that an entity matches on whole-word/token boundaries in normalized text.
 * Prevents substring collisions like 'mot' in 'emotional' or 'shm' in 'freshman'.
 */
export function matchesEntityBounded(text: string, entityNorm: string): boolean {
  if (!text || !entityNorm) return false;
  if (entityNorm.length < 2) return false;
  const escaped = escapeRegex(entityNorm);
  const pattern = new RegExp(`(^|\\s)${escaped}(\\s|$)`, "i");
  return pattern.test(text);
}

/**
 * Query the Knowledge Graph across all subjects, chapters, topics, subtopics, and aliases.
 * Returns best matches ordered by specificity and depth.
 */
export function matchKnowledgeGraph(text: string): TaxonomyMatch[] {
  const norm = normalizeAcademicText(text);
  if (!norm) return [];

  // Expand canonical abbreviations (e.g., com -> center of mass, nlm -> laws of motion)
  let expandedNorm = norm;
  for (const [abbr, expansion] of Object.entries(CANONICAL_ACADEMIC_ALIASES)) {
    if (matchesEntityBounded(norm, abbr)) {
      expandedNorm += " " + expansion;
    }
  }

  const matches: TaxonomyMatch[] = [];

  for (const subjectGraph of ACADEMIC_KNOWLEDGE_GRAPH) {
    for (const chapter of subjectGraph.chapters) {
      // 1. Check exact chapter name
      const chapterNorm = normalizeAcademicText(chapter.name);
      if (matchesEntityBounded(norm, chapterNorm) || matchesEntityBounded(expandedNorm, chapterNorm)) {
        matches.push({
          subject: subjectGraph.subject,
          chapter: chapter.name,
          topic: chapter.topics[0]?.name || chapter.name,
          examRelevance: chapter.exams,
          academicLevel: `${chapter.classLevel} / ${chapter.exams[0] || "JEE/NEET"}`,
          matchedEntity: chapter.name,
          matchConfidence: 0.95,
        });
      }

      // 2. Check chapter aliases
      for (const alias of chapter.aliases) {
        const aliasNorm = normalizeAcademicText(alias);
        if (aliasNorm.length > 2 && (matchesEntityBounded(norm, aliasNorm) || matchesEntityBounded(expandedNorm, aliasNorm))) {
          matches.push({
            subject: subjectGraph.subject,
            chapter: chapter.name,
            topic: chapter.topics[0]?.name || chapter.name,
            examRelevance: chapter.exams,
            academicLevel: `${chapter.classLevel} / ${chapter.exams[0] || "JEE/NEET"}`,
            matchedEntity: alias,
            matchConfidence: 0.90,
          });
        }
      }

      // 3. Check topics & subtopics
      for (const topic of chapter.topics) {
        const topicNorm = normalizeAcademicText(topic.name);
        if (matchesEntityBounded(norm, topicNorm) || matchesEntityBounded(expandedNorm, topicNorm)) {
          matches.push({
            subject: subjectGraph.subject,
            chapter: chapter.name,
            topic: topic.name,
            examRelevance: chapter.exams,
            academicLevel: `${chapter.classLevel} / ${chapter.exams[0] || "JEE/NEET"}`,
            matchedEntity: topic.name,
            matchConfidence: 0.92,
          });
        }

        for (const alias of topic.aliases) {
          const aliasNorm = normalizeAcademicText(alias);
          if (aliasNorm.length > 2 && (matchesEntityBounded(norm, aliasNorm) || matchesEntityBounded(expandedNorm, aliasNorm))) {
            matches.push({
              subject: subjectGraph.subject,
              chapter: chapter.name,
              topic: topic.name,
              examRelevance: chapter.exams,
              academicLevel: `${chapter.classLevel} / ${chapter.exams[0] || "JEE/NEET"}`,
              matchedEntity: alias,
              matchConfidence: 0.88,
            });
          }
        }

        // Keywords
        for (const kw of topic.keywords) {
          const kwNorm = normalizeAcademicText(kw);
          if (kwNorm.length > 3 && matchesEntityBounded(norm, kwNorm)) {
            matches.push({
              subject: subjectGraph.subject,
              chapter: chapter.name,
              topic: topic.name,
              examRelevance: chapter.exams,
              academicLevel: `${chapter.classLevel} / ${chapter.exams[0] || "JEE/NEET"}`,
              matchedEntity: kw,
              matchConfidence: 0.82,
            });
          }
        }

        // Subtopics
        for (const sub of topic.subtopics) {
          const subNorm = normalizeAcademicText(sub.name);
          if (matchesEntityBounded(norm, subNorm)) {
            matches.push({
              subject: subjectGraph.subject,
              chapter: chapter.name,
              topic: topic.name,
              subtopic: sub.name,
              examRelevance: chapter.exams,
              academicLevel: `${chapter.classLevel} / ${chapter.exams[0] || "JEE/NEET"}`,
              matchedEntity: sub.name,
              matchConfidence: 0.93,
            });
          }
          for (const alias of sub.aliases) {
            const subAliasNorm = normalizeAcademicText(alias);
            if (subAliasNorm.length > 2 && matchesEntityBounded(norm, subAliasNorm)) {
              matches.push({
                subject: subjectGraph.subject,
                chapter: chapter.name,
                topic: topic.name,
                subtopic: sub.name,
                examRelevance: chapter.exams,
                academicLevel: `${chapter.classLevel} / ${chapter.exams[0] || "JEE/NEET"}`,
                matchedEntity: alias,
                matchConfidence: 0.89,
              });
            }
          }
        }
      }
    }
  }

  // Sort by highest confidence and longest matched entity
  return matches.sort((a, b) => b.matchConfidence - a.matchConfidence || b.matchedEntity.length - a.matchedEntity.length);
}

/**
 * Search the academic knowledge graph with an optional subject filter.
 */
export function searchKnowledgeGraph(text: string, subjectHint?: AcademicSubject): TaxonomyMatch[] {
  const allMatches = matchKnowledgeGraph(text);
  if (!subjectHint) return allMatches;
  return allMatches.filter((m) => m.subject.toLowerCase() === subjectHint.toLowerCase());
}

/**
 * Retrieve full chapter details by ID or Name from the knowledge graph.
 */
export function getChapterByIdOrName(
  chapterNameOrId: string,
  subjectHint?: AcademicSubject
): { subject: AcademicSubject; chapter: AcademicChapterNode } | null {
  const norm = normalizeAcademicText(chapterNameOrId);
  for (const subjectGraph of ACADEMIC_KNOWLEDGE_GRAPH) {
    if (subjectHint && subjectGraph.subject.toLowerCase() !== subjectHint.toLowerCase()) continue;
    for (const chapter of subjectGraph.chapters) {
      if (chapter.id.toLowerCase() === chapterNameOrId.toLowerCase()) {
        return { subject: subjectGraph.subject, chapter };
      }
      const cNorm = normalizeAcademicText(chapter.name);
      if (cNorm === norm || matchesEntityBounded(norm, cNorm) || chapter.aliases.some((a) => normalizeAcademicText(a) === norm)) {
        return { subject: subjectGraph.subject, chapter };
      }
    }
  }
  return null;
}

