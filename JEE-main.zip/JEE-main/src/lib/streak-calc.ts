export interface MinimalSession {
  date?: string;
  startTime?: string;
  completed?: boolean;
  totalDurationMinutes?: number;
}

/**
 * Format a Date or date string to local YYYY-MM-DD safely
 */
export function toLocalDateKey(d: Date | string): string {
  const dateObj = typeof d === "string" ? new Date(d) : d;
  if (isNaN(dateObj.getTime())) {
    const today = new Date();
    return `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
  }
  const year = dateObj.getFullYear();
  const month = String(dateObj.getMonth() + 1).padStart(2, "0");
  const day = String(dateObj.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

/**
 * Derives current and longest study streak strictly from actual session history.
 * A streak increments for each consecutive calendar day with completed study time.
 * If today hasn't had a session yet, the streak remains intact if yesterday was studied.
 */
export function calculateStreakFromSessions(sessions: MinimalSession[] = []): {
  currentStreak: number;
  longestStreak: number;
} {
  const validSessions = sessions.filter(
    (s) => s && s.completed !== false && Number(s.totalDurationMinutes || 0) > 0
  );

  if (validSessions.length === 0) {
    return { currentStreak: 0, longestStreak: 0 };
  }

  // Collect unique study dates (YYYY-MM-DD)
  const studyDatesSet = new Set<string>();
  validSessions.forEach((s) => {
    if (s.date && /^\d{4}-\d{2}-\d{2}$/.test(s.date)) {
      studyDatesSet.add(s.date);
    } else if (s.startTime) {
      studyDatesSet.add(toLocalDateKey(s.startTime));
    }
  });

  if (studyDatesSet.size === 0) {
    return { currentStreak: 0, longestStreak: 0 };
  }

  const now = new Date();
  const todayKey = toLocalDateKey(now);

  const yesterdayDate = new Date(now);
  yesterdayDate.setDate(yesterdayDate.getDate() - 1);
  const yesterdayKey = toLocalDateKey(yesterdayDate);

  let currentStreak = 0;
  const hasStudiedToday = studyDatesSet.has(todayKey);
  const hasStudiedYesterday = studyDatesSet.has(yesterdayKey);

  // Check if current streak is active
  if (hasStudiedToday || hasStudiedYesterday) {
    let checkDate = hasStudiedToday ? new Date(now) : new Date(yesterdayDate);

    while (true) {
      const key = toLocalDateKey(checkDate);
      if (studyDatesSet.has(key)) {
        currentStreak++;
        checkDate.setDate(checkDate.getDate() - 1);
      } else {
        break;
      }
    }
  }

  // Calculate longest streak historically
  const sortedDates = Array.from(studyDatesSet).sort();
  let longestStreak = 0;
  let tempStreak = 0;
  let prevDate: Date | null = null;

  for (const dateStr of sortedDates) {
    const parts = dateStr.split("-").map(Number);
    const currentDate = new Date(parts[0], parts[1] - 1, parts[2]);

    if (prevDate) {
      const diffMs = currentDate.getTime() - prevDate.getTime();
      const diffDays = Math.round(diffMs / (1000 * 60 * 60 * 24));

      if (diffDays === 1) {
        tempStreak++;
      } else {
        tempStreak = 1;
      }
    } else {
      tempStreak = 1;
    }

    if (tempStreak > longestStreak) {
      longestStreak = tempStreak;
    }
    prevDate = currentDate;
  }

  return {
    currentStreak,
    longestStreak: Math.max(longestStreak, currentStreak),
  };
}
