"use client";

import {
  createUISFX,
  type CueName,
  type PackName,
  type PlayingSFX,
  type UISFXPlayer,
  type PlayOptions,
} from "uisfx";

export type { CueName, PackName, PlayingSFX, PlayOptions };

export type LoopCue =
  | "loading"
  | "processing"
  | "recording"
  | "connecting"
  | "scanning"
  | "streaming";

export const LOOP_CUES = new Set<string>([
  "loading",
  "processing",
  "recording",
  "connecting",
  "scanning",
  "streaming",
]);

// Backward-compatibility alias map for legacy sound cues
const LEGACY_CUE_MAP: Record<string, CueName> = {
  "session-start": "start",
  "session-pause": "pause",
  "session-complete": "complete",
  "task-done": "check",
  "tab-select": "select",
  alert: "warning",
  choose: "select",
  warning: "warning",
  error: "error",
  "level-up": "level-up",
  notification: "notification",
  "toggle-on": "toggle-on",
  "toggle-off": "toggle-off",
};

export type SoundCategory =
  | "ui"
  | "study"
  | "navigation"
  | "notification"
  | "extension"
  | "system";

export type SoundPriority = "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";

// Category mappings for known cues
const CUE_CATEGORY_MAP: Record<string, SoundCategory> = {
  select: "ui",
  choose: "ui",
  open: "ui",
  close: "ui",
  expand: "ui",
  collapse: "ui",
  "toggle-on": "ui",
  "toggle-off": "ui",
  typing: "ui",
  "volume-change": "ui",
  start: "study",
  pause: "study",
  play: "study",
  stop: "study",
  complete: "study",
  checkpoint: "study",
  "level-up": "study",
  notification: "notification",
  success: "notification",
  warning: "notification",
  error: "notification",
  alert: "notification",
  lock: "extension",
  unlock: "extension",
  connect: "extension",
  disconnect: "extension",
  check: "ui",
  stash: "ui",
  unstash: "ui",
  delete: "ui",
};

// Default priority per cue
const CUE_PRIORITY_MAP: Record<string, SoundPriority> = {
  alert: "CRITICAL",
  error: "CRITICAL",
  complete: "HIGH",
  "level-up": "HIGH",
  checkpoint: "HIGH",
  warning: "HIGH",
  disconnect: "HIGH",
  start: "MEDIUM",
  pause: "MEDIUM",
  play: "MEDIUM",
  stop: "MEDIUM",
  success: "MEDIUM",
  notification: "MEDIUM",
  lock: "MEDIUM",
  unlock: "MEDIUM",
  check: "MEDIUM",
  stash: "MEDIUM",
  unstash: "MEDIUM",
  connect: "MEDIUM",
  select: "LOW",
  choose: "LOW",
  open: "LOW",
  close: "LOW",
  expand: "LOW",
  collapse: "LOW",
  "toggle-on": "LOW",
  "toggle-off": "LOW",
  typing: "LOW",
  "volume-change": "LOW",
  delete: "LOW",
};

const PRIORITY_LEVELS: Record<SoundPriority, number> = {
  LOW: 1,
  MEDIUM: 2,
  HIGH: 3,
  CRITICAL: 4,
};

export class SoundManager {
  private player: UISFXPlayer | null = null;
  private enabled: boolean = true;
  private volume: number = 0.7;
  private pack: PackName = "glass";
  private unlocked: boolean = false;
  private activeLoops: Map<string, PlayingSFX> = new Map();
  private throttleMap: Map<string, number> = new Map();
  private initialized: boolean = false;

  // Category specific state
  private categoryEnabled: Record<SoundCategory, boolean> = {
    ui: true,
    study: true,
    navigation: true,
    notification: true,
    extension: true,
    system: true,
  };

  private categoryVolume: Record<SoundCategory, number> = {
    ui: 0.8,
    study: 0.9,
    navigation: 0.7,
    notification: 0.85,
    extension: 0.8,
    system: 0.85,
  };

  // Tracking last high-priority sound timestamp for suppression of low priority cues
  private lastHighPriorityTime: number = 0;

  constructor() {
    if (typeof window !== "undefined") {
      this.initClient();
    }
  }

  private initClient() {
    if (this.initialized) return;
    this.initialized = true;

    try {
      const savedEnabled = localStorage.getItem("focusforge:sfx-enabled");
      if (savedEnabled !== null) {
        this.enabled = savedEnabled === "true";
      }
      const savedVol = localStorage.getItem("focusforge:sfx-volume");
      if (savedVol !== null) {
        const parsed = parseFloat(savedVol);
        if (!isNaN(parsed)) {
          this.volume = Math.max(0, Math.min(1, parsed));
        }
      }
      const savedPack = localStorage.getItem("focusforge:sfx-pack") as PackName | null;
      if (savedPack && typeof savedPack === "string") {
        this.pack = savedPack;
      }

      // Load category enabled states
      const savedCategories = localStorage.getItem("focusforge:sfx-categories");
      if (savedCategories) {
        try {
          const parsed = JSON.parse(savedCategories);
          this.categoryEnabled = { ...this.categoryEnabled, ...parsed };
        } catch {}
      }

      // Load category volume states
      const savedCategoryVols = localStorage.getItem("focusforge:sfx-category-vols");
      if (savedCategoryVols) {
        try {
          const parsed = JSON.parse(savedCategoryVols);
          this.categoryVolume = { ...this.categoryVolume, ...parsed };
        } catch {}
      }
    } catch {
      // Graceful fallback for environments with restricted storage
    }

    try {
      this.player = createUISFX({
        pack: this.pack,
        volume: this.volume,
        enabled: this.enabled,
        preferences: { key: "focusforge:sfx" },
      });
    } catch (err) {
      console.warn("[FocusForge Audio] Failed to instantiate uisfx player:", err);
      this.player = null;
    }

    // Attach unlock handlers on genuine user gestures (pointerdown / keydown) in capture phase
    const unlockHandler = () => {
      this.unlocked = true;
      this.player?.unlock().catch(() => {});
      window.removeEventListener("pointerdown", unlockHandler, true);
      window.removeEventListener("keydown", unlockHandler, true);
    };

    window.addEventListener("pointerdown", unlockHandler, { once: true, capture: true });
    window.addEventListener("keydown", unlockHandler, { once: true, capture: true });
  }

  public async unlock(): Promise<boolean> {
    if (typeof window === "undefined" || !this.player) return false;
    this.unlocked = true;
    try {
      return await this.player.unlock();
    } catch {
      return false;
    }
  }

  public isUnlocked(): boolean {
    return this.unlocked;
  }

  public isEnabled(): boolean {
    return this.enabled;
  }

  public setEnabled(enabled: boolean) {
    if (this.enabled === enabled) return;

    if (!enabled) {
      this.stopAllLoops();
      try {
        this.player?.stopAll();
      } catch {}
    }

    this.enabled = enabled;
    try {
      this.player?.setEnabled(enabled);
      if (typeof window !== "undefined") {
        localStorage.setItem("focusforge:sfx-enabled", String(enabled));
      }
    } catch {}
  }

  public getVolume(): number {
    return this.volume;
  }

  public setVolume(vol: number) {
    const clamped = Math.max(0, Math.min(1, vol));
    this.volume = clamped;
    try {
      this.player?.setVolume(clamped);
      if (typeof window !== "undefined") {
        localStorage.setItem("focusforge:sfx-volume", String(clamped));
      }
    } catch {}
  }

  public getPack(): PackName {
    return this.pack;
  }

  public setPack(pack: PackName) {
    this.pack = pack;
    try {
      this.player?.setPack(pack);
      if (typeof window !== "undefined") {
        localStorage.setItem("focusforge:sfx-pack", pack);
      }
    } catch {}
  }

  // Category Controls
  public isCategoryEnabled(category: SoundCategory): boolean {
    return this.categoryEnabled[category] ?? true;
  }

  public setCategoryEnabled(category: SoundCategory, enabled: boolean) {
    this.categoryEnabled[category] = enabled;
    if (typeof window !== "undefined") {
      try {
        localStorage.setItem(
          "focusforge:sfx-categories",
          JSON.stringify(this.categoryEnabled)
        );
      } catch {}
    }
  }

  public getCategoryVolume(category: SoundCategory): number {
    return this.categoryVolume[category] ?? 0.8;
  }

  public setCategoryVolume(category: SoundCategory, vol: number) {
    const clamped = Math.max(0, Math.min(1, vol));
    this.categoryVolume[category] = clamped;
    if (typeof window !== "undefined") {
      try {
        localStorage.setItem(
          "focusforge:sfx-category-vols",
          JSON.stringify(this.categoryVolume)
        );
      } catch {}
    }
  }

  public getAllCategorySettings(): {
    enabled: Record<SoundCategory, boolean>;
    volumes: Record<SoundCategory, number>;
  } {
    return {
      enabled: { ...this.categoryEnabled },
      volumes: { ...this.categoryVolume },
    };
  }

  public resetToDefaults() {
    this.enabled = true;
    this.volume = 0.7;
    this.pack = "glass";
    this.categoryEnabled = {
      ui: true,
      study: true,
      navigation: true,
      notification: true,
      extension: true,
      system: true,
    };
    this.categoryVolume = {
      ui: 0.8,
      study: 0.9,
      navigation: 0.7,
      notification: 0.85,
      extension: 0.8,
      system: 0.85,
    };

    if (typeof window !== "undefined") {
      try {
        localStorage.setItem("focusforge:sfx-enabled", "true");
        localStorage.setItem("focusforge:sfx-volume", "0.7");
        localStorage.setItem("focusforge:sfx-pack", "glass");
        localStorage.setItem(
          "focusforge:sfx-categories",
          JSON.stringify(this.categoryEnabled)
        );
        localStorage.setItem(
          "focusforge:sfx-category-vols",
          JSON.stringify(this.categoryVolume)
        );
      } catch {}
    }

    try {
      this.player?.setEnabled(true);
      this.player?.setVolume(0.7);
      this.player?.setPack("glass");
    } catch {}
  }

  /**
   * Preview a cue directly for testing/settings.
   * Bypasses category mute and throttle checks.
   */
  public previewCue(cue: CueName | string, category?: SoundCategory): PlayingSFX | null {
    if (typeof window === "undefined" || !this.player) return null;
    try {
      // Temporarily ensure player is active for preview
      const resolvedCue = (LEGACY_CUE_MAP[cue] || cue) as CueName;
      const cat = category || CUE_CATEGORY_MAP[resolvedCue] || "ui";
      const catVol = this.categoryVolume[cat] ?? 0.8;
      const effectiveVolume = Math.min(1, Math.max(0.1, this.volume * catVol));
      return this.player.play(resolvedCue, { volume: effectiveVolume });
    } catch {
      return null;
    }
  }

  public play(
    cue: CueName | keyof typeof LEGACY_CUE_MAP | string,
    options?: PlayOptions,
    categoryOverride?: SoundCategory,
    priorityOverride?: SoundPriority
  ): PlayingSFX | null {
    if (!this.enabled || typeof window === "undefined" || !this.player) return null;

    // Suppress asynchronous or background cues until audio is unlocked by a genuine gesture
    if (!this.unlocked) {
      return null;
    }

    const resolvedCue = (LEGACY_CUE_MAP[cue] || cue) as CueName;
    const category = categoryOverride || CUE_CATEGORY_MAP[resolvedCue] || "ui";

    // Category mute check
    if (!this.isCategoryEnabled(category)) {
      return null;
    }

    const priority = priorityOverride || CUE_PRIORITY_MAP[resolvedCue] || "LOW";
    const priorityVal = PRIORITY_LEVELS[priority];
    const now = Date.now();

    // Priority suppression: if a high/critical cue played in last 300ms, suppress LOW priority clicks
    if (priorityVal === 1 && now - this.lastHighPriorityTime < 300) {
      return null;
    }

    if (priorityVal >= 3) {
      this.lastHighPriorityTime = now;
    }

    // Category volume scaling
    const catVol = this.categoryVolume[category] ?? 1.0;
    const effectiveVolume = (options?.volume ?? 1.0) * catVol;

    try {
      return this.player.play(resolvedCue, {
        ...options,
        volume: effectiveVolume,
      });
    } catch {
      return null;
    }
  }

  public playThrottled(
    cue: CueName,
    cooldownMs = 150,
    options?: PlayOptions,
    categoryOverride?: SoundCategory,
    priorityOverride?: SoundPriority
  ): PlayingSFX | null {
    const now = Date.now();
    const last = this.throttleMap.get(cue) || 0;
    if (now - last < cooldownMs) return null;
    this.throttleMap.set(cue, now);
    return this.play(cue, options, categoryOverride, priorityOverride);
  }

  public playTyping(): void {
    if (!this.enabled || typeof window === "undefined" || !this.player) return;
    if (!this.isCategoryEnabled("ui")) return;
    const catVol = this.categoryVolume.ui ?? 0.8;
    try {
      this.player.play("typing", {
        volume: 0.15 * catVol,
        retrigger: "overlap",
      });
    } catch {}
  }

  public startLoop(cue: LoopCue, category?: SoundCategory): PlayingSFX | null {
    if (!this.enabled || typeof window === "undefined" || !this.player) return null;
    const cat = category || "ui";
    if (!this.isCategoryEnabled(cat)) return null;

    // Idempotent: return existing handle if loop already active
    if (this.activeLoops.has(cue)) {
      return this.activeLoops.get(cue) || null;
    }

    try {
      const catVol = this.categoryVolume[cat] ?? 1.0;
      const handle = this.player.play(cue, { loop: true, volume: catVol });
      if (handle) {
        this.activeLoops.set(cue, handle);
      }
      return handle;
    } catch {
      return null;
    }
  }

  public stopLoop(cue: LoopCue | string): void {
    const handle = this.activeLoops.get(cue);
    if (handle) {
      try {
        handle.stop();
      } catch {}
      this.activeLoops.delete(cue);
    }
  }

  public stopAllLoops(): void {
    for (const [, handle] of this.activeLoops.entries()) {
      try {
        handle.stop();
      } catch {}
    }
    this.activeLoops.clear();
  }

  public stopAll(): void {
    this.stopAllLoops();
    try {
      this.player?.stopAll();
    } catch {}
  }

  public async destroy(): Promise<void> {
    this.stopAllLoops();
    try {
      await this.player?.destroy();
    } catch {}
    this.player = null;
    this.unlocked = false;
  }
}

// Global client-side singleton instance
export const soundManager = new SoundManager();
