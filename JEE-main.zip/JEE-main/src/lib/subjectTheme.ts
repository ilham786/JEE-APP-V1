export * from "@/theme/subjectTheme";

import { getSubjectTheme as getThemeFromModule, SUBJECT_COLORS } from "@/theme/subjectTheme";

export interface SubjectThemeConfig {
  name: "Physics" | "Chemistry" | "Maths" | "Mathematics" | "Botany" | "Zoology" | "Biology" | "All";
  primaryHex: string;
  bgTint: string;
  border: string;
  hover: string;
  textClass: string;
  badgeClass: string;
  progressClass: string;
  borderLeftClass: string;
  focusClass: string;
  accentBg: string;
  accentBorder: string;
  subchapterClass: string;
}

export function getSubjectThemeConfig(subjectName?: string): SubjectThemeConfig {
  const theme = getThemeFromModule(subjectName);

  return {
    name: theme.name as SubjectThemeConfig["name"],
    primaryHex: theme.primary,
    bgTint: theme.background,
    border: theme.border,
    hover: theme.hover,
    textClass: theme.textClass,
    badgeClass: theme.badgeClass,
    progressClass: theme.progressClass,
    borderLeftClass: theme.borderLeftClass,
    focusClass: theme.focusClass,
    accentBg: theme.accentBg,
    accentBorder: theme.accentBorder,
    subchapterClass: theme.subchapterClass,
  };
}

export { SUBJECT_COLORS as SUBJECT_THEMES };
