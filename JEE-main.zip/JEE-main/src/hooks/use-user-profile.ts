"use client";

import { useMemo } from "react";
import { useAuth } from "@/context/AuthContext";
import { useStudyStore } from "@/store/use-study-store";
import { xpService } from "@/services/xpService";
import { calculateStreakFromSessions } from "@/lib/streak-calc";
import { UserProfile } from "@/services/userService";

/**
 * Single authoritative hook for accessing and updating the active user's profile.
 */
export function useUserProfile() {
  const { userProfile, loading, updateProfileData, refreshProfile, checkUsernameAvailability } = useAuth();

  return {
    userProfile,
    profile: userProfile,
    loading,
    updateProfileData,
    updateProfile: updateProfileData,
    refreshProfile,
    refresh: refreshProfile,
    checkUsernameAvailability,
  };
}

/**
 * Unified hook for mathematically consistent XP, Level, and Next-Level progress.
 * Consumes the authoritative xpService.getLevelProgress.
 */
export function useXpProgress(customXp?: number) {
  const { userProfile } = useAuth();
  const { xp: storeXp } = useStudyStore();

  const totalXp = customXp !== undefined ? customXp : (userProfile?.xp ?? storeXp ?? 0);

  const progress = useMemo(() => {
    return xpService.getLevelProgress(totalXp);
  }, [totalXp]);

  return {
    totalXp,
    ...progress,
  };
}

/**
 * Unified hook for derived study streaks based on actual session history.
 */
export function useStudyStreak() {
  const { userProfile } = useAuth();
  const { sessionHistory = [], currentStreak: storeStreak, longestStreak: storeLongest } = useStudyStore();

  const streakData = useMemo(() => {
    if (sessionHistory && sessionHistory.length > 0) {
      return calculateStreakFromSessions(sessionHistory);
    }
    return {
      currentStreak: userProfile?.streak ?? storeStreak ?? 0,
      longestStreak: storeLongest ?? userProfile?.streak ?? 0,
    };
  }, [sessionHistory, userProfile?.streak, storeStreak, storeLongest]);

  return {
    streak: streakData.currentStreak,
    currentStreak: streakData.currentStreak,
    longestStreak: streakData.longestStreak,
  };
}
