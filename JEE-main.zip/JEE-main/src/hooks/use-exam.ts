"use client";

import { useMemo, useCallback } from "react";
import { useAuth } from "@/context/AuthContext";
import {
  ExamType,
  ExamConfig,
  getExamConfig,
  detectExamTypeFromTarget,
  getUpcomingExamYears,
} from "@/lib/exam-config";
import { getSubjectTheme } from "@/theme/themeHelpers";

/**
 * useExam Hook
 * 
 * Centralized, reactive hook for accessing the active user's preparation track.
 * Adapts all pages dynamically to either JEE or NEET without hardcoded conditional logic.
 */
export function useExam() {
  const { userProfile, updateProfileData, refreshProfile } = useAuth();

  // Authoritative exam type detection:
  // 1. Explicit profile.examType
  // 2. Detected from targetExam string
  // 3. Fallback to "JEE"
  const examType: ExamType = useMemo(() => {
    if (userProfile?.examType === "NEET" || userProfile?.examType === "JEE") {
      return userProfile.examType;
    }
    return detectExamTypeFromTarget(userProfile?.targetExam);
  }, [userProfile?.examType, userProfile?.targetExam]);

  const config: ExamConfig = useMemo(() => {
    return getExamConfig(examType);
  }, [examType]);

  const isNeet = examType === "NEET";
  const isJee = examType === "JEE";

  const targetYear = useMemo(() => {
    if (userProfile?.targetYear) return String(userProfile.targetYear);
    const upcoming = getUpcomingExamYears(4);
    return String(upcoming[0]);
  }, [userProfile?.targetYear]);

  const targetExam = userProfile?.targetExam || (isNeet ? `NEET UG ${targetYear}` : `JEE Main & Advanced ${targetYear}`);

  /**
   * Switch user's preparation track between JEE and NEET safely.
   * Updates profile while preserving all historical study sessions and mistake logs.
   */
  const switchExamTrack = useCallback(
    async (newTrack: ExamType, targetYearParam?: number | string) => {
      const upcoming = getUpcomingExamYears(4);
      const chosenYr = targetYearParam ? String(targetYearParam) : String(upcoming[0]);
      const newTargetExam = newTrack === "NEET" ? `NEET UG ${chosenYr}` : `JEE Main & Advanced ${chosenYr}`;
      const newSyllabusVersion = newTrack === "NEET" ? "NEET-UG-2026-NMC" : "JEE-2027";

      await updateProfileData({
        examType: newTrack,
        targetExam: newTargetExam,
        targetYear: chosenYr,
        syllabusVersion: newSyllabusVersion,
      });

      await refreshProfile();
    },
    [updateProfileData, refreshProfile]
  );

  return {
    examType,
    config,
    isNeet,
    isJee,
    subjects: config.subjects.map((s) => s.name),
    subjectConfigs: config.subjects,
    subjectNames: config.subjects.map((s) => s.name),
    targetYear,
    targetExam,
    switchExamTrack,
    getSubjectTheme,
  };
}

