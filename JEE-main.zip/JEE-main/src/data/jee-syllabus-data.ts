export interface FormulaItem {
  name: string;
  expression: string;
  description: string;
}

export interface ChapterData {
  id: string;
  name: string;
  subject: "Physics" | "Chemistry" | "Maths";
  classLevel: "Class 11" | "Class 12";
  subDiscipline: string;
  trendWeightage: number; // Percentage e.g. 7.35
  estimatedQuestions: number;
  weightageTier: "Very High" | "High" | "Medium" | "Low";
  importanceStars: 5 | 4 | 3 | 2 | 1;
  importanceBadge: "Critical" | "High" | "Medium" | "Low" | "Optional";
  difficulty: "Easy" | "Medium" | "Hard" | "Very Hard";
  pyqsTotal: number;
  pyqs2024Count: number;
  pyqs2025Count: number;
  topics: string[];
  subtopics: string[];
  formulas: FormulaItem[];
  shortNotes: string[];
  commonMistakes: string[];
  freqConcepts: string[];
  aiNotesAvailable: boolean;
}

export const JEE_SYLLABUS_DATA: Record<"Physics" | "Chemistry" | "Maths", ChapterData[]> = {
  Physics: [
    // Class 11 Physics
    {
      id: "phy-11-1",
      name: "Units and Measurements",
      subject: "Physics",
      classLevel: "Class 11",
      subDiscipline: "Mechanics",
      trendWeightage: 4.24,
      estimatedQuestions: 2,
      weightageTier: "High",
      importanceStars: 4,
      importanceBadge: "High",
      difficulty: "Easy",
      pyqsTotal: 65,
      pyqs2024Count: 22,
      pyqs2025Count: 33,
      topics: [
        "Units of measurements, System of units, SI Units",
        "Fundamental and derived units, Least count",
        "Significant figures, Errors in measurements",
        "Dimensions of Physics quantities & dimensional analysis"
      ],
      subtopics: ["Absolute error", "Relative error", "Combination of errors", "Dimensional formula matching", "Vernier calipers & Screw gauge"],
      formulas: [
        { name: "Percentage Error", expression: "% \\text{ Error} = \\left| \\frac{\\Delta A}{A} \\right| \\times 100\\%", description: "Fractional uncertainty expressed in percentage." },
        { name: "Vernier Least Count", expression: "LC = 1 \\text{ MSD} - 1 \\text{ VSD} = \\frac{1 \\text{ MSD}}{N}", description: "Difference between 1 Main Scale Division and 1 Vernier Scale Division." },
        { name: "Screw Gauge Least Count", expression: "LC = \\frac{\\text{Pitch}}{\\text{Total Circular Scale Divisions}}", description: "Minimum measurable length of micrometer screw gauge." }
      ],
      shortNotes: [
        "Dimensions of ML^2T^-2 represent Energy, Torque, Work, and Heat.",
        "When multiplying or dividing measurements, keep significant figures equal to the least precise measurement.",
        "Zero error must always be subtracted algebraically from measured reading."
      ],
      commonMistakes: [
        "Forgetting to subtract negative zero error (which turns into addition).",
        "Confusing percentage error in quantities raised to powers like A^2 B^3 / sqrt(C)."
      ],
      freqConcepts: ["Dimensional Analysis", "Combination of Errors in Powers", "Screw Gauge Readings"],
      aiNotesAvailable: true
    },
    {
      id: "phy-11-2",
      name: "Motion in a Straight Line",
      subject: "Physics",
      classLevel: "Class 11",
      subDiscipline: "Mechanics",
      trendWeightage: 2.63,
      estimatedQuestions: 1,
      weightageTier: "Medium",
      importanceStars: 3,
      importanceBadge: "Medium",
      difficulty: "Easy",
      pyqsTotal: 45,
      pyqs2024Count: 14,
      pyqs2025Count: 9,
      topics: [
        "Frame of reference, Motion in a straight line, Speed & Velocity",
        "Uniform & non-uniform motion, Average speed & Instantaneous velocity",
        "Uniformly accelerated motion & kinematic graphs",
        "Relative velocity in 1D"
      ],
      subtopics: ["v-t graph area and slope", "Motion under gravity", "Stopping distance", "Relative velocity of approach"],
      formulas: [
        { name: "Kinematic Equation 1", expression: "v = u + at", description: "Velocity after time t under constant acceleration." },
        { name: "Displacement Equation", expression: "s = ut + \\frac{1}{2}at^2", description: "Displacement under uniform acceleration." },
        { name: "nth Second Distance", expression: "S_n = u + \\frac{a}{2}(2n - 1)", description: "Distance covered specifically in the nth second." }
      ],
      shortNotes: [
        "Area under v-t graph gives displacement; area under |v|-t graph gives distance.",
        "If a body starts from rest with constant acceleration, distances in equal time intervals are in ratio 1:3:5:7 (Galileo's law)."
      ],
      commonMistakes: [
        "Assuming acceleration is zero at maximum height when throwing a ball upward (acceleration is still -g).",
        "Mixing up average speed with magnitude of average velocity."
      ],
      freqConcepts: ["Galileo's Law of Odd Numbers", "Graphs Integration/Differentiation", "Relative Motion in 1D"],
      aiNotesAvailable: true
    },
    {
      id: "phy-11-3",
      name: "Motion in a Plane",
      subject: "Physics",
      classLevel: "Class 11",
      subDiscipline: "Mechanics",
      trendWeightage: 2.92,
      estimatedQuestions: 1,
      weightageTier: "Medium",
      importanceStars: 3,
      importanceBadge: "Medium",
      difficulty: "Medium",
      pyqsTotal: 52,
      pyqs2024Count: 16,
      pyqs2025Count: 10,
      topics: [
        "Vectors and scalars, Vector addition and resolution",
        "Motion in a plane, Projectile motion",
        "Uniform circular motion, Radial acceleration"
      ],
      subtopics: ["Time of flight & Range", "Equation of trajectory", "Relative projectile velocity", "River-swimmer problems", "Rain-umbrella problems"],
      formulas: [
        { name: "Maximum Height", expression: "H_{\\max} = \\frac{u^2 \\sin^2 \\theta}{2g}", description: "Peak height reached by a projectile." },
        { name: "Horizontal Range", expression: "R = \\frac{u^2 \\sin 2\\theta}{g}", description: "Total horizontal distance traversed." },
        { name: "Trajectory Equation", expression: "y = x \\tan\\theta - \\frac{g x^2}{2 u^2 \\cos^2\\theta}", description: "Parabolic trajectory equation." }
      ],
      shortNotes: [
        "Horizontal velocity component (u cosθ) remains unchanged throughout projectile flight.",
        "Complementary angles of projection (θ and 90°-θ) yield equal horizontal ranges."
      ],
      commonMistakes: [
        "Forgetting that acceleration in uniform circular motion is directed towards center (a_c = v^2/r).",
        "Incorrect angle reference for river-swimmer shortest path."
      ],
      freqConcepts: ["Projectile Equation of Trajectory", "River Swimmer Shortest Time", "Centripetal Acceleration"],
      aiNotesAvailable: true
    },
    {
      id: "phy-11-4",
      name: "Newton's Laws of Motion",
      subject: "Physics",
      classLevel: "Class 11",
      subDiscipline: "Mechanics",
      trendWeightage: 2.05,
      estimatedQuestions: 1,
      weightageTier: "Low",
      importanceStars: 2,
      importanceBadge: "Low",
      difficulty: "Medium",
      pyqsTotal: 40,
      pyqs2024Count: 12,
      pyqs2025Count: 11,
      topics: [
        "Force and inertia, Newton's first, second, & third laws",
        "Impulse & Conservation of linear momentum",
        "Static and kinetic friction, Laws of friction",
        "Dynamics of circular motion & Banking of roads"
      ],
      subtopics: ["Apparent weight in lifts", "Atwood pulley systems", "Angle of repose", "Banking angle without friction"],
      formulas: [
        { name: "Impulse-Momentum Theorem", expression: "J = \\int F dt = \\Delta p", description: "Change in momentum produced by impulsive force." },
        { name: "Limiting Friction", expression: "f_s^{\\max} = \\mu_s N", description: "Maximum static friction before impending motion." },
        { name: "Optimum Banking Speed", expression: "v = \\sqrt{rg \\tan\\theta}", description: "Safe speed on banked road without relying on friction." }
      ],
      shortNotes: [
        "Action and reaction forces act on different bodies, so they never cancel each other out.",
        "Kinetic friction is independent of contact surface area and relative speed once sliding begins."
      ],
      commonMistakes: [
        "Using N = mg blindly on inclined planes (where N = mg cosθ).",
        "Assuming static friction is always equal to μ_s N (it adjusts dynamically up to μ_s N)."
      ],
      freqConcepts: ["Pulley Constraint Relations", "Vehicle Banking Equations", "Variable Mass Systems"],
      aiNotesAvailable: true
    },
    {
      id: "phy-11-5",
      name: "Work, Energy & Power",
      subject: "Physics",
      classLevel: "Class 11",
      subDiscipline: "Mechanics",
      trendWeightage: 2.37,
      estimatedQuestions: 1,
      weightageTier: "Medium",
      importanceStars: 3,
      importanceBadge: "Medium",
      difficulty: "Medium",
      pyqsTotal: 48,
      pyqs2024Count: 15,
      pyqs2025Count: 15,
      topics: [
        "Work done by constant & variable force, Work-Energy theorem",
        "Kinetic & potential energy, Conservative & non-conservative forces",
        "Motion in a vertical circle, Elastic and inelastic collisions"
      ],
      subtopics: ["Potential energy curve analysis", "Spring potential energy", "Coefficient of restitution e", "Critical speed in vertical circle"],
      formulas: [
        { name: "Work-Energy Theorem", expression: "W_{\\text{net}} = \\Delta K = K_f - K_i", description: "Net work done by all forces equals change in kinetic energy." },
        { name: "Spring Potential Energy", expression: "U = \\frac{1}{2}k x^2", description: "Energy stored in elastic spring compressed/extended by x." },
        { name: "Vertical Circle Min Speed", expression: "v_{\\text{bottom}} = \\sqrt{5gR}, \\quad v_{\\text{top}} = \\sqrt{gR}", description: "Minimum speeds for complete looping in a vertical circle." }
      ],
      shortNotes: [
        "Force is negative gradient of potential energy: F = -dU/dx. Stable equilibrium occurs at d^2U/dx^2 > 0.",
        "In perfectly elastic collisions, coefficient of restitution e = 1 and kinetic energy is conserved."
      ],
      commonMistakes: [
        "Confusing mechanical energy conservation in the presence of friction (friction does negative work).",
        "Miscalculating velocity components after oblique 2D collisions."
      ],
      freqConcepts: ["Vertical Circular Motion Looping", "Coefficient of Restitution 2D", "Potential Energy Equilibrium Points"],
      aiNotesAvailable: true
    },
    {
      id: "phy-11-6",
      name: "Rotational Motion",
      subject: "Physics",
      classLevel: "Class 11",
      subDiscipline: "Mechanics",
      trendWeightage: 4.31,
      estimatedQuestions: 2,
      weightageTier: "High",
      importanceStars: 4,
      importanceBadge: "High",
      difficulty: "Hard",
      pyqsTotal: 85,
      pyqs2024Count: 28,
      pyqs2025Count: 27,
      topics: [
        "Centre of mass of 2-particle & rigid systems",
        "Torque, angular momentum, conservation of angular momentum",
        "Moment of inertia, Parallel & Perpendicular axes theorems",
        "Pure rolling motion & rotational kinetic energy"
      ],
      subtopics: ["Radius of gyration K", "Combined translational and rotational motion", "Instantaneous axis of rotation", "Angular impulse"],
      formulas: [
        { name: "Torque Equation", expression: "\\vec{\\tau} = \\vec{r} \\times \\vec{F} = I \\vec{\\alpha}", description: "Rotational equivalent of Newton's second law." },
        { name: "Angular Momentum", expression: "L = I \\omega = r p \\sin\\theta", description: "Rotational momentum about a fixed axis." },
        { name: "Parallel Axis Theorem", expression: "I = I_{\\text{cm}} + M d^2", description: "Moment of inertia about any axis parallel to center of mass." }
      ],
      shortNotes: [
        "In pure rolling on a stationary surface, point of contact has zero instantaneous velocity (v_cm = R ω).",
        "Perpendicular axis theorem (I_z = I_x + I_y) applies ONLY to planar 2D laminar objects."
      ],
      commonMistakes: [
        "Applying perpendicular axis theorem to 3D objects like spheres or cylinders.",
        "Incorrect torque direction cross product sign."
      ],
      freqConcepts: ["Conservation of Angular Momentum", "Pure Rolling Acceleration on Incline", "Moment of Inertia Theorems"],
      aiNotesAvailable: true
    },
    {
      id: "phy-11-7",
      name: "Gravitation",
      subject: "Physics",
      classLevel: "Class 11",
      subDiscipline: "Mechanics",
      trendWeightage: 4.49,
      estimatedQuestions: 2,
      weightageTier: "High",
      importanceStars: 4,
      importanceBadge: "High",
      difficulty: "Medium",
      pyqsTotal: 80,
      pyqs2024Count: 25,
      pyqs2025Count: 14,
      topics: [
        "Universal law of gravitation, Acceleration due to gravity g",
        "Variation of g with altitude, depth, & latitude",
        "Gravitational potential energy & gravitational potential",
        "Kepler's laws, Escape velocity, Satellite orbital motion"
      ],
      subtopics: ["Escape speed from Earth", "Kepler's 3rd law T^2 proportional to r^3", "Geostationary satellites", "Gravitational self-energy"],
      formulas: [
        { name: "Variation of g with Height", expression: "g' = g \\left(1 - \\frac{2h}{R}\\right) \\quad (h \\ll R)", description: "Reduction in gravitational acceleration at height h." },
        { name: "Escape Velocity", expression: "v_e = \\sqrt{\\frac{2GM}{R}} = \\sqrt{2gR} \\approx 11.2 \\text{ km/s}", description: "Minimum speed required to escape planetary gravitational pull." },
        { name: "Orbital Velocity", expression: "v_o = \\sqrt{\\frac{GM}{r}}", description: "Circular orbital speed of a satellite at radius r." }
      ],
      shortNotes: [
        "Gravitational potential at the center of a solid sphere is -1.5 GM/R.",
        "Total mechanical energy of a bound satellite is E = -GMm / (2r), which equals -K."
      ],
      commonMistakes: [
        "Using g' = g(1 - 2h/R) when height h is comparable to Earth radius R (must use g' = g R^2 / (R+h)^2).",
        "Forgetting negative sign in gravitational potential energy."
      ],
      freqConcepts: ["Escape Velocity Calculations", "Variation of g with Depth & Altitude", "Satellite Energy Relationships"],
      aiNotesAvailable: true
    },
    {
      id: "phy-11-8",
      name: "Thermodynamics",
      subject: "Physics",
      classLevel: "Class 11",
      subDiscipline: "Heat & Thermodynamics",
      trendWeightage: 3.06,
      estimatedQuestions: 1,
      weightageTier: "Medium",
      importanceStars: 3,
      importanceBadge: "Medium",
      difficulty: "Medium",
      pyqsTotal: 62,
      pyqs2024Count: 19,
      pyqs2025Count: 22,
      topics: [
        "Thermal equilibrium, Zeroth law, Heat, Work & Internal energy",
        "First law of thermodynamics, Isothermal & Adiabatic processes",
        "Second law of thermodynamics, Reversible & irreversible processes",
        "Carnot engine efficiency & heat pumps"
      ],
      subtopics: ["PV indicator diagrams", "Adiabatic equation PV^gamma = const", "Molar heat capacity C_p and C_v", "Carnot cycle efficiency"],
      formulas: [
        { name: "First Law of Thermodynamics", expression: "\\Delta Q = \\Delta U + W", description: "Energy conservation in thermodynamic systems." },
        { name: "Adiabatic Work Done", expression: "W = \\frac{P_1 V_1 - P_2 V_2}{\\gamma - 1}", description: "Work done in adiabatic expansion/compression." },
        { name: "Carnot Efficiency", expression: "\\eta = 1 - \\frac{T_2}{T_1} = 1 - \\frac{Q_2}{Q_1}", description: "Maximum possible thermodynamic efficiency." }
      ],
      shortNotes: [
        "Work done in cyclic process equals cyclic area enclosed in PV diagram (clockwise = positive work).",
        "Internal energy U depends purely on temperature for ideal gases: dU = n C_v dT."
      ],
      commonMistakes: [
        "Confusing physics convention (W = work done BY gas) with chemistry convention (W = work done ON gas).",
        "Using Celsius instead of Absolute Kelvin in Carnot efficiency formula."
      ],
      freqConcepts: ["Cyclic Process Work Calculation", "Polytropic Process Heat Capacity", "Carnot Engine Efficiency"],
      aiNotesAvailable: true
    },

    // Class 12 Physics
    {
      id: "phy-12-1",
      name: "Current Electricity",
      subject: "Physics",
      classLevel: "Class 12",
      subDiscipline: "Electromagnetism",
      trendWeightage: 6.57,
      estimatedQuestions: 3,
      weightageTier: "Very High",
      importanceStars: 5,
      importanceBadge: "Critical",
      difficulty: "Medium",
      pyqsTotal: 120,
      pyqs2024Count: 38,
      pyqs2025Count: 17,
      topics: [
        "Electric current, Drift velocity, Mobility, Ohm's Law",
        "Electrical resistance, Temperature dependence of resistance",
        "Kirchhoff's Laws & circuit network solutions",
        "Wheatstone bridge, Metre bridge, Potentiometer principles"
      ],
      subtopics: ["Drift velocity formula I = n A e v_d", "Combination of cells in series/parallel", "Internal resistance measurement", "Color coding & resistivity"],
      formulas: [
        { name: "Drift Velocity", expression: "v_d = \\frac{e E \\tau}{m} = \\frac{I}{n e A}", description: "Average velocity attained by free electrons due to electric field." },
        { name: "Kirchhoff's Voltage Law", expression: "\\sum V = 0", description: "Sum of potential differences around any closed circuit loop is zero." },
        { name: "Potentiometer EMF Comparison", expression: "\\frac{E_1}{E_2} = \\frac{l_1}{l_2}", description: "Ratio of unknown EMFs matched to null deflection lengths." }
      ],
      shortNotes: [
        "Potentiometer measures true EMF because it draws zero current at null point.",
        "Equivalent resistance of N identical resistors R in parallel is R/N; in series it is N R."
      ],
      commonMistakes: [
        "Incorrect battery polarity signs while traversing Kirchhoff loops.",
        "Neglecting internal resistance r when calculating terminal voltage V = E - I r."
      ],
      freqConcepts: ["Metre Bridge & Potentiometer Null Points", "Equivalent Resistance Circuits", "Kirchhoff Loop Analysis"],
      aiNotesAvailable: true
    },
    {
      id: "phy-12-2",
      name: "Ray Optics and Optical Instruments",
      subject: "Physics",
      classLevel: "Class 12",
      subDiscipline: "Optics",
      trendWeightage: 5.04,
      estimatedQuestions: 3,
      weightageTier: "Very High",
      importanceStars: 5,
      importanceBadge: "Critical",
      difficulty: "Hard",
      pyqsTotal: 105,
      pyqs2024Count: 32,
      pyqs2025Count: 42,
      topics: [
        "Reflection & Refraction at plane & spherical surfaces",
        "Total Internal Reflection (TIR) & optical fibers",
        "Lens maker's formula, Combination of thin lenses",
        "Refraction through a prism, Microscope & Astronomical telescope"
      ],
      subtopics: ["Apparent depth & displacement", "Critical angle sin i_c = 1/mu", "Minimum deviation in prism", "Magnifying power of telescope"],
      formulas: [
        { name: "Lens Maker's Formula", expression: "\\frac{1}{f} = (\\mu - 1) \\left( \\frac{1}{R_1} - \\frac{1}{R_2} \\right)", description: "Focal length calculation based on radii of curvature." },
        { name: "Prism Formula", expression: "\\mu = \\frac{\\sin\\left(\\frac{A + D_m}{2}\\right)}{\\sin\\left(\\frac{A}{2}\\right)}", description: "Refractive index in terms of angle of prism A and min deviation D_m." },
        { name: "Telescope Magnification", expression: "m = -\\frac{f_o}{f_e}", description: "Angular magnification of astronomical telescope at normal adjustment." }
      ],
      shortNotes: [
        "Power of lens in Dioptres P = 1 / f(in meters). Combination of thin lenses in contact: P_eq = P1 + P2.",
        "Total Internal Reflection occurs when light travels from denser to rarer medium at angle > critical angle."
      ],
      commonMistakes: [
        "Cartesian sign convention errors (convex lens f positive, concave lens f negative).",
        "Confusing magnification for relaxed eye (v=infinity) vs distinct vision (v=D)."
      ],
      freqConcepts: ["Prism Minimum Deviation", "Lens Maker Formula Sign Convention", "Compound Microscope Magnification"],
      aiNotesAvailable: true
    },
    {
      id: "phy-12-3",
      name: "Electrostatic Potential and Capacitance",
      subject: "Physics",
      classLevel: "Class 12",
      subDiscipline: "Electromagnetism",
      trendWeightage: 4.49,
      estimatedQuestions: 2,
      weightageTier: "High",
      importanceStars: 4,
      importanceBadge: "High",
      difficulty: "Medium",
      pyqsTotal: 78,
      pyqs2024Count: 24,
      pyqs2025Count: 21,
      topics: [
        "Electric potential due to point charge & dipole",
        "Equipotential surfaces & potential energy of charges",
        "Capacitors & capacitance, Parallel plate capacitor",
        "Dielectric insertion & energy stored in capacitor"
      ],
      subtopics: ["Electric field E = -dV/dr", "Capacitor series/parallel combination", "Dielectric slab insertion effect", "Common potential of sharing capacitors"],
      formulas: [
        { name: "Parallel Plate Capacitance", expression: "C = \\frac{K \\varepsilon_0 A}{d}", description: "Capacitance with dielectric constant K." },
        { name: "Energy Stored in Capacitor", expression: "U = \\frac{1}{2} C V^2 = \\frac{Q^2}{2C} = \\frac{1}{2} Q V", description: "Electrostatic energy stored in electric field between plates." },
        { name: "Dipole Potential", expression: "V = \\frac{1}{4\\pi\\varepsilon_0} \\frac{p \\cos\\theta}{r^2}", description: "Potential at distance r and angle θ from dipole center." }
      ],
      shortNotes: [
        "Electric field lines are always perpendicular to equipotential surfaces.",
        "Inserting dielectric with battery disconnected keeps charge Q constant (C increases by K, V decreases by K)."
      ],
      commonMistakes: [
        "Forgetting whether battery remains connected or disconnected during dielectric insertion.",
        "Incorrect potential inside a conducting sphere (it is uniform and equal to surface potential)."
      ],
      freqConcepts: ["Dielectric Insertion Battery Scenarios", "Equipotential Surface Geometry", "Common Potential & Heat Loss"],
      aiNotesAvailable: true
    },
    {
      id: "phy-12-4",
      name: "Semiconductor Electronics: Materials, Devices and Simple Circuits",
      subject: "Physics",
      classLevel: "Class 12",
      subDiscipline: "Modern Physics",
      trendWeightage: 4.75,
      estimatedQuestions: 2,
      weightageTier: "Very High",
      importanceStars: 5,
      importanceBadge: "Critical",
      difficulty: "Easy",
      pyqsTotal: 92,
      pyqs2024Count: 30,
      pyqs2025Count: 19,
      topics: [
        "Intrinsic & Extrinsic semiconductors (n-type & p-type)",
        "p-n junction diode I-V characteristics (Forward & Reverse bias)",
        "Diode as a rectifier (Half-wave & Full-wave)",
        "Logic gates (OR, AND, NOT, NAND, NOR) & truth tables"
      ],
      subtopics: ["Depletion layer width", "Zener diode as voltage regulator", "NAND/NOR universal gates", "Boolean algebra De Morgan's laws"],
      formulas: [
        { name: "Mass Action Law", expression: "n_e \\cdot n_h = n_i^2", description: "Carrier concentrations product in thermal equilibrium." },
        { name: "Full-Wave Rectifier Ripple Factor", expression: "r = 0.482, \\quad \\text{Efficiency } \\eta = 81.2\\%", description: "Performance metrics of full-wave bridge rectifier." },
        { name: "De Morgan's Theorem", expression: "\\overline{A \\cdot B} = \\overline{A} + \\overline{B}, \\quad \\overline{A + B} = \\overline{A} \\cdot \\overline{B}", description: "Fundamental Boolean logic transformation rules." }
      ],
      shortNotes: [
        "Forward bias decreases depletion layer width; reverse bias increases depletion layer width.",
        "NAND and NOR gates are universal gates because any logic circuit can be built exclusively using them."
      ],
      commonMistakes: [
        "Confusing p-type majority carriers (holes) with overall net charge (p-type is electrically neutral!).",
        "Mistakes in solving complex combination logic gate truth tables."
      ],
      freqConcepts: ["Logic Gate Truth Tables & Boolean Algebra", "Zener Voltage Regulator Calculations", "Forward/Reverse Bias I-V Graphs"],
      aiNotesAvailable: true
    }
  ],

  Chemistry: [
    // Class 11 Chemistry
    {
      id: "chem-11-1",
      name: "Some Basic Concepts of Chemistry",
      subject: "Chemistry",
      classLevel: "Class 11",
      subDiscipline: "Physical Chemistry",
      trendWeightage: 2.82,
      estimatedQuestions: 1,
      weightageTier: "Medium",
      importanceStars: 3,
      importanceBadge: "Medium",
      difficulty: "Easy",
      pyqsTotal: 50,
      pyqs2024Count: 16,
      pyqs2025Count: 22,
      topics: [
        "Matter & its nature, Laws of chemical combination",
        "Atomic & molecular masses, Mole concept & molar mass",
        "Empirical and molecular formula determination",
        "Chemical equations & stoichiometry calculations"
      ],
      subtopics: ["Limiting reagent concept", "Molarity, Molality, Mole fraction", "Percentage yield", "Dulong-Petit law"],
      formulas: [
        { name: "Molarity", expression: "M = \\frac{\\text{Moles of Solute}}{\\text{Volume of Solution (in L)}}", description: "Concentration in moles per liter of solution." },
        { name: "Molality", expression: "m = \\frac{\\text{Moles of Solute}}{\\text{Mass of Solvent (in kg)}}", description: "Temperature-independent concentration measure." },
        { name: "Limiting Reagent Stoichiometry", expression: "\\text{Moles ratio } \\frac{n_A}{a} < \\frac{n_B}{b} \\implies A \\text{ is limiting}", description: "Identifies reactant consumed completely first." }
      ],
      shortNotes: [
        "Molality and mole fraction do not change with temperature; molarity and normality decrease as temperature rises.",
        "Empirical formula is simplest whole number ratio of atoms in compound; Molecular formula = (Empirical formula) x n."
      ],
      commonMistakes: [
        "Using volume of solvent instead of total volume of solution in molarity calculations.",
        "Forgetting to check stoichiometric coefficients before declaring limiting reagent."
      ],
      freqConcepts: ["Limiting Reagent Calculations", "Empirical Formula from % Composition", "Interconversion of Concentration Units"],
      aiNotesAvailable: true
    },
    {
      id: "chem-11-2",
      name: "Atomic Structure",
      subject: "Chemistry",
      classLevel: "Class 11",
      subDiscipline: "Physical Chemistry",
      trendWeightage: 3.34,
      estimatedQuestions: 2,
      weightageTier: "Medium",
      importanceStars: 3,
      importanceBadge: "Medium",
      difficulty: "Medium",
      pyqsTotal: 62,
      pyqs2024Count: 18,
      pyqs2025Count: 19,
      topics: [
        "Bohr model of hydrogen atom, Spectrum of hydrogen",
        "Dual nature of matter & de Broglie relationship",
        "Heisenberg uncertainty principle & quantum mechanics",
        "Quantum numbers (n, l, m, s), Aufbau principle, Hund's rule"
      ],
      subtopics: ["Rydberg equation for spectral lines", "Radial & angular nodes", "Shapes of s, p, d orbitals", "Extra stability of half/fully filled orbitals"],
      formulas: [
        { name: "Bohr Radius & Energy", expression: "r_n = 0.529 \\frac{n^2}{Z} \\text{ \\AA}, \\quad E_n = -13.6 \\frac{Z^2}{n^2} \\text{ eV}", description: "Quantized orbit radius and energy levels in hydrogen-like species." },
        { name: "Rydberg Formula", expression: "\\bar{\\nu} = \\frac{1}{\\lambda} = R Z^2 \\left( \\frac{1}{n_1^2} - \\frac{1}{n_2^2} \\right)", description: "Wavenumber of emitted spectral photons." },
        { name: "Total Nodes Formula", expression: "\\text{Radial Nodes} = n - l - 1, \\quad \\text{Angular Nodes} = l", description: "Node counts in electron orbital probability density." }
      ],
      shortNotes: [
        "Lyman series lies in UV region (n1=1); Balmer series lies in Visible region (n1=2); Paschen, Brackett, Pfund in IR.",
        "Cr (3d5 4s1) and Cu (3d10 4s1) deviate from Aufbau due to extra stability of half/fully filled d subshells."
      ],
      commonMistakes: [
        "Forgetting Z^2 term when dealing with He+ or Li2+ ions in Bohr energy equation.",
        "Mixing up radial nodes (n - l - 1) with total nodes (n - 1)."
      ],
      freqConcepts: ["Hydrogen Spectral Series Transitions", "Quantum Number Sets Validity", "Node Count Calculations"],
      aiNotesAvailable: true
    },
    {
      id: "chem-11-3",
      name: "Chemical Thermodynamics and Energetics",
      subject: "Chemistry",
      classLevel: "Class 11",
      subDiscipline: "Physical Chemistry",
      trendWeightage: 3.65,
      estimatedQuestions: 2,
      weightageTier: "High",
      importanceStars: 4,
      importanceBadge: "High",
      difficulty: "Hard",
      pyqsTotal: 72,
      pyqs2024Count: 22,
      pyqs2025Count: 30,
      topics: [
        "System & surroundings, State functions, Extensive & Intensive properties",
        "First law of thermodynamics, Hess's law of constant heat summation",
        "Enthalpies of bond dissociation, formation, combustion, atomization",
        "Second law of thermodynamics, Entropy S, Gibbs free energy G, Spontaneity criteria"
      ],
      subtopics: ["Standard enthalpy of formation Delta H_f^\circ", "Spontaneity condition Delta G < 0", "Gibbs Helmholtz equation", "Reversible expansion work"],
      formulas: [
        { name: "Gibbs Free Energy Equation", expression: "\\Delta G = \\Delta H - T \\Delta S", description: "Spontaneity criterion at constant temperature and pressure." },
        { name: "Isothermal Reversible Work", expression: "W = -2.303 n R T \\log_{10} \\left( \\frac{V_2}{V_1} \\right)", description: "Work done in reversible expansion of an ideal gas." },
        { name: "Equilibrium Constant & Delta G", expression: "\\Delta G^\\circ = -R T \\ln K_{eq} = -2.303 R T \\log_{10} K_{eq}", description: "Relation between standard free energy change and equilibrium constant." }
      ],
      shortNotes: [
        "Intensive properties (Temperature, Pressure, Density, pH, E°cell) do NOT depend on system size.",
        "Standard enthalpy of formation of pure elements in their standard reference state is defined as zero (e.g. O2 gas, C graphite)."
      ],
      commonMistakes: [
        "Confusing SI units: enthalpy Delta H is in kJ/mol, while entropy Delta S is in J/mol.K (must convert before Delta G = Delta H - T Delta S!).",
        "Using incorrect state of carbon (diamond instead of graphite reference state)."
      ],
      freqConcepts: ["Delta G Spontaneity Calculations", "Hess Law Bond Energy Cycles", "Isothermal vs Adiabatic Work Done"],
      aiNotesAvailable: true
    },
    {
      id: "chem-11-4",
      name: "Equilibrium",
      subject: "Chemistry",
      classLevel: "Class 11",
      subDiscipline: "Physical Chemistry",
      trendWeightage: 4.44,
      estimatedQuestions: 2,
      weightageTier: "High",
      importanceStars: 4,
      importanceBadge: "High",
      difficulty: "Hard",
      pyqsTotal: 75,
      pyqs2024Count: 25,
      pyqs2025Count: 27,
      topics: [
        "Dynamic chemical equilibrium, Law of mass action, K_p and K_c relations",
        "Le Chatelier's principle & factors affecting equilibrium",
        "Ionic equilibrium, Acids and bases (Arrhenius, Bronsted-Lowry, Lewis)",
        "pH scale, Buffer solutions, Salt hydrolysis, Solubility product K_sp"
      ],
      subtopics: ["K_p = K_c (RT)^{Delta n_g}", "Buffer pH Henderson-Hasselbalch equation", "Common ion effect on K_sp", "Hydrolysis constant K_h"],
      formulas: [
        { name: "K_p and K_c Relation", expression: "K_p = K_c (R T)^{\\Delta n_g}", description: "Equilibrium constant conversion using change in gas moles Delta n_g." },
        { name: "Acidic Buffer pH", expression: "\\text{pH} = \\text{p}K_a + \\log_{10} \\left( \\frac{[\\text{Salt}]}{[\\text{Acid}]} \\right)", description: "Henderson-Hasselbalch equation for weak acid buffer." },
        { name: "Solubility Product K_sp", expression: "K_{sp} = x^x y^y S^{(x+y)} \\quad \\text{for } A_x B_y", description: "Molar solubility S relation for sparingly soluble salt." }
      ],
      shortNotes: [
        "Catalysts speed up both forward and reverse reaction rates equally; they do NOT alter K_eq or equilibrium yields.",
        "Addition of inert gas at constant volume has NO effect on equilibrium position."
      ],
      commonMistakes: [
        "Including pure solids or liquids in K_c or K_p equilibrium expressions.",
        "Neglecting Kw water ionization in extremely dilute acid solutions ([H+] < 10^-6 M)."
      ],
      freqConcepts: ["Buffer pH Calculations", "K_sp Solubility in Common Ion", "Le Chatelier Inert Gas Shift"],
      aiNotesAvailable: true
    },

    // Class 12 Chemistry
    {
      id: "chem-12-1",
      name: "Aldehydes, Ketones and Carboxylic Acids",
      subject: "Chemistry",
      classLevel: "Class 12",
      subDiscipline: "Organic Chemistry",
      trendWeightage: 5.95,
      estimatedQuestions: 3,
      weightageTier: "Very High",
      importanceStars: 5,
      importanceBadge: "Critical",
      difficulty: "Hard",
      pyqsTotal: 110,
      pyqs2024Count: 35,
      pyqs2025Count: 33,
      topics: [
        "Nomenclature, structure & carbonyl reactivity",
        "Nucleophilic addition reactions (HCN, NaHSO3, Grignard, NH2-Z)",
        "Reduction (Clemmensen & Wolff-Kishner) & Oxidation reactions",
        "Aldol condensation, Cannizzaro reaction, Haloform reaction",
        "Carboxylic acids acidity & Hell-Volhard-Zelinsky (HVZ) reaction"
      ],
      subtopics: ["Tollens' and Fehling's tests", "Crossed Aldol product prediction", "Acidity order of substituted benzoic acids", "Iodoform test mechanism"],
      formulas: [
        { name: "Clemmensen Reduction", expression: "R-CO-R' \\xrightarrow{\\text{Zn-Hg / conc. HCl}} R-CH_2-R'", description: "Converts carbonyl groups to alkanes under acidic conditions." },
        { name: "Wolff-Kishner Reduction", expression: "R-CO-R' \\xrightarrow{\\text{NH}_2\\text{NH}_2 / \\text{KOH, ethylene glycol}} R-CH_2-R'", description: "Converts carbonyls to alkanes under basic conditions." },
        { name: "Cannizzaro Reaction", expression: "2 R-CHO \\xrightarrow{\\text{conc. NaOH}} R-COONa + R-CH_2OH", description: "Disproportionation of aldehydes lacking alpha-hydrogens." }
      ],
      shortNotes: [
        "Benzaldehyde gives positive Tollens' test but NEGATIVE Fehling's test.",
        "Acidity of carboxylic acids increases with electron-withdrawing groups (-I, -M) and decreases with electron-donating groups (+I, +M)."
      ],
      commonMistakes: [
        "Using Clemmensen reduction on acid-sensitive compounds (use Wolff-Kishner instead!).",
        "Expecting aldol reaction with aldehydes that lack alpha-hydrogens."
      ],
      freqConcepts: ["Aldol vs Cannizzaro Distinction", "Iodoform Positive Test Compounds", "Acidity Comparisons of Carboxylic Acids"],
      aiNotesAvailable: true
    },
    {
      id: "chem-12-2",
      name: "Coordination Compounds",
      subject: "Chemistry",
      classLevel: "Class 12",
      subDiscipline: "Inorganic Chemistry",
      trendWeightage: 5.33,
      estimatedQuestions: 3,
      weightageTier: "Very High",
      importanceStars: 5,
      importanceBadge: "Critical",
      difficulty: "Medium",
      pyqsTotal: 100,
      pyqs2024Count: 30,
      pyqs2025Count: 40,
      topics: [
        "Werner's theory & ligands (denticity, chelation)",
        "IUPAC nomenclature of mononuclear coordination complexes",
        "Isomerism (Structural: Ionization, Hydrate, Linkage, Coordination & Stereoisomerism)",
        "Valence Bond Theory (VBT) & Crystal Field Theory (CFT)",
        "Spectrochemical series, magnetic moment & CFT splitting energy Delta_o"
      ],
      subtopics: ["High spin vs low spin complexes", "Spin-only magnetic moment mu = sqrt(n(n+2))", "t2g and eg orbital splitting", "Color of transition metal complexes"],
      formulas: [
        { name: "Spin-Only Magnetic Moment", expression: "\\mu_s = \\sqrt{n(n+2)} \\text{ BM}", description: "Magnetic moment where n is number of unpaired d-electrons." },
        { name: "Octahedral CFSE", expression: "\\text{CFSE} = (-0.4 n_{t_{2g}} + 0.6 n_{e_g}) \\Delta_o + m P", description: "Crystal Field Stabilization Energy calculation." },
        { name: "Tetrahedral Splitting", expression: "\\Delta_t = \\frac{4}{9} \\Delta_o", description: "Crystal field splitting parameter relation." }
      ],
      shortNotes: [
        "Strong field ligands (CO > CN- > en > NH3) cause electron pairing (low spin); weak field ligands (F-, Cl-, H2O) retain un-paired electrons.",
        "[Fe(CN)6]3- has d5 low spin (t2g5 eg0) with 1 unpaired electron (1.73 BM)."
      ],
      commonMistakes: [
        "Incorrect oxidation state determination of central metal ion.",
        "Confusing linkage isomerism (ambidentate ligands NO2-/ONO-, SCN-/NCS-) with coordination isomerism."
      ],
      freqConcepts: ["CFT Electronic Configurations & Magnetic Moments", "IUPAC Naming & Denticity", "Geometrical Isomerism in Octahedral Complexes"],
      aiNotesAvailable: true
    },
    {
      id: "chem-12-3",
      name: "The d and f-Block Elements",
      subject: "Chemistry",
      classLevel: "Class 12",
      subDiscipline: "Inorganic Chemistry",
      trendWeightage: 4.69,
      estimatedQuestions: 2,
      weightageTier: "High",
      importanceStars: 4,
      importanceBadge: "High",
      difficulty: "Medium",
      pyqsTotal: 78,
      pyqs2024Count: 22,
      pyqs2025Count: 24,
      topics: [
        "General properties of 3d transition elements (atomic radii, ionization enthalpy, oxidation states)",
        "Catalytic properties, magnetic properties, interstitial compounds & alloys",
        "Preparation, properties & redox reactions of K2Cr2O7 and KMnO4",
        "Lanthanoids & Actinoids: electronic configuration, oxidation states, Lanthanoid contraction"
      ],
      subtopics: ["Lanthanoid contraction consequences (Zr/Hf radii similarity)", "Acidic medium KMnO4 conversion to Mn2+", "Chromate-dichromate equilibrium", "Actinoid radio-decay & oxidation state range"],
      formulas: [
        { name: "KMnO4 Acidic Reduction", expression: "\\text{MnO}_4^- + 8\\text{H}^+ + 5e^- \\rightarrow \\text{Mn}^{2+} + 4\\text{H}_2\\text{O} \\quad (E^\\circ = +1.51 \\text{ V})", description: "Permanganate reduction in acidic titration." },
        { name: "K2Cr2O7 Acidic Oxidation", expression: "\\text{Cr}_2\\text{O}_7^{2-} + 14\\text{H}^+ + 6e^- \\rightarrow 2\\text{Cr}^{3+} + 7\\text{H}_2\\text{O} \\quad (E^\\circ = +1.33 \\text{ V})", description: "Dichromate oxidation half-reaction." }
      ],
      shortNotes: [
        "Lanthanoid contraction causes 4d and 5d series elements (e.g. Zr and Hf, Nb and Ta) to have nearly identical atomic radii.",
        "KMnO4 acts as self-indicator in titrations; purple color fades to colorless Mn2+ at equivalence point."
      ],
      commonMistakes: [
        "Confusing Mn oxidation state changes in neutral/faintly alkaline medium (MnO4- to MnO2, n=3) vs strongly alkaline medium (MnO4- to MnO4^2-, n=1).",
        "Forgetting Eu2+ and Yb2+ stability due to f7 and f14 configurations."
      ],
      freqConcepts: ["Lanthanoid Contraction Radius Trends", "KMnO4 Titration Equivalents", "Variable Oxidation States of Transition Metals"],
      aiNotesAvailable: true
    }
  ],

  Maths: [
    // Class 11 Maths
    {
      id: "math-11-1",
      name: "Three-Dimensional Geometry",
      subject: "Maths",
      classLevel: "Class 12",
      subDiscipline: "3D Geometry & Vectors",
      trendWeightage: 7.35,
      estimatedQuestions: 4,
      weightageTier: "Very High",
      importanceStars: 5,
      importanceBadge: "Critical",
      difficulty: "Hard",
      pyqsTotal: 135,
      pyqs2024Count: 40,
      pyqs2025Count: 35,
      topics: [
        "Coordinates of a point in 3D space, Distance formula & section formula",
        "Direction cosines (l, m, n) and direction ratios (a, b, c)",
        "Angle between two intersecting lines",
        "Equation of a straight line in 3D (vector & cartesian forms)",
        "Skew lines, Shortest distance between skew lines & parallel lines"
      ],
      subtopics: ["Foot of perpendicular from point to line", "Image of a point in a line", "Shortest distance formula", "Intersection of two 3D lines"],
      formulas: [
        { name: "Direction Cosines Relation", expression: "l^2 + m^2 + n^2 = 1 \\iff \\cos^2\\alpha + \\cos^2\\beta + \\cos^2\\gamma = 1", description: "Sum of squares of direction cosines equals 1." },
        { name: "Shortest Distance Skew Lines", expression: "d = \\frac{\\left| (\\vec{a}_2 - \\vec{a}_1) \\cdot (\\vec{b}_1 \\times \\vec{b}_2) \\right|}{\\left| \\vec{b}_1 \\times \\vec{b}_2 \\right|}", description: "Minimum distance between non-parallel, non-intersecting lines." },
        { name: "Symmetric Line Equation", expression: "\\frac{x - x_1}{a} = \\frac{y - y_1}{b} = \\frac{z - z_1}{c} = \\lambda", description: "Cartesian line passing through (x1, y1, z1) with direction ratios (a, b, c)." }
      ],
      shortNotes: [
        "Two lines are coplanar if the scalar triple product [(a2 - a1) b1 b2] = 0.",
        "Foot of perpendicular from P(x1, y1, z1) on line is found by expressing general line point in parameter lambda and setting dot product with line direction vector to 0."
      ],
      commonMistakes: [
        "Forgetting to check if lines are parallel before applying skew lines formula.",
        "Incorrect vector direction ratio sign when line equations are given in non-standard forms like (1-x)/a."
      ],
      freqConcepts: ["Shortest Distance Between Skew Lines", "Image & Foot of Perpendicular", "Coplanarity of Lines"],
      aiNotesAvailable: true
    },
    {
      id: "math-11-2",
      name: "Sequences and Series",
      subject: "Maths",
      classLevel: "Class 11",
      subDiscipline: "Algebra",
      trendWeightage: 5.74,
      estimatedQuestions: 3,
      weightageTier: "Very High",
      importanceStars: 5,
      importanceBadge: "Critical",
      difficulty: "Medium",
      pyqsTotal: 105,
      pyqs2024Count: 30,
      pyqs2025Count: 26,
      topics: [
        "Arithmetic Progression (AP), General term, Sum to n terms",
        "Geometric Progression (GP), Infinite GP sum, Geometric mean",
        "Arithmetic-Geometric Progression (AGP)",
        "Relation between Arithmetic Mean (AM) and Geometric Mean (GM)",
        "Sum of special series (sum of n, n^2, n^3)"
      ],
      subtopics: ["AM >= GM >= HM inequality applications", "Sum of infinite GP |r| < 1", "T_n = S_n - S_{n-1}", "Telescoping series method of differences"],
      formulas: [
        { name: "Infinite GP Sum", expression: "S_\\infty = \\frac{a}{1 - r} \\quad (|r| < 1)", description: "Sum of converging infinite geometric sequence." },
        { name: "AM-GM Inequality", expression: "\\frac{a_1 + a_2 + \\dots + a_n}{n} \\ge \\sqrt[n]{a_1 a_2 \\dots a_n}", description: "Arithmetic mean is greater than or equal to geometric mean for positive numbers." },
        { name: "Sum of Squares & Cubes", expression: "\\sum n^2 = \\frac{n(n+1)(2n+1)}{6}, \\quad \\sum n^3 = \\left[ \\frac{n(n+1)}{2} \\right]^2", description: "Standard power sum formulas." }
      ],
      shortNotes: [
        "AM >= GM inequality is extremely useful for finding minimum values of expressions involving positive variables.",
        "If a, b, c are in AP, then 2b = a + c. If a, b, c are in GP, then b^2 = a c."
      ],
      commonMistakes: [
        "Applying AM >= GM to negative terms (it holds strictly for non-negative real numbers!).",
        "Miscalculating common ratio in AGP series differentiation/subtraction method."
      ],
      freqConcepts: ["AM-GM Minimum Value Applications", "Infinite GP & AGP Sums", "Telescoping Series Partial Fractions"],
      aiNotesAvailable: true
    },
    {
      id: "math-11-3",
      name: "Binomial Theorem",
      subject: "Maths",
      classLevel: "Class 11",
      subDiscipline: "Algebra",
      trendWeightage: 5.05,
      estimatedQuestions: 3,
      weightageTier: "Very High",
      importanceStars: 5,
      importanceBadge: "Critical",
      difficulty: "Medium",
      pyqsTotal: 95,
      pyqs2024Count: 26,
      pyqs2025Count: 24,
      topics: [
        "Binomial theorem for positive integral index",
        "General term T_{r+1} & Middle term determination",
        "Properties of binomial coefficients (C_0, C_1, ..., C_n)",
        "Remainder & divisibility problems using Binomial Expansion"
      ],
      subtopics: ["Term independent of x", "Sum of binomial coefficients = 2^n", "Binomial coefficient series differentiation/integration", "Divisibility theorems"],
      formulas: [
        { name: "General Binomial Term", expression: "T_{r+1} = {}^n C_r a^{n-r} b^r", description: "(r+1)th term in expansion of (a + b)^n." },
        { name: "Sum of Coefficients", expression: "\\sum_{r=0}^n {}^n C_r = 2^n, \\quad \\sum_{\\text{even}} {}^n C_r = \\sum_{\\text{odd}} {}^n C_r = 2^{n-1}", description: "Properties of combination sum coefficients." },
        { name: "Binomial Remainder Formula", expression: "(1 + x)^n = 1 + n x + \\frac{n(n-1)}{2} x^2 + \\dots", description: "Used to find remainder when a^n is divided by b." }
      ],
      shortNotes: [
        "Number of terms in expansion of (x + y + z)^n is (n + 1)(n + 2) / 2.",
        "Middle term: If n is even, middle term is T_{(n/2)+1}; if n is odd, there are two middle terms T_{(n+1)/2} and T_{(n+3)/2}."
      ],
      commonMistakes: [
        "Off-by-one errors: 5th term corresponds to r = 4 in T_{r+1}.",
        "Forgetting negative signs when b is negative in (a - b)^n."
      ],
      freqConcepts: ["Term Independent of x", "Remainder & Divisibility Proofs", "Binomial Coefficients Series Sums"],
      aiNotesAvailable: true
    },

    // Class 12 Maths
    {
      id: "math-12-1",
      name: "Matrices and Determinants",
      subject: "Maths",
      classLevel: "Class 12",
      subDiscipline: "Algebra",
      trendWeightage: 7.46,
      estimatedQuestions: 3,
      weightageTier: "Very High",
      importanceStars: 5,
      importanceBadge: "Critical",
      difficulty: "Medium",
      pyqsTotal: 125,
      pyqs2024Count: 36,
      pyqs2025Count: 33,
      topics: [
        "Matrices algebra, types of matrices (Symmetric, Skew-symmetric, Orthogonal, Hermitian)",
        "Determinants evaluation & properties",
        "Adjoint and Inverse of a square matrix",
        "System of linear equations (Cramer's rule & Matrix inversion method), Consistency tests"
      ],
      subtopics: ["Determinant of adjoint |adj(A)| = |A|^{n-1}", "Cramer's rule Delta, Delta_x, Delta_y, Delta_z", "Characteristic equation & Cayley-Hamilton theorem", "Orthogonal matrix A A^T = I"],
      formulas: [
        { name: "Adjoint Determinant Property", expression: "|\\text{adj}(A)| = |A|^{n-1}, \\quad |\\text{adj}(\\text{adj}(A))| = |A|^{(n-1)^2}", description: "Determinant properties of adjoint matrices of order n." },
        { name: "Inverse Formula", expression: "A^{-1} = \\frac{1}{|A|} \\text{adj}(A) \\quad (|A| \\neq 0)", description: "Inverse of non-singular square matrix A." },
        { name: "Cramer's Rule System Solution", expression: "x = \\frac{\\Delta_x}{\\Delta}, \\quad y = \\frac{\\Delta_y}{\\Delta}, \\quad z = \\frac{\\Delta_z}{\\Delta}", description: "Solution for system of non-homogeneous linear equations." }
      ],
      shortNotes: [
        "A system has a unique solution if Delta != 0; infinitely many solutions if Delta = Delta_x = Delta_y = Delta_z = 0 (and at least one co-factor non-zero); no solution if Delta = 0 and at least one Delta_i != 0.",
        "Determinant of skew-symmetric matrix of odd order is ALWAYS ZERO."
      ],
      commonMistakes: [
        "Assuming matrix multiplication is commutative (AB != BA in general!).",
        "Confusing |k A| = k^n |A| for an n x n matrix with |k A| = k |A|."
      ],
      freqConcepts: ["System of Equations Consistency (Cramer's Rule)", "Adjoint & Matrix Powers Properties", "Cayley-Hamilton Theorem Applications"],
      aiNotesAvailable: true
    },
    {
      id: "math-12-2",
      name: "Limit, Continuity and Differentiability",
      subject: "Maths",
      classLevel: "Class 12",
      subDiscipline: "Calculus",
      trendWeightage: 5.50,
      estimatedQuestions: 3,
      weightageTier: "Very High",
      importanceStars: 5,
      importanceBadge: "Critical",
      difficulty: "Hard",
      pyqsTotal: 110,
      pyqs2024Count: 32,
      pyqs2025Count: 19,
      topics: [
        "Limits evaluation (L'Hopital's rule, Standard expansion limits)",
        "Indeterminate forms (0/0, inf/inf, 1^inf, 0^0)",
        "Continuity of functions & removable/non-removable discontinuities",
        "Differentiability & relation between continuity and differentiability",
        "Differentiability of Greatest Integer [x] & Modulus |x| functions"
      ],
      subtopics: ["1^infinity limit form formula e^{lim g(x)(f(x)-1)}", "Right hand derivative vs Left hand derivative", "Differentiability at sharp corners", "Intermediate value theorem"],
      formulas: [
        { name: "1^Infinity Limit Form", expression: "\\lim_{x \\to a} [f(x)]^{g(x)} = e^{\\lim_{x \\to a} g(x) [f(x) - 1]}", description: "Standard transformation for 1^infinity indeterminate limits." },
        { name: "L'Hopital's Rule", expression: "\\lim_{x \\to a} \\frac{f(x)}{g(x)} = \\lim_{x \\to a} \\frac{f'(x)}{g'(x)} \\quad (\\text{for } \\frac{0}{0} \\text{ or } \\frac{\\infty}{\\infty})", description: "Differentiation trick for indeterminate fractional limits." },
        { name: "Derivative Definition", expression: "f'(a) = \\lim_{h \\to 0} \\frac{f(a+h) - f(a)}{h}", description: "Fundamental first principles limit definition." }
      ],
      shortNotes: [
        "Every differentiable function is continuous, but continuous functions are NOT necessarily differentiable (e.g. f(x)=|x| at x=0).",
        "Greatest integer function [x] is discontinuous at all integer values of x."
      ],
      commonMistakes: [
        "Applying L'Hopital's rule repeatedly without verifying if expression remains 0/0 or inf/inf.",
        "Assuming differentiability at sharp corners or cusp points."
      ],
      freqConcepts: ["1^infinity Limit Form Tricks", "Differentiability of Modulus Functions", "Discontinuity Point Counting"],
      aiNotesAvailable: true
    },
    {
      id: "math-12-3",
      name: "Definite Integration",
      subject: "Maths",
      classLevel: "Class 12",
      subDiscipline: "Calculus",
      trendWeightage: 5.08,
      estimatedQuestions: 3,
      weightageTier: "Very High",
      importanceStars: 5,
      importanceBadge: "Critical",
      difficulty: "Hard",
      pyqsTotal: 100,
      pyqs2024Count: 30,
      pyqs2025Count: 20,
      topics: [
        "Fundamental theorem of calculus",
        "Properties of definite integrals (King's property, Queen's property, Even/Odd symmetry)",
        "Leibniz rule of differentiation under integral sign",
        "Definite integral as limit of a sum",
        "Wallis formula for integral of sin^n(x) cos^m(x)"
      ],
      subtopics: ["King's property integral f(x) + f(a+b-x)", "Leibniz differentiation d/dx integral_{u(x)}^{v(x)} f(t) dt", "Limit of sum integral zero to one", "Symmetric limits -a to a"],
      formulas: [
        { name: "King's Property", expression: "\\int_a^b f(x) dx = \\int_a^b f(a + b - x) dx", description: "Most powerful definite integral property for simplification." },
        { name: "Leibniz Rule", expression: "\\frac{d}{dx} \\int_{u(x)}^{v(x)} f(t) dt = f(v(x)) v'(x) - f(u(x)) u'(x)", description: "Differentiation under integral sign." },
        { name: "Limit of a Sum", expression: "\\lim_{n \\to \\infty} \\frac{1}{n} \\sum_{r=1}^n f\\left(\\frac{r}{n}\\right) = \\int_0^1 f(x) dx", description: "Riemann sum conversion to definite integral." }
      ],
      shortNotes: [
        "If f(x) is an odd function, integral_{-a}^a f(x) dx = 0.",
        "Leibniz rule is heavily tested when integral equations are combined with limits or derivatives."
      ],
      commonMistakes: [
        "Forgetting to change integration limits when applying variable substitution (u-substitution).",
        "Misinterpreting odd function property when function is discontinuous in [-a, a]."
      ],
      freqConcepts: ["King's Property Integrals", "Leibniz Differentiation Rule", "Limit of a Sum Riemann Formula"],
      aiNotesAvailable: true
    }
  ]
};

export const JEE_SUBJECT_THEMES = {
  Physics: {
    accentColor: "cyan",
    hex: "#38bdf8",
    gradient: "from-cyan-500 to-blue-600",
    bgGlow: "rgba(56, 189, 248, 0.15)",
    border: "border-cyan-500/30",
    badgeBg: "bg-cyan-500/10 text-cyan-400 border-cyan-500/20",
    ringColor: "#0284c7"
  },
  Chemistry: {
    accentColor: "emerald",
    hex: "#34d399",
    gradient: "from-emerald-400 to-teal-600",
    bgGlow: "rgba(52, 211, 153, 0.15)",
    border: "border-emerald-500/30",
    badgeBg: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
    ringColor: "#059669"
  },
  Maths: {
    accentColor: "purple",
    hex: "#a855f7",
    gradient: "from-purple-500 to-indigo-600",
    bgGlow: "rgba(168, 85, 247, 0.15)",
    border: "border-purple-500/30",
    badgeBg: "bg-purple-500/10 text-purple-400 border-purple-500/20",
    ringColor: "#9333ea"
  }
};
