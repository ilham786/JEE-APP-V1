import { Chapter } from "./types";

export const CHEMISTRY_SYLLABUS: Chapter[] = [
  // Physical Chemistry
  {
    id: "chem-1",
    name: "Some Basic Concepts in Chemistry",
    subject: "Chemistry",
    classLevel: "Class 11",
    weightage: 3,
    revisionDueDays: 4,
    studyTimeMinutes: 140,
    subchapters: [
      {
        id: "chem-1-1",
        name: "Mole Concept & Stoichiometry",
        topics: ["Matter & laws of chemical combination", "Atomic & molecular masses, mole concept", "Empirical & molecular formula"]
      },
      {
        id: "chem-1-2",
        name: "Concentration Terms",
        topics: ["Molarity, Molality, Mole fraction", "Stoichiometry & limiting reagent"]
      }
    ],
    topics: [
      "Matter and its nature, Dalton's atomic theory, Concept of atom, molecule, element and compound",
      "Laws of chemical combination, Atomic and molecular masses, mole concept, molar mass",
      "Empirical and molecular formulae, Chemical equations and stoichiometry"
    ],
    formulas: [
      {
        id: "f-chem-1-1",
        name: "Molarity",
        expression: "M = Moles of Solute / Volume of Solution (in L)",
        description: "Concentration of solution in moles per liter.",
        chapterId: "chem-1",
        chapterName: "Some Basic Concepts in Chemistry",
        subject: "Chemistry",
        isBookmarked: true
      },
      {
        id: "f-chem-1-2",
        name: "Molality",
        expression: "m = Moles of Solute / Mass of Solvent (in kg)",
        description: "Temperature-independent concentration measure.",
        chapterId: "chem-1",
        chapterName: "Some Basic Concepts in Chemistry",
        subject: "Chemistry"
      }
    ],
    notes: []
  },
  {
    id: "chem-2",
    name: "Atomic Structure",
    subject: "Chemistry",
    classLevel: "Class 11",
    weightage: 3,
    revisionDueDays: 2,
    studyTimeMinutes: 180,
    subchapters: [
      {
        id: "chem-2-1",
        name: "Bohr Model & Quantum Mechanics",
        topics: ["Hydrogen atomic spectrum & Bohr postulates", "De Broglie relation & Heisenberg uncertainty principle", "Quantum numbers (n, l, m, s)"]
      },
      {
        id: "chem-2-2",
        name: "Electronic Configurations",
        topics: ["Orbital shapes (s, p, d)", "Aufbau principle, Pauli exclusion, Hund's rule", "Extra stability of half/fully filled orbitals"]
      }
    ],
    topics: [
      "Bohr model of hydrogen atom, Spectrum of hydrogen, de Broglie's relationship",
      "Heisenberg uncertainty principle, Quantum mechanical model of atom",
      "Quantum numbers, shapes of s, p, d orbitals, Aufbau principle, Pauli's & Hund's rule"
    ],
    formulas: [
      {
        id: "f-chem-2-1",
        name: "Bohr Energy Levels",
        expression: "E_n = -13.6 Z^2 / n^2 eV",
        description: "Quantized electronic energy level in hydrogen-like ion.",
        chapterId: "chem-2",
        chapterName: "Atomic Structure",
        subject: "Chemistry",
        isBookmarked: true,
        isPinned: true
      },
      {
        id: "f-chem-2-2",
        name: "Rydberg Spectral Formula",
        expression: "1/λ = R Z^2 (1/n1^2 - 1/n2^2)",
        description: "Wavenumber of emitted spectral lines.",
        chapterId: "chem-2",
        chapterName: "Atomic Structure",
        subject: "Chemistry"
      }
    ],
    notes: []
  },
  {
    id: "chem-3",
    name: "Chemical Bonding and Molecular Structure",
    subject: "Chemistry",
    classLevel: "Class 11",
    weightage: 3,
    revisionDueDays: 0, // Due!
    studyTimeMinutes: 260,
    subchapters: [
      {
        id: "chem-3-1",
        name: "Ionic & Covalent Bonding",
        topics: ["Kossel-Lewis approach", "Ionic bond lattice enthalpy & Fajan's rule", "VSEPR theory & molecular geometry"]
      },
      {
        id: "chem-3-2",
        name: "VBT, MOT & Hydrogen Bonding",
        topics: ["Hybridization (sp, sp2, sp3, sp3d, sp3d2)", "Molecular Orbital Theory (MOT) & Bond order", "Hydrogen bonding & applications"]
      }
    ],
    topics: [
      "Ionic Bonding, Covalent Bonding, Electronegativity, Fajan's rule, Dipole moment",
      "VSEPR theory and shapes of simple molecules, Valence Bond Theory and Hybridization",
      "Molecular Orbital Theory (LCAOs, sigma & pi bonds, bond order, magnetic character)"
    ],
    formulas: [
      {
        id: "f-chem-3-1",
        name: "MOT Bond Order",
        expression: "Bond Order = 0.5 × (N_b - N_a)",
        description: "Half the difference between bonding and antibonding electrons.",
        chapterId: "chem-3",
        chapterName: "Chemical Bonding and Molecular Structure",
        subject: "Chemistry",
        isBookmarked: true,
        isPinned: true
      }
    ],
    notes: [
      {
        id: "n-chem-3-1",
        title: "XeF4 Geometry & Hybridization",
        content: "Xenon has 8 valence e-. 4 bond pairs + 2 lone pairs = Steric Number 6 -> sp3d2 hybridization with Square Planar shape.",
        type: "revision",
        chapterId: "chem-3",
        chapterName: "Chemical Bonding and Molecular Structure",
        subject: "Chemistry",
        isPinned: true,
        createdAt: "2026-07-23"
      }
    ]
  },
  {
    id: "chem-4",
    name: "Chemical Thermodynamics",
    subject: "Chemistry",
    classLevel: "Class 11",
    weightage: 4,
    revisionDueDays: 3,
    studyTimeMinutes: 210,
    subchapters: [
      {
        id: "chem-4-1",
        name: "First Law & Thermochemistry",
        topics: ["System & surroundings, State functions", "First law of thermodynamics ΔU = q + w", "Enthalpy ΔH & Hess's Law"]
      },
      {
        id: "chem-4-2",
        name: "Second Law & Free Energy",
        topics: ["Entropy S & Second law of thermodynamics", "Gibbs free energy G & spontaneity ΔG < 0", "Equilibrium constant ΔG° = -RT ln K"]
      }
    ],
    topics: [
      "First law of thermodynamics, Work, heat, internal energy and enthalpy, Hess's law",
      "Enthalpies of bond dissociation, formation, combustion, atomization",
      "Second law of thermodynamics, Entropy S, Gibbs free energy ΔG spontaneity criterion"
    ],
    formulas: [
      {
        id: "f-chem-4-1",
        name: "Gibbs Free Energy Equation",
        expression: "ΔG = ΔH - T ΔS",
        description: "Criterion for spontaneity at constant temperature and pressure.",
        chapterId: "chem-4",
        chapterName: "Chemical Thermodynamics",
        subject: "Chemistry",
        isBookmarked: true,
        isPinned: true
      }
    ],
    notes: []
  },
  {
    id: "chem-5",
    name: "Solutions",
    subject: "Chemistry",
    classLevel: "Class 12",
    weightage: 5,
    revisionDueDays: 1,
    studyTimeMinutes: 190,
    subchapters: [
      {
        id: "chem-5-1",
        name: "Vapor Pressure & Raoult's Law",
        topics: ["Concentration methods", "Vapor pressure & Raoult's Law", "Ideal & non-ideal solutions (positive/negative deviations)"]
      },
      {
        id: "chem-5-2",
        name: "Colligative Properties & Van't Hoff",
        topics: ["Relative lowering of vapor pressure", "Elevation of boiling point & Depression of freezing point", "Osmotic pressure & Van't Hoff factor i"]
      }
    ],
    topics: [
      "Concentration methods, Vapour pressure of solutions and Raoult's Law, Ideal & non-ideal solutions",
      "Colligative properties: lowering of vapor pressure, boiling elevation, freezing depression, osmotic pressure",
      "Abnormal molar mass and van't Hoff factor i"
    ],
    formulas: [
      {
        id: "f-chem-5-1",
        name: "Freezing Point Depression",
        expression: "ΔT_f = i × K_f × m",
        description: "Depression in freezing point with van't Hoff factor i.",
        chapterId: "chem-5",
        chapterName: "Solutions",
        subject: "Chemistry",
        isBookmarked: true
      }
    ],
    notes: []
  },
  {
    id: "chem-6",
    name: "Equilibrium",
    subject: "Chemistry",
    classLevel: "Class 11",
    weightage: 4,
    revisionDueDays: 0, // Due!
    studyTimeMinutes: 230,
    subchapters: [
      {
        id: "chem-6-1",
        name: "Chemical Equilibrium",
        topics: ["Law of mass action & Kp/Kc relations", "Le Chatelier's principle"]
      },
      {
        id: "chem-6-2",
        name: "Ionic Equilibrium",
        topics: ["Acids and bases concepts", "pH scale & Buffer solutions", "Salt hydrolysis & Solubility product Ksp"]
      }
    ],
    topics: [
      "Dynamic chemical equilibrium, Kp and Kc relations, Le Chatelier's principle",
      "Ionic equilibrium: acids and bases, ionization of water, pH scale, buffer solutions",
      "Solubility product Ksp and common ion effect"
    ],
    formulas: [
      {
        id: "f-chem-6-1",
        name: "Henderson-Hasselbalch Buffer pH",
        expression: "pH = pKa + log10([Salt] / [Acid])",
        description: "pH calculation for acidic buffer solution.",
        chapterId: "chem-6",
        chapterName: "Equilibrium",
        subject: "Chemistry",
        isBookmarked: true,
        isPinned: true
      }
    ],
    notes: []
  },
  {
    id: "chem-7",
    name: "Redox Reactions and Electrochemistry",
    subject: "Chemistry",
    classLevel: "Class 12",
    weightage: 5,
    revisionDueDays: 5,
    studyTimeMinutes: 250,
    subchapters: [
      {
        id: "chem-7-1",
        name: "Redox & Conductance",
        topics: ["Oxidation numbers & balancing redox reactions", "Molar conductivity & Kohlrausch's Law"]
      },
      {
        id: "chem-7-2",
        name: "Electrochemical Cells",
        topics: ["Galvanic & Electrolytic cells", "Nernst equation & EMF", "Batteries & Fuel cells"]
      }
    ],
    topics: [
      "Oxidation and reduction, Redox reactions, Balancing redox equations",
      "Electrolytic and metallic conduction, Molar conductivity, Kohlrausch's law",
      "Electrochemical cells, Nernst equation, Cell potential and Gibbs energy relation"
    ],
    formulas: [
      {
        id: "f-chem-7-1",
        name: "Nernst Equation",
        expression: "E_cell = E°_cell - (0.0591 / n) log10 Q",
        description: "Cell potential at 298 K under non-standard concentrations.",
        chapterId: "chem-7",
        chapterName: "Redox Reactions and Electrochemistry",
        subject: "Chemistry",
        isBookmarked: true,
        isPinned: true
      }
    ],
    notes: []
  },
  {
    id: "chem-8",
    name: "Chemical Kinetics",
    subject: "Chemistry",
    classLevel: "Class 12",
    weightage: 4,
    revisionDueDays: 2,
    studyTimeMinutes: 170,
    subchapters: [
      {
        id: "chem-8-1",
        name: "Reaction Rates & Integrated Rate Laws",
        topics: ["Rate of reaction, Order & Molecularity", "Zero and First order integrated rate equations & half-life"]
      },
      {
        id: "chem-8-2",
        name: "Arrhenius Theory & Collision Theory",
        topics: ["Effect of temperature on rate", "Arrhenius equation k = A e^(-Ea/RT)", "Activation energy & Collision theory"]
      }
    ],
    topics: [
      "Rate of reaction, Order and molecularity, Rate law and rate constant",
      "Integrated rate equations for zero and first order reactions, half-lives",
      "Arrhenius theory, Activation energy, Collision theory of bimolecular reactions"
    ],
    formulas: [
      {
        id: "f-chem-8-1",
        name: "First Order Half-Life",
        expression: "t_1/2 = 0.693 / k",
        description: "Half-life of first-order chemical kinetics.",
        chapterId: "chem-8",
        chapterName: "Chemical Kinetics",
        subject: "Chemistry",
        isBookmarked: true
      }
    ],
    notes: []
  },

  // Inorganic Chemistry
  {
    id: "chem-9",
    name: "Classification of Elements and Periodicity in Properties",
    subject: "Chemistry",
    classLevel: "Class 11",
    weightage: 2,
    revisionDueDays: 6,
    studyTimeMinutes: 110,
    subchapters: [
      {
        id: "chem-9-1",
        name: "Periodic Trends",
        topics: ["Modern periodic law & s, p, d, f blocks", "Atomic & ionic radii trends", "Ionization enthalpy, Electron gain enthalpy, Electronegativity"]
      }
    ],
    topics: [
      "Modern periodic law, s, p, d and f block elements",
      "Periodic trends in properties: atomic & ionic radii, ionization enthalpy, electron gain enthalpy, valence"
    ],
    formulas: [],
    notes: []
  },
  {
    id: "chem-10",
    name: "p-Block Elements",
    subject: "Chemistry",
    classLevel: "Class 12",
    weightage: 5,
    revisionDueDays: 1,
    studyTimeMinutes: 220,
    subchapters: [
      {
        id: "chem-10-1",
        name: "Group 13 to 18 Trends",
        topics: ["Group 13 & 14 properties", "Group 15 to 18 properties & anomalous behavior of 1st element"]
      }
    ],
    topics: [
      "Group 13 to Group 18 Elements, Electronic configuration and general trends across periods and groups"
    ],
    formulas: [],
    notes: []
  },
  {
    id: "chem-11",
    name: "d- and f-Block Elements",
    subject: "Chemistry",
    classLevel: "Class 12",
    weightage: 5,
    revisionDueDays: 3,
    studyTimeMinutes: 190,
    subchapters: [
      {
        id: "chem-11-1",
        name: "Transition Elements (3d series)",
        topics: ["3d series trends: oxidation states, radii, color, magnetism", "Preparation & redox reactions of K2Cr2O7 & KMnO4"]
      },
      {
        id: "chem-11-2",
        name: "Inner Transition Elements (Lanthanoids)",
        topics: ["Lanthanoids electronic configuration & oxidation states", "Lanthanoid contraction and consequences"]
      }
    ],
    topics: [
      "Transition Elements (3d series), oxidation states, catalytic & magnetic properties, K2Cr2O7 and KMnO4",
      "Lanthanoids and Actinoids, Lanthanoid contraction"
    ],
    formulas: [
      {
        id: "f-chem-11-1",
        name: "Spin-Only Magnetic Moment",
        expression: "μ_s = √(n(n+2)) BM",
        description: "Magnetic moment where n is number of unpaired d-electrons.",
        chapterId: "chem-11",
        chapterName: "d- and f-Block Elements",
        subject: "Chemistry",
        isBookmarked: true
      }
    ],
    notes: []
  },
  {
    id: "chem-12",
    name: "Coordination Compounds",
    subject: "Chemistry",
    classLevel: "Class 12",
    weightage: 5,
    revisionDueDays: 0, // Due!
    studyTimeMinutes: 240,
    subchapters: [
      {
        id: "chem-12-1",
        name: "Nomenclature & Isomerism",
        topics: ["Werner's theory & Ligand denticity/chelation", "IUPAC naming of coordination complexes", "Structural & Stereoisomerism"]
      },
      {
        id: "chem-12-2",
        name: "Bonding Theories (VBT & CFT)",
        topics: ["Valence Bond Theory (VBT)", "Crystal Field Theory (CFT) t2g & eg splitting", "Spectrochemical series & CFSE"]
      }
    ],
    topics: [
      "Werner's theory, ligands, denticity, IUPAC nomenclature of mononuclear coordination compounds, isomerism",
      "Valence bond approach and Crystal field theory (CFT), magnetic properties and color"
    ],
    formulas: [
      {
        id: "f-chem-12-1",
        name: "Octahedral CFSE",
        expression: "CFSE = (-0.4 n_t2g + 0.6 n_eg) Δo",
        description: "Crystal Field Stabilization Energy in octahedral field.",
        chapterId: "chem-12",
        chapterName: "Coordination Compounds",
        subject: "Chemistry",
        isBookmarked: true,
        isPinned: true
      }
    ],
    notes: []
  },

  // Organic Chemistry
  {
    id: "chem-13",
    name: "Purification and Characterisation of Organic Compounds",
    subject: "Chemistry",
    classLevel: "Class 11",
    weightage: 2,
    revisionDueDays: 7,
    studyTimeMinutes: 90,
    subchapters: [
      {
        id: "chem-13-1",
        name: "Purification & Analysis",
        topics: ["Crystallization, Sublimation, Distillation, Chromatography", "Qualitative & Quantitative estimation of C, H, N, Halogens"]
      }
    ],
    topics: [
      "Purification methods: crystallization, sublimation, distillation, chromatography",
      "Qualitative and quantitative analysis of organic elements"
    ],
    formulas: [],
    notes: []
  },
  {
    id: "chem-14",
    name: "Some Basic Principles of Organic Chemistry (GOC)",
    subject: "Chemistry",
    classLevel: "Class 11",
    weightage: 1,
    revisionDueDays: 2,
    studyTimeMinutes: 200,
    subchapters: [
      {
        id: "chem-14-1",
        name: "IUPAC Naming & Electronic Effects",
        topics: ["IUPAC nomenclature", "Inductive, Electromeric, Resonance, & Hyperconjugation effects", "Carbocations, carbanions, free radicals stability"]
      }
    ],
    topics: [
      "IUPAC Nomenclature, Electronic displacement: Inductive, electromeric, resonance, hyperconjugation",
      "Carbocation and carbanion stability, Homolytic and heterolytic fission"
    ],
    formulas: [],
    notes: []
  },
  {
    id: "chem-15",
    name: "Hydrocarbons",
    subject: "Chemistry",
    classLevel: "Class 11",
    weightage: 3,
    revisionDueDays: 4,
    studyTimeMinutes: 210,
    subchapters: [
      {
        id: "chem-15-1",
        name: "Alkanes, Alkenes & Alkynes",
        topics: ["Alkanes Sawhorse & Newman projections", "Alkenes Markovnikov addition & ozonolysis", "Alkynes acidic character & addition"]
      },
      {
        id: "chem-15-2",
        name: "Aromatic Hydrocarbons",
        topics: ["Benzene structure & aromaticity", "Electrophilic substitution: Nitration, Halogenation, Friedel-Crafts"]
      }
    ],
    topics: [
      "Alkanes, Alkenes, Alkynes nomenclature, preparation and reactions",
      "Aromatic hydrocarbons: benzene structure, aromaticity, Electrophilic substitution, Friedel-Crafts"
    ],
    formulas: [],
    notes: []
  },
  {
    id: "chem-16",
    name: "Organic Compounds Containing Halogens",
    subject: "Chemistry",
    classLevel: "Class 12",
    weightage: 3,
    revisionDueDays: 5,
    studyTimeMinutes: 150,
    subchapters: [
      {
        id: "chem-16-1",
        name: "Haloalkanes & Haloarenes",
        topics: ["Methods of preparation & C-X bond nature", "SN1 vs SN2 reaction mechanisms", "Uses & environmental effects of chloroform, freons, DDT"]
      }
    ],
    topics: [
      "Haloalkanes and Haloarenes preparation, properties, SN1 & SN2 substitution mechanisms"
    ],
    formulas: [],
    notes: []
  },
  {
    id: "chem-17",
    name: "Organic Compounds Containing Oxygen",
    subject: "Chemistry",
    classLevel: "Class 12",
    weightage: 9,
    revisionDueDays: 0, // Due!
    studyTimeMinutes: 340,
    subchapters: [
      {
        id: "chem-17-1",
        name: "Alcohols, Phenols & Ethers",
        topics: ["Alcohols 1°, 2°, 3° identification & dehydration", "Phenols acidic nature & Reimer-Tiemann reaction", "Ethers structure & preparation"]
      },
      {
        id: "chem-17-2",
        name: "Aldehydes, Ketones & Carboxylic Acids",
        topics: ["Nucleophilic addition (HCN, Grignard)", "Clemmensen & Wolff-Kishner reduction", "Aldol condensation & Cannizzaro reaction", "Carboxylic acids acidity & HVZ reaction"]
      }
    ],
    topics: [
      "Alcohols, Phenols, Ethers: Lucas test, Reimer-Tiemann, Kolbe reaction",
      "Aldehydes and Ketones: Nucleophilic addition, Aldol condensation, Cannizzaro, Iodoform test",
      "Carboxylic Acids: Acidic strength factors, HVZ reaction"
    ],
    formulas: [
      {
        id: "f-chem-17-1",
        name: "Clemmensen vs Wolff-Kishner",
        expression: "Clemmensen: Zn-Hg / HCl (Acidic) | Wolff-Kishner: NH2NH2 / KOH (Basic)",
        description: "Carbonyl >C=O reduction to methylene >CH2.",
        chapterId: "chem-17",
        chapterName: "Organic Compounds Containing Oxygen",
        subject: "Chemistry",
        isBookmarked: true,
        isPinned: true
      }
    ],
    notes: []
  },
  {
    id: "chem-18",
    name: "Organic Compounds Containing Nitrogen",
    subject: "Chemistry",
    classLevel: "Class 12",
    weightage: 4,
    revisionDueDays: 3,
    studyTimeMinutes: 160,
    subchapters: [
      {
        id: "chem-18-1",
        name: "Amines & Diazonium Salts",
        topics: ["Amines classification & basic strength order", "Hinsberg test for 1°, 2°, 3° amines", "Diazonium salts synthetic applications"]
      }
    ],
    topics: [
      "Amines: nomenclature, basic character, identification of 1°, 2°, 3° amines",
      "Diazonium Salts: preparation and synthetic utility in organic chemistry"
    ],
    formulas: [],
    notes: []
  },
  {
    id: "chem-19",
    name: "Biomolecules",
    subject: "Chemistry",
    classLevel: "Class 12",
    weightage: 4,
    revisionDueDays: 6,
    studyTimeMinutes: 130,
    subchapters: [
      {
        id: "chem-19-1",
        name: "Carbohydrates, Proteins & Nucleic Acids",
        topics: ["Carbohydrates classification (Glucose, Fructose, Sucrose)", "Proteins alpha-amino acids & peptide bond", "Vitamins & Nucleic Acids (DNA, RNA)"]
      }
    ],
    topics: [
      "Carbohydrates classification, Proteins amino acids & peptide bond",
      "Vitamins classification, Nucleic acids DNA & RNA constitution"
    ],
    formulas: [],
    notes: []
  },
  {
    id: "chem-20",
    name: "Principles Related to Practical Chemistry",
    subject: "Chemistry",
    classLevel: "Class 12",
    weightage: 1,
    revisionDueDays: 12,
    studyTimeMinutes: 80,
    subchapters: [
      {
        id: "chem-20-1",
        name: "Qualitative Salt Analysis & Organic Tests",
        topics: ["Detection of functional groups", "Qualitative Salt Analysis cations & anions", "Titrimetric exercises (Oxalic acid vs KMnO4)"]
      }
    ],
    topics: [
      "Qualitative Salt Analysis, Titrimetric exercises, Functional group detection"
    ],
    formulas: [],
    notes: []
  }
];
