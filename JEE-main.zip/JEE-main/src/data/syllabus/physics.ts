import { Chapter } from "./types";

export const PHYSICS_SYLLABUS: Chapter[] = [
  {
    id: "phy-1",
    name: "Units and Measurements",
    subject: "Physics",
    classLevel: "Class 11",
    weightage: 4,
    revisionDueDays: 5,
    studyTimeMinutes: 120,
    subchapters: [
      {
        id: "phy-1-1",
        name: "Units & Systems of Measurement",
        topics: ["Units of measurements", "System of units", "SI Units", "Fundamental and derived units"]
      },
      {
        id: "phy-1-2",
        name: "Errors & Instruments",
        topics: ["Least count", "Significant figures", "Errors in measurements", "Vernier calipers & Screw gauge"]
      },
      {
        id: "phy-1-3",
        name: "Dimensional Analysis",
        topics: ["Dimensions of Physics quantities", "Dimensional analysis and its applications"]
      }
    ],
    topics: [
      "Units of measurements, System of units, SI Units",
      "Fundamental and derived units, Least count",
      "Significant figures, Errors in measurements",
      "Dimensions of Physics quantities, dimensional analysis and its applications"
    ],
    formulas: [
      {
        id: "f-phy-1-1",
        name: "Percentage Error",
        expression: "% Error = (|ΔA| / A) × 100",
        description: "Fractional uncertainty expressed in percentage.",
        chapterId: "phy-1",
        chapterName: "Units and Measurements",
        subject: "Physics",
        isBookmarked: true,
        isPinned: true
      },
      {
        id: "f-phy-1-2",
        name: "Vernier Least Count",
        expression: "LC = 1 MSD - 1 VSD = 1 MSD / N",
        description: "Difference between 1 Main Scale Division and 1 Vernier Scale Division.",
        chapterId: "phy-1",
        chapterName: "Units and Measurements",
        subject: "Physics"
      },
      {
        id: "f-phy-1-3",
        name: "Screw Gauge Least Count",
        expression: "LC = Pitch / Total Circular Scale Divisions",
        description: "Minimum measurable length using screw gauge micrometer.",
        chapterId: "phy-1",
        chapterName: "Units and Measurements",
        subject: "Physics"
      }
    ],
    notes: [
      {
        id: "n-phy-1-1",
        title: "Dimensions of Common Physical Constants",
        content: "Gravitational constant G: [M^-1 L^3 T^-2]. Planck's constant h: [M L^2 T^-1]. Torque & Work share identical dimensions [M L^2 T^-2].",
        type: "revision",
        chapterId: "phy-1",
        chapterName: "Units and Measurements",
        subject: "Physics",
        isPinned: true,
        createdAt: "2026-07-20"
      }
    ]
  },
  {
    id: "phy-2",
    name: "Kinematics",
    subject: "Physics",
    classLevel: "Class 11",
    weightage: 6,
    revisionDueDays: 0, // Due today!
    studyTimeMinutes: 240,
    subchapters: [
      {
        id: "phy-2-1",
        name: "Motion in a Straight Line",
        topics: ["Frame of reference", "Speed and velocity", "Uniform & non-uniform motion", "Kinematic graphs (v-t, x-t)", "Relative velocity in 1D"]
      },
      {
        id: "phy-2-2",
        name: "Motion in a Plane & Projectile Motion",
        topics: ["Vectors & scalar resolution", "Projectile motion equation of trajectory", "Time of flight, Range & Max height", "Uniform circular motion"]
      }
    ],
    topics: [
      "Frame of reference, Motion in a straight line, Speed and velocity",
      "Uniform and non-uniform motion, Average speed and instantaneous velocity",
      "Uniformly accelerated motion, velocity-time, position-time graphs",
      "Relative velocity, Motion in a plane, projectile motion, uniform circular motion"
    ],
    formulas: [
      {
        id: "f-phy-2-1",
        name: "Projectile Maximum Height",
        expression: "H_max = (u^2 sin^2 θ) / (2g)",
        description: "Maximum vertical height reached by a projectile.",
        chapterId: "phy-2",
        chapterName: "Kinematics",
        subject: "Physics",
        isBookmarked: true
      },
      {
        id: "f-phy-2-2",
        name: "Projectile Horizontal Range",
        expression: "R = (u^2 sin 2θ) / g",
        description: "Total horizontal distance covered by projectile.",
        chapterId: "phy-2",
        chapterName: "Kinematics",
        subject: "Physics",
        isPinned: true
      },
      {
        id: "f-phy-2-3",
        name: "Trajectory Equation",
        expression: "y = x tanθ - (g x^2) / (2 u^2 cos^2θ)",
        description: "Parabolic trajectory equation in Cartesian coordinates.",
        chapterId: "phy-2",
        chapterName: "Kinematics",
        subject: "Physics"
      }
    ],
    notes: [
      {
        id: "n-phy-2-1",
        title: "Galileo's Law of Odd Numbers",
        content: "For a body starting from rest under uniform acceleration, distances traveled in equal time intervals are in ratio 1:3:5:7:9...",
        type: "quick",
        chapterId: "phy-2",
        chapterName: "Kinematics",
        subject: "Physics",
        createdAt: "2026-07-22"
      }
    ]
  },
  {
    id: "phy-3",
    name: "Laws of Motion",
    subject: "Physics",
    classLevel: "Class 11",
    weightage: 2,
    revisionDueDays: 3,
    studyTimeMinutes: 150,
    subchapters: [
      {
        id: "phy-3-1",
        name: "Newton's Laws & Impulse",
        topics: ["Force and inertia", "Newton's 1st, 2nd, and 3rd laws", "Impulse & momentum conservation", "Free body diagrams"]
      },
      {
        id: "phy-3-2",
        name: "Friction & Circular Dynamics",
        topics: ["Static & kinetic friction", "Laws of friction, rolling friction", "Centripetal force", "Banking of roads"]
      }
    ],
    topics: [
      "Force and inertia, Newton's first law of motion, momentum, Newton's second Law",
      "Impulse, Newton's third Law, Law of conservation of linear momentum",
      "Static and Kinetic friction, laws of friction, rolling friction",
      "Dynamics of uniform circular motion, centripetal force, vehicle on banked road"
    ],
    formulas: [
      {
        id: "f-phy-3-1",
        name: "Impulse-Momentum Theorem",
        expression: "J = ∫ F dt = Δp",
        description: "Impulse delivered equals change in linear momentum.",
        chapterId: "phy-3",
        chapterName: "Laws of Motion",
        subject: "Physics"
      },
      {
        id: "f-phy-3-2",
        name: "Optimum Banking Speed",
        expression: "v = √(r g tanθ)",
        description: "Maximum safe speed on a banked road without friction.",
        chapterId: "phy-3",
        chapterName: "Laws of Motion",
        subject: "Physics"
      }
    ],
    notes: [
      {
        id: "n-phy-3-1",
        title: "Limiting Friction Adjustment",
        content: "Static friction is self-adjusting up to limiting friction f_s(max) = μ_s N. Kinetic friction remains constant f_k = μ_k N once sliding begins.",
        type: "personal",
        chapterId: "phy-3",
        chapterName: "Laws of Motion",
        subject: "Physics",
        createdAt: "2026-07-21"
      }
    ]
  },
  {
    id: "phy-4",
    name: "Work, Energy and Power",
    subject: "Physics",
    classLevel: "Class 11",
    weightage: 2,
    revisionDueDays: 7,
    studyTimeMinutes: 180,
    subchapters: [
      {
        id: "phy-4-1",
        name: "Work & Energy Theorem",
        topics: ["Work done by constant & variable force", "Kinetic & potential energy", "Work-Energy Theorem"]
      },
      {
        id: "phy-4-2",
        name: "Collisions & Vertical Circle",
        topics: ["Spring potential energy", "Conservative & non-conservative forces", "Vertical circular motion", "Elastic and inelastic collisions in 1D & 2D"]
      }
    ],
    topics: [
      "Work done by constant force and variable force, kinetic and potential energies",
      "Work-energy theorem, power, potential energy of a spring",
      "Conservation of mechanical energy, conservative and non-conservative forces",
      "Motion in a vertical circle, Elastic and inelastic collisions in 1D and 2D"
    ],
    formulas: [
      {
        id: "f-phy-4-1",
        name: "Work-Energy Theorem",
        expression: "W_net = ΔK = K_f - K_i",
        description: "Total work done by all forces equals change in kinetic energy.",
        chapterId: "phy-4",
        chapterName: "Work, Energy and Power",
        subject: "Physics",
        isBookmarked: true
      },
      {
        id: "f-phy-4-2",
        name: "Vertical Circle Critical Speed",
        expression: "v_bottom = √(5gR), v_top = √(gR)",
        description: "Minimum speeds required for complete vertical circle looping.",
        chapterId: "phy-4",
        chapterName: "Work, Energy and Power",
        subject: "Physics",
        isPinned: true
      }
    ],
    notes: []
  },
  {
    id: "phy-5",
    name: "Rotational Motion",
    subject: "Physics",
    classLevel: "Class 11",
    weightage: 4,
    revisionDueDays: 0, // Due!
    studyTimeMinutes: 300,
    subchapters: [
      {
        id: "phy-5-1",
        name: "Centre of Mass & Torque",
        topics: ["Centre of mass of 2-particle & rigid body", "Torque & angular momentum", "Conservation of angular momentum"]
      },
      {
        id: "phy-5-2",
        name: "Moment of Inertia & Pure Rolling",
        topics: ["Moment of inertia & radius of gyration", "Parallel & perpendicular axes theorems", "Equations of rotational motion", "Pure rolling motion"]
      }
    ],
    topics: [
      "Centre of mass of a two-particle system, centre of mass of a rigid body",
      "Basic concepts of rotational motion, moment of a force, torque, angular momentum",
      "Conservation of angular momentum and its applications, Moment of inertia",
      "Parallel and perpendicular axes theorems, Pure rolling motion"
    ],
    formulas: [
      {
        id: "f-phy-5-1",
        name: "Torque & Angular Acceleration",
        expression: "τ = I α",
        description: "Rotational counterpart of F = ma.",
        chapterId: "phy-5",
        chapterName: "Rotational Motion",
        subject: "Physics",
        isBookmarked: true,
        isPinned: true
      },
      {
        id: "f-phy-5-2",
        name: "Parallel Axis Theorem",
        expression: "I = I_cm + M d^2",
        description: "Moment of inertia about parallel axis distance d from CM.",
        chapterId: "phy-5",
        chapterName: "Rotational Motion",
        subject: "Physics",
        isPinned: true
      }
    ],
    notes: [
      {
        id: "n-phy-5-1",
        title: "Pure Rolling Contact Condition",
        content: "In pure rolling on stationary ground, point of contact velocity is zero: v_cm = R ω. Acceleration of contact point is purely centripetal a_c = v^2 / R.",
        type: "revision",
        chapterId: "phy-5",
        chapterName: "Rotational Motion",
        subject: "Physics",
        isPinned: true,
        createdAt: "2026-07-24"
      }
    ]
  },
  {
    id: "phy-6",
    name: "Gravitation",
    subject: "Physics",
    classLevel: "Class 11",
    weightage: 4,
    revisionDueDays: 2,
    studyTimeMinutes: 190,
    subchapters: [
      {
        id: "phy-6-1",
        name: "Gravitational Field & Potential",
        topics: ["Universal law of gravitation", "Acceleration due to gravity g and variation with height/depth", "Gravitational potential energy"]
      },
      {
        id: "phy-6-2",
        name: "Kepler's Laws & Satellites",
        topics: ["Kepler's laws of planetary motion", "Escape velocity", "Orbital velocity & satellite period"]
      }
    ],
    topics: [
      "The universal law of gravitation, Acceleration due to gravity and its variation",
      "Kepler's law of planetary motion, Gravitational potential energy and potential",
      "Escape velocity, Motion of a satellite, orbital velocity, time period and energy"
    ],
    formulas: [
      {
        id: "f-phy-6-1",
        name: "Escape Velocity",
        expression: "v_e = √(2GM/R) = √(2gR) ≈ 11.2 km/s",
        description: "Minimum speed required to escape planetary gravitational pull.",
        chapterId: "phy-6",
        chapterName: "Gravitation",
        subject: "Physics",
        isBookmarked: true
      },
      {
        id: "f-phy-6-2",
        name: "Variation of g with Altitude",
        expression: "g' = g (1 - 2h/R)  for h << R",
        description: "Decrease in gravitational acceleration at height h above surface.",
        chapterId: "phy-6",
        chapterName: "Gravitation",
        subject: "Physics"
      }
    ],
    notes: []
  },
  {
    id: "phy-7",
    name: "Properties of Solids and Liquids",
    subject: "Physics",
    classLevel: "Class 11",
    weightage: 7,
    revisionDueDays: 4,
    studyTimeMinutes: 210,
    subchapters: [
      {
        id: "phy-7-1",
        name: "Elasticity of Solids",
        topics: ["Elastic behavior, Stress-strain relationship", "Hooke's Law", "Young's, Bulk, & Rigidity moduli"]
      },
      {
        id: "phy-7-2",
        name: "Fluid Dynamics & Surface Tension",
        topics: ["Pressure, Pascal's law", "Viscosity, Stoke's law, Terminal velocity", "Bernoulli's principle", "Surface tension, Capillary rise"]
      },
      {
        id: "phy-7-3",
        name: "Thermal Properties & Heat Transfer",
        topics: ["Thermal expansion, Calorimetry", "Latent heat", "Conduction, Convection, Radiation"]
      }
    ],
    topics: [
      "Elastic behaviour, stress-strain relationship, Hooke's Law, Young's modulus, bulk modulus",
      "Pressure due to fluid column, Pascal's law, Viscosity, Stoke's law, Terminal velocity, Bernoulli's principle",
      "Surface energy and surface tension, Capillary rise, Heat expansion, Calorimetry, Heat transfer"
    ],
    formulas: [
      {
        id: "f-phy-7-1",
        name: "Terminal Velocity",
        expression: "v_t = 2 r^2 (ρ - σ) g / (9 η)",
        description: "Terminal speed of spherical body falling through viscous fluid.",
        chapterId: "phy-7",
        chapterName: "Properties of Solids and Liquids",
        subject: "Physics"
      },
      {
        id: "f-phy-7-2",
        name: "Capillary Rise Height",
        expression: "h = (2 T cosθ) / (r ρ g)",
        description: "Height of liquid column in capillary tube.",
        chapterId: "phy-7",
        chapterName: "Properties of Solids and Liquids",
        subject: "Physics"
      }
    ],
    notes: []
  },
  {
    id: "phy-8",
    name: "Thermodynamics",
    subject: "Physics",
    classLevel: "Class 11",
    weightage: 3,
    revisionDueDays: 1,
    studyTimeMinutes: 160,
    subchapters: [
      {
        id: "phy-8-1",
        name: "Laws of Thermodynamics",
        topics: ["Thermal equilibrium & Zeroth law", "First law ΔQ = ΔU + W", "Isothermal & Adiabatic processes"]
      },
      {
        id: "phy-8-2",
        name: "Heat Engines & Reversibility",
        topics: ["Second law of thermodynamics", "Reversible & irreversible processes", "Carnot engine efficiency"]
      }
    ],
    topics: [
      "Thermal equilibrium, Zeroth law of thermodynamics, First law of thermodynamics",
      "Isothermal and adiabatic processes, Second law of thermodynamics, Reversible and irreversible processes"
    ],
    formulas: [
      {
        id: "f-phy-8-1",
        name: "First Law of Thermodynamics",
        expression: "ΔQ = ΔU + W",
        description: "Heat supplied equals change in internal energy plus work done BY system.",
        chapterId: "phy-8",
        chapterName: "Thermodynamics",
        subject: "Physics",
        isBookmarked: true
      },
      {
        id: "f-phy-8-2",
        name: "Carnot Engine Efficiency",
        expression: "η = 1 - T2/T1 = 1 - Q2/Q1",
        description: "Maximum efficiency of thermodynamic heat engine.",
        chapterId: "phy-8",
        chapterName: "Thermodynamics",
        subject: "Physics",
        isPinned: true
      }
    ],
    notes: []
  },
  {
    id: "phy-9",
    name: "Kinetic Theory of Gases",
    subject: "Physics",
    classLevel: "Class 11",
    weightage: 3,
    revisionDueDays: 6,
    studyTimeMinutes: 130,
    subchapters: [
      {
        id: "phy-9-1",
        name: "Ideal Gas Laws & Speeds",
        topics: ["Equation of state PV = nRT", "Kinetic theory assumptions", "RMS, Average, & Most Probable speeds"]
      },
      {
        id: "phy-9-2",
        name: "Degrees of Freedom & Specific Heats",
        topics: ["Law of equipartition of energy", "Degrees of freedom", "Molar specific heat capacities (Cp, Cv)"]
      }
    ],
    topics: [
      "Equation of state of a perfect gas, Kinetic theory assumptions",
      "Concept of pressure, Kinetic interpretation of temperature, RMS speed",
      "Degrees of freedom, Law of equipartition of energy, Specific heat capacities"
    ],
    formulas: [
      {
        id: "f-phy-9-1",
        name: "Gas Molecule Speeds",
        expression: "v_rms = √(3RT/M), v_avg = √(8RT/πM), v_mp = √(2RT/M)",
        description: "RMS, Average, and Most Probable speeds of ideal gas molecules.",
        chapterId: "phy-9",
        chapterName: "Kinetic Theory of Gases",
        subject: "Physics"
      }
    ],
    notes: []
  },
  {
    id: "phy-10",
    name: "Oscillations and Waves",
    subject: "Physics",
    classLevel: "Class 11",
    weightage: 5,
    revisionDueDays: 0, // Due!
    studyTimeMinutes: 260,
    subchapters: [
      {
        id: "phy-10-1",
        name: "Simple Harmonic Motion (SHM)",
        topics: ["Periodic motion & SHM equation", "Phase & energy in SHM", "Spring-mass system & simple pendulum"]
      },
      {
        id: "phy-10-2",
        name: "Wave Motion & Superposition",
        topics: ["Longitudinal & transverse waves", "Progressive wave equation", "Standing waves in strings & organ pipes", "Beats"]
      }
    ],
    topics: [
      "Oscillations and periodic motion, SHM equation, phase, spring oscillations",
      "Energy in SHM: kinetic and potential energies, simple pendulum derivation",
      "Wave motion, longitudinal & transverse waves, Principle of superposition",
      "Standing waves in strings and organ pipes, beats"
    ],
    formulas: [
      {
        id: "f-phy-10-1",
        name: "Simple Pendulum Period",
        expression: "T = 2π √(L / g)",
        description: "Time period of small amplitude simple pendulum.",
        chapterId: "phy-10",
        chapterName: "Oscillations and Waves",
        subject: "Physics",
        isBookmarked: true
      },
      {
        id: "f-phy-10-2",
        name: "Beat Frequency",
        expression: "f_beat = |f1 - f2|",
        description: "Number of beats heard per second due to superposed waves.",
        chapterId: "phy-10",
        chapterName: "Oscillations and Waves",
        subject: "Physics"
      }
    ],
    notes: []
  },

  // Class 12 Physics
  {
    id: "phy-11",
    name: "Electrostatics",
    subject: "Physics",
    classLevel: "Class 12",
    weightage: 8,
    revisionDueDays: 2,
    studyTimeMinutes: 320,
    subchapters: [
      {
        id: "phy-11-1",
        name: "Electric Charges & Fields",
        topics: ["Coulomb's Law", "Electric field & Dipole torque", "Electric flux & Gauss's Law"]
      },
      {
        id: "phy-11-2",
        name: "Electrostatic Potential & Capacitance",
        topics: ["Electric potential & equipotential surfaces", "Capacitors in series & parallel", "Energy stored & Dielectric insertion"]
      }
    ],
    topics: [
      "Electric charges, Coulomb's law, Electric field lines, Electric dipole",
      "Electric flux, Gauss's law and its applications",
      "Electric potential, equipotential surfaces, potential energy",
      "Capacitors and capacitance, parallel plate capacitor with dielectric"
    ],
    formulas: [
      {
        id: "f-phy-11-1",
        name: "Parallel Plate Capacitance",
        expression: "C = K ε0 A / d",
        description: "Capacitance with dielectric medium of constant K.",
        chapterId: "phy-11",
        chapterName: "Electrostatics",
        subject: "Physics",
        isBookmarked: true,
        isPinned: true
      },
      {
        id: "f-phy-11-2",
        name: "Capacitor Stored Energy",
        expression: "U = (1/2) C V^2 = Q^2 / (2C) = (1/2) Q V",
        description: "Electrostatic potential energy stored in capacitor field.",
        chapterId: "phy-11",
        chapterName: "Electrostatics",
        subject: "Physics",
        isPinned: true
      }
    ],
    notes: [
      {
        id: "n-phy-11-1",
        title: "Dielectric Insertion Scenarios",
        content: "1) Battery Connected: Voltage V stays constant; Q, C, U increase by K. 2) Battery Disconnected: Charge Q stays constant; C increases by K; V, E decrease by K.",
        type: "revision",
        chapterId: "phy-11",
        chapterName: "Electrostatics",
        subject: "Physics",
        isPinned: true,
        createdAt: "2026-07-25"
      }
    ]
  },
  {
    id: "phy-12",
    name: "Current Electricity",
    subject: "Physics",
    classLevel: "Class 12",
    weightage: 7,
    revisionDueDays: 0, // Due!
    studyTimeMinutes: 280,
    subchapters: [
      {
        id: "phy-12-1",
        name: "Ohm's Law & Circuit Rules",
        topics: ["Drift velocity I = n A e v_d", "Resistivity & temperature dependence", "Kirchhoff's Voltage & Current Laws"]
      },
      {
        id: "phy-12-2",
        name: "Cells & Measuring Instruments",
        topics: ["Combination of cells & internal resistance", "Wheatstone Bridge & Metre Bridge", "Potentiometer principles & EMF comparison"]
      }
    ],
    topics: [
      "Electric current, drift velocity, Ohm's law, electrical resistance",
      "Resistivity, temperature dependence of resistance, Kirchhoff's laws",
      "Internal resistance, EMF of a cell, combination of cells",
      "Wheatstone bridge, Metre bridge, Potentiometer applications"
    ],
    formulas: [
      {
        id: "f-phy-12-1",
        name: "Drift Velocity",
        expression: "v_d = (e E τ) / m = I / (n e A)",
        description: "Average speed acquired by free electrons in electric field.",
        chapterId: "phy-12",
        chapterName: "Current Electricity",
        subject: "Physics",
        isBookmarked: true
      },
      {
        id: "f-phy-12-2",
        name: "Potentiometer EMF Comparison",
        expression: "E1 / E2 = l1 / l2",
        description: "Ratio of unknown battery EMFs matched to null deflection lengths.",
        chapterId: "phy-12",
        chapterName: "Current Electricity",
        subject: "Physics",
        isPinned: true
      }
    ],
    notes: []
  },
  {
    id: "phy-13",
    name: "Magnetic Effects of Current and Magnetism",
    subject: "Physics",
    classLevel: "Class 12",
    weightage: 5,
    revisionDueDays: 4,
    studyTimeMinutes: 220,
    subchapters: [
      {
        id: "phy-13-1",
        name: "Magnetic Field & Forces",
        topics: ["Biot-Savart law & Ampere's law", "Force on moving charge & current conductor", "Moving coil galvanometer & conversion"]
      },
      {
        id: "phy-13-2",
        name: "Magnetism & Magnetic Materials",
        topics: ["Current loop as magnetic dipole", "Bar magnet magnetic field", "Para, dia, and ferromagnetic substances"]
      }
    ],
    topics: [
      "Biot - Savart law, Ampere's law, Force on moving charge in magnetic field",
      "Force between two parallel currents, Moving coil galvanometer conversion",
      "Current loop as magnetic dipole, Bar magnet properties, Dia, para, and ferro-magnetic materials"
    ],
    formulas: [
      {
        id: "f-phy-13-1",
        name: "Biot-Savart Law",
        expression: "dB = (μ0 / 4π) (I dl sinθ) / r^2",
        description: "Magnetic field element created by current element.",
        chapterId: "phy-13",
        chapterName: "Magnetic Effects of Current and Magnetism",
        subject: "Physics"
      }
    ],
    notes: []
  },
  {
    id: "phy-14",
    name: "Electromagnetic Induction and Alternating Currents",
    subject: "Physics",
    classLevel: "Class 12",
    weightage: 7,
    revisionDueDays: 3,
    studyTimeMinutes: 240,
    subchapters: [
      {
        id: "phy-14-1",
        name: "Electromagnetic Induction",
        topics: ["Faraday's law & Lenz's law", "Induced EMF & Eddy currents", "Self & mutual inductance"]
      },
      {
        id: "phy-14-2",
        name: "Alternating Current Circuits",
        topics: ["Peak & RMS current values", "LCR series circuit & resonance", "Power in AC circuits, AC generator & transformer"]
      }
    ],
    topics: [
      "Electromagnetic induction, Faraday's law, induced EMF, Lenz's law",
      "Self and mutual inductance, Alternating currents, Peak and RMS value",
      "Reactance and impedance, LCR series circuit, resonance, power in AC circuits, transformer"
    ],
    formulas: [
      {
        id: "f-phy-14-1",
        name: "LCR Resonant Frequency",
        expression: "f_r = 1 / (2π √(L C))",
        description: "Resonance frequency where inductive reactance equals capacitive reactance.",
        chapterId: "phy-14",
        chapterName: "Electromagnetic Induction and Alternating Currents",
        subject: "Physics",
        isBookmarked: true,
        isPinned: true
      }
    ],
    notes: []
  },
  {
    id: "phy-15",
    name: "Electromagnetic Waves",
    subject: "Physics",
    classLevel: "Class 12",
    weightage: 3,
    revisionDueDays: 8,
    studyTimeMinutes: 90,
    subchapters: [
      {
        id: "phy-15-1",
        name: "EM Waves & Spectrum",
        topics: ["Displacement current", "Transverse nature of EM waves", "Electromagnetic spectrum (Radio to Gamma)"]
      }
    ],
    topics: [
      "Displacement current, Electromagnetic waves and their characteristics",
      "Transverse nature of electromagnetic waves, Electromagnetic spectrum and applications"
    ],
    formulas: [
      {
        id: "f-phy-15-1",
        name: "EM Wave Speed",
        expression: "c = 1 / √(μ0 ε0) = E0 / B0",
        description: "Speed of electromagnetic waves in vacuum.",
        chapterId: "phy-15",
        chapterName: "Electromagnetic Waves",
        subject: "Physics"
      }
    ],
    notes: []
  },
  {
    id: "phy-16",
    name: "Optics",
    subject: "Physics",
    classLevel: "Class 12",
    weightage: 7,
    revisionDueDays: 1,
    studyTimeMinutes: 310,
    subchapters: [
      {
        id: "phy-16-1",
        name: "Ray Optics & Instruments",
        topics: ["Reflection & Refraction, Total Internal Reflection", "Lens maker's formula & combination", "Prism refraction & deviation", "Microscope & Astronomical telescope"]
      },
      {
        id: "phy-16-2",
        name: "Wave Optics",
        topics: ["Huygens' Principle & wavefronts", "Young's Double Slit Interference (YDSE)", "Single slit diffraction", "Polarization & Brewster's law"]
      }
    ],
    topics: [
      "Reflection & Refraction of light, Total internal reflection, Lens maker's formula",
      "Prism refraction, Microscope and astronomical telescope",
      "Wave optics, Huygens' Principle, YDSE Interference fringe width",
      "Diffraction single slit, Polarization and Brewster's law"
    ],
    formulas: [
      {
        id: "f-phy-16-1",
        name: "Lens Maker's Formula",
        expression: "1/f = (μ - 1) (1/R1 - 1/R2)",
        description: "Focal length calculation based on lens surface radii.",
        chapterId: "phy-16",
        chapterName: "Optics",
        subject: "Physics",
        isBookmarked: true,
        isPinned: true
      },
      {
        id: "f-phy-16-2",
        name: "YDSE Fringe Width",
        expression: "β = λ D / d",
        description: "Spacing between adjacent bright or dark interference fringes.",
        chapterId: "phy-16",
        chapterName: "Optics",
        subject: "Physics",
        isPinned: true
      }
    ],
    notes: []
  },
  {
    id: "phy-17",
    name: "Dual Nature of Matter and Radiation",
    subject: "Physics",
    classLevel: "Class 12",
    weightage: 4,
    revisionDueDays: 5,
    studyTimeMinutes: 140,
    subchapters: [
      {
        id: "phy-17-1",
        name: "Photoelectric Effect & Matter Waves",
        topics: ["Photoelectric effect observations", "Einstein's photoelectric equation", "De Broglie relationship for matter waves"]
      }
    ],
    topics: [
      "Dual nature of radiation, Photoelectric effect, Einstein's photoelectric equation",
      "Particle nature of light, Matter waves: de Broglie relation"
    ],
    formulas: [
      {
        id: "f-phy-17-1",
        name: "Einstein Photoelectric Equation",
        expression: "K_max = h ν - Φ = e V_s",
        description: "Maximum kinetic energy of emitted photoelectrons.",
        chapterId: "phy-17",
        chapterName: "Dual Nature of Matter and Radiation",
        subject: "Physics"
      }
    ],
    notes: []
  },
  {
    id: "phy-18",
    name: "Atoms and Nuclei",
    subject: "Physics",
    classLevel: "Class 12",
    weightage: 6,
    revisionDueDays: 3,
    studyTimeMinutes: 200,
    subchapters: [
      {
        id: "phy-18-1",
        name: "Atomic Models & Spectra",
        topics: ["Alpha-particle scattering & Rutherford model", "Bohr model of hydrogen atom", "Energy levels & hydrogen spectral series"]
      },
      {
        id: "phy-18-2",
        name: "Nuclear Physics",
        topics: ["Nucleus composition & size", "Mass defect & binding energy per nucleon", "Nuclear fission and fusion"]
      }
    ],
    topics: [
      "Alpha-particle scattering experiment, Rutherford's & Bohr model of atom",
      "Energy levels, hydrogen spectrum, Composition and size of nucleus",
      "Mass defect, binding energy per nucleon, nuclear fission and fusion"
    ],
    formulas: [
      {
        id: "f-phy-18-1",
        name: "Bohr Energy Levels",
        expression: "E_n = -13.6 Z^2 / n^2 eV",
        description: "Energy of electron in nth orbit of hydrogen-like ion.",
        chapterId: "phy-18",
        chapterName: "Atoms and Nuclei",
        subject: "Physics",
        isBookmarked: true
      }
    ],
    notes: []
  },
  {
    id: "phy-19",
    name: "Electronic Devices",
    subject: "Physics",
    classLevel: "Class 12",
    weightage: 5,
    revisionDueDays: 0, // Due!
    studyTimeMinutes: 170,
    subchapters: [
      {
        id: "phy-19-1",
        name: "Semiconductors & Diodes",
        topics: ["n-type & p-type semiconductors", "p-n junction diode forward/reverse bias", "Diode as rectifier & Zener voltage regulator"]
      },
      {
        id: "phy-19-2",
        name: "Logic Gates",
        topics: ["OR, AND, NOT, NAND, NOR logic gates", "Truth tables & Boolean algebra"]
      }
    ],
    topics: [
      "Semiconductors, p-n junction diode I-V characteristics, Diode as rectifier",
      "Zener diode as voltage regulator, Logic gates (OR, AND, NOT, NAND, NOR)"
    ],
    formulas: [
      {
        id: "f-phy-19-1",
        name: "De Morgan's Laws",
        expression: "overline(A · B) = overline(A) + overline(B), overline(A + B) = overline(A) · overline(B)",
        description: "Universal Boolean algebra transformation relations.",
        chapterId: "phy-19",
        chapterName: "Electronic Devices",
        subject: "Physics",
        isPinned: true
      }
    ],
    notes: []
  },
  {
    id: "phy-20",
    name: "Experimental Skills",
    subject: "Physics",
    classLevel: "Class 12",
    weightage: 2,
    revisionDueDays: 10,
    studyTimeMinutes: 90,
    subchapters: [
      {
        id: "phy-20-1",
        name: "Lab Experiments & Measurements",
        topics: ["Vernier calipers & Screw gauge", "Metre bridge & Ohm's law", "Half deflection galvanometer", "Prism deviation & Travelling microscope"]
      }
    ],
    topics: [
      "Familiarity with lab experiments: Vernier calipers, Screw gauge, Metre bridge, Half deflection method, Prism deviation, Diode characteristics"
    ],
    formulas: [],
    notes: []
  }
];
