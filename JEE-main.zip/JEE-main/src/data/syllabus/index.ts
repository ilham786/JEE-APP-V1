import { Chapter, Formula, Note } from "./types";
import { PHYSICS_SYLLABUS } from "./physics";
import { CHEMISTRY_SYLLABUS } from "./chemistry";
import { MATHEMATICS_SYLLABUS } from "./mathematics";
import { NEET_SYLLABUS_DATA, NeetChapterData } from "../curriculum/neet-syllabus-data";
import { ExamType } from "@/lib/exam-config";

export * from "./types";
export { PHYSICS_SYLLABUS } from "./physics";
export { CHEMISTRY_SYLLABUS } from "./chemistry";
export { MATHEMATICS_SYLLABUS } from "./mathematics";

export function convertNeetChapterToChapter(neet: NeetChapterData): Chapter {
  return {
    id: neet.id,
    name: neet.name,
    subject: neet.subject,
    classLevel: neet.classLevel,
    weightage: neet.trendWeightage || 5,
    subchapters: (neet.subtopics || []).map((st, idx) => ({
      id: `${neet.id}-sub-${idx}`,
      name: st,
      topics: [st],
    })),
    topics: neet.topics || [],
    formulas: (neet.formulas || []).map((f, idx) => ({
      id: `${neet.id}-form-${idx}`,
      name: f.name,
      expression: f.expression,
      description: f.description,
      chapterId: neet.id,
      chapterName: neet.name,
      subject: neet.subject,
    })),
    notes: (neet.shortNotes || []).map((n, idx) => ({
      id: `${neet.id}-note-${idx}`,
      title: `${neet.name} Key Concept ${idx + 1}`,
      content: n,
      type: "revision",
      chapterId: neet.id,
      chapterName: neet.name,
      subject: neet.subject,
      createdAt: new Date().toISOString(),
    })),
    revisionDueDays: 7,
    studyTimeMinutes: 0,
    ncertFacts: neet.ncertFacts,
    diagrams: neet.diagrams,
    reactions: neet.reactions,
    shortNotes: neet.shortNotes,
    commonMistakes: neet.commonMistakes,
    importanceBadge: neet.importanceBadge,
    trendWeightage: neet.trendWeightage,
    pyqsTotal: neet.pyqsTotal,
  };
}

export const NEET_ADAPTED_SYLLABUS: Record<"Physics" | "Chemistry" | "Botany" | "Zoology", Chapter[]> = {
  Physics: (NEET_SYLLABUS_DATA.Physics || []).map(convertNeetChapterToChapter),
  Chemistry: (NEET_SYLLABUS_DATA.Chemistry || []).map(convertNeetChapterToChapter),
  Botany: (NEET_SYLLABUS_DATA.Botany || []).map(convertNeetChapterToChapter),
  Zoology: (NEET_SYLLABUS_DATA.Zoology || []).map(convertNeetChapterToChapter),
};

export const MASTER_SYLLABUS: Record<"Physics" | "Chemistry" | "Maths", Chapter[]> = {
  Physics: PHYSICS_SYLLABUS,
  Chemistry: CHEMISTRY_SYLLABUS,
  Maths: MATHEMATICS_SYLLABUS,
};

export function getCurriculumForExam(examType: ExamType): Record<string, Chapter[]> {
  if (examType === "NEET") {
    return NEET_ADAPTED_SYLLABUS;
  }
  return MASTER_SYLLABUS;
}

export function getSyllabusForSubject(subject: string, examType: ExamType = "JEE"): Chapter[] {
  if (examType === "NEET") {
    const key = subject as "Physics" | "Chemistry" | "Botany" | "Zoology";
    return NEET_ADAPTED_SYLLABUS[key] || [];
  }
  const key = subject === "Mathematics" ? "Maths" : (subject as "Physics" | "Chemistry" | "Maths");
  return MASTER_SYLLABUS[key] || [];
}

export function getAllChaptersForExam(examType: ExamType): Chapter[] {
  const curriculum = getCurriculumForExam(examType);
  return Object.values(curriculum).flat();
}

export function getSyllabusBySubject(subject: "Physics" | "Chemistry" | "Maths"): Chapter[] {
  return MASTER_SYLLABUS[subject] || [];
}

export function getAllChapters(): Chapter[] {
  return [
    ...PHYSICS_SYLLABUS,
    ...CHEMISTRY_SYLLABUS,
    ...MATHEMATICS_SYLLABUS,
  ];
}

export function getAllFormulas(examType?: ExamType): Formula[] {
  if (examType) {
    return getAllChaptersForExam(examType).flatMap((ch) => ch.formulas);
  }
  return getAllChapters().flatMap((ch) => ch.formulas);
}

export function getAllNotes(examType?: ExamType): Note[] {
  if (examType) {
    return getAllChaptersForExam(examType).flatMap((ch) => ch.notes);
  }
  return getAllChapters().flatMap((ch) => ch.notes);
}

export function searchSyllabus(query: string, examType?: ExamType) {
  const q = query.toLowerCase().trim();
  const chapters = examType ? getAllChaptersForExam(examType) : getAllChapters();
  if (!q) return chapters;

  return chapters.filter((ch) => {
    const matchName = ch.name.toLowerCase().includes(q);
    const matchSubject = ch.subject.toLowerCase().includes(q);
    const matchTopics = ch.topics.some((t) => t.toLowerCase().includes(q));
    const matchSubchapters = ch.subchapters.some((sc) => 
      sc.name.toLowerCase().includes(q) || sc.topics.some((t) => t.toLowerCase().includes(q))
    );
    const matchFormulas = ch.formulas.some((f) => 
      f.name.toLowerCase().includes(q) || f.expression.toLowerCase().includes(q)
    );
    const matchNotes = ch.notes.some((n) => 
      n.title.toLowerCase().includes(q) || n.content.toLowerCase().includes(q)
    );

    return matchName || matchSubject || matchTopics || matchSubchapters || matchFormulas || matchNotes;
  });
}
