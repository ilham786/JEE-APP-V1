export type SubjectKey = "Physics" | "Chemistry" | "Maths" | "Mathematics" | "Botany" | "Zoology";

export interface Subchapter {
  id: string;
  name: string;
  topics: string[];
}

export interface Formula {
  id: string;
  name: string;
  expression: string;
  description?: string;
  chapterId: string;
  chapterName: string;
  subject: string;
  isBookmarked?: boolean;
  isPinned?: boolean;
  revisionDue?: boolean;
  lastViewed?: string;
}

export interface Note {
  id: string;
  title: string;
  content: string;
  type: "personal" | "revision" | "quick";
  chapterId: string;
  chapterName: string;
  subject: string;
  isBookmarked?: boolean;
  isPinned?: boolean;
  createdAt: string;
}

export interface Chapter {
  id: string;
  name: string;
  subject: string;
  classLevel: "Class 11" | "Class 12";
  weightage: number; // Percentage e.g. 7
  subchapters: Subchapter[];
  topics: string[];
  formulas: Formula[];
  notes: Note[];
  revisionDueDays: number; // Days until next revision is due (<=0 means due)
  studyTimeMinutes: number;
  // NEET-specific optional NCERT enrichments:
  ncertFacts?: { fact: string; category: "definition" | "example" | "exception" | "high-yield"; pageRef?: string }[];
  diagrams?: { name: string; description: string; highYieldLabel: string }[];
  reactions?: { name: string; reagents: string; equation: string; notes: string }[];
  shortNotes?: string[];
  commonMistakes?: string[];
  importanceBadge?: "Critical" | "High" | "Medium" | "Low";
  trendWeightage?: number;
  pyqsTotal?: number;
}

export interface SubjectSyllabus {
  subject: string;
  chapters: Chapter[];
}
