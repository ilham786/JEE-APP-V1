import { Chapter } from "./types";

export const MATHEMATICS_SYLLABUS: Chapter[] = [
  {
    id: "math-1",
    name: "Sets, Relations and Functions",
    subject: "Maths",
    classLevel: "Class 11",
    weightage: 3,
    revisionDueDays: 5,
    studyTimeMinutes: 140,
    subchapters: [
      {
        id: "math-1-1",
        name: "Sets & Operations",
        topics: ["Sets & representation", "Union, intersection, complement", "Power set"]
      },
      {
        id: "math-1-2",
        name: "Relations & Functions",
        topics: ["Types of relations & equivalence relations", "One-one, into, onto functions", "Composition of functions"]
      }
    ],
    topics: [
      "Sets and their representation; Union, intersection and complement of sets",
      "Power set; Relations, type of relations, equivalence relations",
      "Functions; one-one, into and onto functions, the composition of functions"
    ],
    formulas: [
      {
        id: "f-math-1-1",
        name: "Set Inclusion-Exclusion",
        expression: "n(A ∪ B) = n(A) + n(B) - n(A ∩ B)",
        description: "Number of elements in union of two finite sets.",
        chapterId: "math-1",
        chapterName: "Sets, Relations and Functions",
        subject: "Maths",
        isBookmarked: true
      }
    ],
    notes: []
  },
  {
    id: "math-2",
    name: "Complex Numbers and Quadratic Equations",
    subject: "Maths",
    classLevel: "Class 11",
    weightage: 5,
    revisionDueDays: 2,
    studyTimeMinutes: 200,
    subchapters: [
      {
        id: "math-2-1",
        name: "Complex Numbers & Argand Plane",
        topics: ["Representation a + ib & Argand diagram", "Modulus & argument of complex number", "Triangle inequality"]
      },
      {
        id: "math-2-2",
        name: "Quadratic Equations & Roots",
        topics: ["Quadratic equations in real & complex systems", "Relation between roots and coefficients", "Nature of roots & forming quadratics"]
      }
    ],
    topics: [
      "Complex numbers as ordered pairs of reals, Argand diagram, Modulus & argument",
      "Quadratic equations solutions, Relations between roots and coefficients, Nature of roots"
    ],
    formulas: [
      {
        id: "f-math-2-1",
        name: "Quadratic Roots & Sum/Product",
        expression: "x = (-b ± √(b^2 - 4ac)) / (2a), α + β = -b/a, α β = c/a",
        description: "Roots of ax^2 + bx + c = 0 and relations.",
        chapterId: "math-2",
        chapterName: "Complex Numbers and Quadratic Equations",
        subject: "Maths",
        isBookmarked: true,
        isPinned: true
      }
    ],
    notes: []
  },
  {
    id: "math-3",
    name: "Matrices and Determinants",
    subject: "Maths",
    classLevel: "Class 12",
    weightage: 7,
    revisionDueDays: 0, // Due!
    studyTimeMinutes: 280,
    subchapters: [
      {
        id: "math-3-1",
        name: "Matrices Algebra & Types",
        topics: ["Types of matrices (Symmetric, Skew-symmetric, Orthogonal)", "Matrix addition & multiplication"]
      },
      {
        id: "math-3-2",
        name: "Determinants & Linear Systems",
        topics: ["Determinants evaluation & properties", "Adjoint & Inverse of square matrix", "Cramer's rule & System consistency"]
      }
    ],
    topics: [
      "Matrices, algebra of matrices, type of matrices, determinants of order 2 and 3",
      "Adjoint and inverse of square matrix, Test of consistency and solution of simultaneous linear equations"
    ],
    formulas: [
      {
        id: "f-math-3-1",
        name: "Adjoint Determinant Property",
        expression: "|adj(A)| = |A|^(n-1)",
        description: "Determinant of adjoint matrix of order n.",
        chapterId: "math-3",
        chapterName: "Matrices and Determinants",
        subject: "Maths",
        isBookmarked: true,
        isPinned: true
      },
      {
        id: "f-math-3-2",
        name: "Matrix Inverse",
        expression: "A^-1 = (1 / |A|) adj(A)",
        description: "Inverse of non-singular matrix A.",
        chapterId: "math-3",
        chapterName: "Matrices and Determinants",
        subject: "Maths",
        isPinned: true
      }
    ],
    notes: [
      {
        id: "n-math-3-1",
        title: "Cramer's Rule Consistency Rules",
        content: "1) Δ ≠ 0: Unique solution. 2) Δ = Δx = Δy = Δz = 0: Infinitely many solutions. 3) Δ = 0 and any Δi ≠ 0: No solution.",
        type: "revision",
        chapterId: "math-3",
        chapterName: "Matrices and Determinants",
        subject: "Maths",
        isPinned: true,
        createdAt: "2026-07-22"
      }
    ]
  },
  {
    id: "math-4",
    name: "Permutations and Combinations",
    subject: "Maths",
    classLevel: "Class 11",
    weightage: 4,
    revisionDueDays: 4,
    studyTimeMinutes: 180,
    subchapters: [
      {
        id: "math-4-1",
        name: "Fundamental Counting & Permutations",
        topics: ["Fundamental principle of counting", "Meaning of P(n,r) & arrangements"]
      },
      {
        id: "math-4-2",
        name: "Combinations & Applications",
        topics: ["Meaning of C(n,r) & selections", "Simple applications & grouping"]
      }
    ],
    topics: [
      "The fundamental principle of counting, permutations and combinations",
      "Meaning of P(n, r) and C(n, r), Simple applications"
    ],
    formulas: [
      {
        id: "f-math-4-1",
        name: "Combinations Formula",
        expression: "C(n, r) = n! / (r! (n - r)!)",
        description: "Number of ways to select r items from n distinct items.",
        chapterId: "math-4",
        chapterName: "Permutations and Combinations",
        subject: "Maths",
        isBookmarked: true
      }
    ],
    notes: []
  },
  {
    id: "math-5",
    name: "Binomial Theorem and its Simple Applications",
    subject: "Maths",
    classLevel: "Class 11",
    weightage: 5,
    revisionDueDays: 1,
    studyTimeMinutes: 200,
    subchapters: [
      {
        id: "math-5-1",
        name: "Expansion & General Term",
        topics: ["Binomial theorem for positive integral index", "General term Tr+1 & Middle term"]
      },
      {
        id: "math-5-2",
        name: "Properties of Coefficients",
        topics: ["Sum of binomial coefficients", "Remainder & divisibility problems"]
      }
    ],
    topics: [
      "Binomial theorem for a positive integral index, general term and middle term and simple applications"
    ],
    formulas: [
      {
        id: "f-math-5-1",
        name: "General Binomial Term",
        expression: "T_(r+1) = C(n, r) a^(n-r) b^r",
        description: "(r+1)th term in expansion of (a + b)^n.",
        chapterId: "math-5",
        chapterName: "Binomial Theorem and its Simple Applications",
        subject: "Maths",
        isBookmarked: true,
        isPinned: true
      }
    ],
    notes: []
  },
  {
    id: "math-6",
    name: "Sequence and Series",
    subject: "Maths",
    classLevel: "Class 11",
    weightage: 6,
    revisionDueDays: 0, // Due!
    studyTimeMinutes: 220,
    subchapters: [
      {
        id: "math-6-1",
        name: "AP & GP Progressions",
        topics: ["Arithmetic Progression (AP) & sum to n terms", "Geometric Progression (GP) & infinite GP sum"]
      },
      {
        id: "math-6-2",
        name: "Means & Special Series",
        topics: ["Insertion of AM and GM", "AM >= GM relation", "Sum of n, n^2, n^3 special series"]
      }
    ],
    topics: [
      "Arithmetic and Geometric progressions, insertion of arithmetic, geometric means",
      "Relation between A.M and G.M, Sum of special series"
    ],
    formulas: [
      {
        id: "f-math-6-1",
        name: "Infinite GP Sum",
        expression: "S_∞ = a / (1 - r)   (|r| < 1)",
        description: "Sum of converging infinite geometric progression.",
        chapterId: "math-6",
        chapterName: "Sequence and Series",
        subject: "Maths",
        isBookmarked: true,
        isPinned: true
      },
      {
        id: "f-math-6-2",
        name: "AM-GM Inequality",
        expression: "(a + b) / 2 ≥ √(a b)",
        description: "Arithmetic mean is greater than or equal to geometric mean for positive numbers.",
        chapterId: "math-6",
        chapterName: "Sequence and Series",
        subject: "Maths",
        isPinned: true
      }
    ],
    notes: []
  },
  {
    id: "math-7",
    name: "Limit, Continuity and Differentiability",
    subject: "Maths",
    classLevel: "Class 12",
    weightage: 6,
    revisionDueDays: 2,
    studyTimeMinutes: 290,
    subchapters: [
      {
        id: "math-7-1",
        name: "Limits & Continuity",
        topics: ["Limits evaluation & L'Hopital's rule", "1^∞ indeterminate limit forms", "Continuity of functions"]
      },
      {
        id: "math-7-2",
        name: "Differentiability & Applications of Derivatives",
        topics: ["Differentiability definition", "Differentiation rules (Chain, Product, Implicit)", "Rate of change, Monotonicity, Maxima & Minima"]
      }
    ],
    topics: [
      "Limits, continuity and differentiability, Differentiation of algebraic, trig, log, exp functions",
      "Derivatives of order up to two, Applications of derivatives: Rate of change, Monotonicity, Maxima and minima"
    ],
    formulas: [
      {
        id: "f-math-7-1",
        name: "1^Infinity Limit Form",
        expression: "lim [f(x)]^g(x) = e^(lim g(x) [f(x) - 1])",
        description: "Transformation trick for 1^infinity indeterminate limits.",
        chapterId: "math-7",
        chapterName: "Limit, Continuity and Differentiability",
        subject: "Maths",
        isBookmarked: true,
        isPinned: true
      }
    ],
    notes: []
  },
  {
    id: "math-8",
    name: "Integral Calculus",
    subject: "Maths",
    classLevel: "Class 12",
    weightage: 7,
    revisionDueDays: 0, // Due!
    studyTimeMinutes: 320,
    subchapters: [
      {
        id: "math-8-1",
        name: "Indefinite Integration",
        topics: ["Fundamental integrals", "Integration by substitution, parts & partial fractions"]
      },
      {
        id: "math-8-2",
        name: "Definite Integration & Area",
        topics: ["Properties of definite integrals (King's property)", "Fundamental theorem of calculus", "Area under simple curves"]
      }
    ],
    topics: [
      "Integral as anti-derivative, Integration by substitution, parts and partial fractions",
      "Properties of definite integrals, Evaluation of definite integrals, Area bounded by curves"
    ],
    formulas: [
      {
        id: "f-math-8-1",
        name: "King's Property",
        expression: "∫[a, b] f(x) dx = ∫[a, b] f(a + b - x) dx",
        description: "Definite integral property for simplification.",
        chapterId: "math-8",
        chapterName: "Integral Calculus",
        subject: "Maths",
        isBookmarked: true,
        isPinned: true
      }
    ],
    notes: []
  },
  {
    id: "math-9",
    name: "Differential Equations",
    subject: "Maths",
    classLevel: "Class 12",
    weightage: 4,
    revisionDueDays: 3,
    studyTimeMinutes: 170,
    subchapters: [
      {
        id: "math-9-1",
        name: "Order, Degree & Methods",
        topics: ["Order and degree of differential equations", "Separation of variables method", "Homogeneous & Linear differential equations dy/dx + P(x)y = Q(x)"]
      }
    ],
    topics: [
      "Ordinary differential equations, order and degree, separation of variables, homogeneous & linear differential equations"
    ],
    formulas: [
      {
        id: "f-math-9-1",
        name: "Linear Differential Integrating Factor",
        expression: "IF = e^(∫ P dx),  y × IF = ∫ (Q × IF) dx + C",
        description: "Solution formula for linear first order differential equation.",
        chapterId: "math-9",
        chapterName: "Differential Equations",
        subject: "Maths",
        isBookmarked: true
      }
    ],
    notes: []
  },
  {
    id: "math-10",
    name: "Co-ordinate Geometry",
    subject: "Maths",
    classLevel: "Class 11",
    weightage: 8,
    revisionDueDays: 1,
    studyTimeMinutes: 300,
    subchapters: [
      {
        id: "math-10-1",
        name: "Straight Lines",
        topics: ["Distance & section formula", "Forms of line equations, angle between lines", "Distance of point from line, Centroid, Orthocentre, Circumcentre"]
      },
      {
        id: "math-10-2",
        name: "Circles & Conic Sections",
        topics: ["Circle equations & tangent properties", "Parabola standard equations & focus/directrix", "Ellipse & Hyperbola standard equations"]
      }
    ],
    topics: [
      "Straight line forms, intersection, concurrence, distance of a point from line",
      "Circle standard form and general form, radii and center",
      "Conic sections: Parabola, Ellipse, Hyperbola in standard forms"
    ],
    formulas: [
      {
        id: "f-math-10-1",
        name: "Distance from Point to Line",
        expression: "d = |a x1 + b y1 + c| / √(a^2 + b^2)",
        description: "Perpendicular distance from (x1, y1) to line ax + by + c = 0.",
        chapterId: "math-10",
        chapterName: "Co-ordinate Geometry",
        subject: "Maths",
        isBookmarked: true
      }
    ],
    notes: []
  },
  {
    id: "math-11",
    name: "Three Dimensional Geometry",
    subject: "Maths",
    classLevel: "Class 12",
    weightage: 7,
    revisionDueDays: 0, // Due!
    studyTimeMinutes: 260,
    subchapters: [
      {
        id: "math-11-1",
        name: "Lines in 3D Space",
        topics: ["Direction cosines (l, m, n) & direction ratios (a, b, c)", "Equation of line in 3D (Vector & Cartesian)", "Angle between intersecting lines"]
      },
      {
        id: "math-11-2",
        name: "Skew Lines & Distances",
        topics: ["Skew lines definition", "Shortest distance between skew lines formula"]
      }
    ],
    topics: [
      "Coordinates in space, Direction ratios and direction cosines",
      "Equation of a line, Skew lines, Shortest distance between skew lines"
    ],
    formulas: [
      {
        id: "f-math-11-1",
        name: "Shortest Distance Skew Lines",
        expression: "d = |(a2 - a1) · (b1 × b2)| / |b1 × b2|",
        description: "Minimum distance between non-parallel, non-intersecting 3D lines.",
        chapterId: "math-11",
        chapterName: "Three Dimensional Geometry",
        subject: "Maths",
        isBookmarked: true,
        isPinned: true
      }
    ],
    notes: [
      {
        id: "n-math-11-1",
        title: "Direction Cosines Identity",
        content: "l^2 + m^2 + n^2 = 1 or cos^2 α + cos^2 β + cos^2 γ = 1. Vector parallel to line is b = a i^ + b j^ + c k^.",
        type: "revision",
        chapterId: "math-11",
        chapterName: "Three Dimensional Geometry",
        subject: "Maths",
        isPinned: true,
        createdAt: "2026-07-26"
      }
    ]
  },
  {
    id: "math-12",
    name: "Vector Algebra",
    subject: "Maths",
    classLevel: "Class 12",
    weightage: 5,
    revisionDueDays: 3,
    studyTimeMinutes: 190,
    subchapters: [
      {
        id: "math-12-1",
        name: "Vector Products & Operations",
        topics: ["Vectors and scalars, vector addition", "Scalar (dot) product a · b = |a||b| cosθ", "Vector (cross) product a × b"]
      }
    ],
    topics: [
      "Vectors and scalars, addition of vectors, components in 2D and 3D, scalar and vector products"
    ],
    formulas: [
      {
        id: "f-math-12-1",
        name: "Vector Cross Product",
        expression: "|a × b| = |a| |b| sinθ",
        description: "Magnitude of vector product representing area of parallelogram.",
        chapterId: "math-12",
        chapterName: "Vector Algebra",
        subject: "Maths"
      }
    ],
    notes: []
  },
  {
    id: "math-13",
    name: "Statistics and Probability",
    subject: "Maths",
    classLevel: "Class 12",
    weightage: 4,
    revisionDueDays: 5,
    studyTimeMinutes: 180,
    subchapters: [
      {
        id: "math-13-1",
        name: "Statistics",
        topics: ["Mean, median, mode", "Standard deviation & variance for grouped/ungrouped data"]
      },
      {
        id: "math-13-2",
        name: "Probability",
        topics: ["Probability of an event & addition/multiplication theorems", "Bayes' Theorem & Probability distribution of random variable"]
      }
    ],
    topics: [
      "Measures of dispersion, mean, median, mode, standard deviation and variance",
      "Probability of an event, addition & multiplication theorems, Bayes' theorem, probability distribution"
    ],
    formulas: [
      {
        id: "f-math-13-1",
        name: "Bayes' Theorem",
        expression: "P(Ai | B) = [P(B | Ai) P(Ai)] / [∑ P(B | Aj) P(Aj)]",
        description: "Conditional probability of cause given observed event B.",
        chapterId: "math-13",
        chapterName: "Statistics and Probability",
        subject: "Maths",
        isBookmarked: true
      }
    ],
    notes: []
  },
  {
    id: "math-14",
    name: "Trigonometry",
    subject: "Maths",
    classLevel: "Class 11",
    weightage: 3,
    revisionDueDays: 6,
    studyTimeMinutes: 150,
    subchapters: [
      {
        id: "math-14-1",
        name: "Identities & Inverse Trigonometry",
        topics: ["Trigonometrical identities & functions", "Inverse trigonometrical functions and their properties"]
      }
    ],
    topics: [
      "Trigonometrical identities and functions, inverse trigonometrical functions and properties"
    ],
    formulas: [
      {
        id: "f-math-14-1",
        name: "Compound Angle Sine Formula",
        expression: "sin(A ± B) = sinA cosB ± cosA sinB",
        description: "Standard trigonometric expansion identity.",
        chapterId: "math-14",
        chapterName: "Trigonometry",
        subject: "Maths"
      }
    ],
    notes: []
  }
];
