"use client";

import React, { createContext, useContext, useEffect, useState, useCallback } from "react";
import { User, Session } from "@supabase/supabase-js";
import { supabase, setActiveUserId, clearActiveUserId, clearGuestSession } from "@/lib/supabase/client";
import { userService, UserProfile } from "@/services/userService";
import { syncService } from "@/services/syncService";
import { blockerService } from "@/services/blockerService";

import { getUpcomingJeeYears } from "@/lib/jee-years";
import { getUpcomingExamYears } from "@/lib/exam-config";

interface AuthContextType {
  currentUser: User | null;
  session: Session | null;
  uid: string | null;
  userProfile: UserProfile | null;
  loading: boolean;
  login: (email: string, pass: string) => Promise<void>;
  signup: (
    email: string,
    pass: string,
    name: string,
    username?: string,
    targetExam?: string,
    country?: string,
    targetYear?: string,
    dailyGoal?: string,
    examType?: "JEE" | "NEET"
  ) => Promise<void>;
  loginWithGoogle: () => Promise<void>;
  logout: (options?: { redirect?: boolean }) => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  updatePassword: (newPassword: string) => Promise<void>;
  sendVerificationEmail: () => Promise<void>;
  loginAsGuest: () => Promise<void>;
  checkUsernameAvailability: (username: string) => Promise<boolean>;
  claimUsername: (username: string) => Promise<boolean>;
  updateProfileData: (updates: Partial<UserProfile>) => Promise<void>;
  refreshProfile: () => Promise<UserProfile | null>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  // Active auth token ref to guard against out-of-order async resolution (User A vs User B race condition)
  const activeAuthUidRef = React.useRef<string | null>(null);

  // Parse Supabase Auth errors into user-friendly messages
  const parseAuthError = (err: unknown): Error => {
    const errorObj = err as { message?: string; code?: string };
    const rawMsg = errorObj?.message || String(err);
    const lowerMsg = rawMsg.toLowerCase();
    if (lowerMsg.includes("invalid login credentials")) {
      return new Error("Invalid email or password. Please check your credentials and try again.");
    }
    if (
      lowerMsg.includes("user already registered") ||
      lowerMsg.includes("already registered") ||
      lowerMsg.includes("already exists") ||
      errorObj?.code === "user_already_exists"
    ) {
      return new Error("An account with this email already exists. Please log in instead.");
    }
    if (
      lowerMsg.includes("over_email_send_rate_limit") ||
      lowerMsg.includes("email rate limit exceeded") ||
      (errorObj?.code === "over_email_send_rate_limit")
    ) {
      return new Error("Too many reset emails requested for this address. Please wait a moment before requesting another email.");
    }
    if (
      lowerMsg.includes("over_request_rate_limit") ||
      lowerMsg.includes("too many requests") ||
      (errorObj?.code === "over_request_rate_limit")
    ) {
      return new Error("Too many requests from this network. Please wait a few moments and try again.");
    }
    if (lowerMsg.includes("rate limit")) {
      return new Error("Too many requests. Please wait a moment and try again.");
    }
    if (lowerMsg.includes("provider is not enabled") || lowerMsg.includes("sign in with google is not enabled")) {
      return new Error("Google Sign-In is not enabled on this Supabase project. Please use email & password or Guest mode.");
    }
    if (lowerMsg.includes("new password should be different")) {
      return new Error("New password should be different from your old password.");
    }
    if (lowerMsg.includes("password should be at least")) {
      return new Error("Password must be at least 8 characters long.");
    }
    if (
      lowerMsg.includes("recovery link is invalid") ||
      lowerMsg.includes("has expired") ||
      lowerMsg.includes("token has expired") ||
      lowerMsg.includes("otp expired") ||
      lowerMsg.includes("auth session missing") ||
      lowerMsg.includes("session missing")
    ) {
      return new Error("This password reset link is invalid or has expired. Please request a new one.");
    }
    return new Error(rawMsg);
  };

  const syncProfile = useCallback(async (user: User) => {
    activeAuthUidRef.current = user.id;
    try {
      setActiveUserId(user.id);
      clearGuestSession();

      const rawExamType = user.user_metadata?.exam_type as ("JEE" | "NEET" | undefined);
      const targetExamMeta = user.user_metadata?.target_exam;
      const detectedExamType = rawExamType || (targetExamMeta?.includes("NEET") ? "NEET" : "JEE");
      const upcomingYears = getUpcomingExamYears(4);
      const defaultYear = String(upcomingYears[0]);
      const defaultExam = detectedExamType === "NEET" ? `NEET UG ${defaultYear}` : `JEE Main & Advanced ${defaultYear}`;
      const defaultName = detectedExamType === "NEET" ? "NEET Aspirant" : "JEE Aspirant";

      let profile = await userService.getUserProfile(user.id);
      if (activeAuthUidRef.current !== user.id) return;

      if (!profile) {
        profile = await userService.createUserProfile({
          uid: user.id,
          displayName: user.user_metadata?.full_name || user.user_metadata?.name || user.email?.split("@")[0] || defaultName,
          email: user.email || `${user.id}@focusforge.internal`,
          photoURL: user.user_metadata?.avatar_url || `https://api.dicebear.com/7.x/bottts/svg?seed=${user.id}`,
          country: user.user_metadata?.country || "India",
          targetExam: user.user_metadata?.target_exam || defaultExam,
          targetYear: user.user_metadata?.target_year || defaultYear,
          examType: detectedExamType,
          targetExamYear: parseInt(user.user_metadata?.target_year || defaultYear, 10) || upcomingYears[0],
          syllabusVersion: detectedExamType === "NEET" ? "NMC-2026" : "NTA-2026",
          studyGoal: user.user_metadata?.daily_goal || "6 Hours Daily",
        });
      } else {
        await userService.updateUserProfile(user.id, { lastLogin: new Date().toISOString() });
      }

      if (activeAuthUidRef.current !== user.id) return;
      setUserProfile(profile);

      // Hydrate all user sessions, mistakes, streaks, and syllabus progress cleanly
      await syncService.hydrateUserData(user.id);

      if (activeAuthUidRef.current !== user.id) return;

      // Notify Chrome Extension of authenticated user with complete Supabase session
      if (typeof window !== "undefined") {
        const { data: { session: activeSession } } = await supabase.auth.getSession();
        broadcastSessionToExtension(activeSession);
      }
    } catch (err) {
      console.warn("Could not sync user profile from Supabase, using local session state:", err);
    } finally {
      if (activeAuthUidRef.current === user.id) {
        setLoading(false);
      }
    }
  }, []);

  function broadcastSessionToExtension(activeSession: Session | null) {
    if (typeof window === "undefined") return;
    if (activeSession?.user) {
      window.postMessage(
        {
          type: "FOCUSFORGE_AUTH_SESSION",
          session: {
            access_token: activeSession.access_token,
            refresh_token: activeSession.refresh_token,
            expires_at: activeSession.expires_at,
            expires_in: activeSession.expires_in,
            token_type: activeSession.token_type,
            user: {
              id: activeSession.user.id,
              email: activeSession.user.email,
            },
          },
        },
        "*"
      );
      window.postMessage(
        {
          type: "FOCUSFORGE_AUTH",
          userId: activeSession.user.id,
          email: activeSession.user.email,
        },
        "*"
      );
    } else {
      window.postMessage({ type: "FOCUSFORGE_AUTH_LOGOUT" }, "*");
      window.postMessage({ type: "FOCUSFORGE_LOGOUT" }, "*");
    }
  }

  const handleGuestFallback = useCallback(() => {
    const localExamType = ((typeof window !== "undefined" ? localStorage.getItem("focusforge_exam_type") : null) || "JEE") as "JEE" | "NEET";
    const upcomingYears = getUpcomingExamYears(4);
    const defaultYear = String(upcomingYears[0]);
    const defaultExam = localExamType === "NEET" ? `NEET UG ${defaultYear}` : `JEE Main & Advanced ${defaultYear}`;
    const defaultSubject = localExamType === "NEET" ? "Botany" : "Physics";

    const localGuest = typeof window !== "undefined" ? localStorage.getItem("focusforge_guest_uid") : null;
    if (localGuest) {
      const guestProfile: UserProfile = {
        uid: localGuest,
        username: `@guest_${localGuest.slice(0, 6)}`,
        displayName: localExamType === "NEET" ? "Guest NEET Aspirant" : "Guest JEE Aspirant",
        email: `guest_${localGuest.slice(0, 6)}@focusforge.app`,
        photoURL: `https://api.dicebear.com/7.x/bottts/svg?seed=${localGuest}`,
        theme: "dark",
        targetExam: defaultExam,
        targetYear: defaultYear,
        examType: localExamType,
        targetExamYear: upcomingYears[0],
        syllabusVersion: localExamType === "NEET" ? "NMC-2026" : "NTA-2026",
        studyGoal: "6 Hours Daily",
        joinedAt: new Date().toISOString(),
        lastLogin: new Date().toISOString(),
        bio: localExamType === "NEET"
          ? "NEET UG medical aspirant working towards AIIMS Delhi."
          : "IIT-JEE Main & Advanced aspirant working towards rank 1.",
        timezone: "Asia/Kolkata",
        country: "India",
        preferences: { defaultSubject, autoBlock: true, monkModeDefault: false },
        streak: 0,
        xp: 0,
        level: 1,
        extensionConnected: false,
        browserName: "Chrome Desktop",
        deviceName: localExamType === "NEET" ? "NEET Medical Workstation" : "IIT-JEE Workstation",
        notificationSettings: { email: true, browser: true, sound: true },
        privacySettings: { publicProfile: true, showStreak: true },
        statistics: { totalFocusMinutes: 0, completedSessions: 0, mistakesLogged: 0, formulasBookmarked: 0 },
      };
      setUserProfile(guestProfile);
    } else {
      setUserProfile(null);
    }
  }, []);

  // Real-time cross-tab profile synchronization listener
  useEffect(() => {
    const handleRealtimeProfileUpdate = (e: Event) => {
      const customEvent = e as CustomEvent<Record<string, unknown>>;
      const updated = customEvent.detail;
      if (!updated) return;

      setUserProfile((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          displayName: (updated.display_name as string) ?? prev.displayName,
          username: (updated.username as string) ?? prev.username,
          bio: (updated.bio as string) ?? prev.bio,
          country: (updated.country as string) ?? prev.country,
          targetExam: (updated.target_exam as string) ?? prev.targetExam,
          targetYear: (updated.target_year as string) ?? prev.targetYear,
          examType: (updated.exam_type as "JEE" | "NEET") ?? prev.examType,
          targetExamYear: (updated.target_exam_year as number) ?? prev.targetExamYear,
          syllabusVersion: (updated.syllabus_version as string) ?? prev.syllabusVersion,
          studyGoal: (updated.daily_goal as string) ?? prev.studyGoal,
          streak: Number(updated.streak ?? prev.streak),
          xp: Number(updated.xp ?? prev.xp),
          level: Number(updated.level ?? prev.level),
        };
      });
    };

    if (typeof window !== "undefined") {
      window.addEventListener("focusforge_profile_updated", handleRealtimeProfileUpdate);
    }
    return () => {
      if (typeof window !== "undefined") {
        window.removeEventListener("focusforge_profile_updated", handleRealtimeProfileUpdate);
      }
    };
  }, []);

  useEffect(() => {
    // 1. Initial Session Hydration
    supabase.auth.getSession().then(({ data: { session: activeSession } }) => {
      setSession(activeSession);
      broadcastSessionToExtension(activeSession);
      const user = activeSession?.user || null;
      setCurrentUser(user);
      if (user) {
        activeAuthUidRef.current = user.id;
        syncProfile(user);
      } else {
        activeAuthUidRef.current = null;
        handleGuestFallback();
        setLoading(false);
      }
    });

    // 2. Real-time Supabase Auth Listener
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, newSession) => {
      setSession(newSession);
      broadcastSessionToExtension(newSession);
      const user = newSession?.user || null;

      // Handle user logout / isolation
      if (event === "SIGNED_OUT" || !user) {
        activeAuthUidRef.current = null;
        syncService.handleUserLogout();
        setCurrentUser(null);
        setUserProfile(null);
        handleGuestFallback();
        setLoading(false);
        return;
      }

      // Check if user account changed (User A logged out, User B logged in)
      const prevSyncedId = syncService.getCurrentSyncedUserId();
      if (prevSyncedId && prevSyncedId !== user.id) {
        syncService.handleUserLogout();
        setUserProfile(null);
      }

      activeAuthUidRef.current = user.id;
      setCurrentUser(user);
      await syncProfile(user);
    });

    // 3. Extension handshake listener: respond when extension requests active auth session
    const handleExtensionHandshake = async (event: MessageEvent) => {
      if (event.data?.type === "FOCUSFORGE_REQUEST_AUTH_SESSION") {
        const { data: { session: curSession } } = await supabase.auth.getSession();
        broadcastSessionToExtension(curSession);
      }
    };

    if (typeof window !== "undefined") {
      window.addEventListener("message", handleExtensionHandshake);
    }

    // 4. Multi-tab storage & BroadcastChannel logout listener
    const handleStorage = (e: StorageEvent) => {
      if (e.key === "focusforge_active_uid" && !e.newValue) {
        activeAuthUidRef.current = null;
        syncService.handleUserLogout();
        setCurrentUser(null);
        setSession(null);
        setUserProfile(null);
        if (
          typeof window !== "undefined" &&
          !window.location.pathname.startsWith("/login") &&
          !window.location.pathname.startsWith("/reset-password")
        ) {
          window.location.href = "/login?reason=multi_tab_logout";
        }
      }
    };

    let authChannel: BroadcastChannel | null = null;
    if (typeof window !== "undefined" && "BroadcastChannel" in window) {
      try {
        authChannel = new BroadcastChannel("focusforge_auth_channel");
        authChannel.onmessage = (event) => {
          if (event.data?.type === "LOGOUT") {
            activeAuthUidRef.current = null;
            syncService.handleUserLogout();
            setCurrentUser(null);
            setSession(null);
            setUserProfile(null);
            if (
              typeof window !== "undefined" &&
              !window.location.pathname.startsWith("/login") &&
              !window.location.pathname.startsWith("/reset-password")
            ) {
              window.location.href = "/login?reason=multi_tab_logout";
            }
          }
        };
      } catch {}
    }

    if (typeof window !== "undefined") {
      window.addEventListener("storage", handleStorage);
    }

    return () => {
      subscription.unsubscribe();
      if (typeof window !== "undefined") {
        window.removeEventListener("storage", handleStorage);
        window.removeEventListener("message", handleExtensionHandshake);
      }
      if (authChannel) {
        try {
          authChannel.close();
        } catch {}
      }
    };
  }, [syncProfile, handleGuestFallback]);

  const login = async (email: string, pass: string) => {
    setLoading(true);
    try {
      const normalizedEmail = email.trim().toLowerCase();
      if (!normalizedEmail) {
        throw new Error("Please enter your email address.");
      }

      const { data, error } = await supabase.auth.signInWithPassword({
        email: normalizedEmail,
        password: pass,
      });
      if (error) throw error;
      if (data.user) {
        activeAuthUidRef.current = data.user.id;
        setActiveUserId(data.user.id);
        await syncProfile(data.user);
      }
    } catch (err) {
      throw parseAuthError(err);
    } finally {
      setLoading(false);
    }
  };

  const signup = async (
    email: string,
    pass: string,
    name: string,
    customUsername?: string,
    targetExam?: string,
    country = "India",
    targetYear?: string,
    dailyGoal = "6 Hours Daily",
    examType?: "JEE" | "NEET"
  ): Promise<void> => {
    setLoading(true);
    try {
      const normalizedEmail = email.trim().toLowerCase();
      if (!normalizedEmail || !normalizedEmail.includes("@")) {
        throw new Error("Please enter a valid email address.");
      }

      const effectiveExamType: "JEE" | "NEET" = examType || (targetExam?.includes("NEET") ? "NEET" : "JEE");
      const upcomingYears = getUpcomingExamYears(4);
      const effectiveYear = targetYear || String(upcomingYears[0]);
      const effectiveExam = targetExam || (effectiveExamType === "NEET" ? `NEET UG ${effectiveYear}` : `JEE Main & Advanced ${effectiveYear}`);

      const cleanUsername = customUsername
        ? customUsername.replace(/^@/, "").toLowerCase().trim()
        : normalizedEmail.split("@")[0].replace(/[^a-z0-9_]/g, "");

      // 1. Attempt normal Supabase Auth signup
      const { data, error } = await supabase.auth.signUp({
        email: normalizedEmail,
        password: pass,
        options: {
          data: {
            full_name: name.trim() || normalizedEmail.split("@")[0],
            username: cleanUsername,
            country: country || "India",
            target_exam: effectiveExam,
            target_year: effectiveYear,
            exam_type: effectiveExamType,
            target_exam_year: parseInt(effectiveYear, 10) || upcomingYears[0],
            daily_goal: dailyGoal || "6 Hours Daily",
          },
        },
      });

      // 2. Catch Supabase errors indicating user already registered
      if (error) {
        const lower = (error.message || "").toLowerCase();
        if (
          lower.includes("user already registered") ||
          lower.includes("already registered") ||
          lower.includes("already exists") ||
          (error as { code?: string })?.code === "user_already_exists"
        ) {
          throw new Error("An account with this email already exists. Please log in instead.");
        }
        throw parseAuthError(error);
      }

      // 3. Detect Supabase returning an obfuscated user with empty identities (when email already exists)
      if (data?.user && Array.isArray(data.user.identities) && data.user.identities.length === 0) {
        throw new Error("An account with this email already exists. Please log in instead.");
      }

      // 4. Ensure an active session is established immediately
      let activeUser = data?.user || null;
      let activeSession = data?.session || null;

      if (!activeSession && activeUser) {
        // Fallback: If signup response did not include session, sign in immediately with credentials
        const { data: signInData, error: signInError } = await supabase.auth.signInWithPassword({
          email: normalizedEmail,
          password: pass,
        });
        if (signInError) {
          throw parseAuthError(signInError);
        }
        activeSession = signInData.session;
        activeUser = signInData.user;
      }

      if (!activeUser) {
        throw new Error("Account creation failed. Please check your credentials and try again.");
      }

      // 5. Active session established immediately: bootstrap profile & hydrate
      activeAuthUidRef.current = activeUser.id;
      setActiveUserId(activeUser.id);

      const profile = await userService.createUserProfile({
        uid: activeUser.id,
        username: `@${cleanUsername}`,
        displayName: name.trim() || normalizedEmail.split("@")[0],
        email: normalizedEmail,
        country: country || "India",
        targetExam: effectiveExam,
        targetYear: effectiveYear,
        examType: effectiveExamType,
        targetExamYear: parseInt(effectiveYear, 10) || upcomingYears[0],
        syllabusVersion: effectiveExamType === "NEET" ? "NMC-2026" : "NTA-2026",
        studyGoal: dailyGoal || "6 Hours Daily",
      });

      setUserProfile(profile);

      // Seed the 15 default blocked domains for newly created account
      await blockerService.seedDefaultBlockedSites(activeUser.id).catch((err) =>
        console.warn("[AuthContext] Blocker seeding warning:", err)
      );

      await syncService.hydrateUserData(activeUser.id);

      if (typeof window !== "undefined") {
        broadcastSessionToExtension(activeSession);
      }
    } catch (err) {
      throw parseAuthError(err);
    } finally {
      setLoading(false);
    }
  };

  const loginWithGoogle = async () => {
    setLoading(true);
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider: "google",
        options: {
          redirectTo: typeof window !== "undefined" ? `${window.location.origin}/dashboard` : undefined,
        },
      });
      if (error) throw error;
    } catch (err) {
      throw parseAuthError(err);
    } finally {
      setLoading(false);
    }
  };

  const loginAsGuest = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.auth.signInAnonymously();
      if (error || !data.user) {
        throw error || new Error("Anonymous auth unavailable");
      }
      const profile = await userService.createUserProfile({
        uid: data.user.id,
        displayName: "Guest Aspirant",
        email: `guest_${data.user.id.slice(0, 6)}@focusforge.app`,
      });
      setUserProfile(profile);
    } catch {
      console.warn("Supabase Anonymous auth fallback to local guest session.");
      const fallbackUid = `guest_${Date.now()}`;
      if (typeof window !== "undefined") {
        localStorage.setItem("focusforge_guest_uid", fallbackUid);
      }
      const guestProfile = await userService.createUserProfile({
        uid: fallbackUid,
        displayName: "Guest Aspirant",
        email: `guest_${fallbackUid.slice(0, 6)}@focusforge.app`,
      });
      setUserProfile(guestProfile);
    } finally {
      setLoading(false);
    }
  };

  const logout = async (options?: { redirect?: boolean }) => {
    try {
      setLoading(true);
      activeAuthUidRef.current = null;

      // 1. Invalidate HTTP cookies on server
      await fetch("/api/auth/logout", {
        method: "POST",
        credentials: "include",
      }).catch(() => {});

      // 2. Clear client Supabase GoTrue session
      await supabase.auth.signOut({ scope: "local" }).catch(() => {});

      // 3. Clear local storage & tokens
      clearActiveUserId();

      if (typeof window !== "undefined") {
        window.postMessage({ type: "FOCUSFORGE_LOGOUT" }, "*");

        // Notify other tabs via BroadcastChannel
        try {
          if ("BroadcastChannel" in window) {
            const channel = new BroadcastChannel("focusforge_auth_channel");
            channel.postMessage({ type: "LOGOUT" });
            channel.close();
          }
        } catch {}

        localStorage.removeItem("focusforge_active_uid");
        localStorage.removeItem("focusforge_guest_uid");
        localStorage.removeItem("focusforge-study-storage");
        localStorage.removeItem("focusforge-mistakes-storage");

        // Purge any orphaned or user-scoped local storage tokens
        for (let i = localStorage.length - 1; i >= 0; i--) {
          const key = localStorage.key(i);
          if (
            key &&
            (key.startsWith("sb-") ||
              key.includes("supabase.auth.token") ||
              key.startsWith("focusforge_study_") ||
              key.startsWith("focusforge_mistakes_"))
          ) {
            localStorage.removeItem(key);
          }
        }
      }

      // 4. Reset sync service and all Zustand stores
      syncService.handleUserLogout();
      setCurrentUser(null);
      setSession(null);
      setUserProfile(null);

      // 5. Clean redirect to login page
      if (options?.redirect !== false && typeof window !== "undefined") {
        window.location.href = "/login?logged_out=true";
      }
    } finally {
      setLoading(false);
    }
  };

  const resetPassword = async (email: string) => {
    try {
      const normalizedEmail = email.trim().toLowerCase();
      if (!normalizedEmail || !normalizedEmail.includes("@")) {
        throw new Error("Please enter a valid email address.");
      }

      const defaultSiteUrl =
        process.env.NEXT_PUBLIC_SITE_URL || "https://jee-made-easy-by-ilham.vercel.app";
      const origin =
        typeof window !== "undefined" && window.location.origin
          ? window.location.origin
          : defaultSiteUrl;

      const { error } = await supabase.auth.resetPasswordForEmail(normalizedEmail, {
        redirectTo: `${origin}/reset-password`,
      });
      if (error) throw error;
    } catch (err) {
      throw parseAuthError(err);
    }
  };

  const updatePassword = async (newPassword: string) => {
    try {
      const { error } = await supabase.auth.updateUser({
        password: newPassword,
      });
      if (error) throw error;
    } catch (err) {
      throw parseAuthError(err);
    }
  };

  const sendVerificationEmail = async () => {
    if (currentUser?.email) {
      await supabase.auth.resend({
        type: "signup",
        email: currentUser.email,
      });
    }
  };

  const checkUsernameAvailability = useCallback(async (username: string) => {
    return userService.checkUsernameAvailability(username);
  }, []);

  const claimUsername = async (username: string) => {
    const effectiveUid = currentUser?.id || userProfile?.uid;
    if (!effectiveUid) return false;
    const success = await userService.claimUsername(effectiveUid, username);
    if (success && userProfile) {
      const updated = { ...userProfile, username: `@${username.replace(/^@/, "").toLowerCase()}` };
      setUserProfile(updated);
    }
    return success;
  };

  const updateProfileData = async (updates: Partial<UserProfile>) => {
    const effectiveUid = currentUser?.id || userProfile?.uid;
    if (!effectiveUid) return;
    await userService.updateUserProfile(effectiveUid, updates);
    if (userProfile) {
      setUserProfile({ ...userProfile, ...updates });
    }
  };

  const refreshProfile = useCallback(async (): Promise<UserProfile | null> => {
    const effectiveUid = currentUser?.id || userProfile?.uid;
    if (!effectiveUid || effectiveUid.startsWith("guest")) return null;
    try {
      const fresh = await userService.getUserProfile(effectiveUid);
      if (fresh) {
        setUserProfile(fresh);
      }
      return fresh;
    } catch {
      return null;
    }
  }, [currentUser?.id, userProfile?.uid]);

  const effectiveUid = currentUser?.id || userProfile?.uid || null;

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        session,
        uid: effectiveUid,
        userProfile,
        loading,
        login,
        signup,
        loginWithGoogle,
        logout,
        resetPassword,
        updatePassword,
        sendVerificationEmail,
        loginAsGuest,
        checkUsernameAvailability,
        claimUsername,
        updateProfileData,
        refreshProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
