"use client";

import { useState, useRef } from "react";
import Link from "next/link";
import { Zap, Shield, BookOpen, Bot, ArrowRight, Sparkles, Download, Puzzle, CheckCircle2, HelpCircle, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button, Carousel } from "@/components/ui/controls";
import { ScrollCue } from "@/components/ui/scroll-cue";
import { gsap, useGSAP, CustomEase } from "@/lib/gsap";
import { Magnetic } from "@/components/ui/magnetic";
import { soundManager } from "@/lib/sound-manager";
import { downloadExtension, EXTENSION_FILENAME } from "@/lib/extension-download";

export default function Home() {
  const [showGuideModal, setShowGuideModal] = useState(false);
  const [showReleaseModal, setShowReleaseModal] = useState(false);

  const containerRef = useRef<HTMLDivElement>(null);

  useGSAP(
    () => {
      CustomEase.create("focusEase", "0.16, 1, 0.3, 1");

      const mm = gsap.matchMedia();
      mm.add("(prefers-reduced-motion: no-preference)", () => {
        const tl = gsap.timeline({ defaults: { ease: "focusEase" } });

        tl.from(".gsap-badge", {
          opacity: 0,
          y: -16,
          scale: 0.94,
          duration: 0.7,
        })
          .from(
            ".gsap-headline",
            {
              opacity: 0,
              y: 35,
              duration: 0.9,
            },
            "-=0.4"
          )
          .from(
            ".gsap-sub",
            {
              opacity: 0,
              y: 20,
              duration: 0.7,
            },
            "-=0.5"
          )
          .from(
            ".gsap-author",
            {
              opacity: 0,
              y: 12,
              duration: 0.5,
            },
            "-=0.4"
          )
          .from(
            ".gsap-ctas",
            {
              opacity: 0,
              y: 22,
              duration: 0.7,
            },
            "-=0.4"
          )
          .from(
            ".gsap-scroll-cue",
            {
              opacity: 0,
              y: 16,
              duration: 0.6,
              clearProps: "transform,opacity",
            },
            "-=0.3"
          );

        // ScrollTrigger for extension card showcase
        gsap.from(".gsap-extension-card", {
          scrollTrigger: {
            trigger: ".gsap-extension-card",
            start: "top 85%",
            toggleActions: "play none none reverse",
          },
          opacity: 0,
          y: 35,
          duration: 0.85,
          ease: "focusEase",
        });

        // ScrollTrigger for feature tour
        gsap.from(".gsap-feature-tour", {
          scrollTrigger: {
            trigger: ".gsap-feature-tour",
            start: "top 85%",
            toggleActions: "play none none reverse",
          },
          opacity: 0,
          y: 40,
          duration: 0.9,
          ease: "focusEase",
        });
      });
    },
    { scope: containerRef }
  );

  return (
    <div ref={containerRef} className="flex flex-col min-h-screen bg-[#08090d] text-foreground relative overflow-hidden font-sans selection:bg-purple-500/30 selection:text-purple-200">
      {/* Background ambient glow */}
      <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] rounded-full bg-purple-600/10 blur-[140px] pointer-events-none" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] rounded-full bg-blue-600/10 blur-[140px] pointer-events-none" />
      <div className="absolute top-[40%] right-[20%] w-[35%] h-[35%] rounded-full bg-emerald-500/5 blur-[120px] pointer-events-none" />

      {/* Navbar */}
      <header className="max-w-6xl w-full mx-auto flex items-center justify-between px-6 h-20 relative z-10">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-purple-500/10 border border-purple-500/20 text-purple-400">
            <Zap className="w-5 h-5 fill-purple-500/20" />
          </div>
          <span className="text-xl font-extrabold tracking-tight bg-gradient-to-r from-purple-400 via-indigo-300 to-blue-400 bg-clip-text text-transparent">
            FocusForge
          </span>
        </div>
        <div className="flex items-center gap-3">
          <Button
            variant="secondary"
            size="sm"
            className="hidden sm:flex items-center gap-1.5 font-semibold cursor-pointer border-purple-500/30 hover:border-purple-400 bg-purple-500/10 hover:bg-purple-500/20 text-purple-200 hover:text-white transition-all shadow-sm"
            onClick={() => {
              soundManager.play("start");
              downloadExtension();
            }}
          >
            <Download className="w-4 h-4 text-purple-400" />
            Install Extension
          </Button>
          <Magnetic strength={0.15}>
            <Link href="/dashboard">
              <Button variant="primary" size="sm" className="font-semibold">
                Enter Workspace
              </Button>
            </Link>
          </Magnetic>
        </div>
      </header>

      {/* Hero Section */}
      <main className="flex-1 flex flex-col items-center justify-center max-w-5xl mx-auto px-6 text-center py-16 relative z-10">
        <div className="space-y-6 w-full">
          <div className="gsap-badge inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-purple-500/20 bg-purple-500/10 text-xs font-semibold text-purple-300 shadow-sm backdrop-blur-md">
            <Sparkles className="w-3.5 h-3.5 text-purple-400 animate-pulse" />
            Empowering serious IIT-JEE & competitive aspirants
          </div>

          <h1 className="gsap-headline text-3xl sm:text-5xl md:text-6xl font-black leading-tight tracking-tight bg-gradient-to-b from-white via-gray-100 to-gray-400 bg-clip-text text-transparent">
            The Study Operating System <br />
            For Competitive Exams.
          </h1>

          <p className="gsap-sub max-w-2xl mx-auto text-base md:text-lg text-gray-400 leading-relaxed font-normal">
            Stop raw willpower battles. FocusForge hardwires discipline into your workflow. Track sessions, log mistakes, plan spaced repetitions, block distractions, and unlock IIT-JEE goals.
          </p>

          <p className="gsap-author text-xs md:text-sm text-purple-400 font-semibold tracking-wide">
            Developed by <Link href="https://github.com/ilham786" className="underline decoration-purple-400/30 hover:text-white transition-colors">ILHAM FAROOQUE</Link>
          </p>

          <div className="gsap-ctas pt-4 flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Magnetic strength={0.25}>
              <Link href="/login">
                <Button size="lg" className="w-52 shadow-xl shadow-purple-950/40">
                  Launch Workspace <ArrowRight className="w-4 h-4 ml-1" />
                </Button>
              </Link>
            </Magnetic>
            <Magnetic strength={0.25}>
              <Button
                variant="secondary"
                size="lg"
                className="w-56 cursor-pointer border-purple-500/30 hover:border-purple-400 bg-purple-500/5 hover:bg-purple-500/15 shadow-xl shadow-purple-950/25 transition-all text-white font-semibold"
                onClick={() => {
                  soundManager.play("start");
                  downloadExtension();
                }}
              >
                <Download className="w-4 h-4 text-cyan-400" />
                Install Extension
              </Button>
            </Magnetic>
          </div>
        </div>

        {/* Focus Forge Modern Scroll Suggestion Cue */}
        <div className="gsap-scroll-cue w-full flex justify-center pt-8 pb-1 min-h-[76px]">
          <ScrollCue targetId="extension-showcase" label="Scroll to discover" />
        </div>

        {/* Chrome Extension Download Card Showcase */}
        <section id="extension-showcase" className="gsap-extension-card w-full mt-4 sm:mt-6 max-w-3xl mx-auto scroll-mt-24">
          <Card variant="glass" className="p-6 text-left border-purple-500/20 bg-purple-500/5 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/[0.08] pb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400 shrink-0">
                  <Puzzle className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
                    FocusForge Companion Extension
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                      v1.2.0 Verified PKZip
                    </span>
                  </h3>
                  <p className="text-xs text-gray-400">Desktop browser enforcement, distraction tracking, and focus shield.</p>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <Button
                  variant="primary"
                  size="sm"
                  className="cursor-pointer text-xs shadow-md shadow-purple-950/40 hover:shadow-purple-900/50 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-semibold transition-all"
                  onClick={() => {
                    soundManager.play("start");
                    downloadExtension();
                  }}
                >
                  <Download className="w-3.5 h-3.5" /> Install Extension
                </Button>
                <Button
                  onClick={() => {
                    soundManager.play("open");
                    setShowGuideModal(true);
                  }}
                  variant="ghost"
                  size="sm"
                  className="cursor-pointer text-xs"
                >
                  <HelpCircle className="w-3.5 h-3.5" /> Guide
                </Button>
                <Button
                  onClick={() => {
                    soundManager.play("open");
                    setShowReleaseModal(true);
                  }}
                  variant="ghost"
                  size="sm"
                  className="cursor-pointer text-xs"
                >
                  Release Notes
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
              <div className="p-2.5 rounded-lg bg-white/[0.03] border border-white/[0.06] space-y-0.5">
                <span className="text-[10px] text-gray-500 block uppercase font-semibold">Version</span>
                <span className="font-bold text-purple-300">v1.2.0 Stable</span>
              </div>
              <div className="p-2.5 rounded-lg bg-white/[0.03] border border-white/[0.06] space-y-0.5">
                <span className="text-[10px] text-gray-500 block uppercase font-semibold">File Size</span>
                <span className="font-bold text-cyan-300">~110 KB</span>
              </div>
              <div className="p-2.5 rounded-lg bg-white/[0.03] border border-white/[0.06] space-y-0.5">
                <span className="text-[10px] text-gray-500 block uppercase font-semibold">Latest Update</span>
                <span className="font-bold text-white">September 2026</span>
              </div>
              <div className="p-2.5 rounded-lg bg-white/[0.03] border border-white/[0.06] space-y-0.5">
                <span className="text-[10px] text-gray-500 block uppercase font-semibold">Supported</span>
                <span className="font-bold text-emerald-400">Chrome, Edge, Brave</span>
              </div>
            </div>
          </Card>
        </section>

        {/* Feature Carousel Section */}
        <section className="gsap-feature-tour w-full mt-16 max-w-4xl mx-auto">
          <div className="text-center mb-6">
            <span className="text-xs font-bold text-purple-400 uppercase tracking-widest block mb-1">
              Interactive Feature Tour
            </span>
            <h2 className="text-2xl font-bold text-white tracking-tight">
              Built Specifically for IIT-JEE Main & Advanced Mastery
            </h2>
          </div>

          <Carousel
            ariaLabel="FocusForge core features"
            slides={[
              {
                id: 1,
                content: (
                  <Card variant="glass" className="text-left space-y-4 p-8 border-purple-500/20 bg-purple-500/5">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-2xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400 shadow-inner">
                        <Shield className="w-6 h-6" />
                      </div>
                      <div>
                        <span className="text-xs text-purple-400 font-semibold uppercase tracking-wider block">Module 01</span>
                        <h3 className="text-xl font-bold text-white tracking-tight">Monk Mode Blocker & Distraction Shield</h3>
                      </div>
                    </div>
                    <p className="text-sm text-gray-300 leading-relaxed">
                      Isolate distracting websites and social media platforms completely. Monk Mode hides all navigation bars, counters, and charts to leave only your focus timer.
                    </p>
                  </Card>
                ),
              },
              {
                id: 2,
                content: (
                  <Card variant="glass" className="text-left space-y-4 p-8 border-blue-500/20 bg-blue-500/5">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-2xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400 shadow-inner">
                        <BookOpen className="w-6 h-6" />
                      </div>
                      <div>
                        <span className="text-xs text-blue-400 font-semibold uppercase tracking-wider block">Module 02</span>
                        <h3 className="text-xl font-bold text-white tracking-tight">Spaced Repetition Mistake Journal</h3>
                      </div>
                    </div>
                    <p className="text-sm text-gray-300 leading-relaxed">
                      Log your conceptual errors, silly calculation mistakes, or time-pressure slips. The SuperMemo-2 algorithm automatically queues mistakes for review at 1, 3, 7, 15, and 30-day intervals.
                    </p>
                  </Card>
                ),
              },
              {
                id: 3,
                content: (
                  <Card variant="glass" className="text-left space-y-4 p-8 border-emerald-500/20 bg-emerald-500/5">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 shadow-inner">
                        <Bot className="w-6 h-6" />
                      </div>
                      <div>
                        <span className="text-xs text-emerald-400 font-semibold uppercase tracking-wider block">Module 03</span>
                        <h3 className="text-xl font-bold text-white tracking-tight">Adaptive Heuristic AI Study Coach</h3>
                      </div>
                    </div>
                    <p className="text-sm text-gray-300 leading-relaxed">
                      Consult your AI coach to identify weak topics across Physics, Chemistry, and Mathematics, calculate burnout risk scores, and project syllabus completion targets.
                    </p>
                  </Card>
                ),
              },
            ]}
          />
        </section>
      </main>

      {/* Footer */}
      <footer className="h-16 border-t border-white/[0.06] flex items-center justify-center px-6 relative z-10 bg-[#08090d]">
        <p className="text-xs text-gray-500 font-medium">
          FocusForge &copy; 2026. Built for serious aspirants. Developed by <Link href="https://github.com/ilham786" className="underline hover:text-white transition-colors">ILHAM FAROOQUE</Link>.
        </p>
      </footer>

      {/* Installation Guide Modal */}
      <AnimatePresence>
        {showGuideModal && (
          <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-gray-950 border border-gray-800 p-6 sm:p-8 rounded-2xl max-w-md w-full space-y-5 shadow-2xl"
            >
              <div className="flex items-center justify-between border-b border-gray-800 pb-3">
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <Puzzle className="w-5 h-5 text-purple-400" /> Chrome Extension Setup
                </h3>
                <button onClick={() => setShowGuideModal(false)} className="text-gray-400 hover:text-white p-1">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <ol className="space-y-3 text-xs text-gray-300 list-decimal list-inside leading-relaxed font-mono">
                <li>Click <strong className="text-purple-300">&quot;Install Extension&quot;</strong> to download the ZIP archive.</li>
                <li>Extract the downloaded <strong className="text-white">{EXTENSION_FILENAME}</strong> folder.</li>
                <li>Open your browser and navigate to <strong className="text-cyan-300">chrome://extensions</strong>.</li>
                <li>Enable <strong className="text-amber-300">Developer Mode</strong> toggle in the top right.</li>
                <li>Click <strong className="text-emerald-300">&quot;Load Unpacked&quot;</strong> button.</li>
                <li>Select the extracted folder.</li>
                <li>Done! The extension auto-connects to your active session.</li>
              </ol>

              <div className="pt-2">
                <Button
                  onClick={() => {
                    soundManager.play("close");
                    setShowGuideModal(false);
                  }}
                  variant="primary"
                  size="md"
                  className="w-full cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" /> Got It!
                </Button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Release Notes Modal */}
      <AnimatePresence>
        {showReleaseModal && (
          <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-gray-950 border border-gray-800 p-6 sm:p-8 rounded-2xl max-w-lg w-full space-y-4 shadow-2xl"
            >
              <div className="flex items-center justify-between border-b border-gray-800 pb-3">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-purple-400" />
                  <h3 className="text-base sm:text-lg font-bold text-white">Release Notes</h3>
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-purple-500/20 text-purple-300 border border-purple-500/30">
                    v1.2.0
                  </span>
                </div>
                <button
                  onClick={() => {
                    soundManager.play("close");
                    setShowReleaseModal(false);
                  }}
                  className="text-gray-400 hover:text-white p-1 rounded-lg hover:bg-white/5 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="max-h-[60vh] overflow-y-auto pr-1 space-y-3.5 text-xs text-gray-300 leading-relaxed custom-scrollbar">
                {/* v1.2.0 */}
                <div className="p-3.5 rounded-xl bg-purple-500/10 border border-purple-500/25 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-purple-300 flex items-center gap-1.5 font-mono">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                      v1.2.0 (Current Release)
                    </span>
                    <span className="text-[10px] text-gray-400 font-mono">Sept 2026</span>
                  </div>
                  <ul className="space-y-1.5 text-gray-300 list-disc list-inside text-[11px] leading-relaxed">
                    <li><strong className="text-white">YouTube Study Guard (DNR Session Rules):</strong> Hard request & navigation layer enforcement via Chrome Manifest V3 Declarative Net Request session rules. No cosmetic DOM-only bypasses.</li>
                    <li><strong className="text-white">Three-Tier Priority Architecture:</strong> Priority 2000 (exact approved educational video allow) overrides Priority 1500 (surface blocks on Shorts/Home/Search/Feed) and Priority 1000 (general watch protection).</li>
                    <li><strong className="text-white">Zero Subresource Blocking:</strong> Scripts, styles, fonts, playback APIs, and video stream chunks from googlevideo.com and youtube.com remain 100% unblocked for 4K/1080p lectures.</li>
                    <li><strong className="text-white">Master Invariant 5-Point Gate:</strong> YouTube Guard is active only with an authenticated, verified study session lease. Fails open (100% normal YouTube) during breaks, pauses, or outside study sessions.</li>
                    <li><strong className="text-white">Block Page Auto-Verification:</strong> Intercepted educational links are automatically verified against syllabus topics and seamlessly unlocked.</li>
                  </ul>
                </div>

                {/* v1.1.0 */}
                <div className="p-3 rounded-xl bg-white/[0.02] border border-white/[0.06] space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-cyan-300 font-mono">v1.1.0</span>
                    <span className="text-[10px] text-gray-500 font-mono">Sept 2026</span>
                  </div>
                  <ul className="space-y-1 text-gray-400 list-disc list-inside text-[11px] leading-relaxed">
                    <li><strong className="text-gray-300">Continuous Session Architecture:</strong> Decoupled Control Plane from Telemetry Plane; sync never resets timers.</li>
                    <li><strong className="text-gray-300">Zero-Flicker DNR Blocker Engine:</strong> Config-hash rule validation prevents momentary site unblocking.</li>
                    <li><strong className="text-gray-300">Continuous Distraction Tracking:</strong> Single stable UUID visit tracking with uninterrupted duration (&ge; 60s).</li>
                    <li><strong className="text-gray-300">Pause Guard Mode:</strong> Priority 10,000 temporary allow rules for single-page and whole-site breaks.</li>
                  </ul>
                </div>

                {/* v1.0.9 */}
                <div className="p-3 rounded-xl bg-white/[0.02] border border-white/[0.06] space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-cyan-300 font-mono">v1.0.9</span>
                    <span className="text-[10px] text-gray-500 font-mono">Sept 2026</span>
                  </div>
                  <p className="text-[11px] text-gray-400">
                    Clean Navigation Dispatch and 0ms status handshake between website tabs and extension popup.
                  </p>
                </div>

                {/* v1.0.8 */}
                <div className="p-3 rounded-xl bg-white/[0.02] border border-white/[0.06] space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-gray-300 font-mono">v1.0.8</span>
                    <span className="text-[10px] text-gray-500 font-mono">Sept 2026</span>
                  </div>
                  <p className="text-[11px] text-gray-400">
                    Declarative Net Request Priority Hierarchy (20000 Whitelist &gt; 10000 Break &gt; 100 Blocker) and Web Audio sound feedback.
                  </p>
                </div>

                {/* v1.0.7 */}
                <div className="p-3 rounded-xl bg-white/[0.02] border border-white/[0.06] space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-gray-400 font-mono">v1.0.7</span>
                    <span className="text-[10px] text-gray-500 font-mono">Aug 2026</span>
                  </div>
                  <p className="text-[11px] text-gray-400">
                    Dual-layer realtime engine with low-latency Supabase broadcast channel and presence heartbeats.
                  </p>
                </div>
              </div>

              <div className="pt-2">
                <Button
                  onClick={() => {
                    soundManager.play("close");
                    setShowReleaseModal(false);
                  }}
                  variant="secondary"
                  size="md"
                  className="w-full cursor-pointer"
                >
                  Close
                </Button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
