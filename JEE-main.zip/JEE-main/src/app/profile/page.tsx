"use client";

import React, { useState, useEffect, useMemo } from "react";
import { WorkspaceLayout } from "@/components/workspace-layout";
import { Card } from "@/components/ui/card";
import { Button, Badge } from "@/components/ui/controls";
import { useAuth } from "@/context/AuthContext";
import { useUserProfile, useXpProgress, useStudyStreak } from "@/hooks/use-user-profile";
import { getUpcomingExamYears, getExamTargetOptions, type ExamType } from "@/lib/exam-config";
import { isPastJeeYear } from "@/lib/jee-years";
import { useExam } from "@/hooks/use-exam";
import { useIsClient } from "@/hooks/use-is-client";
import confetti from "canvas-confetti";
import {
  AtSign,
  GraduationCap,
  Flame,
  Zap,
  Clock,
  ShieldCheck,
  Edit3,
  Laptop,
  CheckCircle2,
  X,
  Award,
  BookOpen,
  History,
  AlertTriangle,
  Globe,
  Target,
  Check,
  LogOut,
  Volume2,
  Sparkles,
} from "lucide-react";
import { LogoutModal } from "@/components/ui/logout-modal";
import { Magnetic } from "@/components/ui/magnetic";
import { SoundSettingsPanel } from "@/components/settings/sound-settings-panel";
import { soundManager } from "@/lib/sound-manager";

import { useStudyStore } from "@/store/use-study-store";
import { useMistakeStore } from "@/store/use-mistake-store";

export default function ProfilePage() {
  const isMounted = useIsClient();
  const { userProfile, loading, updateProfileData, checkUsernameAvailability } = useUserProfile();
  const { totalXp, level, xpIntoCurrentLevel, xpRequiredForNextLevel, progressPercent } = useXpProgress();
  const { streak } = useStudyStreak();

  const { sessionHistory = [] } = useStudyStore();
  const { mistakes = [] } = useMistakeStore();

  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [editError, setEditError] = useState("");
  const [showLogoutModal, setShowLogoutModal] = useState(false);
  const [activeTab, setActiveTab] = useState<"profile" | "sound">("profile");

  useEffect(() => {
    if (typeof window !== "undefined" && window.location.hash === "#sound-settings") {
      setActiveTab("sound");
    }
  }, []);

  const { examType, config, isNeet, isJee, switchExamTrack } = useExam();
  const upcomingYears = useMemo(() => getUpcomingExamYears(4), []);

  // Form states
  const [displayName, setDisplayName] = useState("");
  const [bio, setBio] = useState("");
  const [targetExam, setTargetExam] = useState("");
  const [targetYear, setTargetYear] = useState("");
  const [studyGoal, setStudyGoal] = useState("");
  const [country, setCountry] = useState("India");
  const [editUsername, setEditUsername] = useState("");
  const [editExamType, setEditExamType] = useState<ExamType>("JEE");
  const [usernameStatus, setUsernameStatus] = useState<"idle" | "checking" | "available" | "taken">("idle");
  const [pendingTrack, setPendingTrack] = useState<ExamType | null>(null);
  const [isSwitchingTrack, setIsSwitchingTrack] = useState(false);

  // Keep local edit state in sync with loaded profile
  useEffect(() => {
    if (userProfile) {
      const resolvedExamType: ExamType = userProfile.examType || (userProfile.targetExam?.includes("NEET") ? "NEET" : "JEE");
      setEditExamType(resolvedExamType);
      setDisplayName(userProfile.displayName || "");
      setBio(userProfile.bio || "");
      setTargetExam(userProfile.targetExam || `${resolvedExamType === "NEET" ? "NEET UG" : "JEE Main & Advanced"} ${upcomingYears[0]}`);
      setTargetYear(userProfile.targetYear ? String(userProfile.targetYear) : String(upcomingYears[0]));
      setStudyGoal(userProfile.studyGoal || "6 Hours Daily");
      setCountry(userProfile.country || "India");
      setEditUsername(userProfile.username || "");
    }
  }, [userProfile, upcomingYears]);

  const handleConfirmTrackSwitch = async () => {
    if (!pendingTrack) return;
    setIsSwitchingTrack(true);
    try {
      await switchExamTrack(pendingTrack);
      soundManager.play("level-up");
      confetti({
        particleCount: 110,
        spread: 80,
        origin: { y: 0.6 },
        colors: pendingTrack === "NEET" ? ["#10b981", "#8b5cf6", "#06b6d4"] : ["#8b5cf6", "#3b82f6", "#06b6d4"],
      });
      setPendingTrack(null);
    } catch (err) {
      console.error("Failed to switch exam track:", err);
    } finally {
      setIsSwitchingTrack(false);
    }
  };

  // Username availability check when editing
  useEffect(() => {
    const timer = setTimeout(async () => {
      const clean = editUsername.replace(/^@/, "").toLowerCase().trim();
      if (!isEditing || !clean || clean === (userProfile?.username || "")) {
        setUsernameStatus("idle");
        return;
      }

      setUsernameStatus("checking");
      try {
        const isAvail = await checkUsernameAvailability(clean);
        setUsernameStatus(isAvail ? "available" : "taken");
      } catch {
        setUsernameStatus("idle");
      }
    }, 400);

    return () => clearTimeout(timer);
  }, [editUsername, isEditing, userProfile?.username, checkUsernameAvailability]);

  // Derived stats from real sessions
  const validSessions = useMemo(() => {
    return (sessionHistory || []).filter((s) => s && s.completed !== false && Number(s.totalDurationMinutes || 0) > 0);
  }, [sessionHistory]);

  const totalFocusMinutes = validSessions.reduce((acc, s) => acc + (s.totalDurationMinutes || 0), 0) || Number(userProfile?.statistics?.totalFocusMinutes || 0);
  const completedSessions = validSessions.length || Number(userProfile?.statistics?.completedSessions || 0);
  const mistakesLogged = (mistakes || []).length || Number(userProfile?.statistics?.mistakesLogged || 0);
  const formulasBookmarked = Number(userProfile?.statistics?.formulasBookmarked || 0);

  const monkModeSessionsCount = validSessions.filter((s) => s.mode === "DeepWork").length;
  const hasStreakBadge = streak >= 10;
  const hasDeepFocusBadge = monkModeSessionsCount >= 10;

  // Past year warning check
  const isPastTarget = useMemo(() => {
    if (!userProfile?.targetYear) return false;
    return isPastJeeYear(userProfile.targetYear);
  }, [userProfile?.targetYear]);

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (usernameStatus === "taken") {
      setEditError("The chosen handle is already taken. Please pick another.");
      return;
    }

    setIsSaving(true);
    setEditError("");

    try {
      if (editExamType !== examType) {
        await switchExamTrack(editExamType);
      }
      await updateProfileData({
        displayName,
        bio,
        targetExam,
        targetYear,
        examType: editExamType,
        targetExamYear: parseInt(targetYear, 10) || upcomingYears[0],
        studyGoal,
        country,
        username: editUsername.replace(/^@/, "").toLowerCase().trim(),
      });
      setIsEditing(false);
    } catch (err: unknown) {
      const errorObj = err as { message?: string };
      setEditError(errorObj?.message || "Failed to update profile.");
    } finally {
      setIsSaving(false);
    }
  };

  const usernameDisplay = userProfile?.username
    ? `@${userProfile.username}`
    : userProfile?.email
      ? `@${userProfile.email.split("@")[0]}`
      : "@aspirant";

  const initials = (userProfile?.displayName || displayName || "JA")
    .trim()
    .split(" ")
    .map((n: string) => n[0])
    .filter(Boolean)
    .join("")
    .substring(0, 2)
    .toUpperCase() || "JA";

  if (loading && !userProfile) {
    return (
      <WorkspaceLayout title="User Profile">
        <div className="max-w-5xl mx-auto space-y-6 animate-pulse">
          <div className="h-44 bg-slate-900/60 rounded-3xl border border-white/10" />
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="h-80 bg-slate-900/60 rounded-3xl border border-white/10" />
            <div className="lg:col-span-2 h-80 bg-slate-900/60 rounded-3xl border border-white/10" />
          </div>
        </div>
      </WorkspaceLayout>
    );
  }

  return (
    <WorkspaceLayout title="User Profile">
      <div className="space-y-6 max-w-5xl mx-auto">

        {/* Past Exam Year Warning Banner */}
        {isPastTarget && (
          <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-start justify-between gap-3 text-amber-200 text-xs">
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-amber-300 block">Exam Target Passed</span>
                Your target exam year ({userProfile?.targetYear}) has concluded. Update your academic cycle to an upcoming JEE examination year to maintain accurate countdowns and syllabus tracking.
              </div>
            </div>
            <Button
              onClick={() => setIsEditing(true)}
              variant="secondary"
              size="sm"
              className="shrink-0 bg-amber-500/20 text-amber-300 border-amber-500/40 hover:bg-amber-500/30 cursor-pointer"
            >
              Update Year
            </Button>
          </div>
        )}

        {/* Profile Hero Header Card with Rich Purple Color Fill */}
        <div
          className="relative overflow-hidden rounded-3xl border border-purple-500/30 p-6 sm:p-8 space-y-6 shadow-2xl shadow-purple-950/40"
          style={{
            background: "radial-gradient(circle at 18% 28%, rgba(147, 51, 234, 0.32) 0%, rgba(35, 20, 65, 0.6) 35%, rgba(12, 14, 24, 0.95) 75%)"
          }}
        >
          {/* Ambient luminous glow layer */}
          <div
            className="absolute -top-20 -left-20 w-96 h-96 rounded-full pointer-events-none blur-3xl opacity-70"
            style={{ background: "radial-gradient(circle, rgba(147, 51, 234, 0.5) 0%, rgba(99, 102, 241, 0.25) 55%, transparent 75%)" }}
          />

          <div className="relative z-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">

            <div className="flex items-center gap-4 sm:gap-6 min-w-0">
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-gradient-to-tr from-[#9333ea] via-[#6366f1] to-[#38bdf8] flex items-center justify-center text-xl sm:text-2xl font-black text-white shadow-[0_0_25px_rgba(147,51,234,0.5)] border-2 border-white/20 shrink-0">
                {initials}
              </div>

              <div className="space-y-1 overflow-hidden">
                <div className="flex items-center gap-2.5">
                  <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight truncate">
                    {userProfile?.displayName || "Aspirant"}
                  </h1>
                  <span className="shrink-0 px-2.5 py-0.5 rounded-full text-[10px] font-bold font-mono uppercase tracking-wider bg-[#26134b] border border-purple-500/40 text-purple-300">
                    LVL {level}
                  </span>
                </div>

                <div className="flex items-center gap-3 text-xs font-mono">
                  <span className="flex items-center gap-1 font-bold text-cyan-400">
                    <AtSign className="w-3.5 h-3.5 text-cyan-400" />
                    {usernameDisplay}
                  </span>
                  <span className="text-gray-500">•</span>
                  <span className="flex items-center gap-1 text-amber-400 font-bold">
                    <Flame className="w-3.5 h-3.5 fill-amber-400/20 text-amber-400" />
                    {streak} Day Streak
                  </span>
                </div>

                <p className="text-xs text-gray-300 line-clamp-1 pt-0.5 font-sans">
                  {userProfile?.bio || "IIT-JEE Main & Advanced aspirant working towards rank 1."}
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setIsEditing(true)}
              className="shrink-0 px-4 py-2 rounded-xl text-xs font-semibold text-white bg-[#101422] border border-white/10 hover:bg-[#151b2e] hover:border-white/20 flex items-center gap-2 transition-all cursor-pointer shadow-lg shadow-black/40"
            >
              <Edit3 className="w-4 h-4 text-purple-400" />
              <span>Edit Profile</span>
            </button>
          </div>

          {/* XP & Level Bar */}
          <div className="relative z-10 pt-4 border-t border-white/[0.08] space-y-2">
            <div className="flex justify-between text-xs font-mono">
              <span className="flex items-center gap-1.5 text-cyan-400 font-bold">
                <Zap className="w-3.5 h-3.5 text-cyan-400 fill-cyan-400/20" />
                {totalXp} Lifetime XP
              </span>
              <span className="text-gray-400">
                Next Level: {xpIntoCurrentLevel} / {xpRequiredForNextLevel} XP ({progressPercent}%)
              </span>
            </div>
            <div className="w-full h-1.5 bg-[#0e1220] rounded-full overflow-hidden border border-white/10">
              <div
                className="h-full bg-gradient-to-r from-purple-500 via-indigo-500 to-cyan-400 rounded-full transition-all duration-500"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>
        </div>

        {/* Section Navigation Tabs */}
        <div className="flex items-center gap-2 border-b border-white/[0.08] pb-3">
          <button
            type="button"
            onClick={() => {
              soundManager.play("select");
              setActiveTab("profile");
            }}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === "profile"
                ? "bg-purple-500/20 text-purple-200 border border-purple-500/40 shadow-sm"
                : "text-gray-400 hover:text-white hover:bg-white/[0.04] border border-transparent"
            }`}
          >
            <GraduationCap className="w-4 h-4" />
            <span>Profile & Academics</span>
          </button>

          <button
            type="button"
            id="sound-settings"
            onClick={() => {
              soundManager.play("select");
              setActiveTab("sound");
            }}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === "sound"
                ? "bg-purple-500/20 text-purple-200 border border-purple-500/40 shadow-sm"
                : "text-gray-400 hover:text-white hover:bg-white/[0.04] border border-transparent"
            }`}
          >
            <Volume2 className="w-4 h-4" />
            <span>Audio & Sensory Experience</span>
          </button>
        </div>

        {activeTab === "profile" ? (
          /* 2-Column Grid: Details & Stats */
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

          {/* Left Column: Personal & Study Settings */}
          <div className="space-y-6">

            {/* Preparation Track Card */}
            <Card variant="glass" className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-purple-400" /> Preparation Track
                </h3>
                <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-bold border ${
                  examType === "NEET"
                    ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-300"
                    : "bg-purple-500/10 border-purple-500/30 text-purple-300"
                }`}>
                  {config.shortName} Active
                </span>
              </div>

              <p className="text-xs text-gray-400 leading-relaxed font-sans">
                Switching tracks adapts your syllabus, tracker, subject categories, and analytics while preserving all study sessions and mistake logs.
              </p>

              <div className="grid grid-cols-2 gap-2.5 pt-1">
                <button
                  type="button"
                  onClick={() => {
                    if (examType !== "JEE") setPendingTrack("JEE");
                  }}
                  className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col gap-1 ${
                    examType === "JEE"
                      ? "bg-purple-600/20 border-purple-500 text-white ring-1 ring-purple-500/50 shadow-md shadow-purple-950/40"
                      : "bg-slate-950/80 border-white/10 text-gray-400 hover:text-white hover:border-white/20"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white flex items-center gap-1.5">
                      ⚡ JEE Track
                    </span>
                    {examType === "JEE" && <Check className="w-3.5 h-3.5 text-purple-400" />}
                  </div>
                  <span className="text-[10px] text-gray-400 font-mono">PCM (Engineering)</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    if (examType !== "NEET") setPendingTrack("NEET");
                  }}
                  className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col gap-1 ${
                    examType === "NEET"
                      ? "bg-emerald-600/20 border-emerald-500 text-white ring-1 ring-emerald-500/50 shadow-md shadow-emerald-950/40"
                      : "bg-slate-950/80 border-white/10 text-gray-400 hover:text-white hover:border-white/20"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white flex items-center gap-1.5">
                      🩺 NEET Track
                    </span>
                    {examType === "NEET" && <Check className="w-3.5 h-3.5 text-emerald-400" />}
                  </div>
                  <span className="text-[10px] text-gray-400 font-mono">PCB (Medical)</span>
                </button>
              </div>
            </Card>

            {/* Study Target Settings Card */}
            <Card variant="glass" className="space-y-4">
              <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <GraduationCap className="w-4 h-4 text-purple-400" /> Target Academic Goals
              </h3>

              <div className="space-y-3 text-xs font-mono">
                <div className="p-3 bg-slate-950/80 rounded-xl border border-white/[0.08] flex justify-between items-center">
                  <span className="text-gray-400">Target Exam:</span>
                  <span className="font-bold text-purple-300">{userProfile?.targetExam || "Not Set"}</span>
                </div>
                <div className="p-3 bg-slate-950/80 rounded-xl border border-white/[0.08] flex justify-between items-center">
                  <span className="text-gray-400">Target Year:</span>
                  <span className="font-bold text-cyan-300 flex items-center gap-1.5">
                    {userProfile?.targetYear || "Not Set"}
                    {isPastTarget && (
                      <span className="text-[10px] text-amber-400 font-semibold px-1.5 py-0.5 rounded bg-amber-500/10 border border-amber-500/20">
                        Expired
                      </span>
                    )}
                  </span>
                </div>
                <div className="p-3 bg-slate-950/80 rounded-xl border border-white/[0.08] flex justify-between items-center">
                  <span className="text-gray-400">Daily Study Goal:</span>
                  <span className="font-bold text-emerald-400">{userProfile?.studyGoal || "Not Set"}</span>
                </div>
              </div>
            </Card>

            {/* Account Metadata Card */}
            <Card variant="glass" className="space-y-4">
              <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-cyan-400" /> Identity Details
              </h3>

              <div className="space-y-3 text-xs font-mono">
                <div className="p-3 bg-slate-950/80 rounded-xl border border-white/[0.08] flex justify-between items-center">
                  <span className="text-gray-400">Username:</span>
                  <span className="font-bold text-white">{usernameDisplay}</span>
                </div>
                <div className="p-3 bg-slate-950/80 rounded-xl border border-white/[0.08] flex justify-between items-center overflow-hidden">
                  <span className="text-gray-400 shrink-0">Email:</span>
                  <span className="font-bold text-gray-300 truncate ml-2">{userProfile?.email || "Guest Aspirant"}</span>
                </div>
                <div className="p-3 bg-slate-950/80 rounded-xl border border-white/[0.08] flex justify-between items-center">
                  <span className="text-gray-400">Country:</span>
                  <span className="font-bold text-gray-200">{userProfile?.country || "India"}</span>
                </div>
                <div className="p-3 bg-slate-950/80 rounded-xl border border-white/[0.08] flex justify-between items-center">
                  <span className="text-gray-400">Joined Date:</span>
                  <span className="font-bold text-gray-400 text-[10px]">
                    {userProfile?.joinedAt && isMounted
                      ? new Date(userProfile.joinedAt).toLocaleDateString([], { month: "short", year: "numeric", day: "numeric" })
                      : userProfile?.joinedAt
                        ? userProfile.joinedAt.split("T")[0]
                        : "Active Member"}
                  </span>
                </div>
              </div>
            </Card>

            {/* Connected Extension Card */}
            <Card variant="glass" className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                  <Laptop className="w-4 h-4 text-emerald-400" /> Companion Extension
                </h3>
                <Badge variant="green">Connected</Badge>
              </div>

              <div className="p-3.5 bg-slate-950/80 rounded-xl border border-white/[0.08] space-y-2 text-xs font-mono">
                <div className="flex justify-between items-center text-gray-400">
                  <span>Browser:</span>
                  <span className="text-white font-bold">{userProfile?.browserName || "Chrome Desktop"}</span>
                </div>
                <div className="flex justify-between items-center text-gray-400">
                  <span>Sync Health:</span>
                  <span className="text-emerald-400 font-bold flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" /> Realtime Active
                  </span>
                </div>
              </div>
            </Card>
          </div>

          {/* Right Column: Statistics & Achievements */}
          <div className="lg:col-span-2 space-y-6">

            {/* Overview Stats Cards */}
            <Card variant="glass" className="space-y-4">
              <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Award className="w-4 h-4 text-purple-400" /> Lifetime Study Statistics
              </h3>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono text-xs">
                <div className="p-4 bg-purple-500/5 border border-purple-500/20 rounded-xl space-y-1">
                  <Clock className="w-5 h-5 text-purple-400 mb-1" />
                  <span className="text-2xl font-extrabold text-white block">{totalFocusMinutes}</span>
                  <span className="text-[10px] text-gray-400 uppercase font-semibold">Focus Minutes</span>
                </div>
                <div className="p-4 bg-cyan-500/5 border border-cyan-500/20 rounded-xl space-y-1">
                  <History className="w-5 h-5 text-cyan-400 mb-1" />
                  <span className="text-2xl font-extrabold text-white block">{completedSessions}</span>
                  <span className="text-[10px] text-gray-400 uppercase font-semibold">Sessions Done</span>
                </div>
                <div className="p-4 bg-red-500/5 border border-red-500/20 rounded-xl space-y-1">
                  <BookOpen className="w-5 h-5 text-red-400 mb-1" />
                  <span className="text-2xl font-extrabold text-white block">{mistakesLogged}</span>
                  <span className="text-[10px] text-gray-400 uppercase font-semibold">Mistakes Logged</span>
                </div>
                <div className="p-4 bg-emerald-500/5 border border-emerald-500/20 rounded-xl space-y-1">
                  <Zap className="w-5 h-5 text-emerald-400 mb-1" />
                  <span className="text-2xl font-extrabold text-white block">{formulasBookmarked}</span>
                  <span className="text-[10px] text-gray-400 uppercase font-semibold">Formulas Saved</span>
                </div>
              </div>
            </Card>

            {/* Badges & Achievements */}
            <Card variant="glass" className="space-y-4">
              <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Award className="w-4 h-4 text-amber-400" /> Rank Badges & Achievements
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className={`p-3.5 bg-slate-950/80 border rounded-xl flex items-center gap-3 transition-all ${hasStreakBadge ? "border-amber-500/30" : "border-white/[0.06] opacity-60"
                  }`}>
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center shrink-0 ${hasStreakBadge ? "bg-amber-500/20 border border-amber-500/30 text-amber-400" : "bg-white/[0.04] text-gray-500"
                    }`}>
                    🔥
                  </div>
                  <div>
                    <h4 className="font-bold text-white flex items-center gap-1.5">
                      Consistent Aspirant
                      {hasStreakBadge && <span className="text-[10px] text-emerald-400 font-normal">Unlocked</span>}
                    </h4>
                    <p className="text-[10px] text-gray-400">
                      {hasStreakBadge ? "Maintained a 10+ day study streak!" : `Requires 10-day streak (${streak}/10)`}
                    </p>
                  </div>
                </div>

                <div className={`p-3.5 bg-slate-950/80 border rounded-xl flex items-center gap-3 transition-all ${hasDeepFocusBadge ? "border-purple-500/30" : "border-white/[0.06] opacity-60"
                  }`}>
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center shrink-0 ${hasDeepFocusBadge ? "bg-purple-500/20 border border-purple-500/30 text-purple-400" : "bg-white/[0.04] text-gray-500"
                    }`}>
                    ⚡
                  </div>
                  <div>
                    <h4 className="font-bold text-white flex items-center gap-1.5">
                      Deep Focus Master
                      {hasDeepFocusBadge && <span className="text-[10px] text-emerald-400 font-normal">Unlocked</span>}
                    </h4>
                    <p className="text-[10px] text-gray-400">
                      {hasDeepFocusBadge ? "Completed 10+ Monk Mode sessions!" : `Requires 10 Deep Work sessions (${monkModeSessionsCount}/10)`}
                    </p>
                  </div>
                </div>
              </div>
            </Card>

            {/* Account Security & Sign Out Section */}
            <Card variant="glass" className="p-5 sm:p-6 border-red-500/20 bg-gradient-to-br from-red-500/5 via-transparent to-purple-500/5 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-red-500/10 border border-red-500/20 flex items-center justify-center text-red-400 shrink-0">
                    <LogOut className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white tracking-tight flex items-center gap-2">
                      Account Session & Security
                    </h3>
                    <p className="text-xs text-gray-400 mt-0.5">
                      Signed in as <span className="text-white font-semibold">{userProfile?.displayName || "Aspirant"}</span> ({userProfile?.email || "cloud account active"}).
                    </p>
                  </div>
                </div>

                <Magnetic strength={0.2}>
                  <button
                    type="button"
                    onClick={() => setShowLogoutModal(true)}
                    className="px-4 py-2.5 rounded-xl text-xs font-bold text-red-300 bg-red-500/10 hover:bg-red-500/20 border border-red-500/30 hover:border-red-500/50 transition-all flex items-center gap-2 shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-red-500/50"
                  >
                    <LogOut className="w-4 h-4" />
                    Sign Out of FocusForge
                  </button>
                </Magnetic>
              </div>
            </Card>

          </div>

        </div>
        ) : (
          <SoundSettingsPanel />
        )}

      </div>

      {/* Logout Confirmation Dialog */}
      <LogoutModal isOpen={showLogoutModal} onClose={() => setShowLogoutModal(false)} />

      {/* Edit Profile Modal */}
      {isEditing && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-gray-950 border border-gray-800 p-6 rounded-3xl max-w-md w-full space-y-4 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-gray-800 pb-3">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <Edit3 className="w-5 h-5 text-purple-400" /> Edit Profile
              </h3>
              <button
                type="button"
                onClick={() => setIsEditing(false)}
                className="text-gray-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {editError && (
              <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-xl text-red-400 text-xs">
                {editError}
              </div>
            )}

            <form onSubmit={handleSaveProfile} className="space-y-4 text-xs font-mono">
              <div>
                <label className="block text-gray-400 mb-1">Display Name</label>
                <input
                  type="text"
                  required
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-gray-900 border border-gray-800 text-white focus:outline-none focus:border-purple-500"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-gray-400">Unique Username (@handle)</label>
                  {usernameStatus === "checking" && (
                    <span className="text-[10px] text-purple-400 animate-pulse">Checking...</span>
                  )}
                  {usernameStatus === "available" && (
                    <span className="text-[10px] text-emerald-400 flex items-center gap-1 font-bold">
                      <Check className="w-3 h-3" /> Available
                    </span>
                  )}
                  {usernameStatus === "taken" && (
                    <span className="text-[10px] text-red-400 font-bold">Taken</span>
                  )}
                </div>
                <input
                  type="text"
                  required
                  value={editUsername}
                  onChange={(e) => setEditUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ""))}
                  className={`w-full px-3.5 py-2.5 rounded-xl bg-gray-900 border transition-colors text-white focus:outline-none ${usernameStatus === "available"
                      ? "border-emerald-500/50"
                      : usernameStatus === "taken"
                        ? "border-red-500/50"
                        : "border-gray-800 focus:border-purple-500"
                    }`}
                />
              </div>

              <div>
                <label className="block text-gray-400 mb-1">Bio</label>
                <textarea
                  rows={2}
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-gray-900 border border-gray-800 text-white focus:outline-none focus:border-purple-500 font-sans text-xs"
                />
              </div>

              {/* Preparation Track in Modal */}
              <div>
                <label className="block text-gray-400 mb-1">Preparation Track</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setEditExamType("JEE");
                      const opts = getExamTargetOptions("JEE", targetYear);
                      setTargetExam(opts[0]?.value || `JEE Main & Advanced ${targetYear}`);
                    }}
                    className={`py-2 px-3 rounded-xl text-xs font-bold transition-all text-center border cursor-pointer ${
                      editExamType === "JEE"
                        ? "bg-purple-600/30 border-purple-500 text-white ring-1 ring-purple-500/50"
                        : "bg-gray-900 border-gray-800 text-gray-400 hover:text-white"
                    }`}
                  >
                    ⚡ JEE (Engineering)
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setEditExamType("NEET");
                      const opts = getExamTargetOptions("NEET", targetYear);
                      setTargetExam(opts[0]?.value || `NEET UG ${targetYear}`);
                    }}
                    className={`py-2 px-3 rounded-xl text-xs font-bold transition-all text-center border cursor-pointer ${
                      editExamType === "NEET"
                        ? "bg-emerald-600/30 border-emerald-500 text-white ring-1 ring-emerald-500/50"
                        : "bg-gray-900 border-gray-800 text-gray-400 hover:text-white"
                    }`}
                  >
                    🩺 NEET (Medical)
                  </button>
                </div>
              </div>

              {/* Dynamic Target Year Selector */}
              <div>
                <label className="block text-gray-400 mb-1">Target Exam Year</label>
                <div className="grid grid-cols-4 gap-2">
                  {upcomingYears.map((yr) => {
                    const isSelected = targetYear === String(yr);
                    return (
                      <button
                        type="button"
                        key={yr}
                        onClick={() => {
                          setTargetYear(String(yr));
                          const opts = getExamTargetOptions(editExamType, yr);
                          setTargetExam(opts[0]?.value || `${editExamType === "NEET" ? "NEET UG" : "JEE Main & Advanced"} ${yr}`);
                        }}
                        className={`py-2 px-1 rounded-xl text-xs font-bold transition-all text-center border cursor-pointer ${isSelected
                            ? editExamType === "NEET"
                              ? "bg-emerald-600 border-emerald-500 text-white shadow-md shadow-emerald-950/40"
                              : "bg-purple-600 border-purple-500 text-white shadow-md shadow-purple-950/40"
                            : "bg-gray-900 border-gray-800 text-gray-400 hover:text-white"
                          }`}
                      >
                        {yr}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Target Exam Dropdown */}
              <div>
                <label className="block text-gray-400 mb-1">Target Examination</label>
                <select
                  value={targetExam}
                  onChange={(e) => setTargetExam(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-gray-900 border border-gray-800 text-white focus:outline-none focus:border-purple-500"
                >
                  {getExamTargetOptions(editExamType, Number(targetYear) || upcomingYears[0]).map((opt) => (
                    <option key={opt.value} value={opt.value}>
                      {opt.label}
                    </option>
                  ))}
                </select>
              </div>

              {/* Country and Study Goal */}
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-gray-400 mb-1">Country</label>
                  <select
                    value={country}
                    onChange={(e) => setCountry(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl bg-gray-900 border border-gray-800 text-white focus:outline-none focus:border-purple-500 text-xs"
                  >
                    <option value="India">India</option>
                    <option value="United Arab Emirates">UAE</option>
                    <option value="Saudi Arabia">Saudi Arabia</option>
                    <option value="Singapore">Singapore</option>
                    <option value="Qatar">Qatar</option>
                    <option value="Oman">Oman</option>
                    <option value="Kuwait">Kuwait</option>
                    <option value="United States">United States</option>
                    <option value="Nepal">Nepal</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="block text-gray-400 mb-1">Daily Study Goal</label>
                  <select
                    value={studyGoal}
                    onChange={(e) => setStudyGoal(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl bg-gray-900 border border-gray-800 text-white focus:outline-none focus:border-purple-500 text-xs"
                  >
                    <option value="4 Hours Daily">4 Hours</option>
                    <option value="6 Hours Daily">6 Hours (Rec.)</option>
                    <option value="8 Hours Daily">8 Hours</option>
                    <option value="10+ Hours Daily">10+ Hours</option>
                  </select>
                </div>
              </div>

              <div className="flex gap-2 pt-3">
                <Button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  variant="secondary"
                  size="md"
                  className="flex-1 cursor-pointer"
                  disabled={isSaving}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  variant="primary"
                  size="md"
                  className="flex-1 cursor-pointer"
                  disabled={isSaving}
                >
                  {isSaving ? "Saving..." : "Save Changes"}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Track Switch Confirmation Modal */}
      {pendingTrack && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-gray-950 border border-gray-800 p-6 rounded-3xl max-w-md w-full space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-gray-800 pb-3">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-purple-400" /> Switch Preparation Track?
              </h3>
              <button
                type="button"
                onClick={() => setPendingTrack(null)}
                className="text-gray-400 hover:text-white cursor-pointer"
                disabled={isSwitchingTrack}
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs text-gray-300">
              <p>
                You are about to switch your active track from{" "}
                <span className="font-bold text-white">{examType}</span> to{" "}
                <span className="font-bold text-cyan-400">{pendingTrack}</span>.
              </p>
              <div className="p-3 bg-purple-500/10 border border-purple-500/20 rounded-xl space-y-1.5 text-purple-200">
                <div className="font-semibold text-white flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-purple-400" /> What changes dynamically:
                </div>
                <ul className="list-disc list-inside space-y-1 text-[11px] text-gray-300 pl-1">
                  <li>Curriculum chapters and historical weightage trends</li>
                  <li>Subject categories (Botany & Zoology for NEET / Math for JEE)</li>
                  <li>Syllabus tracker, formula & NCERT vaults, and analytics</li>
                </ul>
              </div>
              <p className="text-[11px] text-emerald-400 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 shrink-0" />
                All your prior study sessions and mistake records remain safely preserved.
              </p>
            </div>

            <div className="flex gap-2 pt-2">
              <Button
                type="button"
                onClick={() => setPendingTrack(null)}
                variant="secondary"
                size="md"
                className="flex-1 cursor-pointer"
                disabled={isSwitchingTrack}
              >
                Cancel
              </Button>
              <Button
                type="button"
                onClick={handleConfirmTrackSwitch}
                variant="primary"
                size="md"
                className="flex-1 cursor-pointer"
                disabled={isSwitchingTrack}
              >
                {isSwitchingTrack ? "Switching..." : `Confirm Switch to ${pendingTrack}`}
              </Button>
            </div>
          </div>
        </div>
      )}
    </WorkspaceLayout>
  );
}
