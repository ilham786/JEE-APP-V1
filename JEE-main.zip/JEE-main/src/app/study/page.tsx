"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { WorkspaceLayout } from "@/components/workspace-layout";
import { Card, CardHeader, CardBody } from "@/components/ui/card";
import { Button, Badge, Select } from "@/components/ui/controls";
import { Magnetic } from "@/components/ui/magnetic";
import { useStudyStore, SessionMode } from "@/store/use-study-store";
import { useMistakeStore } from "@/store/use-mistake-store";
import { getSyllabusForSubject } from "@/data/syllabus";
import { useExam } from "@/hooks/use-exam";
import { getSubjectVariant } from "@/lib/syllabus-filter-helper";
import {
  Timer,
  Play,
  Pause,
  RotateCcw,
  CheckCircle,
  Eye,
  EyeOff,
  AlertTriangle,
  Sparkles,
  Trash2,
  Lock,
  ShieldAlert,
  Snowflake,
  Clock,
  ArrowRight,
} from "lucide-react";
import { playTimerCompleteSound, triggerConfetti, playErrorSound } from "@/lib/sound-effects";
import { soundManager } from "@/lib/sound-manager";
import { useIsClient } from "@/hooks/use-is-client";

function getSessionTimeDetails(
  startTime?: string,
  endTime?: string,
  durationMins = 0,
  dateStr?: string,
  isMounted = true
) {
  let durationFormatted = `${durationMins} min`;
  if (durationMins >= 60) {
    const hrs = Math.floor(durationMins / 60);
    const mins = durationMins % 60;
    durationFormatted = mins > 0 ? `${hrs}h ${mins}m` : `${hrs}h`;
  }

  // Deterministic SSR & initial hydration pass - prevents locale / time divergence
  if (!isMounted) {
    return {
      startFormatted: "--:--",
      endFormatted: null,
      timeOfDay: {
        label: "Deep Work Block",
        icon: "⚡",
        badgeClass: "bg-purple-500/10 text-purple-300 border-purple-500/20",
      },
      relativeAge: dateStr || "Recent",
      durationFormatted,
    };
  }

  let start: Date | null = null;
  if (startTime) {
    const d = new Date(startTime);
    if (!isNaN(d.getTime())) start = d;
  }
  if (!start && dateStr) {
    const d = new Date(dateStr.includes("T") ? dateStr : `${dateStr}T12:00:00Z`);
    if (!isNaN(d.getTime())) start = d;
  }

  let end: Date | null = null;
  if (endTime) {
    const d = new Date(endTime);
    if (!isNaN(d.getTime())) end = d;
  }
  if (start && !end && durationMins > 0) {
    end = new Date(start.getTime() + durationMins * 60000);
  }

  const formatHourMin = (d: Date) => {
    return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: true });
  };

  const startFormatted = start ? formatHourMin(start) : null;
  const endFormatted = end ? formatHourMin(end) : null;

  let timeOfDay = {
    label: "Deep Work Block",
    icon: "⚡",
    badgeClass: "bg-purple-500/10 text-purple-300 border-purple-500/20",
  };

  if (start) {
    const hour = start.getHours();
    if (hour >= 0 && hour < 4) {
      timeOfDay = {
        label: "Midnight Deep Work",
        icon: "🌌",
        badgeClass: "bg-indigo-500/10 text-indigo-300 border-indigo-500/25",
      };
    } else if (hour >= 4 && hour < 8) {
      timeOfDay = {
        label: "Early Bird Dawn",
        icon: "🌅",
        badgeClass: "bg-amber-500/10 text-amber-300 border-amber-500/25",
      };
    } else if (hour >= 8 && hour < 12) {
      timeOfDay = {
        label: "Morning Peak",
        icon: "☀️",
        badgeClass: "bg-yellow-500/10 text-yellow-300 border-yellow-500/25",
      };
    } else if (hour >= 12 && hour < 17) {
      timeOfDay = {
        label: "Afternoon Focus",
        icon: "🌤️",
        badgeClass: "bg-cyan-500/10 text-cyan-300 border-cyan-500/25",
      };
    } else if (hour >= 17 && hour < 21) {
      timeOfDay = {
        label: "Evening Sprint",
        icon: "🌇",
        badgeClass: "bg-orange-500/10 text-orange-300 border-orange-500/25",
      };
    } else {
      timeOfDay = {
        label: "Night Owl Study",
        icon: "🌙",
        badgeClass: "bg-violet-500/10 text-violet-300 border-violet-500/25",
      };
    }
  }

  let relativeAge = dateStr || "Recent";
  if (start) {
    const diffMs = Date.now() - start.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMins / 60);
    const diffDays = Math.floor(diffHours / 24);

    if (diffMins < 1) relativeAge = "Just now";
    else if (diffMins < 60) relativeAge = `${diffMins}m ago`;
    else if (diffHours < 24 && new Date().toDateString() === start.toDateString()) {
      relativeAge = `Today • ${diffHours}h ago`;
    } else if (diffDays === 1) {
      relativeAge = "Yesterday";
    } else if (diffDays > 1 && diffDays < 7) {
      relativeAge = `${diffDays}d ago`;
    } else {
      relativeAge = start.toLocaleDateString([], { month: "short", day: "numeric" });
    }
  }

  return {
    startFormatted,
    endFormatted,
    timeOfDay,
    relativeAge,
    durationFormatted,
  };
}

export default function StudySessionPage() {
  const {
    status,
    mode,
    timeLeft,
    durationMinutes,
    activeSession,
    monkModeEnabled,
    blockedWebsites,
    whitelistOnly,
    examModeEnabled,
    coolingBlockUntil,
    toggleMonkMode,
    startSession,
    pauseSession,
    resumeSession,
    completeSession,
    abandonSession,
    cancelSession,
    triggerEmergencyExit,
    clearCoolingBlock,
    deleteCompletedSession,
    openSummaryModal,
    volume,
    sessionHistory = [],
  } = useStudyStore();

  const { syllabus } = useMistakeStore();
  const { examType, subjects, isNeet } = useExam();

  // Session configuration form states
  const [selectedSubject, setSelectedSubject] = useState<string>("Physics");
  const [selectedChapter, setSelectedChapter] = useState("");
  const [selectedSubchapter, setSelectedSubchapter] = useState("");
  const [selectedType, setSelectedType] = useState("PYQ");
  const [selectedMode, setSelectedMode] = useState<SessionMode>("Pomodoro");
  const [customTime, setCustomTime] = useState(45);
  const [showEmergencyModal, setShowEmergencyModal] = useState(false);

  // Keep selectedSubject aligned with active exam track
  useEffect(() => {
    if (subjects.length > 0 && !subjects.includes(selectedSubject)) {
      setSelectedSubject(subjects[0]);
      setSelectedChapter("");
      setSelectedSubchapter("");
    }
  }, [subjects, selectedSubject]);

  // Chapter Validation & Shake Animation States
  const [chapterError, setChapterError] = useState(false);
  const [shakeTrigger, setShakeTrigger] = useState(0);

  const isMounted = useIsClient();
  const [isStarting, setIsStarting] = useState(false);

  // Live interval ticker for emergency cooling block - 0 during SSR prevents hydration divergence
  const [currentTime, setCurrentTime] = useState<number>(0);
  useEffect(() => {
    setCurrentTime(Date.now());
  }, []);

  useEffect(() => {
    if (!coolingBlockUntil || coolingBlockUntil <= Date.now()) return;
    const interval = setInterval(() => {
      const now = Date.now();
      setCurrentTime(now);
      if (now >= coolingBlockUntil) {
        clearCoolingBlock();
      }
    }, 1000);
    return () => clearInterval(interval);
  }, [coolingBlockUntil, clearCoolingBlock]);

  const isCoolingActive = isMounted && !!(coolingBlockUntil && coolingBlockUntil > currentTime);
  const coolingSecondsRemaining = isCoolingActive ? Math.max(0, Math.ceil((coolingBlockUntil! - currentTime) / 1000)) : 0;

  // Handler to switch subject cleanly and reset chapter/subchapter
  const handleSubjectChange = (newSubject: string) => {
    soundManager.play("select");
    setSelectedSubject(newSubject);
    setSelectedChapter("");
    setSelectedSubchapter("");
    setChapterError(false);
  };

  // Handler to select chapter and auto-sync its primary subchapter
  const handleChapterSelect = (chapterName: string, autoStart: boolean = false) => {
    soundManager.play("choose");
    setSelectedChapter(chapterName);
    setChapterError(false);

    const list = getSyllabusForSubject(selectedSubject, examType);
    const chapObj = list.find((c) => c.name === chapterName);
    const subName = chapObj && chapObj.subchapters.length > 0
      ? chapObj.subchapters[0].name
      : "General Practice";
    setSelectedSubchapter(subName);

    if (autoStart) {
      startSession(selectedSubject, chapterName, selectedType, selectedMode, customTime, subName, examType).catch((err: any) => {
        console.error("Failed to auto-start session:", err);
      });
    }
  };

  // Format seconds to MM:SS
  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const s = secs % 60;
    return `${mins.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
  };

  // Run countdown percentage calculation
  const totalSeconds = durationMinutes * 60;
  const progressPercent = totalSeconds > 0 ? ((totalSeconds - timeLeft) / totalSeconds) * 100 : 0;

  const handleStart = async () => {
    // Chapter Selection Validation Guardrail
    if (!selectedChapter || selectedChapter.trim() === "") {
      setChapterError(true);
      setShakeTrigger((prev) => prev + 1);
      playErrorSound(volume);
      if (typeof window !== "undefined" && navigator.vibrate) {
        navigator.vibrate([100, 50, 100, 50, 150]);
      }
      return;
    }

    try {
      setIsStarting(true);
      await startSession(selectedSubject, selectedChapter, selectedType, selectedMode, customTime, selectedSubchapter, examType);
    } catch (err: any) {
      console.error("Failed to start study session:", err);
      alert(`Could not start study session: ${err?.message || "Failed to persist to database."}`);
    } finally {
      setIsStarting(false);
    }
  };

  const handleCompleteEarly = () => {
    completeSession({
      subchapter: selectedSubchapter,
      notes: "Focus zone completed manually.",
      wasGoalCompleted: true,
    });
    playTimerCompleteSound(volume);
    triggerConfetti();
    openSummaryModal();
  };

  const triggerTimerState = () => {
    if (examModeEnabled) {
      return; // Strictly disabled during Exam Mode (Monk Lockdown)
    }
    if (status === "focus") {
      pauseSession();
    } else {
      resumeSession();
    }
  };

  // Keyboard shortcut listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Space to toggle pause / resume
      if (e.code === "Space" && (status === "focus" || status === "paused") && document.activeElement?.tagName !== "INPUT" && document.activeElement?.tagName !== "TEXTAREA") {
        e.preventDefault();
        if (!examModeEnabled) {
          triggerTimerState();
        }
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [status, examModeEnabled]);

  // Monk Mode component content
  if (monkModeEnabled && (status === "focus" || status === "paused")) {
    return (
      <div className="fixed inset-0 bg-black z-50 flex flex-col items-center justify-center p-4 md:p-6 select-none transition-all">
        {/* Ambient indicator */}
        <div className="absolute top-4 left-4 md:top-8 md:left-8 flex items-center gap-3 text-xs text-zinc-500 font-semibold tracking-wider uppercase">
          <span className={`w-2.5 h-2.5 rounded-full ${status === "paused" ? "bg-amber-400" : "bg-purple-500 animate-pulse"}`} />
          Monk Session: {activeSession?.subject} - {activeSession?.chapter}
          {status === "paused" && <span className="text-amber-400 font-bold ml-2">[ PAUSED ]</span>}
        </div>

        {/* Digital focus display */}
        <div className="flex flex-col items-center space-y-8 text-center max-w-md w-full">
          <h2 className={`text-6xl sm:text-8xl md:text-9xl font-black font-mono tracking-tighter tabular-nums select-all ${status === "paused" ? "text-amber-400/90" : "text-white"}`}>
            {formatTime(timeLeft)}
          </h2>

          <div className="space-y-2">
            <p className="text-sm font-semibold text-zinc-400 tracking-wide">
              Focusing on: <span className="text-white">{activeSession?.taskType}</span>
            </p>
            <p className="text-xs text-zinc-500">
              {examModeEnabled
                ? "🔒 Timers Locked — Exam Mode Active (No Pausing Allowed)"
                : `Press Spacebar to ${status === "focus" ? "Pause" : "Resume"}`}
            </p>
          </div>

          {/* Control Buttons */}
          <div className="flex items-center gap-4 pt-8">
            <button
              onClick={triggerTimerState}
              disabled={examModeEnabled}
              className={`w-14 h-14 rounded-full border flex items-center justify-center transition-all focus-visible:ring-2 ${examModeEnabled
                ? "bg-red-500/10 border-red-500/30 text-red-400/60 cursor-not-allowed"
                : status === "paused"
                  ? "bg-amber-500/20 border-amber-500/40 text-amber-300 hover:bg-amber-500/30 cursor-pointer"
                  : "bg-zinc-900 border-zinc-800 text-white hover:bg-zinc-800 cursor-pointer"
                }`}
              title={examModeEnabled ? "🔒 Timers Locked (Exam Mode Active)" : status === "focus" ? "Pause Zone" : "Resume Zone"}
            >
              {examModeEnabled ? (
                <Lock className="w-5 h-5 text-red-400" />
              ) : status === "focus" ? (
                <Pause className="w-6 h-6" />
              ) : (
                <Play className="w-6 h-6 fill-amber-300 ml-0.5" />
              )}
            </button>
            <Button
              onClick={handleCompleteEarly}
              size="lg"
              variant="primary"
              className="rounded-full px-8 cursor-pointer"
            >
              <CheckCircle className="w-5 h-5" />
              Complete Zone
            </Button>
          </div>
        </div>

        {/* Exit panel */}
        <div className="absolute bottom-4 md:bottom-8 flex flex-col items-center gap-3">
          <button
            onClick={toggleMonkMode}
            className="flex items-center gap-2 text-xs font-semibold text-zinc-500 hover:text-red-400 transition-colors bg-zinc-950 border border-zinc-900 px-4 py-2.5 rounded-full cursor-pointer"
          >
            <EyeOff className="w-4 h-4" />
            Disable Monk Interface
          </button>
          <p className="text-[10px] text-zinc-700">All dashboard panels and social stats are currently hidden.</p>
        </div>
      </div>
    );
  }

  // Active or selected chapter subchapters
  const currentChapterList = getSyllabusForSubject(selectedSubject, examType);
  const currentChapterObj = currentChapterList.find((c) => c.name === selectedChapter);


  return (
    <WorkspaceLayout title="Focus Space">
      {/* Emergency Cooling Lockdown Banner */}
      <AnimatePresence>
        {isCoolingActive && (
          <motion.div
            initial={{ opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            className="mb-6 p-4 rounded-2xl bg-gradient-to-r from-cyan-950/80 via-slate-900/90 to-blue-950/80 border-2 border-cyan-500/40 shadow-[0_0_30px_rgba(6,182,212,0.2)] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
          >
            <div className="flex items-center gap-3.5">
              <div className="w-10 h-10 rounded-xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center shrink-0">
                <Snowflake className="w-5 h-5 text-cyan-300 animate-spin" style={{ animationDuration: "10s" }} />
              </div>
              <div className="space-y-0.5">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-black uppercase tracking-wider text-cyan-300">
                    Emergency Cooling Lockdown Active
                  </span>
                  <Badge variant="blue">Strict Whitelist Only</Badge>
                </div>
                <p className="text-xs text-zinc-300">
                  Session aborted during Exam Mode. Non-study browsing is restricted for another{" "}
                  <span className="font-mono font-bold text-cyan-200 text-sm">
                    {formatTime(coolingSecondsRemaining)}
                  </span>.
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
              <span className="text-xs font-mono text-cyan-400 font-bold px-3 py-1.5 rounded-lg bg-cyan-500/10 border border-cyan-500/20">
                ❄️ {formatTime(coolingSecondsRemaining)} remaining
              </span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

        {/* Main Countdown Timer display */}
        <Card variant="glass" className="lg:col-span-2 flex flex-col items-center justify-center text-center relative overflow-hidden min-h-[460px] p-6 sm:p-8">
          {status === "idle" ? (
            // Form to start session
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
              className="max-w-md w-full space-y-6"
            >
              <div className="space-y-1.5">
                <h2 className="text-2xl font-bold text-white tracking-tight flex items-center justify-center gap-2">
                  <Timer className="w-6 h-6 text-purple-400" />
                  Start New Focus Zone
                </h2>
                <p className="text-xs text-gray-400">Choose subject and duration parameters to begin.</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-left">
                {/* Subject selector */}
                <Select
                  label="Subject"
                  variant={getSubjectVariant(selectedSubject) as any}
                  options={subjects.map((sub) => ({ value: sub, label: sub }))}
                  value={selectedSubject}
                  onChange={(val) => handleSubjectChange(Array.isArray(val) ? val[0] || "Physics" : val)}
                />

                {/* Chapter selector with Vibrating/Blinking Error Shake */}
                <div className="relative">
                  <motion.div
                    key={shakeTrigger}
                    animate={
                      chapterError
                        ? {
                          x: [0, -14, 14, -12, 12, -8, 8, -4, 4, 0],
                          y: [0, -2, 2, -2, 2, 0],
                          transition: { duration: 0.55, ease: "easeInOut" },
                        }
                        : {}
                    }
                    className={`rounded-2xl transition-all duration-300 ${chapterError
                      ? "p-1 bg-red-500/10 border-2 border-red-500 ring-4 ring-red-500/30 shadow-[0_0_28px_rgba(239,68,68,0.55)] animate-pulse"
                      : "p-0"
                      }`}
                  >
                    <Select
                      label="Chapter"
                      variant={
                        chapterError
                          ? "accent"
                          : (getSubjectVariant(selectedSubject) as any)
                      }
                      options={currentChapterList.map((chap) => ({
                        value: chap.name,
                        label: chap.name,
                        description: `[ ${chap.weightage}% ] • ${chap.classLevel}`,
                      }))}
                      value={selectedChapter}
                      onChange={(val) => {
                        const chapName = Array.isArray(val) ? val[0] || "" : val;
                        if (chapName) {
                          handleChapterSelect(chapName, false);
                        } else {
                          setSelectedChapter("");
                        }
                      }}
                      searchable
                      placeholder="Select chapter..."
                    />
                  </motion.div>
                </div>

                {/* Subchapter selector */}
                {currentChapterObj && currentChapterObj.subchapters.length > 0 && (
                  <div className="sm:col-span-2">
                    <Select
                      label="Subchapter"
                      variant={getSubjectVariant(selectedSubject) as any}
                      options={currentChapterObj.subchapters.map((sub) => ({
                        value: sub.name,
                        label: sub.name,
                      }))}
                      value={selectedSubchapter}
                      onChange={(val) => setSelectedSubchapter(Array.isArray(val) ? val[0] || "" : val)}
                    />
                  </div>
                )}

                {/* Task Type selector */}
                <Select
                  label="Task Type"
                  options={
                    isNeet
                      ? [
                          { value: "Lecture", label: "Video Lecture" },
                          { value: "NCERT Reading", label: "NCERT Line-by-Line" },
                          { value: "PYQ", label: "PYQ Solving" },
                          { value: "Diagram", label: "Diagram / Labeling Practice" },
                          { value: "Revision", label: "Fact & Formula Recap" },
                          { value: "Test", label: "Mock Test" },
                        ]
                      : [
                          { value: "Lecture", label: "Video Lecture" },
                          { value: "PYQ", label: "PYQ Solving" },
                          { value: "Revision", label: "Formula Revision" },
                          { value: "Test", label: "Mock Test" },
                        ]
                  }
                  value={selectedType}
                  onChange={(val) => setSelectedType(Array.isArray(val) ? val[0] || "Lecture" : val)}
                />

                {/* Mode selector */}
                <Select
                  label="Focus Mode"
                  options={[
                    { value: "Pomodoro", label: "Pomodoro (50m)" },
                    { value: "DeepWork", label: "Deep Work (90m)" },
                    { value: "Custom", label: "Custom Timer" },
                  ]}
                  value={selectedMode}
                  onChange={(val) => setSelectedMode(val as SessionMode)}
                />
              </div>

              {selectedMode === "Custom" && (
                <div className="space-y-1.5 text-left">
                  <label className="text-xs font-semibold uppercase tracking-wider text-gray-400">Duration (minutes)</label>
                  <input
                    type="number"
                    min="1"
                    max="180"
                    value={customTime}
                    onChange={(e) => setCustomTime(parseInt(e.target.value) || 45)}
                    className="w-full glass-input px-3.5 py-2.5 text-xs text-white focus:outline-none"
                  />
                </div>
              )}

              <Button onClick={handleStart} variant="primary" size="lg" className="w-full cursor-pointer" disabled={isStarting}>
                <Play className="w-4 h-4 fill-white" />
                {isStarting ? "CONNECTING TO DATABASE..." : "INITIATE FOCUS ZONE"}
              </Button>
            </motion.div>
          ) : (
            // Active timer UI
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
              className="flex flex-col items-center space-y-6 max-w-sm w-full"
            >
              {/* Circular progress container */}
              <div className="relative w-48 h-48 sm:w-60 sm:h-60 flex items-center justify-center">
                <svg className="absolute w-full h-full transform -rotate-90" viewBox="0 0 224 224">
                  <circle
                    cx="112"
                    cy="112"
                    r="96"
                    className="stroke-white/[0.06]"
                    strokeWidth="8"
                    fill="transparent"
                  />
                  <circle
                    cx="112"
                    cy="112"
                    r="96"
                    className={`${status === "break" ? "stroke-emerald-400" : status === "paused" ? "stroke-amber-400" : "stroke-purple-500"} transition-all duration-1000`}
                    strokeWidth="8"
                    fill="transparent"
                    strokeDasharray={2 * Math.PI * 96}
                    strokeDashoffset={2 * Math.PI * 96 * (1 - progressPercent / 100)}
                    strokeLinecap="round"
                  />
                </svg>

                <div className="text-center z-10 space-y-1">
                  <span className={`text-4xl sm:text-5xl md:text-6xl font-black font-mono tabular-nums tracking-tight ${status === "paused" ? "text-amber-300" : "text-white"}`}>
                    {formatTime(timeLeft)}
                  </span>
                  <span className="text-[11px] text-purple-300 font-bold tracking-widest uppercase block pt-1">
                    {status === "break" ? "Break Time" : status === "paused" ? "Zone Paused" : "Focus Zone"}
                  </span>
                </div>
              </div>

              <div className="space-y-1 text-center">
                <h3 className="text-base font-bold text-white tracking-tight">
                  {activeSession?.subject} - {activeSession?.chapter}
                </h3>
                {activeSession?.subchapter && (
                  <p className="text-xs font-semibold text-cyan-300 font-mono">• {activeSession.subchapter}</p>
                )}
                <p className="text-xs text-gray-400">
                  Tasking: {activeSession?.taskType} ({mode} mode)
                </p>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-3 pt-2">
                <button
                  onClick={triggerTimerState}
                  disabled={examModeEnabled}
                  className={`w-12 h-12 rounded-full border flex items-center justify-center transition-all focus-visible:outline-none focus-visible:ring-2 ${examModeEnabled
                    ? "border-red-500/30 bg-red-500/10 text-red-400/60 cursor-not-allowed"
                    : "border-white/10 bg-white/[0.04] hover:bg-white/[0.08] text-white cursor-pointer focus-visible:ring-purple-500/50"
                    }`}
                  title={examModeEnabled ? "🔒 Timers Locked (Exam Mode Active)" : status === "focus" ? "Pause Zone (Spacebar)" : "Resume Zone"}
                >
                  {examModeEnabled ? (
                    <Lock className="w-5 h-5 text-red-400" />
                  ) : status === "focus" ? (
                    <Pause className="w-5 h-5" />
                  ) : (
                    <Play className="w-5 h-5 fill-white ml-0.5" />
                  )}
                </button>

                <Magnetic strength={0.25}>
                  <Button onClick={handleCompleteEarly} variant="primary" size="md" className="cursor-pointer">
                    <CheckCircle className="w-4 h-4" />
                    Complete Zone
                  </Button>
                </Magnetic>

                <button
                  onClick={() => {
                    if (examModeEnabled) {
                      setShowEmergencyModal(true);
                    } else {
                      abandonSession();
                    }
                  }}
                  className="w-12 h-12 rounded-full border border-white/10 bg-white/[0.04] hover:bg-white/[0.08] text-gray-400 hover:text-red-400 flex items-center justify-center transition-all cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-red-500/50"
                  title={examModeEnabled ? "Emergency Abort (Triggers 5-min Penalty)" : "Abandon Session"}
                >
                  {examModeEnabled ? (
                    <ShieldAlert className="w-5 h-5 text-red-400 hover:scale-110 transition-transform" />
                  ) : (
                    <RotateCcw className="w-5 h-5" />
                  )}
                </button>
              </div>
            </motion.div>
          )}
        </Card>

        {/* Sidebar Blocker details & Monk Mode Controls */}
        <div className="space-y-6">
          {/* Monk Mode Controller Card */}
          <Card variant="glass" className="space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Eye className="w-4.5 h-4.5 text-purple-400" /> Monk Interface
            </h3>
            <p className="text-xs text-gray-400 leading-relaxed">
              Disable all widgets, notifications, and menus. Leaves only the black screen focus timer to avoid visual distractions.
            </p>
            <Button
              onClick={toggleMonkMode}
              variant={monkModeEnabled ? "primary" : "secondary"}
              className="w-full cursor-pointer"
            >
              {monkModeEnabled ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              {monkModeEnabled ? "Interface Lock Enabled" : "Initiate Interface Lock"}
            </Button>
          </Card>

          {/* Web Blocker simulation */}
          <Card variant="glass" className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <AlertTriangle className="w-4.5 h-4.5 text-amber-400" /> Blocker Shield
              </h3>
              {examModeEnabled ? (
                <Badge variant="red">🔒 Exam Lockdown</Badge>
              ) : whitelistOnly ? (
                <Badge variant="purple">🛡️ Whitelist Only</Badge>
              ) : (
                <Badge variant="green">Active</Badge>
              )}
            </div>

            <p className="text-xs text-gray-400 leading-relaxed">
              {examModeEnabled
                ? "Exam Mode (Monk Lockdown) is active. Web browsing is strictly locked to Whitelisted Study Domains only, with emergency cooling penalty on abort."
                : whitelistOnly
                  ? "Whitelist-Only Mode is active. All web domains outside of approved study sites are blocked."
                  : "Web blocker simulation logs access attempts to social sites during focus sessions to degrade focus scores."}
            </p>

            <div className="p-3.5 bg-slate-900/60 border border-white/[0.08] rounded-xl text-xs space-y-2.5">
              <div className="flex justify-between text-gray-400 text-[10px] font-semibold uppercase tracking-wider">
                <span>Currently Blocked Domains</span>
                <span>{blockedWebsites.length} total</span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {blockedWebsites.slice(0, 3).map((site) => (
                  <Badge key={site} variant="red">
                    {site}
                  </Badge>
                ))}
                {blockedWebsites.length > 3 && (
                  <Badge variant="gray">
                    +{blockedWebsites.length - 3} more
                  </Badge>
                )}
              </div>
            </div>
          </Card>
        </div>
      </div>

      {/* RECENT STUDY SESSIONS HISTORY */}
      <div className="pt-6">
        <Card variant="glass" className="space-y-4">
          <div className="flex items-center justify-between border-b border-white/[0.08] pb-3">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-purple-400" /> STUDY SESSION HISTORY ({sessionHistory.length})
            </h3>
            <span className="text-[11px] text-emerald-400/90 font-mono font-bold flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              Cloud-Synced Database History
            </span>
          </div>

          {sessionHistory.length > 0 ? (
            <div className="space-y-3">
              {sessionHistory.map((sess) => {
                const timeInfo = getSessionTimeDetails(
                  sess.startTime,
                  sess.endTime,
                  sess.totalDurationMinutes,
                  sess.date,
                  isMounted
                );

                return (
                  <div
                    key={sess.id}
                    className="p-4 bg-slate-950/90 rounded-2xl border border-white/[0.08] hover:border-purple-500/30 transition-all space-y-3 shadow-lg shadow-black/40"
                  >
                    {/* Row 1: Header - Subject Tag, Chapter, Subchapter & Duration */}
                    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-white/[0.05] pb-2.5">
                      <div className="flex items-center gap-2 flex-wrap min-w-0">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                          sess.subject === "Physics"
                            ? "bg-cyan-500/15 text-cyan-300 border border-cyan-500/30"
                            : sess.subject === "Chemistry"
                              ? "bg-emerald-500/15 text-emerald-300 border border-emerald-500/30"
                              : sess.subject === "Botany"
                                ? "bg-emerald-500/15 text-emerald-300 border border-emerald-500/30"
                                : sess.subject === "Zoology"
                                  ? "bg-purple-500/15 text-purple-300 border border-purple-500/30"
                                  : "bg-purple-500/15 text-purple-300 border border-purple-500/30"
                        }`}>
                          {sess.subject}
                        </span>
                        <span className="font-bold text-white text-sm tracking-tight truncate">{sess.chapter}</span>
                        {sess.subchapter && (
                          <span className="text-xs text-cyan-300/90 font-mono font-medium truncate">• {sess.subchapter}</span>
                        )}
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <span className="text-xs font-bold text-emerald-400 font-mono px-2.5 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/25">
                          ⚡ {timeInfo.durationFormatted}
                        </span>
                        <button
                          onClick={() => deleteCompletedSession(sess.id)}
                          title="Delete session"
                          className="p-1 text-gray-400 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition-all border border-transparent hover:border-rose-500/20 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    {/* Creative Time Ribbon: Clock interval, Time-of-Day, and Recency */}
                    <div className="p-2 rounded-xl bg-gradient-to-r from-white/[0.04] via-white/[0.02] to-transparent border border-white/[0.06] flex flex-wrap items-center justify-between gap-2 text-xs">
                      {/* Left: Clock Interval & Period Icon */}
                      <div className="flex items-center gap-2 flex-wrap">
                        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-black/50 border border-white/[0.08] font-mono text-white text-xs font-bold shadow-inner">
                          <Clock className="w-3.5 h-3.5 text-purple-400" />
                          <span>{timeInfo.startFormatted || "--:--"}</span>
                          {timeInfo.endFormatted && (
                            <>
                              <ArrowRight className="w-3 h-3 text-gray-500" />
                              <span className="text-cyan-300">{timeInfo.endFormatted}</span>
                            </>
                          )}
                        </div>

                        {/* Time of Day Period Badge */}
                        <div className={`px-2 py-0.5 rounded-full text-[10px] font-bold border flex items-center gap-1 ${timeInfo.timeOfDay.badgeClass}`}>
                          <span>{timeInfo.timeOfDay.icon}</span>
                          <span>{timeInfo.timeOfDay.label}</span>
                        </div>
                      </div>

                      {/* Right: Date & Relative Age */}
                      <div className="flex items-center gap-1.5 text-[11px] font-mono text-gray-400">
                        <span>{sess.date}</span>
                        <span className="text-white/20">•</span>
                        <span className="text-purple-300 font-semibold">{timeInfo.relativeAge}</span>
                      </div>
                    </div>

                    {/* Row 2: Minimal Metrics & Attributes Strip */}
                    <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-xs">
                      {/* Type & Mode */}
                      <div className="p-2 rounded-lg bg-white/[0.03] border border-white/[0.05] space-y-0.5">
                        <span className="text-[9px] font-semibold text-gray-500 uppercase tracking-wider block">Type & Mode</span>
                        <span className="font-bold text-purple-300 text-[11px] block truncate">{sess.taskType} ({sess.mode})</span>
                      </div>

                      {/* Productivity */}
                      <div className="p-2 rounded-lg bg-white/[0.03] border border-white/[0.05] space-y-0.5">
                        <span className="text-[9px] font-semibold text-gray-500 uppercase tracking-wider block">Productivity</span>
                        <span className="font-bold text-amber-300 text-[11px] block">★ {sess.productivityRating || 5} / 5</span>
                      </div>

                      {/* Difficulty */}
                      <div className="p-2 rounded-lg bg-white/[0.03] border border-white/[0.05] space-y-0.5">
                        <span className="text-[9px] font-semibold text-gray-500 uppercase tracking-wider block">Difficulty</span>
                        <span className="font-bold text-cyan-300 text-[11px] block truncate">{sess.difficulty || "Medium"}</span>
                      </div>

                      {/* Mood & Focus Score */}
                      <div className="p-2 rounded-lg bg-white/[0.03] border border-white/[0.05] space-y-0.5">
                        <span className="text-[9px] font-semibold text-gray-500 uppercase tracking-wider block">Mood & Focus</span>
                        <span className="font-bold text-white text-[11px] block truncate">{sess.mood || "Focused"} • {sess.focusScore ?? 0}%</span>
                      </div>

                      {/* Goal Completion */}
                      <div className="p-2 rounded-lg bg-white/[0.03] border border-white/[0.05] space-y-0.5 col-span-2 sm:col-span-1">
                        <span className="text-[9px] font-semibold text-gray-500 uppercase tracking-wider block">Goal Met</span>
                        <span className={`font-bold text-[11px] block ${sess.wasGoalCompleted !== false ? "text-emerald-400" : "text-rose-400"}`}>
                          {sess.wasGoalCompleted !== false ? "✓ Goal Met" : "✕ Partial"}
                        </span>
                      </div>
                    </div>

                    {/* Row 3: Session Notes (if present) */}
                    {sess.notes && (
                      <div className="pt-0.5">
                        <p className="text-[11px] text-gray-400 italic bg-white/[0.02] p-2 rounded-lg border border-white/[0.04]">
                          {`"${sess.notes}"`}
                        </p>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          ) : (
            <p className="text-xs text-gray-400 py-4 text-center">No completed study sessions yet. Initiate a focus zone to log session history!</p>
          )}
        </Card>
      </div>

      {/* Emergency Exit Confirmation Modal (Exam Mode Lockdown) */}
      <AnimatePresence>
        {showEmergencyModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 16 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 16 }}
              transition={{ duration: 0.2 }}
              className="relative max-w-md w-full bg-slate-950 border-2 border-red-500/50 rounded-2xl p-6 shadow-2xl shadow-red-950/60 space-y-5"
            >
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-red-500/20 border border-red-500/40 flex items-center justify-center shrink-0">
                  <ShieldAlert className="w-6 h-6 text-red-400 animate-pulse" />
                </div>
                <div>
                  <h3 className="text-lg font-black text-white tracking-tight">
                    Emergency Exit Lockdown
                  </h3>
                  <p className="text-xs text-red-400 font-semibold">
                    Exam Mode (Monk Lockdown) is Active
                  </p>
                </div>
              </div>

              <div className="p-4 bg-red-950/30 border border-red-500/20 rounded-xl space-y-2.5 text-xs text-zinc-300">
                <p className="font-bold text-red-200 flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
                  Abandoning this session triggers an immediate penalty:
                </p>
                <ul className="space-y-1.5 text-zinc-300 text-xs pl-1">
                  <li className="flex items-start gap-2">
                    <span className="text-red-400 font-bold">•</span>
                    <span>
                      <strong className="text-white">5-Minute Cooling Lockdown:</strong> Browser-wide blocking remains active.
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-red-400 font-bold">•</span>
                    <span>
                      <strong className="text-white">Strict Whitelist Only:</strong> Only approved study domains (e.g. Khan Academy, PhysicsWallah) are accessible.
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-red-400 font-bold">•</span>
                    <span>
                      <strong className="text-white">Unskippable:</strong> The penalty timer cannot be bypassed until 5 minutes expire.
                    </span>
                  </li>
                </ul>
              </div>

              <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
                <Button
                  onClick={() => setShowEmergencyModal(false)}
                  variant="secondary"
                  className="w-full sm:flex-1 cursor-pointer order-2 sm:order-1"
                >
                  Stay Focused (Resume)
                </Button>
                <Button
                  onClick={() => {
                    setShowEmergencyModal(false);
                    triggerEmergencyExit();
                  }}
                  variant="danger"
                  className="w-full sm:flex-1 cursor-pointer order-1 sm:order-2"
                >
                  Confirm Exit & Lock
                </Button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </WorkspaceLayout>
  );
}

