"use client";

import { useEffect, useState, useMemo } from "react";
import Link from "next/link";
import { WorkspaceLayout } from "@/components/workspace-layout";
import { Card, CardHeader, CardBody } from "@/components/ui/card";
import { Badge, Button } from "@/components/ui/controls";
import { useMistakeStore } from "@/store/use-mistake-store";
import {
  TrendingUp,
  BarChart,
  PieChart as PieIcon,
  Flame,
  Award,
  Activity,
  AlertCircle,
  Timer,
  Video,
  ShieldCheck,
  CheckCircle2,
  XCircle,
  Clock,
  Sparkles,
  ExternalLink,
  BookOpen,
} from "lucide-react";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart as RechartsBarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  PieChart,
  Pie,
  Cell,
  Legend,
} from "recharts";

import { useStudyStore } from "@/store/use-study-store";
import { analyticsService, ErrorClassificationPoint, TrendTimeframe } from "@/services/analyticsService";
import { useIsClient } from "@/hooks/use-is-client";
import { useExam } from "@/hooks/use-exam";
import { soundManager } from "@/lib/sound-manager";
import { getCurrentUserId } from "@/lib/supabase/client";
import { youtubeGuardService, YouTubeAccessLogEntry } from "@/services/youtubeGuardService";

export default function AnalyticsPage() {
  const { mistakes, syllabus } = useMistakeStore();
  const { sessionHistory = [], status: studyStatus } = useStudyStore();
  const { examType, isNeet, config } = useExam();
  const isMounted = useIsClient();
  const [timeframe, setTimeframe] = useState<TrendTimeframe>("7d");

  // YouTube Study Content Guard Analytics State
  const [ytAnalytics, setYtAnalytics] = useState<{
    totalStudySeconds: number;
    videosWatchedCount: number;
    subjectBreakdown: Record<string, number>;
    blockedAttemptsCount: number;
    recentAccessLogs: YouTubeAccessLogEntry[];
  }>({
    totalStudySeconds: 0,
    videosWatchedCount: 0,
    subjectBreakdown: {},
    blockedAttemptsCount: 0,
    recentAccessLogs: [],
  });
  const [ytLoading, setYtLoading] = useState(true);

  useEffect(() => {
    const uid = getCurrentUserId();
    async function loadYtAnalytics() {
      try {
        setYtLoading(true);
        const res = await fetch(`/api/youtube/logs?userId=${encodeURIComponent(uid || "")}`);
        if (res.ok) {
          const json = await res.json();
          if (json.success) {
            setYtAnalytics({
              totalStudySeconds: json.totalStudySeconds || 0,
              videosWatchedCount: json.videosWatchedCount || 0,
              subjectBreakdown: json.subjectBreakdown || {},
              blockedAttemptsCount: json.blockedAttemptsCount || 0,
              recentAccessLogs: json.recentAccessLogs || [],
            });
            return;
          }
        }
        // Fallback to local client service if fetch is unconfigured
        if (uid) {
          const localData = await youtubeGuardService.getStudyAnalytics(uid);
          setYtAnalytics(localData);
        }
      } catch (err) {
        console.warn("Failed to load YouTube guard analytics:", err);
      } finally {
        setYtLoading(false);
      }
    }

    loadYtAnalytics();
  }, []);

  const formatWatchDuration = (seconds: number) => {
    if (!seconds || seconds <= 0) return "0 min";
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.round((seconds % 3600) / 60);
    if (hrs > 0) return `${hrs}h ${mins}m`;
    return `${mins} min`;
  };

  const ytSubjectChartData = useMemo(() => {
    const breakdown = ytAnalytics.subjectBreakdown;
    const subjects = ["Physics", "Chemistry", "Mathematics", "Biology", "English"];
    const colors: Record<string, string> = {
      Physics: "#3b82f6",
      Chemistry: "#10b981",
      Mathematics: "#f59e0b",
      Biology: "#ec4899",
      English: "#8b5cf6",
    };

    return subjects.map((sub) => {
      const sec = breakdown[sub] || 0;
      const mins = Math.round(sec / 60);
      return {
        subject: sub,
        minutes: mins,
        hours: Number((sec / 3600).toFixed(1)),
        color: colors[sub] || "#6366f1",
      };
    });
  }, [ytAnalytics.subjectBreakdown]);

  const metrics = useMemo(() => {
    return analyticsService.calculateAnalyticsMetrics(sessionHistory, mistakes, syllabus, timeframe, examType);
  }, [sessionHistory, mistakes, syllabus, timeframe, examType]);

  const {
    consistencyScore,
    strongestSubject,
    weakestSubject,
    projectedCompletionDays,
    trendData,
    errorData,
    compareChartData,
    hasData,
  } = metrics;

  const validSessionsCount = sessionHistory.filter(
    (s) => s && s.completed !== false && Number(s.totalDurationMinutes || 0) > 0
  ).length;

  return (
    <WorkspaceLayout title="Analytics & Trends">
      {/* Metric Indicators Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Consistency metric */}
        <Card variant="glass">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <span className="text-xs font-semibold text-gray-400 uppercase tracking-wider block">Consistency Score</span>
              <span className="text-2xl font-black text-white font-mono">{consistencyScore} / 100</span>
              <p className="text-xs text-purple-400 font-semibold">
                {consistencyScore >= 80 ? "Exceptional study habits" : consistencyScore > 0 ? "Building consistency" : "Start your first session"}
              </p>
            </div>
            <div className="w-12 h-12 rounded-2xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400 shrink-0 shadow-inner">
              <Activity className="w-6 h-6" />
            </div>
          </div>
        </Card>

        {/* Strongest Subject */}
        <Card variant="glass">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <span className="text-xs font-semibold text-gray-400 uppercase tracking-wider block">Strongest Subject</span>
              <span className="text-2xl font-black text-emerald-400">{strongestSubject}</span>
              <p className="text-xs text-emerald-400/80 font-semibold">Highest syllabus progress</p>
            </div>
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 shrink-0 shadow-inner">
              <Award className="w-6 h-6" />
            </div>
          </div>
        </Card>

        {/* Weakest Subject */}
        <Card variant="glass">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <span className="text-xs font-semibold text-gray-400 uppercase tracking-wider block">Weakest Focus</span>
              <span className="text-2xl font-black text-amber-400">{weakestSubject}</span>
              <p className="text-xs text-amber-400/80 font-semibold">Requires review sprints</p>
            </div>
            <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 shrink-0 shadow-inner">
              <Flame className="w-6 h-6" />
            </div>
          </div>
        </Card>

        {/* Forecast syllabus completion */}
        <Card variant="glass">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <span className="text-xs font-semibold text-gray-400 uppercase tracking-wider block">Projected Completion</span>
              <span className="text-2xl font-black text-white font-mono">
                {projectedCompletionDays > 0 ? `${projectedCompletionDays} Days` : "N/A"}
              </span>
              <p className="text-xs text-blue-400 font-semibold">Based on current study pace</p>
            </div>
            <div className="w-12 h-12 rounded-2xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400 shrink-0 shadow-inner">
              <TrendingUp className="w-6 h-6" />
            </div>
          </div>
        </Card>
      </div>

      {/* Main Charts area */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Trend Area chart */}
        <Card variant="glass" className="lg:col-span-2 space-y-4">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-purple-400" />
                Daily Study Trend
              </h2>
              <p className="text-xs text-gray-400 mt-0.5">
                {timeframe === "7d" && "Total deep work hours logged over the past 7 days"}
                {timeframe === "30d" && "Total deep work hours logged over the past 30 days"}
                {timeframe === "90d" && "3-day aggregated study velocity over 90 days"}
                {timeframe === "1y" && "Monthly aggregated deep work hours over 12 months"}
              </p>
            </div>

            {/* Timeframe Selector Pills */}
            <div className="flex items-center gap-1 bg-slate-900/80 p-1 rounded-xl border border-white/10">
              {(["7d", "30d", "90d", "1y"] as TrendTimeframe[]).map((tf) => (
                <button
                  key={tf}
                  onClick={() => {
                    soundManager.play("select");
                    setTimeframe(tf);
                  }}
                  className={`px-2.5 py-1 text-[11px] font-bold rounded-lg transition-all cursor-pointer ${timeframe === tf
                      ? "bg-purple-600 text-white shadow-md shadow-purple-900/40"
                      : "text-gray-400 hover:text-white hover:bg-white/5"
                    }`}
                >
                  {tf.toUpperCase()}
                </button>
              ))}
            </div>
          </div>

          <div className="h-72 w-full relative">
            {isMounted ? (
              <>
                <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
                  <AreaChart data={trendData} margin={{ top: 10, right: 5, left: -20, bottom: 0 }}>
                    <defs>
                      <linearGradient id="hoursG" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.35} />
                        <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <XAxis dataKey="date" stroke="#6b7280" fontSize={11} tickLine={false} />
                    <YAxis stroke="#6b7280" fontSize={11} tickLine={false} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "#0f1118",
                        borderColor: "rgba(255,255,255,0.12)",
                        borderRadius: 12,
                        fontSize: 12,
                        boxShadow: "0 8px 32px rgba(0,0,0,0.5)",
                      }}
                      labelStyle={{ color: "#fff", fontWeight: "bold" }}
                      itemStyle={{ color: "#c4b5fd" }}
                      formatter={(val: unknown) => [`${val} hrs`, "Study Duration"]}
                    />
                    <Area
                      type="monotone"
                      dataKey="Hours"
                      stroke="#8b5cf6"
                      strokeWidth={2.5}
                      fillOpacity={1}
                      fill="url(#hoursG)"
                      name="Study Hours"
                      dot={{ fill: "#8b5cf6", strokeWidth: 0, r: 3 }}
                      activeDot={{ r: 6, fill: "#a78bfa" }}
                    />
                  </AreaChart>
                </ResponsiveContainer>

                {validSessionsCount === 0 && (
                  <div className="absolute inset-0 bg-slate-950/40 backdrop-blur-[2px] rounded-2xl flex flex-col items-center justify-center text-center p-4 border border-dashed border-white/10">
                    <AlertCircle className="w-8 h-8 text-purple-400 mb-2 animate-bounce" />
                    <p className="text-sm font-bold text-white">No completed study sessions yet.</p>
                    <p className="text-xs text-gray-400 mt-1 max-w-xs">
                      Log your first study session to populate live trends and analytics.
                    </p>
                    <Link href="/study" className="mt-3">
                      <Button size="sm" variant="primary">
                        <Timer className="w-3.5 h-3.5" /> Start Focus Session
                      </Button>
                    </Link>
                  </div>
                )}
              </>
            ) : (
              <div className="h-72 w-full rounded-2xl bg-white/[0.02] animate-pulse" />
            )}
          </div>
        </Card>

        {/* Subject progress bar charts */}
        <Card variant="glass" className="space-y-4">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <BarChart className="w-4 h-4 text-blue-400" />
              Subject Comparison
            </h2>
            <p className="text-xs text-gray-400 mt-0.5">Average syllabus completion & PYQs solved</p>
          </div>

          <div className="h-72 w-full">
            {isMounted ? (
              <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
                <RechartsBarChart data={compareChartData} margin={{ top: 10, right: 5, left: -20, bottom: 5 }}>
                  <XAxis dataKey="name" stroke="#6b7280" fontSize={11} tickLine={false} />
                  <YAxis stroke="#6b7280" fontSize={11} tickLine={false} />
                  <Tooltip
                    contentStyle={{ backgroundColor: "#0f1118", borderColor: "rgba(255,255,255,0.12)", borderRadius: 12, fontSize: 12, boxShadow: "0 8px 32px rgba(0,0,0,0.5)" }}
                    labelStyle={{ color: "#fff", fontWeight: "bold" }}
                    cursor={{ fill: "rgba(255,255,255,0.04)" }}
                  />
                  <Legend wrapperStyle={{ fontSize: 11, color: "#9ca3af" }} />
                  <Bar dataKey="Completion %" fill="#8b5cf6" radius={[6, 6, 0, 0]} />
                  <Bar dataKey="PYQs Solved" fill="#3b82f6" radius={[6, 6, 0, 0]} />
                </RechartsBarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-72 w-full rounded-2xl bg-white/[0.02] animate-pulse" />
            )}
          </div>
        </Card>
      </div>

      {/* Errors breakdown pie chart */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Pie chart */}
        <Card variant="glass" className="flex flex-col justify-between space-y-4 lg:col-span-1">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <PieIcon className="w-4 h-4 text-purple-400" /> Error Classifications
            </h2>
            <p className="text-xs text-gray-400 mt-0.5">Frequency breakdown of error types logged</p>
          </div>

          <div className="h-44 flex items-center justify-center relative">
            {isMounted ? (
              <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
                <PieChart>
                  <Pie
                    data={errorData}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={68}
                    paddingAngle={4}
                    dataKey="value"
                    strokeWidth={0}
                  >
                    {errorData.map((entry: ErrorClassificationPoint, index: number) => (
                      <Cell key={`cell-${index}`} fill={entry.color} opacity={0.85} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{ backgroundColor: "#0f1118", borderColor: "rgba(255,255,255,0.12)", borderRadius: 12, fontSize: 11 }}
                    labelStyle={{ color: "#fff", fontWeight: "bold" }}
                  />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-44 w-full rounded-full bg-white/[0.02] animate-pulse" />
            )}
          </div>

          <div className="space-y-1.5 text-xs">
            {errorData.map((d: ErrorClassificationPoint) => (
              <div key={d.name} className="flex justify-between items-center px-3 py-2 rounded-xl bg-white/[0.03] border border-white/[0.08] hover:border-white/[0.15] transition-all">
                <span className="flex items-center gap-2 text-gray-300 font-medium">
                  <span className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: d.color }} />
                  {d.name}
                </span>
                <span className="font-bold font-mono text-white">{d.value}</span>
              </div>
            ))}
          </div>
        </Card>

        {/* Detailed reports summary */}
        <Card variant="glass" className="lg:col-span-2 space-y-4 flex flex-col justify-between">
          <div>
            <h2 className="text-base font-bold text-white tracking-tight">Syllabus Completion Projected Forecast</h2>
            <p className="text-xs text-gray-400 mt-0.5">Heuristics-based diagnostic report</p>
          </div>

          <div className="space-y-3.5 text-xs leading-relaxed flex-1">
            <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-xl space-y-1.5 shadow-inner">
              <span className="text-emerald-400 font-extrabold block uppercase tracking-wider text-[10px]">Strongest: {strongestSubject}</span>
              <p className="text-gray-300 leading-relaxed">
                {isNeet
                  ? `${strongestSubject} shows the highest syllabus progress. NCERT mastery and high solved PYQ count in core chapters provide a solid 360-mark foundation. Continue daily revision to lock in memory.`
                  : `${strongestSubject} chapters have the highest completion metrics. Core topics are systematically mapped with high solved PYQ count. Keep using these subjects to balance your daily study streaks.`}
              </p>
            </div>

            <div className="p-4 bg-amber-500/10 border border-amber-500/20 rounded-xl space-y-1.5 shadow-inner">
              <span className="text-amber-400 font-extrabold block uppercase tracking-wider text-[10px]">Weakest Focus: {weakestSubject}</span>
              <p className="text-gray-300 leading-relaxed">
                {isNeet
                  ? `${weakestSubject} currently has lower relative completion. Schedule dedicated 90-minute Deep Work blocks to work through NCERT line-by-line questions and high-yield PYQs.`
                  : `${weakestSubject} has lower relative completion. Focus on high-weightage chapters next; schedule a dedicated 90-minute Deep Work session to watch lectures on key problem-solving techniques.`}
              </p>
            </div>

            <p className="text-[11px] text-gray-400 leading-relaxed">
              FocusForge analyzes your study consistency weights daily across your {config.displayName} track. Ensure you keep logged details in sync for optimum forecasts.
            </p>
          </div>
        </Card>
      </div>

      {/* YouTube Study Content Guard - Verified Lecture Analytics & Compliance */}
      <div className="space-y-4 pt-4 border-t border-white/10">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wider uppercase bg-red-500/10 border border-red-500/30 text-red-400">
                <Video className="w-3 h-3 text-red-400" /> YouTube Content Guard
              </span>
              <span
                className={`flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-bold tracking-wider uppercase border ${
                  studyStatus === "focus"
                    ? "bg-emerald-500/15 border-emerald-500/30 text-emerald-300"
                    : "bg-slate-800 border-white/10 text-gray-400"
                }`}
              >
                <span
                  className={`w-1.5 h-1.5 rounded-full ${
                    studyStatus === "focus" ? "bg-emerald-400 animate-ping" : "bg-gray-500"
                  }`}
                />
                {studyStatus === "focus" ? "Enforcing Master Rule (Active Focus)" : "Standby (Normal YouTube)"}
              </span>
            </div>
            <h2 className="text-xl font-bold text-white flex items-center gap-2 tracking-tight">
              Verified Academic Lecture Analytics & Distraction Defense
            </h2>
            <p className="text-xs text-gray-400 mt-0.5">
              Autonomous multi-signal verification across JEE, NEET & CBSE Class 12 syllabi with zero non-study leakage.
            </p>
          </div>

          <Link href="/blocker">
            <Button size="sm" variant="secondary" className="text-xs">
              <ShieldCheck className="w-3.5 h-3.5 text-purple-400" />
              Configure Guard & Channels
            </Button>
          </Link>
        </div>

        {/* 4 Quick Stat Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card variant="glass" className="p-4 border-white/10">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <span className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider block">
                  Verified Watch Time
                </span>
                <span className="text-2xl font-black text-white font-mono">
                  {formatWatchDuration(ytAnalytics.totalStudySeconds)}
                </span>
                <p className="text-[11px] text-emerald-400 font-semibold">
                  {ytAnalytics.totalStudySeconds > 0 ? "Educational focus credit" : "Awaiting first verified lecture"}
                </p>
              </div>
              <div className="w-11 h-11 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 shrink-0">
                <Clock className="w-5 h-5" />
              </div>
            </div>
          </Card>

          <Card variant="glass" className="p-4 border-white/10">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <span className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider block">
                  Lectures Permitted
                </span>
                <span className="text-2xl font-black text-purple-400 font-mono">
                  {ytAnalytics.videosWatchedCount}
                </span>
                <p className="text-[11px] text-purple-400/80 font-semibold">Syllabus-aligned videos</p>
              </div>
              <div className="w-11 h-11 rounded-xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400 shrink-0">
                <CheckCircle2 className="w-5 h-5" />
              </div>
            </div>
          </Card>

          <Card variant="glass" className="p-4 border-white/10">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <span className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider block">
                  Distractions Deflected
                </span>
                <span className="text-2xl font-black text-rose-400 font-mono">
                  {ytAnalytics.blockedAttemptsCount}
                </span>
                <p className="text-[11px] text-rose-400/80 font-semibold">Gaming, vlogs & Shorts blocked</p>
              </div>
              <div className="w-11 h-11 rounded-xl bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-rose-400 shrink-0">
                <XCircle className="w-5 h-5" />
              </div>
            </div>
          </Card>

          <Card variant="glass" className="p-4 border-white/10">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <span className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider block">
                  Master Rule Status
                </span>
                <span
                  className={`text-lg font-black ${
                    studyStatus === "focus" ? "text-emerald-400" : "text-gray-300"
                  }`}
                >
                  {studyStatus === "focus" ? "ACTIVE FOCUS" : "UNRESTRICTED"}
                </span>
                <p className="text-[11px] text-gray-400 font-medium">
                  {studyStatus === "focus" ? "YouTube filtered & guarded" : "YouTube normal outside study"}
                </p>
              </div>
              <div className="w-11 h-11 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400 shrink-0">
                <ShieldCheck className="w-5 h-5" />
              </div>
            </div>
          </Card>
        </div>

        {/* 2-Column Visual Charts & Realtime Activity Log */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Column 1: Subject-wise Verified Study Distribution */}
          <Card variant="glass" className="p-5 space-y-4">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-purple-400" />
                Verified Study by Academic Subject
              </h3>
              <p className="text-xs text-gray-400 mt-0.5">
                Distribution of verified video watch duration across syllabi
              </p>
            </div>

            <div className="space-y-3 pt-1">
              {ytSubjectChartData.map((item) => (
                <div key={item.subject} className="space-y-1">
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-semibold text-gray-300 flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }} />
                      {item.subject}
                    </span>
                    <span className="font-mono text-gray-400">
                      {item.minutes > 0 ? `${item.minutes}m (${item.hours}h)` : "0 min"}
                    </span>
                  </div>
                  <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden border border-white/5">
                    <div
                      className="h-full rounded-full transition-all duration-500"
                      style={{
                        backgroundColor: item.color,
                        width: `${
                          ytAnalytics.totalStudySeconds > 0
                            ? Math.min(100, Math.round(((item.minutes * 60) / ytAnalytics.totalStudySeconds) * 100))
                            : 0
                        }%`,
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>

            <div className="pt-2 border-t border-white/5 text-[11px] text-gray-400 flex items-center justify-between">
              <span>Syllabus Taxonomy:</span>
              <span className="text-purple-400 font-semibold">JEE • NEET • CBSE 12</span>
            </div>
          </Card>

          {/* Column 2: Live Activity & Access Log Stream */}
          <Card variant="glass" className="lg:col-span-2 p-5 space-y-4 flex flex-col justify-between">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-emerald-400" />
                  Recent Study & Defense Stream
                </h3>
                <p className="text-xs text-gray-400 mt-0.5">
                  Live verification audit trail during active study sessions
                </p>
              </div>
              <Badge variant="purple" className="text-[10px] font-mono">
                {ytAnalytics.recentAccessLogs.length} Events Logged
              </Badge>
            </div>

            {ytAnalytics.recentAccessLogs.length > 0 ? (
              <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1">
                {ytAnalytics.recentAccessLogs.slice(0, 6).map((log) => {
                  const isAllowed = log.decision === "ALLOW";
                  return (
                    <div
                      key={log.id}
                      className={`p-3 rounded-xl border transition-all flex items-center justify-between gap-3 ${
                        isAllowed
                          ? "bg-emerald-500/5 border-emerald-500/20 hover:border-emerald-500/30"
                          : "bg-rose-500/5 border-rose-500/20 hover:border-rose-500/30"
                      }`}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div
                          className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                            isAllowed ? "bg-emerald-500/15 text-emerald-400" : "bg-rose-500/15 text-rose-400"
                          }`}
                        >
                          {isAllowed ? <CheckCircle2 className="w-4 h-4" /> : <XCircle className="w-4 h-4" />}
                        </div>
                        <div className="min-w-0">
                          <p className="text-xs font-semibold text-white truncate max-w-md">
                            {log.title || "YouTube Content"}
                          </p>
                          <div className="flex items-center gap-2 text-[10px] text-gray-400 mt-0.5">
                            {log.channelName && <span>{log.channelName}</span>}
                            {log.subject && (
                              <span className="px-1.5 py-0.2 rounded bg-white/10 text-gray-300 font-medium">
                                {log.subject}
                              </span>
                            )}
                            {log.topic && <span className="truncate max-w-xs">{log.topic}</span>}
                          </div>
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider block ${
                            isAllowed
                              ? "bg-emerald-500/20 text-emerald-300"
                              : "bg-rose-500/20 text-rose-300"
                          }`}
                        >
                          {isAllowed ? "VERIFIED" : "BLOCKED"}
                        </span>
                        <span className="text-[10px] text-gray-400 font-mono mt-0.5 block">
                          {isAllowed
                            ? log.watchDurationSeconds > 0
                              ? formatWatchDuration(log.watchDurationSeconds)
                              : "Just opened"
                            : "Intercepted"}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="p-8 rounded-2xl bg-slate-900/40 border border-dashed border-white/10 text-center flex flex-col items-center justify-center space-y-2">
                <Video className="w-8 h-8 text-purple-400/80 mb-1" />
                <p className="text-xs font-bold text-white">No YouTube study activity recorded yet.</p>
                <p className="text-[11px] text-gray-400 max-w-md">
                  During any active Focus session, visit YouTube to watch relevant lectures on Physics, Chemistry, Math, Biology, or English. FocusForge will automatically permit and credit study time while deflecting distractions.
                </p>
                <div className="flex items-center gap-2 pt-2">
                  <Link href="/study">
                    <Button size="sm" variant="primary" className="text-xs">
                      <Timer className="w-3.5 h-3.5" /> Start Focus Session
                    </Button>
                  </Link>
                  <Link href="/blocker">
                    <Button size="sm" variant="secondary" className="text-xs">
                      <ExternalLink className="w-3.5 h-3.5" /> Open Guard Setup
                    </Button>
                  </Link>
                </div>
              </div>
            )}

            <div className="pt-2 text-[10px] text-gray-400 flex items-center justify-between border-t border-white/5">
              <span>Master Rule Protection:</span>
              <span className="text-gray-300">
                YouTube is never blocked outside active study sessions.
              </span>
            </div>
          </Card>
        </div>
      </div>
    </WorkspaceLayout>
  );
}
