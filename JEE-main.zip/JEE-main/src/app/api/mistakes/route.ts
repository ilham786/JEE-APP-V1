import { NextResponse } from "next/server";
import { createSupabaseServerClient } from "@/lib/supabase/server";

export async function GET() {
  try {
    const supabase = await createSupabaseServerClient();
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser();

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { data, error } = await supabase
      .from("mistake_journal")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false });

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    return NextResponse.json({ mistakes: data || [] });
  } catch (error: unknown) {
    const err = error as { message?: string };
    return NextResponse.json({ error: err.message || "Internal server error" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const supabase = await createSupabaseServerClient();
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser();

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const now = new Date().toISOString();

    const { data, error } = await supabase
      .from("mistake_journal")
      .upsert({
        id: body.id,
        user_id: user.id,
        subject: body.subject || "Physics",
        chapter: body.chapter || "",
        subchapter: body.subchapter || "",
        question_reference: body.title || body.questionReference || "Mistake Entry",
        error_category: body.errorCategory || body.errorType || "Conceptual",
        description: body.description || "",
        correct_solution: body.correctSolution || body.explanation || "",
        my_wrong_attempt: body.myWrongAttempt || "",
        tags: body.tags || [],
        difficulty: body.difficulty || "Medium",
        reviewed_count: Number(body.reviewedCount || body.timesRevised || 0),
        next_review_date: body.nextReviewDate ? body.nextReviewDate.split("T")[0] : null,
        completed: Boolean(body.completed || body.status === "completed"),
        updated_at: now,
      })
      .select()
      .single();

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    return NextResponse.json({ success: true, mistake: data });
  } catch (error: unknown) {
    const err = error as { message?: string };
    return NextResponse.json({ error: err.message || "Internal server error" }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const supabase = await createSupabaseServerClient();
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser();

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json({ error: "Missing mistake id parameter" }, { status: 400 });
    }

    const { error } = await supabase
      .from("mistake_journal")
      .delete()
      .eq("id", id)
      .eq("user_id", user.id);

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    return NextResponse.json({ success: true });
  } catch (error: unknown) {
    const err = error as { message?: string };
    return NextResponse.json({ error: err.message || "Internal server error" }, { status: 500 });
  }
}
