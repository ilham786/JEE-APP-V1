import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

export const dynamic = "force-dynamic";

export async function GET() {
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || "https://yhcowzmcvlsmcffbqryb.supabase.co";
  const supabaseKey =
    process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY ||
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ||
    "sb_publishable_F20ljth7U20W5cxupHPQiw_btbZuvGk";

  const client = createClient(supabaseUrl, supabaseKey);

  const checks: Record<string, { status: "pass" | "fail"; latencyMs?: number; error?: string }> = {};
  let overallHealthy = true;

  // 1. Supabase Connection & Profiles check
  const t0 = Date.now();
  try {
    const { error } = await client.from("profiles").select("id").limit(1);
    const latency = Date.now() - t0;
    if (error) {
      checks["supabase_profiles"] = { status: "fail", error: error.message, latencyMs: latency };
      overallHealthy = false;
    } else {
      checks["supabase_profiles"] = { status: "pass", latencyMs: latency };
    }
  } catch (err: unknown) {
    const e = err as { message?: string };
    checks["supabase_profiles"] = { status: "fail", error: e.message || String(err) };
    overallHealthy = false;
  }

  // 2. Study Sessions table check
  const t1 = Date.now();
  try {
    const { error } = await client.from("study_sessions").select("id").limit(1);
    const latency = Date.now() - t1;
    if (error) {
      checks["supabase_study_sessions"] = { status: "fail", error: error.message, latencyMs: latency };
      overallHealthy = false;
    } else {
      checks["supabase_study_sessions"] = { status: "pass", latencyMs: latency };
    }
  } catch (err: unknown) {
    const e = err as { message?: string };
    checks["supabase_study_sessions"] = { status: "fail", error: e.message || String(err) };
    overallHealthy = false;
  }

  // 3. Mistake Journal table check
  const t2 = Date.now();
  try {
    const { error } = await client.from("mistake_journal").select("id").limit(1);
    const latency = Date.now() - t2;
    if (error) {
      checks["supabase_mistake_journal"] = { status: "fail", error: error.message, latencyMs: latency };
      overallHealthy = false;
    } else {
      checks["supabase_mistake_journal"] = { status: "pass", latencyMs: latency };
    }
  } catch (err: unknown) {
    const e = err as { message?: string };
    checks["supabase_mistake_journal"] = { status: "fail", error: e.message || String(err) };
    overallHealthy = false;
  }

  // 4. Curriculum Progress table check
  const t3 = Date.now();
  try {
    const { error } = await client.from("jee_progress").select("id").limit(1);
    const latency = Date.now() - t3;
    if (error) {
      checks["supabase_curriculum_progress"] = { status: "fail", error: error.message, latencyMs: latency };
      overallHealthy = false;
    } else {
      checks["supabase_curriculum_progress"] = { status: "pass", latencyMs: latency };
    }
  } catch (err: unknown) {
    const e = err as { message?: string };
    checks["supabase_curriculum_progress"] = { status: "fail", error: e.message || String(err) };
    overallHealthy = false;
  }

  return NextResponse.json(
    {
      status: overallHealthy ? "healthy" : "degraded",
      timestamp: new Date().toISOString(),
      version: "2.5.0-multi-exam",
      platform: "FocusForge (JEE + NEET)",
      architecture: {
        auth: "Supabase GoTrue (One Canonical Auth System)",
        dataIsolation: "Strict Row-Level Security (auth.uid() = user_id)",
        storage: "User-Scoped Local Partitioning",
        realtime: "syncService (Single Source of Truth)",
      },
      checks,
    },
    { status: overallHealthy ? 200 : 503 }
  );
}
