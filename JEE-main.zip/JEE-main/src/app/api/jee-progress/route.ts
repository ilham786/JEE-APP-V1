import { NextResponse } from "next/server";
import { createSupabaseServerClient } from "@/lib/supabase/server";

export async function GET() {
  try {
    const supabase = await createSupabaseServerClient();
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser();

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { data, error } = await supabase
      .from("jee_progress")
      .select("*")
      .eq("user_id", user.id);

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    return NextResponse.json({ progress: data || [] });
  } catch (error: unknown) {
    const err = error as { message?: string };
    return NextResponse.json({ error: err.message || "Internal server error" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const supabase = await createSupabaseServerClient();
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser();

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const now = new Date().toISOString();

    if (Array.isArray(body.chapters)) {
      const rows = body.chapters.map((chap: Record<string, unknown>) => ({
        id: `${user.id}_${chap.id}`,
        user_id: user.id,
        subject: chap.subject || "Physics",
        chapter_id: chap.id,
        chapter_name: chap.name || chap.id,
        completed: Boolean(chap.completed || Number(chap.completion || 0) >= 100),
        progress_percent: Number(chap.completion || 0),
        solved_pyq_count: Number(chap.pyqsSolved || 0),
        total_pyq_count: Number(chap.pyqsTotal || 50),
        subchapters: (chap.weakTopics || []) as unknown as Record<string, unknown>,
        updated_at: now,
      }));

      const { data, error } = await supabase.from("jee_progress").upsert(rows).select();

      if (error) {
        return NextResponse.json({ error: error.message }, { status: 500 });
      }

      return NextResponse.json({ success: true, count: data?.length });
    } else {
      const { data, error } = await supabase
        .from("jee_progress")
        .upsert({
          id: `${user.id}_${body.id}`,
          user_id: user.id,
          subject: body.subject || "Physics",
          chapter_id: body.id,
          chapter_name: body.name || body.id,
          completed: Boolean(body.completed || Number(body.completion || 0) >= 100),
          progress_percent: Number(body.completion || 0),
          solved_pyq_count: Number(body.pyqsSolved || 0),
          total_pyq_count: Number(body.pyqsTotal || 50),
          subchapters: (body.weakTopics || []) as unknown as Record<string, unknown>,
          updated_at: now,
        })
        .select()
        .single();

      if (error) {
        return NextResponse.json({ error: error.message }, { status: 500 });
      }

      return NextResponse.json({ success: true, chapter: data });
    }
  } catch (error: unknown) {
    const err = error as { message?: string };
    return NextResponse.json({ error: err.message || "Internal server error" }, { status: 500 });
  }
}
