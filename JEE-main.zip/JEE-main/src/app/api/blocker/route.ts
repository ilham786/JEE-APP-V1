import { NextResponse } from "next/server";
import { createSupabaseServerClient } from "@/lib/supabase/server";

export async function GET() {
  try {
    const supabase = await createSupabaseServerClient();
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser();

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { data: sites, error: sitesErr } = await supabase
      .from("blocked_sites")
      .select("*")
      .eq("user_id", user.id);

    const { data: logs, error: logsErr } = await supabase
      .from("distraction_logs")
      .select("*")
      .eq("user_id", user.id)
      .order("timestamp", { ascending: false })
      .limit(50);

    if (sitesErr || logsErr) {
      return NextResponse.json({ error: sitesErr?.message || logsErr?.message }, { status: 500 });
    }

    return NextResponse.json({ sites: sites || [], logs: logs || [] });
  } catch (error: unknown) {
    const err = error as { message?: string };
    return NextResponse.json({ error: err.message || "Internal server error" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const supabase = await createSupabaseServerClient();
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser();

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();

    if (body.sites && Array.isArray(body.sites)) {
      // Save full blocked websites list
      await supabase.from("blocked_sites").delete().eq("user_id", user.id);

      if (body.sites.length > 0) {
        const rows = body.sites.map((domain: string) => ({
          id: `${user.id}_${domain}`,
          user_id: user.id,
          domain,
          category: "Social",
          is_active: true,
          created_at: new Date().toISOString(),
        }));
        await supabase.from("blocked_sites").insert(rows);
      }

      return NextResponse.json({ success: true, count: body.sites.length });
    }

    if (body.log) {
      const { data, error } = await supabase
        .from("distraction_logs")
        .insert({
          id: Math.random().toString(36).substring(2, 9),
          user_id: user.id,
          domain: body.log.domain,
          timestamp: body.log.timestamp || new Date().toISOString(),
          attempted_url: body.log.attemptedUrl || `https://${body.log.domain}`,
          blocked: body.log.blocked ?? true,
        })
        .select()
        .single();

      if (error) {
        return NextResponse.json({ error: error.message }, { status: 500 });
      }

      return NextResponse.json({ success: true, log: data });
    }

    return NextResponse.json({ error: "Invalid payload" }, { status: 400 });
  } catch (error: unknown) {
    const err = error as { message?: string };
    return NextResponse.json({ error: err.message || "Internal server error" }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const supabase = await createSupabaseServerClient();
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser();

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");
    const clearAll = searchParams.get("all") === "true";

    if (clearAll) {
      await supabase.from("distraction_logs").delete().eq("user_id", user.id);
      return NextResponse.json({ success: true, cleared: true });
    }

    if (id) {
      await supabase.from("distraction_logs").delete().eq("id", id).eq("user_id", user.id);
      return NextResponse.json({ success: true, deleted: id });
    }

    return NextResponse.json({ error: "Missing id or all parameter" }, { status: 400 });
  } catch (error: unknown) {
    const err = error as { message?: string };
    return NextResponse.json({ error: err.message || "Internal server error" }, { status: 500 });
  }
}
