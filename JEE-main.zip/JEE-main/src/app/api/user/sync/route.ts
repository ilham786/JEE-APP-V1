import { NextResponse } from "next/server";
import { createSupabaseServerClient } from "@/lib/supabase/server";

export async function GET() {
  try {
    const supabase = await createSupabaseServerClient();
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser();

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = user.id;

    // Fetch all user state in parallel
    const [profileRes, sessionsRes, mistakesRes, progressRes, blockerRes] = await Promise.all([
      supabase.from("profiles").select("*").eq("id", userId).maybeSingle(),
      supabase.from("study_sessions").select("*").eq("user_id", userId).order("start_time", { ascending: false }),
      supabase.from("mistake_journal").select("*").eq("user_id", userId).order("created_at", { ascending: false }),
      supabase.from("jee_progress").select("*").eq("user_id", userId),
      supabase.from("blocked_sites").select("*").eq("user_id", userId),
    ]);

    return NextResponse.json({
      userId,
      profile: profileRes.data,
      sessions: sessionsRes.data || [],
      mistakes: mistakesRes.data || [],
      progress: progressRes.data || [],
      blockedSites: blockerRes.data || [],
      syncedAt: new Date().toISOString(),
    });
  } catch (error: unknown) {
    const err = error as { message?: string };
    return NextResponse.json({ error: err.message || "Internal server error" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const supabase = await createSupabaseServerClient();
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser();

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = user.id;
    const body = await request.json();
    const now = new Date().toISOString();

    // 1. Batch sync study sessions if provided
    if (body.sessions && Array.isArray(body.sessions) && body.sessions.length > 0) {
      const sessionRows = body.sessions.map((s: Record<string, unknown>) => ({
        id: s.id,
        user_id: userId,
        subject: s.subject || "Physics",
        chapter: s.chapter || "General",
        subchapter: s.subchapter || "",
        task_type: s.taskType || "Practice",
        mode: s.mode || "Pomodoro",
        start_time: s.startTime || now,
        end_time: s.endTime || now,
        total_duration_minutes: Number(s.totalDurationMinutes || 0),
        date: s.date || (typeof s.startTime === "string" ? s.startTime.split("T")[0] : now.split("T")[0]),
        notes: s.notes || "",
        productivity_rating: Number(s.productivityRating || 5),
        difficulty: s.difficulty || "Medium",
        mood: s.mood || "Focused",
        focus_score: Number(s.focusScore || 90),
        was_goal_completed: s.wasGoalCompleted ?? true,
        completed: s.completed !== false,
        updated_at: now,
      }));

      await supabase.from("study_sessions").upsert(sessionRows);
    }

    // 2. Batch sync mistakes if provided
    if (body.mistakes && Array.isArray(body.mistakes) && body.mistakes.length > 0) {
      const mistakeRows = body.mistakes.map((m: Record<string, unknown>) => ({
        id: m.id,
        user_id: userId,
        subject: m.subject || "Physics",
        chapter: m.chapter || "",
        subchapter: m.subchapter || "",
        question_reference: m.title || "Mistake Log",
        error_category: m.errorType || "Conceptual Gap",
        description: m.description || "",
        correct_solution: m.explanation || "",
        tags: m.tags || [],
        difficulty: m.difficulty || "Medium",
        reviewed_count: Number(m.timesRevised || 0),
        next_review_date: typeof m.nextRevisionAt === "string" ? m.nextRevisionAt.split("T")[0] : null,
        completed: m.status === "completed",
        updated_at: now,
      }));

      await supabase.from("mistake_journal").upsert(mistakeRows);
    }

    return NextResponse.json({
      success: true,
      syncedAt: now,
    });
  } catch (error: unknown) {
    const err = error as { message?: string };
    return NextResponse.json({ error: err.message || "Internal server error" }, { status: 500 });
  }
}
