import { NextResponse } from "next/server";
import { createSupabaseServerClient } from "@/lib/supabase/server";

export async function GET() {
  try {
    const supabase = await createSupabaseServerClient();
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser();

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { data: profile, error: profileError } = await supabase
      .from("profiles")
      .select("*")
      .eq("id", user.id)
      .maybeSingle();

    if (profileError) {
      return NextResponse.json({ error: profileError.message }, { status: 500 });
    }

    return NextResponse.json({
      user: {
        id: user.id,
        email: user.email,
      },
      profile,
    });
  } catch (error: unknown) {
    const err = error as { message?: string };
    return NextResponse.json({ error: err.message || "Internal server error" }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  try {
    const supabase = await createSupabaseServerClient();
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser();

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const payload: Record<string, unknown> = {
      updated_at: new Date().toISOString(),
    };

    if (body.displayName !== undefined) payload.display_name = body.displayName;
    if (body.targetExam !== undefined) payload.target_exam = body.targetExam;
    if (body.targetYear !== undefined) payload.target_year = body.targetYear;
    if (body.studyGoal !== undefined) payload.daily_goal = body.studyGoal;
    if (body.bio !== undefined) payload.bio = body.bio;
    if (body.theme !== undefined) payload.theme = body.theme;
    if (body.preferences !== undefined) payload.preferences = body.preferences;
    if (body.streak !== undefined) payload.streak = body.streak;
    if (body.xp !== undefined) payload.xp = body.xp;
    if (body.level !== undefined) payload.level = body.level;

    const { data, error } = await supabase
      .from("profiles")
      .update(payload)
      .eq("id", user.id)
      .select()
      .single();

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    return NextResponse.json({ success: true, profile: data });
  } catch (error: unknown) {
    const err = error as { message?: string };
    return NextResponse.json({ error: err.message || "Internal server error" }, { status: 500 });
  }
}
