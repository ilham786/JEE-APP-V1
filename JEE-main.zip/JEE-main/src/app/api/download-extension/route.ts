import { NextRequest, NextResponse } from "next/server";
import fs from "fs";
import path from "path";
import { EXTENSION_FILENAME, EXTENSION_FALLBACK_FILENAME } from "@/lib/extension-download";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const requestedFilename = searchParams.get("filename") || EXTENSION_FILENAME;

    // Sanitize filename to prevent directory traversal
    const safeFilename = path.basename(requestedFilename);
    const primaryPath = path.join(process.cwd(), "public", safeFilename);
    const fallbackPath = path.join(process.cwd(), "public", EXTENSION_FALLBACK_FILENAME);

    let targetFile = primaryPath;
    let targetFilename = safeFilename;

    if (!fs.existsSync(targetFile)) {
      if (fs.existsSync(fallbackPath)) {
        targetFile = fallbackPath;
        targetFilename = EXTENSION_FALLBACK_FILENAME;
      }
    }

    // If local file exists, serve binary buffer with correct PKZip headers
    if (fs.existsSync(targetFile)) {
      const zipBuffer = fs.readFileSync(targetFile);

      // Verify binary magic header (PK\x03\x04)
      if (
        zipBuffer[0] === 0x50 &&
        zipBuffer[1] === 0x4b &&
        zipBuffer[2] === 0x03 &&
        zipBuffer[3] === 0x04
      ) {
        const headers = new Headers();
        headers.set("Content-Type", "application/zip");
        headers.set(
          "Content-Disposition",
          `attachment; filename="${targetFilename}"`
        );
        headers.set("Content-Length", zipBuffer.length.toString());
        headers.set("Cache-Control", "public, max-age=3600");

        return new NextResponse(zipBuffer, {
          status: 200,
          headers,
        });
      }
    }

    // Resilient fallback for serverless environments (e.g. Vercel) where static files live on CDN
    return NextResponse.redirect(new URL(`/${safeFilename}`, req.url), 302);
  } catch (error: unknown) {
    const errorObj = error as { message?: string };
    console.error("Error serving Chrome Extension ZIP:", error);
    return NextResponse.json(
      { error: "Failed to download extension archive", details: errorObj.message },
      { status: 500 }
    );
  }
}
