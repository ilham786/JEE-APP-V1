import { NextResponse } from "next/server";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { youtubeGuardService } from "@/services/youtubeGuardService";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    let targetUid = searchParams.get("userId");

    try {
      const supabase = await createSupabaseServerClient();
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (user?.id) targetUid = user.id;
    } catch {}

    if (!targetUid) {
      return NextResponse.json({
        totalStudySeconds: 0,
        videosWatchedCount: 0,
        subjectBreakdown: {},
        blockedAttemptsCount: 0,
        recentAccessLogs: [],
      });
    }

    const analytics = await youtubeGuardService.getStudyAnalytics(targetUid);
    return NextResponse.json({ success: true, ...analytics });
  } catch (error: unknown) {
    const err = error as { message?: string };
    return NextResponse.json({ error: err.message || "Internal server error" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    let targetUid = body.userId;

    try {
      const supabase = await createSupabaseServerClient();
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (user?.id) targetUid = user.id;
    } catch {}

    if (!targetUid || !body.videoId) {
      return NextResponse.json({ error: "Missing required parameters" }, { status: 400 });
    }

    const recorded = await youtubeGuardService.recordWatchTime({
      userId: targetUid,
      sessionId: body.sessionId,
      videoId: body.videoId,
      title: body.title || "YouTube Study Lecture",
      channelName: body.channelName,
      decision: body.decision || "ALLOW",
      subject: body.subject,
      chapter: body.chapter,
      topic: body.topic,
      durationSeconds: Number(body.durationSeconds || 0),
    });

    return NextResponse.json({ success: recorded });
  } catch (error: unknown) {
    const err = error as { message?: string };
    return NextResponse.json({ error: err.message || "Internal server error" }, { status: 500 });
  }
}
