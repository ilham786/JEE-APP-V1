import { NextResponse } from "next/server";
import { youtubeGuardService } from "@/services/youtubeGuardService";

export async function GET() {
  try {
    const channels = await youtubeGuardService.getTrustedChannels();
    return NextResponse.json({ success: true, channels });
  } catch (error: unknown) {
    const err = error as { message?: string };
    return NextResponse.json({ error: err.message || "Internal server error" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    if (!body || !body.channelName) {
      return NextResponse.json({ error: "Missing channelName" }, { status: 400 });
    }

    const added = await youtubeGuardService.addTrustedChannel({
      channelId: body.channelId || `ch_${Date.now()}`,
      channelName: body.channelName,
      subjects: body.subjects || ["General Academic"],
      exams: body.exams || ["JEE Main"],
      trustStatus: "user_added",
      description: body.description || "User added trusted channel",
    });

    return NextResponse.json({ success: added });
  } catch (error: unknown) {
    const err = error as { message?: string };
    return NextResponse.json({ error: err.message || "Internal server error" }, { status: 500 });
  }
}
