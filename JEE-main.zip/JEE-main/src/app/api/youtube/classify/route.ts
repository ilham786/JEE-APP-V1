import { NextResponse } from "next/server";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { youtubeGuardService, YouTubeClassificationInput } from "@/services/youtubeGuardService";
import { toStructuredResponse } from "@/services/academicEngine";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    const body: (YouTubeClassificationInput & { userId?: string }) | { candidates?: YouTubeClassificationInput[]; userId?: string } = await request.json();

    // Try resolving authenticated user
    let userId = body?.userId;
    try {
      const supabase = await createSupabaseServerClient();
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (user?.id) {
        userId = user.id;
      }
    } catch {
      // In guest or background context, fallback to payload userId if provided
    }

    // 1. Batch Candidates Classification Support
    if ("candidates" in body && Array.isArray(body.candidates)) {
      if (body.candidates.length === 0) {
        return NextResponse.json({ success: true, results: [] });
      }
      const results = await youtubeGuardService.batchClassifyVideos(body.candidates, userId);
      return NextResponse.json({
        success: true,
        results,
      });
    }

    // 2. Single Video Classification Support
    const singleInput = body as YouTubeClassificationInput;
    if (!singleInput || !singleInput.videoId) {
      return NextResponse.json({ error: "Missing required videoId or candidates parameter" }, { status: 400 });
    }

    const result = await youtubeGuardService.classifyVideo(singleInput, userId);
    const structured = toStructuredResponse(result as any);

    return NextResponse.json({
      success: true,
      result,
      structured,
    });
  } catch (error: unknown) {
    const err = error as { message?: string };
    console.error("[api/youtube/classify] Error:", err);
    return NextResponse.json({ error: err.message || "Internal server error" }, { status: 500 });
  }
}
