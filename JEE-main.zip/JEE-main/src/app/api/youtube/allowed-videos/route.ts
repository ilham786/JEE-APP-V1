import { NextResponse } from "next/server";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { youtubeGuardService } from "@/services/youtubeGuardService";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    let targetUid = searchParams.get("userId");

    try {
      const supabase = await createSupabaseServerClient();
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (user?.id) targetUid = user.id;
    } catch {}

    if (!targetUid) {
      return NextResponse.json({ videos: [] });
    }

    const videos = await youtubeGuardService.getAllowedVideos(targetUid);
    return NextResponse.json({ success: true, videos });
  } catch (error: unknown) {
    const err = error as { message?: string };
    return NextResponse.json({ error: err.message || "Internal server error" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    let targetUid = body.userId;

    try {
      const supabase = await createSupabaseServerClient();
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (user?.id) targetUid = user.id;
    } catch {}

    if (!targetUid || !body.videoId || !body.title) {
      return NextResponse.json({ error: "Missing required video parameters" }, { status: 400 });
    }

    const success = await youtubeGuardService.approveVideo(targetUid, {
      videoId: body.videoId,
      title: body.title,
      channelId: body.channelId,
      subject: body.subject,
      chapter: body.chapter,
      topic: body.topic,
      exam: body.exam,
    });

    return NextResponse.json({ success });
  } catch (error: unknown) {
    const err = error as { message?: string };
    return NextResponse.json({ error: err.message || "Internal server error" }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const videoId = searchParams.get("videoId");
    let targetUid = searchParams.get("userId");

    try {
      const supabase = await createSupabaseServerClient();
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (user?.id) targetUid = user.id;
    } catch {}

    if (!targetUid || !videoId) {
      return NextResponse.json({ error: "Missing required parameters" }, { status: 400 });
    }

    const success = await youtubeGuardService.revokeVideoApproval(targetUid, videoId);
    return NextResponse.json({ success });
  } catch (error: unknown) {
    const err = error as { message?: string };
    return NextResponse.json({ error: err.message || "Internal server error" }, { status: 500 });
  }
}
