import { NextResponse } from "next/server";
import { youtubeGuardService } from "@/services/youtubeGuardService";
import { TAXONOMY_VERSION, CLASSIFIER_VERSION } from "@/services/academicEngine";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const videoId = searchParams.get("videoId");
    const userId = searchParams.get("userId") || undefined;

    if (videoId) {
      const diag = await youtubeGuardService.getDiagnostics(videoId, userId);
      return NextResponse.json({
        success: true,
        diagnostics: diag,
      });
    }

    return NextResponse.json({
      success: true,
      status: "ONLINE",
      taxonomyVersion: TAXONOMY_VERSION,
      classifierVersion: CLASSIFIER_VERSION,
      subsystem: "FocusForgeYouTubeGuard",
      supportedExams: ["JEE Main", "JEE Advanced", "NEET", "CBSE Class 12", "NCERT"],
      supportedSubjects: ["Physics", "Chemistry", "Mathematics", "Biology", "English"],
      health: {
        taxonomyLoaded: true,
        classifierLoaded: true,
        cacheAvailable: true,
        gatewayConfigured: true,
      },
    });
  } catch (error: unknown) {
    const err = error as { message?: string };
    return NextResponse.json({ error: err.message || "Failed to fetch diagnostics" }, { status: 500 });
  }
}
