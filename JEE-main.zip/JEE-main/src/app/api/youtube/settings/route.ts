import { NextResponse } from "next/server";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { youtubeGuardService } from "@/services/youtubeGuardService";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    let targetUid = searchParams.get("userId");

    try {
      const supabase = await createSupabaseServerClient();
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (user?.id) targetUid = user.id;
    } catch {}

    const settings = await youtubeGuardService.getSettings(targetUid || "guest");
    return NextResponse.json({ success: true, settings });
  } catch (error: unknown) {
    const err = error as { message?: string };
    return NextResponse.json({ error: err.message || "Internal server error" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    let targetUid = body.userId;

    try {
      const supabase = await createSupabaseServerClient();
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (user?.id) targetUid = user.id;
    } catch {}

    if (!targetUid) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const updated = await youtubeGuardService.updateSettings(targetUid, body);
    return NextResponse.json({ success: updated });
  } catch (error: unknown) {
    const err = error as { message?: string };
    return NextResponse.json({ error: err.message || "Internal server error" }, { status: 500 });
  }
}
