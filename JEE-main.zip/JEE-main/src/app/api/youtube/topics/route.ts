import { NextResponse } from "next/server";
import { SEEDED_ACADEMIC_TAXONOMY, AcademicSubject } from "@/services/youtubeGuardService";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const subject = searchParams.get("subject") as AcademicSubject | null;
    const query = (searchParams.get("q") || "").toLowerCase().trim();

    let topics = SEEDED_ACADEMIC_TAXONOMY;

    if (subject) {
      topics = topics.filter((t) => t.subject.toLowerCase() === subject.toLowerCase());
    }

    if (query) {
      topics = topics.filter(
        (t) =>
          t.chapter.toLowerCase().includes(query) ||
          t.topic.toLowerCase().includes(query) ||
          t.keywords.some((k) => k.toLowerCase().includes(query)) ||
          t.aliases.some((a) => a.toLowerCase().includes(query))
      );
    }

    return NextResponse.json({ success: true, count: topics.length, topics });
  } catch (error: unknown) {
    const err = error as { message?: string };
    return NextResponse.json({ error: err.message || "Internal server error" }, { status: 500 });
  }
}
