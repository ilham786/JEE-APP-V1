import { NextResponse } from "next/server";
import { createSupabaseServerClient } from "@/lib/supabase/server";

/**
 * POST /api/auth/logout
 * Server-side logout route that revokes session tokens and clears all auth cookies via @supabase/ssr.
 */
export async function POST() {
  try {
    const supabase = await createSupabaseServerClient();
    
    // Sign out from Supabase GoTrue with local scope (clearing this device's cookies)
    await supabase.auth.signOut({ scope: "local" });

    return NextResponse.json({
      success: true,
      message: "Session signed out and cookies purged successfully.",
    });
  } catch (error: unknown) {
    const err = error as { message?: string };
    console.error("Server logout error:", err.message);
    // Still return 200 with success: true so client can complete its local storage cleanup
    return NextResponse.json({
      success: true,
      warning: err.message || "Failed to invalidate remote session token.",
    });
  }
}
