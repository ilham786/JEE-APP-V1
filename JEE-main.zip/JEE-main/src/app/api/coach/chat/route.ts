import { NextResponse } from "next/server";
import { coachOrchestrator } from "@/services/coach/coachOrchestrator";
import { CoachChatRequestPayload } from "@/services/coach/coachTypes";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    const body: CoachChatRequestPayload = await request.json();

    if (!body || !body.message || typeof body.message !== "string") {
      return NextResponse.json(
        { error: "Invalid request: message string is required." },
        { status: 400 }
      );
    }

    const result = await coachOrchestrator.processMessage(body);

    return NextResponse.json({
      success: true,
      response: result.response,
      trace: result.toolExecutionTrace,
      context: result.contextSnapshot,
    });
  } catch (error: unknown) {
    const err = error as Error;
    console.error("[API /api/coach/chat] Execution error:", err);
    return NextResponse.json(
      {
        error: "ForgeCoach processing failed. Academic fallback activated.",
        details: err.message,
      },
      { status: 500 }
    );
  }
}
