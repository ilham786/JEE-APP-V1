"use client";

import { useState, useMemo, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { WorkspaceLayout } from "@/components/workspace-layout";
import { Card } from "@/components/ui/card";
import { Button, Badge, ProgressBar, Select } from "@/components/ui/controls";
import { useMistakeStore, MistakeEntry } from "@/store/use-mistake-store";
import { MistakeDifficulty } from "@/services/mistakeJournalService";
import { useStudyStore } from "@/store/use-study-store";
import { getSyllabusBySubject } from "@/data/syllabus";
import { getDependentChapterOptions, isValidChapterForSubject, getSubjectVariant } from "@/lib/syllabus-filter-helper";
import { getCurrentUserId } from "@/lib/supabase/client";
import { soundManager } from "@/lib/sound-manager";
import { useExam } from "@/hooks/use-exam";
import { useIsClient } from "@/hooks/use-is-client";
import {
  BookOpen,
  Search,
  PlusCircle,
  Calendar,
  AlertOctagon,
  CheckCircle2,
  BarChart2,
  X,
  Sparkles,
  Edit3,
  Archive,
  Trash2,
  RotateCcw,
  Clock,
  ExternalLink,
  HelpCircle,
  FileText,
  Filter,
  CheckSquare,
  AlertTriangle,
  Flame,
  Award,
} from "lucide-react";

type StatusTab = "active" | "due_today" | "overdue" | "needs_practice" | "completed" | "archived";

export default function MistakeJournalPage() {
  const {
    mistakes,
    addMistake,
    markUnderstood,
    needsMorePractice,
    editMistake,
    archiveMistake,
    restoreMistake,
    deleteMistake,
    restoreMistakeStore,
  } = useMistakeStore();

  const { addXp } = useStudyStore();
  const { examType, subjects, isNeet } = useExam();

  // Hydration / Loading state
  const isMounted = useIsClient();
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);

  // Restore Cloud Data on mount
  useEffect(() => {
    const init = async () => {
      const uid = getCurrentUserId();
      if (uid) {
        await restoreMistakeStore(uid);
      }
      setIsLoading(false);
    };
    init();
  }, [restoreMistakeStore]);

  // Tab & Filters
  const [activeTab, setActiveTab] = useState<StatusTab>("active");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedSubject, setSelectedSubject] = useState("");
  const [selectedChapter, setSelectedChapter] = useState("");
  const [selectedSubchapter, setSelectedSubchapter] = useState("");
  const [selectedDifficulty, setSelectedDifficulty] = useState("");
  const [selectedTag, setSelectedTag] = useState("");

  // Modals state
  const [reviewMistake, setReviewMistake] = useState<MistakeEntry | null>(null);
  const [editingMistake, setEditingMistake] = useState<MistakeEntry | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);

  // Form states (Add/Edit)
  const [formSubject, setFormSubject] = useState("Physics");
  const [formChapter, setFormChapter] = useState("Electrostatics");
  const [formSubchapter, setFormSubchapter] = useState("");
  const [formTitle, setFormTitle] = useState("");
  const [formDifficulty, setFormDifficulty] = useState<"Easy" | "Medium" | "Hard">("Medium");
  const [formErrorType, setFormErrorType] = useState("Calculation Error");
  const [formDesc, setFormDesc] = useState("");
  const [formExpl, setFormExpl] = useState("");
  const [formNotes, setFormNotes] = useState("");
  const [formEstTime, setFormEstTime] = useState(5);
  const [screenshotUrl, setScreenshotUrl] = useState("");

  const errorTypes = isNeet
    ? [
        "NCERT Fact / Recall",
        "Reaction / Reagent",
        "Diagram / Labeling",
        "Statement / Assertion-Reason",
        "Calculation Error",
        "Conceptual Gap",
        "Silly Mistake",
        "Time Pressure",
        "Question Reading",
      ]
    : [
        "Calculation Error",
        "Conceptual Gap",
        "Silly Mistake",
        "Time Pressure",
        "Question Reading",
      ];
  const difficultyOptions = ["Easy", "Medium", "Hard"];

  // Keep form subject aligned with active exam track
  useEffect(() => {
    if (subjects.length > 0 && !subjects.includes(formSubject)) {
      const defaultSub = subjects[0];
      setFormSubject(defaultSub);
      const newOpts = getDependentChapterOptions(defaultSub, false, examType);
      if (newOpts.length > 0) setFormChapter(newOpts[0].value);
    }
  }, [subjects, formSubject, examType]);

  // Reset form when opening edit modal
  const openEditModal = (mistake: MistakeEntry) => {
    soundManager.play("open");
    setEditingMistake(mistake);
    setSaveError(null);
    setFormSubject(mistake.subject || "Physics");
    setFormChapter(mistake.chapter || "");
    setFormSubchapter(mistake.subchapter || "");
    setFormTitle(mistake.title || "");
    setFormDifficulty(mistake.difficulty || "Medium");
    setFormErrorType(mistake.errorType || "Conceptual Gap");
    setFormDesc(mistake.description || "");
    setFormExpl(mistake.explanation || "");
    setFormNotes(mistake.notes || "");
    setFormEstTime(mistake.estimatedReviewTime || 5);
    setScreenshotUrl(mistake.screenshotUrl || "");
  };

  // Submit Add / Edit Form
  const handleSaveMistake = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formDesc || !formExpl || !formTitle) {
      soundManager.play("warning");
      alert("Please fill in the Mistake Title, Problem Description, and Solution/Correction.");
      return;
    }

    try {
      setIsSaving(true);
      setSaveError(null);

      if (editingMistake) {
        await editMistake(editingMistake.id, {
          subject: formSubject,
          chapter: formChapter,
          subchapter: formSubchapter,
          title: formTitle,
          difficulty: formDifficulty,
          errorType: formErrorType,
          tags: [formErrorType, formDifficulty],
          description: formDesc,
          explanation: formExpl,
          notes: formNotes,
          estimatedReviewTime: formEstTime,
          screenshotUrl: screenshotUrl || null,
        });
        setEditingMistake(null);
        soundManager.play("success");
      } else {
        await addMistake({
          subject: formSubject,
          chapter: formChapter,
          subchapter: formSubchapter,
          title: formTitle,
          difficulty: formDifficulty,
          errorType: formErrorType,
          tags: [formErrorType, formDifficulty],
          description: formDesc,
          explanation: formExpl,
          notes: formNotes,
          estimatedReviewTime: formEstTime,
          screenshotUrl: screenshotUrl || null,
        });
        addXp(50);
        setShowAddForm(false);
        soundManager.play("success");
      }

      // Reset fields only on successful save
      setFormTitle("");
      setFormDesc("");
      setFormExpl("");
      setFormNotes("");
      setFormSubchapter("");
      setScreenshotUrl("");
    } catch (err: any) {
      console.error("Failed to save mistake entry:", err);
      const msg = err?.message || "Failed to persist mistake to database. Please check your connection.";
      setSaveError(msg);
      soundManager.play("warning");
    } finally {
      setIsSaving(false);
    }
  };

  // Compute stats
  const now = new Date();

  const activeMistakesList = useMemo(() => {
    return mistakes.filter((m) => m.status === "pending" || m.status === "needs_practice");
  }, [mistakes]);

  const completedMistakesList = useMemo(() => {
    return mistakes.filter((m) => m.status === "completed");
  }, [mistakes]);

  const archivedMistakesList = useMemo(() => {
    return mistakes.filter((m) => m.status === "archived");
  }, [mistakes]);

  const dueTodayCount = useMemo(() => {
    return activeMistakesList.filter((m) => new Date(m.nextRevisionAt) <= now).length;
  }, [activeMistakesList, now]);

  const overdueCount = useMemo(() => {
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);
    return activeMistakesList.filter((m) => new Date(m.nextRevisionAt) < todayStart).length;
  }, [activeMistakesList]);

  const completionRatePct = useMemo(() => {
    const total = mistakes.length;
    if (total === 0) return 0;
    return Math.round((completedMistakesList.length / total) * 100);
  }, [mistakes.length, completedMistakesList.length]);

  // Most mistaken subject & chapter
  const mostMistakenSubject = useMemo(() => {
    const counts: Record<string, number> = { Physics: 0, Chemistry: 0, Maths: 0 };
    mistakes.forEach((m) => {
      if (counts[m.subject] !== undefined) counts[m.subject]++;
    });
    let maxSub = "Physics";
    let maxVal = -1;
    Object.entries(counts).forEach(([sub, count]) => {
      if (count > maxVal) {
        maxVal = count;
        maxSub = sub;
      }
    });
    return maxVal > 0 ? maxSub : "None";
  }, [mistakes]);

  const weakestChapter = useMemo(() => {
    const chapterCounts: Record<string, number> = {};
    mistakes.forEach((m) => {
      chapterCounts[m.chapter] = (chapterCounts[m.chapter] || 0) + 1;
    });
    let maxChap = "None";
    let maxVal = 0;
    Object.entries(chapterCounts).forEach(([chap, count]) => {
      if (count > maxVal) {
        maxVal = count;
        maxChap = chap;
      }
    });
    return maxChap;
  }, [mistakes]);

  // Unique chapters & tags for filter dropdowns
  const availableChapters = useMemo(() => {
    const set = new Set<string>();
    mistakes.forEach((m) => {
      if (m.chapter) set.add(m.chapter);
    });
    return Array.from(set);
  }, [mistakes]);

  const availableTags = useMemo(() => {
    const set = new Set<string>();
    mistakes.forEach((m) => {
      (m.tags || []).forEach((t) => set.add(t));
      if (m.errorType) set.add(m.errorType);
    });
    return Array.from(set);
  }, [mistakes]);

  // Filtered Mistakes List based on tab, search, and dropdowns
  const filteredMistakes = useMemo(() => {
    return mistakes.filter((m) => {
      // Status tab matching
      if (activeTab === "active" && m.status !== "pending" && m.status !== "needs_practice") return false;
      if (activeTab === "completed" && m.status !== "completed") return false;
      if (activeTab === "archived" && m.status !== "archived") return false;
      if (activeTab === "needs_practice" && m.status !== "needs_practice") return false;
      if (activeTab === "due_today") {
        if (m.status === "completed" || m.status === "archived") return false;
        const revDate = new Date(m.nextRevisionAt);
        if (revDate > new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59)) return false;
      }
      if (activeTab === "overdue") {
        if (m.status === "completed" || m.status === "archived") return false;
        const todayStart = new Date();
        todayStart.setHours(0, 0, 0, 0);
        if (new Date(m.nextRevisionAt) >= todayStart) return false;
      }

      // Subject filter
      if (selectedSubject && m.subject !== selectedSubject) return false;
      // Chapter filter
      if (selectedChapter && m.chapter !== selectedChapter) return false;
      // Subchapter filter
      if (selectedSubchapter && m.subchapter?.toLowerCase() !== selectedSubchapter.toLowerCase()) return false;
      // Difficulty filter
      if (selectedDifficulty && m.difficulty !== selectedDifficulty) return false;
      // Tag filter
      if (selectedTag) {
        const hasTag = (m.tags || []).includes(selectedTag) || m.errorType === selectedTag;
        if (!hasTag) return false;
      }

      // Keyword search
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesTitle = m.title?.toLowerCase().includes(q);
        const matchesDesc = m.description?.toLowerCase().includes(q);
        const matchesExpl = m.explanation?.toLowerCase().includes(q);
        const matchesChap = m.chapter?.toLowerCase().includes(q);
        const matchesSub = m.subchapter?.toLowerCase().includes(q);
        const matchesNotes = m.notes?.toLowerCase().includes(q);
        const matchesTags = (m.tags || []).some((t) => t.toLowerCase().includes(q));

        if (!matchesTitle && !matchesDesc && !matchesExpl && !matchesChap && !matchesSub && !matchesNotes && !matchesTags) {
          return false;
        }
      }

      return true;
    });
  }, [
    mistakes,
    activeTab,
    selectedSubject,
    selectedChapter,
    selectedSubchapter,
    selectedDifficulty,
    selectedTag,
    searchQuery,
    now,
  ]);

  return (
    <WorkspaceLayout title="Mistake Journal">
      <div className="space-y-6">

        {/* Simplified Statistics Panel */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3 sm:gap-4">
          <Card variant="glass" className="p-3.5 sm:p-4 space-y-1">
            <div className="flex items-center justify-between text-gray-400 text-xs">
              <span>Active</span>
              <AlertOctagon className="w-3.5 h-3.5 text-amber-400" />
            </div>
            <p className="text-xl sm:text-2xl font-bold font-mono text-white">{activeMistakesList.length}</p>
          </Card>

          <Card variant="glass" className="p-3.5 sm:p-4 space-y-1">
            <div className="flex items-center justify-between text-gray-400 text-xs">
              <span>Completed</span>
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            </div>
            <p className="text-xl sm:text-2xl font-bold font-mono text-emerald-400">{completedMistakesList.length}</p>
          </Card>

          <Card variant="glass" className="p-3.5 sm:p-4 space-y-1">
            <div className="flex items-center justify-between text-gray-400 text-xs">
              <span>Due Today</span>
              <Clock className="w-3.5 h-3.5 text-rose-400" />
            </div>
            <p className="text-xl sm:text-2xl font-bold font-mono text-rose-400">{dueTodayCount}</p>
          </Card>

          <Card variant="glass" className="p-3.5 sm:p-4 space-y-1">
            <div className="flex items-center justify-between text-gray-400 text-xs">
              <span>Completion</span>
              <BarChart2 className="w-3.5 h-3.5 text-purple-400" />
            </div>
            <p className="text-xl sm:text-2xl font-bold font-mono text-purple-300">{completionRatePct}%</p>
          </Card>

          <Card variant="glass" className="p-3.5 sm:p-4 space-y-1">
            <div className="flex items-center justify-between text-gray-400 text-xs">
              <span>Top Mistake</span>
              <Flame className="w-3.5 h-3.5 text-orange-400" />
            </div>
            <p className="text-sm font-semibold text-white truncate">{mostMistakenSubject}</p>
          </Card>

          <Card variant="glass" className="p-3.5 sm:p-4 space-y-1">
            <div className="flex items-center justify-between text-gray-400 text-xs">
              <span>Weak Chapter</span>
              <AlertTriangle className="w-3.5 h-3.5 text-yellow-400" />
            </div>
            <p className="text-xs font-semibold text-white truncate">{weakestChapter}</p>
          </Card>

          <Card variant="glass" className="p-3.5 sm:p-4 space-y-1 col-span-2 md:col-span-4 lg:col-span-1">
            <div className="flex items-center justify-between text-gray-400 text-xs">
              <span>Weekly Rate</span>
              <Award className="w-3.5 h-3.5 text-cyan-400" />
            </div>
            <div className="space-y-1.5 pt-1">
              <ProgressBar value={completionRatePct} showPercentage={false} variant="primary" />
              <span className="text-[10px] text-gray-400 font-mono">Target: 80%+</span>
            </div>
          </Card>
        </div>

        {/* Action Header & Tabs */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/[0.08] pb-4">

          {/* Status Navigation Tabs */}
          <div className="flex flex-wrap items-center gap-1 bg-[#0c0f17] p-1 rounded-xl border border-white/10">
            {[
              { id: "active", label: "Active", count: activeMistakesList.length },
              { id: "due_today", label: "Review Today", count: dueTodayCount },
              { id: "overdue", label: "Overdue", count: overdueCount },
              { id: "needs_practice", label: "Needs Practice", count: mistakes.filter(m => m.status === "needs_practice").length },
              { id: "completed", label: "Completed", count: completedMistakesList.length },
              { id: "archived", label: "Archived", count: archivedMistakesList.length },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => {
                  soundManager.play("select");
                  setActiveTab(tab.id as StatusTab);
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 cursor-pointer ${activeTab === tab.id
                    ? "bg-[#581c87] text-white border border-purple-500/30 shadow-sm"
                    : "text-gray-400 hover:text-white hover:bg-white/[0.04]"
                  }`}
              >
                <span>{tab.label}</span>
                <span className={`px-1.5 py-0.2 text-[10px] font-mono rounded-md ${activeTab === tab.id ? "bg-white/20 text-white font-bold" : "bg-white/[0.06] text-gray-400"}`}>
                  {tab.count}
                </span>
              </button>
            ))}
          </div>

          {/* Add Mistake Button */}
          <Button
            onClick={() => {
              setEditingMistake(null);
              const next = !showAddForm;
              setShowAddForm(next);
              soundManager.play(next ? "open" : "close");
            }}
            variant="primary"
            size="md"
            className="shrink-0"
          >
            {showAddForm ? <X className="w-4 h-4" /> : <PlusCircle className="w-4 h-4" />}
            {showAddForm ? "CLOSE FORM" : "LOG MISTAKE"}
          </Button>
        </div>

        {/* Multi-Field Filters Bar */}
        <Card variant="glass" className="p-4 space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-6 gap-3">

            {/* Instant Search input */}
            <div className="relative md:col-span-2">
              <Search className="absolute left-3 top-2.5 w-4 h-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search by title, topic, notes, formula..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full glass-input pl-9 pr-8 py-2 text-xs text-white placeholder-gray-500 focus:outline-none"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery("")}
                  className="absolute right-2.5 top-2.5 text-gray-400 hover:text-white"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Subject Dropdown */}
            <Select
              label=""
              isClearable
              placeholder="All Subjects"
              variant={getSubjectVariant(selectedSubject)}
              options={[
                { value: "", label: "All Subjects" },
                ...subjects.map((s) => ({ value: s, label: s === "Maths" ? "Mathematics" : s, subject: s })),
              ]}
              value={selectedSubject}
              onChange={(val) => {
                const newSub = (Array.isArray(val) ? val[0] : val) || "";
                setSelectedSubject(newSub);
                if (newSub && selectedChapter && !isValidChapterForSubject(newSub, selectedChapter, examType)) {
                  setSelectedChapter("");
                }
              }}
            />

            {/* Dependent Chapter Dropdown */}
            <Select
              label=""
              isClearable
              searchable
              placeholder={selectedSubject ? `All ${selectedSubject} Chapters` : "All Chapters"}
              variant={getSubjectVariant(selectedSubject)}
              options={getDependentChapterOptions(selectedSubject, true, examType)}
              value={selectedChapter}
              onChange={(val) => setSelectedChapter(Array.isArray(val) ? val[0] || "" : val)}
            />

            {/* Difficulty Dropdown */}
            <Select
              label=""
              isClearable
              placeholder="All Difficulties"
              options={[
                { value: "", label: "All Difficulties" },
                ...difficultyOptions.map((d) => ({ value: d, label: d })),
              ]}
              value={selectedDifficulty}
              onChange={(val) => setSelectedDifficulty(Array.isArray(val) ? val[0] || "" : val)}
            />

            {/* Tag / Error Type Dropdown */}
            <Select
              label=""
              isClearable
              placeholder="All Tags"
              options={[
                { value: "", label: "All Tags" },
                ...availableTags.map((t) => ({ value: t, label: t })),
              ]}
              value={selectedTag}
              onChange={(val) => setSelectedTag(Array.isArray(val) ? val[0] || "" : val)}
            />
          </div>
        </Card>

        {/* Create / Edit Form Drawer */}
        <AnimatePresence>
          {(showAddForm || editingMistake) && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.2 }}
            >
              <Card variant="glass" className="p-6 space-y-4 border-l-4 border-l-purple-500">
                <div className="flex items-center justify-between pb-3 border-b border-white/[0.08]">
                  <h2 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-purple-400" />
                    {editingMistake ? "Edit Mistake Log" : "Log New Incorrect Question"}
                  </h2>
                  <button
                    onClick={() => {
                      setShowAddForm(false);
                      setEditingMistake(null);
                      setSaveError(null);
                    }}
                    className="text-xs text-gray-400 hover:text-white"
                  >
                    Cancel
                  </button>
                </div>

                {saveError && (
                  <div className="p-3 bg-rose-500/15 border border-rose-500/30 rounded-xl text-xs text-rose-300 flex items-center gap-2">
                    <AlertOctagon className="w-4 h-4 text-rose-400 shrink-0" />
                    <span>{saveError}</span>
                  </div>
                )}

                <form onSubmit={handleSaveMistake} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                    <Select
                      label="Subject"
                      variant={getSubjectVariant(formSubject)}
                      options={subjects.map((s) => ({ value: s, label: s === "Maths" ? "Mathematics" : s, subject: s }))}
                      value={formSubject}
                      onChange={(val) => {
                        const sVal = Array.isArray(val) ? val[0] || "" : val;
                        setFormSubject(sVal);
                        const newOpts = getDependentChapterOptions(sVal, false, examType);
                        if (newOpts.length > 0 && !isValidChapterForSubject(sVal, formChapter, examType)) {
                          setFormChapter(newOpts[0].value);
                        }
                      }}
                    />

                    <Select
                      label="Chapter"
                      searchable
                      variant={getSubjectVariant(formSubject)}
                      options={getDependentChapterOptions(formSubject, false, examType)}
                      value={formChapter}
                      onChange={(val) => setFormChapter(Array.isArray(val) ? val[0] || "" : val)}
                    />

                    <div className="space-y-1">
                      <label className="text-xs font-medium text-gray-400">Subchapter / Topic</label>
                      <input
                        type="text"
                        value={formSubchapter}
                        onChange={(e) => setFormSubchapter(e.target.value)}
                        placeholder="E.g. Integration Limits"
                        className="w-full glass-input px-3 py-2 text-xs text-white focus:outline-none"
                      />
                    </div>

                    <Select
                      label="Difficulty"
                      options={difficultyOptions.map((d) => ({ value: d, label: d }))}
                      value={formDifficulty}
                      onChange={(val) => setFormDifficulty((Array.isArray(val) ? val[0] || "Medium" : val) as MistakeDifficulty)}
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div className="sm:col-span-2 space-y-1">
                      <label className="text-xs font-medium text-gray-400">Mistake Title *</label>
                      <input
                        type="text"
                        required
                        value={formTitle}
                        onChange={(e) => setFormTitle(e.target.value)}
                        placeholder="E.g. Incorrect integration limits on rod field"
                        className="w-full glass-input px-3 py-2 text-xs text-white focus:outline-none"
                      />
                    </div>

                    <Select
                      label="Error Classification"
                      options={errorTypes.map((t) => ({ value: t, label: t }))}
                      value={formErrorType}
                      onChange={(val) => setFormErrorType(Array.isArray(val) ? val[0] || "" : val)}
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-medium text-gray-400">Problem Description (What was the question & mistake?) *</label>
                    <textarea
                      rows={3}
                      required
                      value={formDesc}
                      onChange={(e) => setFormDesc(e.target.value)}
                      placeholder="Detailed question context and where you made a slip..."
                      className="w-full glass-input p-3 text-xs text-white focus:outline-none"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-medium text-gray-400">Correct Solution & Formula *</label>
                    <textarea
                      rows={3}
                      required
                      value={formExpl}
                      onChange={(e) => setFormExpl(e.target.value)}
                      placeholder="Step by step derivation, key formula, and conceptual rule..."
                      className="w-full glass-input p-3 text-xs text-white focus:outline-none"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-xs font-medium text-gray-400">Personal Notes / Reminder</label>
                      <input
                        type="text"
                        value={formNotes}
                        onChange={(e) => setFormNotes(e.target.value)}
                        placeholder="E.g. Double check coordinate system"
                        className="w-full glass-input px-3 py-2 text-xs text-white focus:outline-none"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-xs font-medium text-gray-400">Est. Review Time (Mins)</label>
                      <input
                        type="number"
                        min={1}
                        max={60}
                        value={formEstTime}
                        onChange={(e) => setFormEstTime(parseInt(e.target.value) || 5)}
                        className="w-full glass-input px-3 py-2 text-xs text-white focus:outline-none font-mono"
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-medium text-gray-400">Screenshot / Attachment URL (Optional)</label>
                    <input
                      type="url"
                      value={screenshotUrl}
                      onChange={(e) => setScreenshotUrl(e.target.value)}
                      placeholder="https://i.imgur.com/example.png"
                      className="w-full glass-input px-3 py-2 text-xs text-white focus:outline-none"
                    />
                  </div>

                  <div className="flex justify-end gap-3 pt-2">
                    <Button
                      type="button"
                      variant="ghost"
                      onClick={() => {
                        setShowAddForm(false);
                        setEditingMistake(null);
                        setSaveError(null);
                      }}
                    >
                      Cancel
                    </Button>
                    <Button type="submit" variant="primary" disabled={isSaving}>
                      {isSaving ? "Saving to Cloud..." : editingMistake ? "Save Changes" : "Create Log (+50 XP)"}
                    </Button>
                  </div>
                </form>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Mistake Cards Grid / List */}
        {isLoading ? (
          /* Loading Skeletons */
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[1, 2, 3, 4].map((i) => (
              <Card key={i} variant="glass" className="h-44 animate-pulse p-4 space-y-3">
                <div className="h-4 bg-white/10 rounded w-1/3" />
                <div className="h-6 bg-white/10 rounded w-3/4" />
                <div className="h-10 bg-white/5 rounded w-full" />
              </Card>
            ))}
          </div>
        ) : filteredMistakes.length === 0 ? (
          /* Empty State */
          <Card variant="glass" className="p-12 text-center space-y-3">
            <BookOpen className="w-10 h-10 text-purple-400 mx-auto opacity-60" />
            <h3 className="text-base font-bold text-white">No Mistakes Found</h3>
            <p className="text-xs text-gray-400 max-w-sm mx-auto">
              {searchQuery
                ? "No entries match your current search query and filters."
                : "You don't have any mistakes logged in this status view. Keep practicing!"}
            </p>
            {activeTab !== "active" && (
              <Button onClick={() => setActiveTab("active")} variant="secondary" size="sm">
                View Active Journal
              </Button>
            )}
          </Card>
        ) : (
          /* Cards Grid */
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredMistakes.map((mistake) => {
              const isDue = new Date(mistake.nextRevisionAt) <= now;
              const isOverdue =
                mistake.status !== "completed" &&
                mistake.status !== "archived" &&
                new Date(mistake.nextRevisionAt) < new Date(now.getFullYear(), now.getMonth(), now.getDate());

              const subjectVariant =
                mistake.subject === "Physics"
                  ? "physics"
                  : mistake.subject === "Chemistry"
                    ? "chemistry"
                    : "maths";

              return (
                <Card
                  key={mistake.id}
                  variant={subjectVariant}
                  className={`relative flex flex-col justify-between p-4 transition-all hover:border-purple-500/40 ${isOverdue
                      ? "border-l-4 border-l-rose-500 shadow-lg shadow-rose-950/20"
                      : isDue
                        ? "border-l-4 border-l-amber-500"
                        : ""
                    }`}
                >
                  <div className="space-y-3">
                    {/* Header Badges: Subject, Chapter, Subchapter */}
                    <div className="flex flex-wrap items-center gap-1.5">
                      <Badge
                        variant={
                          mistake.subject === "Physics"
                            ? "physics"
                            : mistake.subject === "Chemistry"
                              ? "chemistry"
                              : "maths"
                        }
                      >
                        {mistake.subject}
                      </Badge>

                      <Badge variant="gray" className="truncate max-w-[140px]">
                        {mistake.chapter}
                      </Badge>

                      {mistake.subchapter && (
                        <Badge variant="purple" className="truncate max-w-[140px]">
                          {mistake.subchapter}
                        </Badge>
                      )}

                      {/* Difficulty */}
                      <span
                        className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ml-auto ${mistake.difficulty === "Hard"
                            ? "bg-rose-500/20 text-rose-300 border border-rose-500/30"
                            : mistake.difficulty === "Medium"
                              ? "bg-amber-500/20 text-amber-300 border border-amber-500/30"
                              : "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
                          }`}
                      >
                        {mistake.difficulty}
                      </span>
                    </div>

                    {/* Title */}
                    <div>
                      <h4 className="text-sm font-bold text-white tracking-tight leading-snug">
                        {mistake.title}
                      </h4>
                      <p className="text-xs text-gray-400 line-clamp-2 mt-1 leading-relaxed">
                        {mistake.description}
                      </p>
                    </div>

                    {/* Dates & Status Badge */}
                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px] text-gray-400">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5 text-purple-400" />
                        Created: {isMounted ? new Date(mistake.createdAt).toLocaleDateString() : (mistake.createdAt ? mistake.createdAt.split("T")[0] : "—")}
                      </span>

                      <span className="flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5 text-cyan-400" />
                        Next:{" "}
                        {mistake.status === "completed" ? (
                          <span className="text-emerald-400 font-semibold">Completed</span>
                        ) : isOverdue ? (
                          <span className="text-rose-400 font-bold">OVERDUE</span>
                        ) : isDue ? (
                          <span className="text-amber-400 font-bold">DUE TODAY</span>
                        ) : (
                          isMounted ? new Date(mistake.nextRevisionAt).toLocaleDateString() : (mistake.nextRevisionAt ? mistake.nextRevisionAt.split("T")[0] : "—")
                        )}
                      </span>

                      <span className="font-mono text-[10px] text-gray-500 ml-auto">
                        ⏱ {mistake.estimatedReviewTime}m
                      </span>
                    </div>

                    {/* Tags */}
                    {mistake.tags && mistake.tags.length > 0 && (
                      <div className="flex flex-wrap gap-1">
                        {mistake.tags.map((tag, idx) => (
                          <span
                            key={idx}
                            className="text-[10px] bg-white/[0.06] text-gray-300 px-2 py-0.5 rounded-md"
                          >
                            #{tag}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Card Action Buttons: Review, Edit, Archive, Delete */}
                  <div className="flex items-center justify-between pt-3.5 mt-3 border-t border-white/[0.08]">
                    <div className="flex items-center gap-2">
                      <Button
                        onClick={() => {
                          soundManager.play("open");
                          setReviewMistake(mistake);
                        }}
                        variant="primary"
                        size="sm"
                        className="bg-purple-600 hover:bg-purple-500 text-white font-bold"
                      >
                        <BookOpen className="w-3.5 h-3.5" />
                        Review
                      </Button>

                      <Button
                        onClick={() => openEditModal(mistake)}
                        variant="ghost"
                        size="sm"
                        className="text-gray-400 hover:text-white"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                        Edit
                      </Button>
                    </div>

                    <div className="flex items-center gap-1">
                      {mistake.status === "archived" ? (
                        <button
                          onClick={() => {
                            soundManager.play("unstash");
                            restoreMistake(mistake.id);
                          }}
                          title="Restore to Active"
                          className="p-1.5 text-gray-400 hover:text-emerald-400 transition-colors"
                        >
                          <RotateCcw className="w-4 h-4" />
                        </button>
                      ) : (
                        <button
                          onClick={() => {
                            soundManager.play("stash");
                            archiveMistake(mistake.id);
                          }}
                          title="Archive Entry"
                          className="p-1.5 text-gray-400 hover:text-amber-400 transition-colors"
                        >
                          <Archive className="w-4 h-4" />
                        </button>
                      )}

                      <button
                        onClick={() => {
                          soundManager.play("open");
                          setDeletingId(mistake.id);
                        }}
                        title="Delete Permanently"
                        className="p-1.5 text-gray-400 hover:text-rose-400 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        )}

      </div>

      {/* ==================================================== */}
      {/* DISTRACTION-FREE REVIEW MODAL                        */}
      {/* ==================================================== */}
      <AnimatePresence>
        {reviewMistake && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-2xl bg-slate-900 border border-white/10 rounded-2xl p-6 space-y-5 shadow-2xl overflow-y-auto max-h-[90vh]"
            >
              {/* Review Header */}
              <div className="flex items-start justify-between pb-3 border-b border-white/[0.08]">
                <div className="space-y-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <Badge
                      variant={
                        reviewMistake.subject === "Physics"
                          ? "physics"
                          : reviewMistake.subject === "Chemistry"
                            ? "chemistry"
                            : "maths"
                      }
                    >
                      {reviewMistake.subject}
                    </Badge>
                    <Badge variant="gray">{reviewMistake.chapter}</Badge>
                    {reviewMistake.subchapter && <Badge variant="purple">{reviewMistake.subchapter}</Badge>}
                  </div>
                  <h2 className="text-lg font-bold text-white">{reviewMistake.title}</h2>
                </div>
                <button
                  onClick={() => setReviewMistake(null)}
                  className="p-1 text-gray-400 hover:text-white rounded-lg hover:bg-white/10"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Problem Question Section */}
              <div className="space-y-1.5">
                <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center gap-1.5">
                  <HelpCircle className="w-4 h-4 text-purple-400" /> Question & Mistake Description
                </h4>
                <div className="p-4 bg-slate-950/60 rounded-xl border border-white/[0.06] text-xs text-white leading-relaxed">
                  {reviewMistake.description}
                </div>
              </div>

              {/* Correct Solution & Formula Section */}
              <div className="space-y-1.5">
                <h4 className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                  <CheckSquare className="w-4 h-4 text-emerald-400" /> Correct Solution & Formula
                </h4>
                <div className="p-4 bg-slate-950/80 rounded-xl border border-emerald-500/20 text-xs text-emerald-200 leading-relaxed font-mono whitespace-pre-wrap">
                  {reviewMistake.explanation}
                </div>
              </div>

              {/* Screenshot / Attachment preview if available */}
              {reviewMistake.screenshotUrl && (
                <div className="space-y-1.5">
                  <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center gap-1.5">
                    <ExternalLink className="w-4 h-4 text-cyan-400" /> Attached Diagram / Screenshot
                  </h4>
                  <div className="rounded-xl overflow-hidden border border-white/10 max-h-60 bg-black flex items-center justify-center">
                    <img
                      src={reviewMistake.screenshotUrl}
                      alt="Mistake Diagram"
                      className="max-h-60 object-contain"
                    />
                  </div>
                </div>
              )}

              {/* Personal Notes */}
              {reviewMistake.notes && (
                <div className="space-y-1.5">
                  <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center gap-1.5">
                    <FileText className="w-4 h-4 text-amber-400" /> Personal Key Takeaways
                  </h4>
                  <div className="p-3 bg-amber-500/10 rounded-xl border border-amber-500/20 text-xs text-amber-200">
                    {reviewMistake.notes}
                  </div>
                </div>
              )}

              {/* Review Decision Action Buttons */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-4 border-t border-white/[0.08]">
                <div className="flex items-center gap-2 w-full sm:w-auto">
                  <Button
                    onClick={async () => {
                      const id = reviewMistake.id;
                      setReviewMistake(null);
                      await markUnderstood(id);
                      soundManager.play("check");
                    }}
                    variant="primary"
                    size="md"
                    className="w-full sm:w-auto bg-emerald-600 hover:bg-emerald-500 text-white font-bold"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    Mark Understood
                  </Button>

                  <Button
                    onClick={async () => {
                      const id = reviewMistake.id;
                      setReviewMistake(null);
                      await needsMorePractice(id);
                      soundManager.play("checkpoint");
                    }}
                    variant="secondary"
                    size="md"
                    className="w-full sm:w-auto text-amber-300 border-amber-500/40 hover:bg-amber-500/20"
                  >
                    <RotateCcw className="w-4 h-4 text-amber-400" />
                    Needs More Practice
                  </Button>
                </div>

                <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                  <Button
                    onClick={() => {
                      const current = reviewMistake;
                      setReviewMistake(null);
                      openEditModal(current);
                    }}
                    variant="ghost"
                    size="md"
                  >
                    <Edit3 className="w-4 h-4" />
                    Edit
                  </Button>

                  <Button
                    onClick={() => {
                      setReviewMistake(null);
                      soundManager.play("close");
                    }}
                    variant="ghost"
                    size="md"
                  >
                    Close
                  </Button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ==================================================== */}
      {/* DELETE CONFIRMATION MODAL                            */}
      {/* ==================================================== */}
      <AnimatePresence>
        {deletingId && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-md bg-slate-900 border border-white/10 rounded-2xl p-6 space-y-4 shadow-2xl"
            >
              <div className="flex items-center gap-3 text-rose-400">
                <AlertTriangle className="w-6 h-6" />
                <h3 className="text-base font-bold text-white">Confirm Permanent Deletion</h3>
              </div>
              <p className="text-xs text-gray-300">
                Are you sure you want to permanently delete this mistake log? It will be removed from your active journal, revision queue, and cloud storage.
              </p>
              <div className="flex justify-end gap-3 pt-3">
                <Button
                  variant="ghost"
                  onClick={() => {
                    setDeletingId(null);
                    soundManager.play("cancel");
                  }}
                >
                  Cancel
                </Button>
                <Button
                  variant="primary"
                  className="bg-rose-600 hover:bg-rose-500 text-white font-bold"
                  onClick={async () => {
                    const id = deletingId;
                    setDeletingId(null);
                    await deleteMistake(id);
                    soundManager.play("delete");
                  }}
                >
                  Delete
                </Button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </WorkspaceLayout>
  );
}
