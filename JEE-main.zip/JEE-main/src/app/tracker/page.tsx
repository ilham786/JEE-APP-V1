"use client";

import { useEffect, useState, useMemo } from "react";
import { useIsClient } from "@/hooks/use-is-client";
import { WorkspaceLayout } from "@/components/workspace-layout";
import { useStudyStore } from "@/store/use-study-store";
import { blockerService, VisitLogDoc } from "@/services/blockerService";
import { analyticsService } from "@/services/analyticsService";
import { soundManager } from "@/lib/sound-manager";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/components/ui/controls";
import {
  TrendingDown,
  Clock,
  AlertTriangle,
  Zap,
  Search,
  Download,
  Trash2,
  Filter,
  Globe,
  Monitor,
  Target,
  ShieldAlert,
  Sparkles,
  Layers,
  List,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell,
} from "recharts";

export default function DistractionTrackerPage() {
  const { uid } = useAuth();
  const { sessionHistory = [] } = useStudyStore();
  const mounted = useIsClient();
  const [logs, setLogs] = useState<VisitLogDoc[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [dateFilter, setDateFilter] = useState<"All" | "Today" | "Week">("All");
  const [liveTracking, setLiveTracking] = useState<{
    domain: string;
    url: string;
    elapsedSeconds: number;
    sessionState: string;
    activityType: string;
  } | null>(null);

  const targetUid = uid || "guest";

  const allLogs = useMemo<VisitLogDoc[]>(() => {
    return [...logs].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }, [logs]);

  useEffect(() => {
    const unsub = blockerService.subscribeDistractionLogs(targetUid, (realtimeLogs) => {
      setLogs(realtimeLogs || []);
    });

    // Listen for live tracking & finalized distraction log postMessages from companion extension
    const handleMessage = (e: MessageEvent) => {
      if (e.data?.type === "FOCUSFORGE_LIVE_TRACKING") {
        setLiveTracking(e.data.data);
      } else if (e.data?.type === "FOCUSFORGE_DISTRACTION_LOGGED" && e.data.data) {
        const item = e.data.data;
        const durSec = item.duration_seconds || 0;
        const mappedLog: VisitLogDoc = {
          id: item.id || item.visit_id || `log-${Date.now()}`,
          userId: item.user_id || targetUid,
          website: item.attempted_url || `https://${item.domain}`,
          domain: item.domain,
          timestamp: item.timestamp || item.ended_at || new Date().toISOString(),
          durationMinutes: Math.floor(durSec / 60),
          durationSeconds: durSec,
          blocked: Boolean(item.blocked),
          isDuringSession: Boolean(item.is_during_session),
          sessionState: item.session_state,
          activityType: item.activity_type,
          focusSessionId: item.session_id,
          createdAt: item.timestamp || new Date().toISOString(),
          updatedAt: item.ended_at || new Date().toISOString(),
        };
        setLogs((prev) => {
          if (prev.some((l) => l.id === mappedLog.id)) return prev;
          return [mappedLog, ...prev];
        });
        setLiveTracking(null);
        blockerService.logVisit(targetUid, mappedLog).catch(console.warn);
      }
    };
    window.addEventListener("message", handleMessage);

    return () => {
      unsub();
      window.removeEventListener("message", handleMessage);
    };
  }, [targetUid]);

  const handleDeleteLog = async (id: string, domain?: string) => {
    soundManager.play("delete");
    // 1. Instantly remove from local component state
    setLogs((prev) => prev.filter((l) => l.id !== id));
    // 2. Remove from localStorage & Supabase
    try {
      await blockerService.deleteVisitLog(id, domain);
    } catch (err) {
      console.error("Failed to delete visit log:", err);
    }
  };

  const handleClearAll = async () => {
    soundManager.play("delete");
    setLogs([]);
    try {
      await blockerService.clearAllVisitLogs(targetUid);
    } catch (err) {
      console.error("Failed to clear visit logs:", err);
    }
  };

  const handleExportCSV = () => {
    if (allLogs.length === 0) return;
    soundManager.play("success");
    const headers = ["Domain", "Website", "Timestamp", "Duration(min)", "Blocked", "FocusSessionId", "Device"];
    const rows = allLogs.map((l) => [
      l.domain,
      l.website,
      l.timestamp,
      l.durationMinutes,
      l.blocked ? "Yes" : "No",
      l.focusSessionId || "N/A",
      l.device || "Browser",
    ]);

    const csvContent = [headers.join(","), ...rows.map((r) => r.join(","))].join("\n");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", `FocusForge_DistractionLogs_${new Date().toISOString().split("T")[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const [initialNowMs] = useState(() => Date.now());

  // Single-pass O(N+M) high efficiency analytics computation
  const analytics = useMemo(() => {
    return analyticsService.calculateDistractionAnalytics(
      allLogs,
      sessionHistory,
      dateFilter,
      searchQuery,
      initialNowMs
    );
  }, [allLogs, sessionHistory, dateFilter, searchQuery, initialNowMs]);

  const {
    filteredLogs,
    totalWastedMinutes,
    totalWastedSeconds,
    totalBreakMinutes,
    totalBreakSeconds,
    totalProductiveMinutes,
    focusEfficiency,
    focusLeakIndex,
    severityLevel,
    severityBadgeBg,
    equivalentQuestionsLost,
    inSessionWastedMinutes,
    inSessionContaminationRate,
    peakVulnerability,
    compareChartData: compareData,
    domainBreakdown: domainsSplit,
  } = analytics;

  const [viewMode, setViewMode] = useState<"domain" | "detailed">("domain");
  const [expandedDomains, setExpandedDomains] = useState<Set<string>>(new Set());

  const toggleExpandDomain = (domain: string) => {
    setExpandedDomains((prev) => {
      const next = new Set(prev);
      if (next.has(domain)) {
        next.delete(domain);
      } else {
        next.add(domain);
      }
      return next;
    });
  };

  const handleDeleteDomainLogs = async (domain: string, ids: string[]) => {
    soundManager.play("delete");
    setLogs((prev) => prev.filter((l) => l.domain?.toLowerCase() !== domain.toLowerCase()));
    if (ids.length > 0) {
      try {
        await blockerService.deleteVisitLog(ids[0], domain);
      } catch (err) {
        console.error("Failed to delete domain log:", err);
      }
    }
  };

  interface DomainSummary {
    domain: string;
    totalSeconds: number;
    totalMinutes: number;
    totalBreakMinutes: number;
    visitCount: number;
    blockedCount: number;
    inSessionCount: number;
    lastVisited: string;
    sampleUrl: string;
    incidentIds: string[];
    logs: VisitLogDoc[];
  }

  const domainSummaries = useMemo<DomainSummary[]>(() => {
    const map = new Map<string, DomainSummary>();
    for (const log of filteredLogs) {
      const dom = log.domain?.toLowerCase() || "unknown";
      const durSec = log.durationSeconds ?? (log.durationMinutes ? log.durationMinutes * 60 : 0);
      const isBlocked = Boolean(log.blocked);
      const isInSession = Boolean(log.isDuringSession || log.focusSessionId);
      const isPauseBreak = log.activityType === "pause_break" || log.sessionState === "paused";

      const existing = map.get(dom);
      if (!existing) {
        map.set(dom, {
          domain: log.domain,
          totalSeconds: isBlocked ? 0 : (isPauseBreak ? 0 : durSec),
          totalMinutes: isBlocked ? 0 : (isPauseBreak ? 0 : Math.floor(durSec / 60)),
          totalBreakMinutes: isBlocked ? 0 : (isPauseBreak ? Math.floor(durSec / 60) : 0),
          visitCount: 1,
          blockedCount: isBlocked ? 1 : 0,
          inSessionCount: isInSession ? 1 : 0,
          lastVisited: log.timestamp,
          sampleUrl: log.website,
          incidentIds: [log.id],
          logs: [log],
        });
      } else {
        if (!isBlocked) {
          if (isPauseBreak) {
            existing.totalBreakMinutes += Math.floor(durSec / 60);
          } else {
            existing.totalSeconds += durSec;
            existing.totalMinutes += Math.floor(durSec / 60);
          }
        } else {
          existing.blockedCount += 1;
        }
        existing.visitCount += 1;
        if (isInSession) existing.inSessionCount += 1;
        if (new Date(log.timestamp).getTime() > new Date(existing.lastVisited).getTime()) {
          existing.lastVisited = log.timestamp;
          existing.sampleUrl = log.website;
        }
        existing.incidentIds.push(log.id);
        existing.logs.push(log);
      }
    }

    return Array.from(map.values()).sort((a, b) => {
      if (b.totalSeconds !== a.totalSeconds) return b.totalSeconds - a.totalSeconds;
      return b.visitCount - a.visitCount;
    });
  }, [filteredLogs]);

  return (
    <WorkspaceLayout title="Distraction Logs">
      {/* Live Active Distraction / Break Banner */}
      {liveTracking && liveTracking.elapsedSeconds > 0 && (
        <div
          className={`mb-6 rounded-2xl border p-4 shadow-xl flex items-center justify-between transition-all ${
            liveTracking.activityType === "pause_break"
              ? "bg-amber-950/20 border-amber-500/30 text-amber-300"
              : "bg-red-950/20 border-red-500/30 text-red-300"
          }`}
        >
          <div className="flex items-center gap-3.5">
            <span
              className={`w-3 h-3 rounded-full animate-ping shrink-0 ${
                liveTracking.activityType === "pause_break" ? "bg-amber-400" : "bg-red-500"
              }`}
            />
            <div>
              <span className="text-xs uppercase font-bold tracking-wider block">
                {liveTracking.activityType === "pause_break"
                  ? "⏸️ Intentional Break Active"
                  : "🚨 Active Focus Breach"}
              </span>
              <span className="text-sm font-semibold text-white">
                Currently browsing <span className="font-mono text-amber-400 underline">{liveTracking.domain}</span>
              </span>
            </div>
          </div>
          <div className="text-right font-mono shrink-0">
            <span className="text-[10px] uppercase text-gray-400 font-semibold block">Live Elapsed</span>
            <span className="text-xl font-bold text-white">
              {Math.floor(liveTracking.elapsedSeconds / 60)}m{" "}
              {(liveTracking.elapsedSeconds % 60).toString().padStart(2, "0")}s
            </span>
          </div>
        </div>
      )}

      {/* Metrics Row - 5 Dimensional Focus & Break Architecture */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {/* Wasted time card */}
        <div className="rounded-2xl border border-white/10 bg-[#0c101a]/90 p-4 sm:p-5 shadow-xl flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-xs text-gray-400 font-semibold uppercase tracking-wider block">STUDY WASTE TIME</span>
            <span className="text-2xl sm:text-3xl font-bold text-red-500 block">{totalWastedMinutes} min</span>
            <p className="text-[11px] text-gray-400 block">
              {inSessionWastedMinutes > 0
                ? `${inSessionWastedMinutes}m in active sessions`
                : "0m active breach"}
            </p>
          </div>
          <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-red-950/20 border border-red-500/20 flex items-center justify-center text-red-500 shrink-0">
            <Clock className="w-5 h-5 text-red-500" />
          </div>
        </div>

        {/* Break time card */}
        <div className="rounded-2xl border border-white/10 bg-[#0c101a]/90 p-4 sm:p-5 shadow-xl flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-xs text-gray-400 font-semibold uppercase tracking-wider block">PAUSE BREAK TIME</span>
            <span className="text-2xl sm:text-3xl font-bold text-amber-400 block">{totalBreakMinutes} min</span>
            <p className="text-[11px] text-gray-400 block">Authorized rest intervals</p>
          </div>
          <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-amber-950/20 border border-amber-500/20 flex items-center justify-center text-amber-400 shrink-0">
            <Sparkles className="w-5 h-5 text-amber-400" />
          </div>
        </div>

        {/* Productive time card */}
        <div className="rounded-2xl border border-white/10 bg-[#0c101a]/90 p-4 sm:p-5 shadow-xl flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-xs text-gray-400 font-semibold uppercase tracking-wider block">PRODUCTIVE TIME</span>
            <span className="text-2xl sm:text-3xl font-bold text-emerald-400 block">{totalProductiveMinutes} min</span>
            <p className="text-[11px] text-gray-400 block">Deep study hours accumulated</p>
          </div>
          <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-emerald-950/20 border border-emerald-500/20 flex items-center justify-center text-emerald-400 shrink-0">
            <Zap className="w-5 h-5 text-emerald-400" />
          </div>
        </div>

        {/* Focus Efficiency & Leak card */}
        <div className="rounded-2xl border border-white/10 bg-[#0c101a]/90 p-4 sm:p-5 shadow-xl flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-xs text-gray-400 font-semibold uppercase tracking-wider block">FOCUS EFFICIENCY</span>
            <div className="flex items-center gap-1.5 mt-0.5">
              <span className="text-2xl sm:text-3xl font-bold text-white">{focusEfficiency}%</span>
            </div>
            <p className="text-[11px] text-gray-400 block">{focusLeakIndex}% study energy leaked</p>
          </div>
          <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-purple-950/30 border border-purple-500/20 flex items-center justify-center text-purple-400 shrink-0">
            <TrendingDown className="w-5 h-5 text-purple-400" />
          </div>
        </div>

        {/* JEE Cognitive Impact: PYQs Lost */}
        <div className="rounded-2xl border border-white/10 bg-[#0c101a]/90 p-4 sm:p-5 shadow-xl flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-xs text-gray-400 font-semibold uppercase tracking-wider block">QUESTIONS LOST</span>
            <span className="text-2xl sm:text-3xl font-bold text-amber-400 block">~{equivalentQuestionsLost} PYQs</span>
            <p className="text-[11px] text-gray-400 block">At ~3.5 min/numerical</p>
          </div>
          <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-amber-950/20 border border-amber-500/20 flex items-center justify-center text-amber-400 shrink-0">
            <Target className="w-5 h-5 text-amber-400" />
          </div>
        </div>
      </div>

      {/* Peak Vulnerability & Diagnostic Insight Banner */}
      <div className="rounded-2xl border border-white/10 bg-[#0c101a]/90 p-5 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-xl bg-amber-950/20 border border-amber-500/30 flex items-center justify-center text-amber-500 shrink-0">
            <ShieldAlert className="w-5 h-5 text-amber-500" />
          </div>
          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-amber-500">PEAK VULNERABILITY WINDOW</span>
              <span className="px-2.5 py-0.5 rounded-full text-[11px] font-mono text-gray-200 bg-[#121826] border border-white/10 font-bold">
                {peakVulnerability.slot}
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-purple-950/40 text-purple-300 border border-purple-500/30">
                {peakVulnerability.minutes}m leaked ({peakVulnerability.percentage}%)
              </span>
            </div>
            <p className="text-xs text-gray-300 leading-relaxed">
              {peakVulnerability.recommendation}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-6 shrink-0 self-end md:self-center text-right font-mono">
          <div>
            <span className="text-[10px] text-gray-400 font-semibold uppercase tracking-wider block">ZONE CONTAMINATION</span>
            <span className="text-base font-bold text-purple-400 block mt-0.5">{inSessionContaminationRate}%</span>
          </div>
          <div>
            <span className="text-[10px] text-gray-400 font-semibold uppercase tracking-wider block">IN-SESSION LEAKS</span>
            <span className="text-base font-bold text-red-500 block mt-0.5">{inSessionWastedMinutes}m</span>
          </div>
        </div>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

        {/* Productive vs Wasted Bar chart */}
        <div className="rounded-2xl border border-white/10 bg-[#0c101a]/90 p-6 lg:col-span-2 space-y-4 shadow-xl">
          <div>
            <h2 className="text-base font-bold text-white">Efficiency Split</h2>
            <p className="text-xs text-gray-400">Comparing productive minutes vs. distraction minutes weekly</p>
          </div>

          <div className="h-72 w-full">
            {mounted ? (
              <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
                <BarChart data={compareData} margin={{ top: 10, right: 5, left: -20, bottom: 5 }}>
                  <XAxis dataKey="day" stroke="#4b5563" fontSize={11} tickLine={false} />
                  <YAxis stroke="#4b5563" fontSize={11} tickLine={false} />
                  <Tooltip
                    contentStyle={{ backgroundColor: "#11141d", borderColor: "rgba(255,255,255,0.06)", borderRadius: 8 }}
                    labelStyle={{ color: "#fff", fontWeight: "bold" }}
                  />
                  <Legend wrapperStyle={{ fontSize: 11 }} />
                  <Bar dataKey="Productive" fill="#10b981" radius={[4, 4, 0, 0]} name="Productive (Min)" />
                  <Bar dataKey="Wasted" fill="#ef4444" radius={[4, 4, 0, 0]} name="Wasted (Min)" />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-72 w-full rounded-2xl bg-[#11141d]" />
            )}
          </div>
        </div>

        {/* Top Distractions Donut */}
        <div className="rounded-2xl border border-white/10 bg-[#0c101a]/90 p-6 flex flex-col justify-between space-y-4 shadow-xl">
          <div>
            <h2 className="text-base font-bold text-white">Top Distractions</h2>
            <p className="text-xs text-gray-400">Sources of focus leakages</p>
          </div>

          <div className="h-44 flex items-center justify-center relative">
            {mounted ? (
              <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
                <PieChart>
                  <Pie
                    data={domainsSplit}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={65}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {domainsSplit.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-44 w-full rounded-2xl bg-[#11141d]" />
            )}
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none text-center">
              <span className="text-[10px] text-gray-400 uppercase tracking-wider block">Wasted ({dateFilter})</span>
              <span className="text-xl font-black text-white">{totalWastedMinutes}m</span>
            </div>
          </div>

          <div className="space-y-1.5 text-xs">
            {domainsSplit.map((d) => (
              <div key={d.name} className="flex justify-between items-center px-2 py-1 rounded bg-white/2 border border-card-border">
                <span className="flex items-center gap-1.5 text-gray-300 truncate max-w-[140px]">
                  <span className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: d.color }} />
                  <span className="truncate">{d.name}</span>
                </span>
                <div className="flex items-center gap-2 font-mono">
                  <span className="text-[10px] text-gray-400">{d.minutes}m</span>
                  <span className="font-bold text-white">{d.value}%</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Distraction Logs Registry with Filter, Search & Export */}
      <div className="rounded-2xl border border-white/10 bg-[#0c101a]/90 p-6 space-y-4 shadow-xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-white/[0.08] pb-4">
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-orange-400" />
            <span>
              Distraction Registry (
              {viewMode === "domain"
                ? `${domainSummaries.length} ${domainSummaries.length === 1 ? "domain" : "domains"}`
                : `${filteredLogs.length} ${filteredLogs.length === 1 ? "log" : "logs"}`}
              )
            </span>
          </h2>

          <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
            {/* View Mode Toggle */}
            <div className="flex items-center gap-1 bg-white/[0.04] p-1 rounded-xl border border-white/[0.08] text-xs">
              <button
                type="button"
                onClick={() => setViewMode("domain")}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg font-bold text-[11px] transition-all cursor-pointer ${
                  viewMode === "domain" ? "bg-purple-600 text-white" : "text-gray-400 hover:text-white"
                }`}
                title="Group distractions by domain"
              >
                <Layers className="w-3.5 h-3.5" />
                <span>Grouped</span>
              </button>
              <button
                type="button"
                onClick={() => setViewMode("detailed")}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg font-bold text-[11px] transition-all cursor-pointer ${
                  viewMode === "detailed" ? "bg-purple-600 text-white" : "text-gray-400 hover:text-white"
                }`}
                title="Show all individual activity logs"
              >
                <List className="w-3.5 h-3.5" />
                <span>All Logs</span>
              </button>
            </div>

            {/* Search Input */}
            <div className="relative flex-1 sm:w-48">
              <Search className="w-3.5 h-3.5 absolute left-3 top-3 text-gray-500 pointer-events-none" />
              <input
                type="text"
                placeholder="Search domain..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full glass-input pl-8 pr-3 py-1.5 text-xs text-white focus:outline-none"
              />
            </div>

            {/* Date Filter */}
            <div className="flex items-center gap-1 bg-white/[0.04] p-1 rounded-xl border border-white/[0.08] text-xs">
              <Filter className="w-3.5 h-3.5 text-gray-400 ml-1" />
              {(["All", "Today", "Week"] as const).map((df) => (
                <button
                  key={df}
                  onClick={() => setDateFilter(df)}
                  className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition-all cursor-pointer ${
                    dateFilter === df ? "bg-purple-600 text-white" : "text-gray-400 hover:text-white"
                  }`}
                >
                  {df}
                </button>
              ))}
            </div>

            {/* Export CSV Button */}
            <Button onClick={handleExportCSV} variant="secondary" size="sm" className="cursor-pointer">
              <Download className="w-3.5 h-3.5" />
              Export CSV
            </Button>

            {/* Clear All Button */}
            {allLogs.length > 0 && (
              <button
                type="button"
                onClick={handleClearAll}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-red-400 bg-red-500/10 border border-red-500/20 hover:bg-red-500/20 hover:text-red-300 transition-colors cursor-pointer"
                title="Clear all recorded distraction logs"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Clear All</span>
              </button>
            )}
          </div>
        </div>

        {/* Logs Rendering */}
        <div className="space-y-3">
          {viewMode === "domain" ? (
            /* Group by Domain View */
            domainSummaries.length === 0 ? (
              <p className="text-xs text-gray-500 text-center py-6">No distraction logs matching criteria. Excellent focus!</p>
            ) : (
              domainSummaries.map((summary) => {
                const isExpanded = expandedDomains.has(summary.domain);
                const m = Math.floor(summary.totalSeconds / 60);
                const s = summary.totalSeconds % 60;
                const timeDisplay =
                  summary.totalSeconds > 0
                    ? `${m}m ${s > 0 ? `${s}s ` : ""}wasted`
                    : summary.blockedCount > 0
                    ? "0s (Shield Intercepted)"
                    : "0s";

                const dateObj = new Date(summary.lastVisited);
                const isValidDate = !isNaN(dateObj.getTime());
                const lastTimeFormatted = isValidDate && mounted
                  ? dateObj.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: true })
                  : "—";
                const lastDateFormatted = isValidDate && mounted
                  ? dateObj.toLocaleDateString([], { month: "short", day: "numeric" })
                  : (isValidDate ? summary.lastVisited.split("T")[0] : "Today");

                return (
                  <div
                    key={summary.domain}
                    className="rounded-xl border border-white/[0.08] bg-slate-950/80 hover:border-purple-500/30 transition-all overflow-hidden shadow-md"
                  >
                    <div
                      onClick={() => toggleExpandDomain(summary.domain)}
                      className="p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs cursor-pointer select-none"
                    >
                      <div className="space-y-1.5 flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <Globe className="w-4 h-4 text-purple-400 shrink-0" />
                          <span className="font-bold text-white text-sm font-mono">{summary.domain}</span>

                          {/* Aggregated Duration Pill */}
                          <span className="px-2.5 py-0.5 rounded text-[11px] font-bold font-mono bg-amber-500/15 text-amber-300 border border-amber-500/30 flex items-center gap-1">
                            <Clock className="w-3 h-3 text-amber-400" />
                            <span>{timeDisplay}</span>
                          </span>

                          {/* Total Visits Pill */}
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold font-mono bg-white/[0.05] text-gray-300 border border-white/[0.08]">
                            {summary.visitCount} {summary.visitCount === 1 ? "visit" : "visits"}
                          </span>

                          {/* Blocked vs Browsing */}
                          {summary.blockedCount > 0 && (
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-red-500/15 text-red-400 border border-red-500/30">
                              🛡️ {summary.blockedCount} Blocked
                            </span>
                          )}

                          {/* In-Session Leaks */}
                          {summary.inSessionCount > 0 && (
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-500/15 text-purple-300 border border-purple-500/30">
                              🚨 {summary.inSessionCount} in Focus Zone
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-gray-400 font-mono truncate max-w-md">
                          Last activity {lastDateFormatted} at {lastTimeFormatted}
                        </p>
                      </div>

                      <div className="flex items-center gap-3 shrink-0 self-end sm:self-center">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleExpandDomain(summary.domain);
                          }}
                          className="flex items-center gap-1 px-2.5 py-1 rounded text-[11px] text-gray-300 hover:text-white bg-white/[0.04] hover:bg-white/[0.08] transition-colors cursor-pointer"
                        >
                          <span>{isExpanded ? "Hide details" : "View details"}</span>
                          {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                        </button>

                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeleteDomainLogs(summary.domain, summary.incidentIds);
                          }}
                          className="p-1.5 rounded-lg text-gray-400 hover:text-red-400 hover:bg-red-500/10 transition-colors cursor-pointer"
                          title={`Delete all logs for ${summary.domain}`}
                          aria-label={`Delete all logs for ${summary.domain}`}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    {/* Expanded child logs */}
                    {isExpanded && (
                      <div className="border-t border-white/[0.06] bg-black/40 p-3 space-y-2">
                        {summary.logs.map((log) => {
                          const dateObj = new Date(log.timestamp);
                          const isValid = !isNaN(dateObj.getTime());
                          const tFormatted = isValid && mounted
                            ? dateObj.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: true })
                            : "—";
                          const dFormatted = isValid && mounted
                            ? dateObj.toLocaleDateString([], { month: "short", day: "numeric" })
                            : (isValid ? log.timestamp.split("T")[0] : "Today");
                          const durM = log.durationMinutes || 0;
                          const durS = log.durationSeconds ?? durM * 60;

                          return (
                            <div
                              key={log.id}
                              className="p-2.5 rounded-lg border border-white/[0.04] bg-white/[0.02] flex items-center justify-between text-[11px] gap-2 font-mono"
                            >
                              <div className="flex items-center gap-2 flex-wrap min-w-0">
                                <span className="text-gray-400">{dFormatted} {tFormatted}</span>
                                <span className="text-gray-300 truncate max-w-xs">{log.website}</span>
                                <span className="text-amber-300 font-bold">
                                  {log.blocked ? "🛡️ 0s" : `${durS}s (${durM}m)`}
                                </span>
                                {log.isDuringSession && (
                                  <span className="text-[10px] text-purple-300">🚨 In Session</span>
                                )}
                              </div>

                              <button
                                type="button"
                                onClick={() => handleDeleteLog(log.id, log.domain)}
                                className="text-gray-500 hover:text-red-400 transition-colors shrink-0 p-1 cursor-pointer"
                                title="Delete this incident"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              })
            )
          ) : (
            /* All Activity Logs View */
            filteredLogs.length === 0 ? (
              <p className="text-xs text-gray-500 text-center py-6">No distraction logs matching criteria. Excellent focus!</p>
            ) : (
              filteredLogs.map((log: VisitLogDoc) => {
                const dateObj = new Date(log.timestamp);
                const isValidDate = !isNaN(dateObj.getTime());
                const timeFormatted = isValidDate && mounted
                  ? dateObj.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: true })
                  : "—";
                const dateFormatted = isValidDate && mounted
                  ? dateObj.toLocaleDateString([], { month: "short", day: "numeric" })
                  : (isValidDate ? log.timestamp.split("T")[0] : "Today");

                const durationMins = log.durationMinutes || 0;
                const durationSecs = log.durationSeconds || durationMins * 60;

                return (
                  <div key={log.id} className="p-4 rounded-xl border border-white/[0.08] bg-slate-950/80 hover:border-purple-500/30 transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs shadow-md">
                    <div className="space-y-1.5">
                      <div className="flex items-center gap-2 flex-wrap">
                        <Globe className="w-4 h-4 text-red-400 shrink-0" />
                        <span className="font-bold text-white text-sm font-mono">{log.domain}</span>

                        {/* Wasted Duration Pill */}
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold font-mono bg-amber-500/15 text-amber-300 border border-amber-500/30 flex items-center gap-1">
                          <Clock className="w-3 h-3 text-amber-400" />
                          <span>{durationMins} min wasted ({durationSecs}s)</span>
                        </span>

                        {/* Shield vs Active Social Browsing */}
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${log.blocked
                            ? "bg-red-500/15 text-red-400 border border-red-500/30"
                            : "bg-orange-500/15 text-orange-400 border border-orange-500/30"
                          }`}>
                          {log.blocked ? "🛡️ Blocked Shield" : "📱 Active Social Browsing"}
                        </span>

                        {/* Session Context Pill */}
                        {log.isDuringSession || log.focusSessionId ? (
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-500/15 text-purple-300 border border-purple-500/30">
                            🚨 Leaked in Focus Zone
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded text-[10px] font-mono text-gray-400 bg-white/[0.03] border border-white/[0.06]">
                            ☕ Casual Browsing
                          </span>
                        )}

                        <span className="px-2 py-0.5 rounded text-[10px] font-mono text-gray-400 bg-white/[0.04] border border-white/[0.06]">
                          {dateFormatted}
                        </span>
                      </div>
                      <p className="text-[11px] text-gray-400 font-mono truncate max-w-md">{log.website}</p>
                    </div>

                    <div className="flex items-center gap-4 shrink-0 justify-between w-full sm:w-auto pt-2 sm:pt-0 border-t sm:border-t-0 border-white/[0.05]">
                      <div className="text-left sm:text-right space-y-0.5">
                        <p className="text-xs font-bold text-white font-mono flex items-center sm:justify-end gap-1.5">
                          <Clock className="w-3.5 h-3.5 text-amber-400" />
                          <span>{timeFormatted}</span>
                        </p>
                        <div className="flex items-center sm:justify-end gap-2 text-[10px] text-gray-500 font-mono">
                          <Monitor className="w-3 h-3 text-cyan-400" />
                          <span>{log.device || "Chrome Extension"}</span>
                          {log.focusSessionId && <span className="text-purple-400">• Sess: {log.focusSessionId.slice(0, 10)}</span>}
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDeleteLog(log.id, log.domain);
                        }}
                        className="p-1.5 rounded-lg text-gray-400 hover:text-red-400 hover:bg-red-500/10 transition-colors cursor-pointer"
                        title="Delete log entry"
                        aria-label={`Delete ${log.domain} log`}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })
            )
          )}
        </div>
      </div>
    </WorkspaceLayout>
  );
}
