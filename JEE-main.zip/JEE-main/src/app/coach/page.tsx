"use client";

import { useState, useEffect, useRef, useMemo } from "react";
import { useRouter } from "next/navigation";
import { WorkspaceLayout } from "@/components/workspace-layout";
import { useStudyStore } from "@/store/use-study-store";
import { useMistakeStore } from "@/store/use-mistake-store";
import { useUserProfile, useStudyStreak } from "@/hooks/use-user-profile";
import { useExam } from "@/hooks/use-exam";
import { soundManager } from "@/lib/sound-manager";
import { MathText } from "@/components/ui/math-text";
import {
  CoachMode,
  CoachMessage,
  StructuredCoachResponse,
  SuggestedCoachAction,
} from "@/services/coach/coachTypes";
import {
  computeStudyLoadSignal,
  computeMistakeTrend,
  computePreparationSnapshot,
  generateDynamicQuickActions,
  generateProactiveForgeInsight,
} from "@/services/coach/coachMetrics";
import {
  Bot,
  Sparkles,
  Send,
  Upload,
  BookOpen,
  Calculator,
  HelpCircle,
  Clock,
  Flame,
  ChevronRight,
  TrendingDown,
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  ThumbsUp,
  ThumbsDown,
  Layers,
  FileText,
  Play,
  RotateCcw,
  Activity,
  Compass,
  X,
  Target,
} from "lucide-react";

export default function AIStudyCoachPage() {
  const router = useRouter();

  // FocusForge Store Bindings
  const {
    activeSession,
    status: sessionStatus,
    durationMinutes,
    accumulatedElapsedSeconds,
    timerStartedAtTimestamp,
    sessionHistory,
    startSession,
  } = useStudyStore();

  const { mistakes, syllabus } = useMistakeStore();
  const { userProfile } = useUserProfile();
  const { streak } = useStudyStreak();
  const { config, isNeet, isJee } = useExam();

  // Active User Profile Info
  const userFirstName = userProfile?.displayName?.trim().split(" ")[0] || "Aspirant";
  const examType = isNeet ? "NEET" : isJee ? "JEE" : "CBSE";
  const targetYear = userProfile?.targetYear || "2027";
  const profileStreamLabel = isNeet
    ? `NEET • Class 12 • PCB (${targetYear})`
    : isJee
    ? `JEE • Class 12 • PCM (${targetYear})`
    : `CBSE • Class 12 • ${config.displayName}`;

  // Active / Last Studied Context
  const hasActiveSession = Boolean(activeSession && (sessionStatus === "focus" || sessionStatus === "paused"));
  const activeSubject = activeSession?.subject || (sessionHistory.length > 0 ? sessionHistory[sessionHistory.length - 1].subject : "Physics");
  const activeChapter = activeSession?.chapter || (sessionHistory.length > 0 ? sessionHistory[sessionHistory.length - 1].chapter : "Electrostatics");
  const activeTopic = activeSession?.subchapter || activeSession?.taskType || "Core Concepts";

  // Calculate live elapsed minutes
  const [liveElapsedSeconds, setLiveElapsedSeconds] = useState(accumulatedElapsedSeconds || 0);
  useEffect(() => {
    if (sessionStatus !== "focus" || !timerStartedAtTimestamp) {
      setLiveElapsedSeconds(accumulatedElapsedSeconds || 0);
      return;
    }
    const interval = setInterval(() => {
      const run = Math.max(0, Math.floor((Date.now() - timerStartedAtTimestamp) / 1000));
      setLiveElapsedSeconds((accumulatedElapsedSeconds || 0) + run);
    }, 1000);
    return () => clearInterval(interval);
  }, [sessionStatus, timerStartedAtTimestamp, accumulatedElapsedSeconds]);

  const activeElapsedMinutes = Math.floor(liveElapsedSeconds / 60);

  // Today study minutes calculated from real session history
  const todayMins = useMemo(() => {
    const todayKey = new Date().toISOString().split("T")[0];
    return (sessionHistory || [])
      .filter((s) => s.date === todayKey || (s.startTime && s.startTime.startsWith(todayKey)))
      .reduce((sum, s) => sum + (s.totalDurationMinutes || 0), 0) + (hasActiveSession ? activeElapsedMinutes : 0);
  }, [sessionHistory, hasActiveSession, activeElapsedMinutes]);

  const todayHours = (todayMins / 60).toFixed(1);

  // Real Metrics (Zero Fake Intelligence)
  const studyLoadSignal = useMemo(() => computeStudyLoadSignal(sessionHistory), [sessionHistory]);
  const mistakeTrend = useMemo(() => computeMistakeTrend(mistakes), [mistakes]);

  const dueRevisionsCount = useMemo(() => {
    return (mistakes || []).filter((m) => {
      if (m.status === "completed" || m.status === "archived") return false;
      if (!m.nextRevisionAt) return true;
      return new Date(m.nextRevisionAt).getTime() <= Date.now();
    }).length;
  }, [mistakes]);

  const prepSnapshot = useMemo(() => {
    return computePreparationSnapshot(syllabus, sessionHistory, mistakes, dueRevisionsCount);
  }, [syllabus, sessionHistory, mistakes, dueRevisionsCount]);

  const quickActionCards = useMemo(() => {
    return generateDynamicQuickActions(syllabus, mistakes, sessionHistory, dueRevisionsCount, activeSubject);
  }, [syllabus, mistakes, sessionHistory, dueRevisionsCount, activeSubject]);

  const proactiveInsight = useMemo(() => {
    return generateProactiveForgeInsight(sessionHistory, mistakes, syllabus);
  }, [sessionHistory, mistakes, syllabus]);

  // Mode Selector
  const [selectedMode, setSelectedMode] = useState<CoachMode>("ASK");

  // Dynamic Prompt Suggestions based on current Subject & Chapter
  const promptSuggestions = useMemo(() => {
    const subj = activeSubject.toLowerCase();
    if (subj.includes("physics")) {
      return [
        `Explain capacitance and dielectric insertion simply`,
        `Give me 3 ${examType}-level questions on ${activeChapter}`,
        `Test me on electrostatic potential and field`,
        `Show my mistake patterns in Physics`,
        `Give me a 30-minute revision plan for ${activeChapter}`,
      ];
    } else if (subj.includes("chem")) {
      return [
        `Explain Nernst equation with temperature dependence`,
        `Give me 3 ${examType}-level questions on ${activeChapter}`,
        `Distinguish between SN1 and SN2 mechanisms`,
        `Show my repeated chemistry errors`,
        `Explain Crystal Field Theory splitting for d4 complexes`,
      ];
    } else if (subj.includes("math")) {
      return [
        `Explain King's Rule of definite integrals with examples`,
        `Solve shortest distance between skew lines step-by-step`,
        `Give me 3 ${examType} problems on ${activeChapter}`,
        `Explain Bayes theorem formula derivation`,
        `Quiz me on Matrices & Determinants properties`,
      ];
    } else if (subj.includes("bio")) {
      return [
        `Explain Lac Operon regulation with inducer action`,
        `Give me 3 NEET-level questions on ${activeChapter}`,
        `Summarize spermatogenesis vs oogenesis differences`,
        `Explain the principle of RNA interference (RNAi)`,
        `Quiz me on Mendelian dihybrid inheritance ratios`,
      ];
    } else {
      return [
        `Explain the central theme of The Last Lesson`,
        `Show the official CBSE Class 12 Notice Writing format`,
        `Give me CBSE-style literature questions on ${activeChapter}`,
        `Analyze my answer against CBSE marking schemes`,
        `Explain literary devices in Keeping Quiet`,
      ];
    }
  }, [activeSubject, activeChapter, examType]);

  // Initial Context-Aware Greeting
  const initialGreeting = useMemo(() => {
    if (hasActiveSession) {
      return `Welcome back, ${userFirstName}. You are currently ${activeElapsedMinutes} minutes into your focus block on **${activeSubject}: ${activeChapter}**.\n\nI have synced your syllabus tracking, mistake records, and exam profile (${examType} ${targetYear}). How can I assist your study session right now?`;
    }
    if (todayMins > 0) {
      return `Greetings ${userFirstName}. You have completed ${todayHours}h of study today with an active streak of ${streak} ${streak === 1 ? "day" : "days"}. You completed **${activeChapter}** and have ${dueRevisionsCount} pending revision ${dueRevisionsCount === 1 ? "item" : "items"}. What should we tackle next?`;
    }
    return `ForgeCoach is ready, ${userFirstName}. Context is synchronized with your ${profileStreamLabel} profile. Ask me an academic question, request a concept explanation, solve a problem, analyze your mistakes, or generate exam practice questions.`;
  }, [userFirstName, hasActiveSession, activeElapsedMinutes, activeSubject, activeChapter, examType, targetYear, todayMins, todayHours, streak, dueRevisionsCount, profileStreamLabel]);

  // Chat State
  const [chatMessages, setChatMessages] = useState<CoachMessage[]>([
    {
      id: "msg-init",
      sender: "coach",
      text: initialGreeting,
      timestamp: Date.now(),
    },
  ]);

  const [inputText, setInputText] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [thinkingStage, setThinkingStage] = useState<string | null>(null);
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const chatScrollRef = useRef<HTMLDivElement>(null);

  // Auto-scroll chat to bottom
  useEffect(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight;
    }
  }, [chatMessages, isTyping, thinkingStage]);

  // Image Upload Handler
  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      setUploadedImage(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  // Send Message Flow
  const handleSendMessage = async (customPrompt?: string) => {
    const textToSend = (customPrompt || inputText).trim();
    if (!textToSend && !uploadedImage) return;

    soundManager.play("send");
    soundManager.startLoop("processing");

    const userMessageId = `user-${Date.now()}`;
    const userMsg: CoachMessage = {
      id: userMessageId,
      sender: "user",
      text: textToSend || (uploadedImage ? "Analyze this uploaded question/problem screenshot." : ""),
      imageUrl: uploadedImage || undefined,
      timestamp: Date.now(),
    };

    setChatMessages((prev) => [...prev, userMsg]);
    setInputText("");
    const currentImage = uploadedImage;
    setUploadedImage(null);
    setIsTyping(true);
    setThinkingStage("Analyzing question & checking academic syllabus...");

    try {
      // Build client state snapshot for server context builder
      const payload = {
        message: textToSend,
        mode: selectedMode,
        imageBase64: currentImage || undefined,
        conversationHistory: chatMessages.slice(-6).map((m) => ({
          sender: m.sender,
          text: m.text,
        })),
        userState: {
          userProfile,
          activeSession,
          status: sessionStatus,
          durationMinutes,
          accumulatedElapsedSeconds,
          timerStartedAtTimestamp,
          todayStudyMinutes: todayMins,
          streak,
          syllabus,
          mistakes,
          sessionHistory,
        },
      };

      const res = await fetch("/api/coach/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        throw new Error(`HTTP error ${res.status}`);
      }

      const json = await res.json();
      const structuredResp: StructuredCoachResponse = json.response;

      const coachMsg: CoachMessage = {
        id: `coach-${Date.now()}`,
        sender: "coach",
        text: structuredResp.answer,
        structuredResponse: structuredResp,
        timestamp: Date.now(),
      };

      setChatMessages((prev) => [...prev, coachMsg]);
      soundManager.play("receive");
    } catch (err: unknown) {
      console.warn("[ForgeCoach] API call error, applying local academic reasoning fallback:", err);

      // Local graceful fallback
      const fallbackMsg: CoachMessage = {
        id: `coach-${Date.now()}`,
        sender: "coach",
        text: `I evaluated your question regarding "${textToSend}".\n\nEnsure you identify your given quantities, write the governing formula with standard SI units, and calculate intermediate values step-by-step. All FocusForge local databases remain accessible.`,
        structuredResponse: {
          intent: selectedMode,
          answer: `I evaluated your question regarding "${textToSend}".\n\nEnsure you identify your given quantities, write the governing formula with standard SI units, and calculate intermediate values step-by-step.`,
          keyIdea: "Active reasoning from first principles delivers permanent exam retention.",
          confidence: "HIGH",
          sources: [
            { title: "FocusForge Offline Knowledge Layer", ref: "Canonical Curriculum v2026.2", type: "SYLLABUS" },
          ],
        },
        timestamp: Date.now(),
      };
      setChatMessages((prev) => [...prev, fallbackMsg]);
      soundManager.play("receive");
    } finally {
      soundManager.stopLoop("processing");
      setIsTyping(false);
      setThinkingStage(null);
    }
  };

  // Action Button Execution Handler
  const handleExecuteAction = async (action: SuggestedCoachAction) => {
    soundManager.play("click");

    switch (action.type) {
      case "START_SESSION": {
        const mins = (action.payload?.minutes as number) || 25;
        const subj = (action.payload?.subject as string) || activeSubject || "Physics";
        const chap = (action.payload?.chapter as string) || activeChapter || "Electrostatics";
        const taskType = (action.payload?.taskType as string) || "PYQ";
        await startSession(subj, chap, taskType, "Pomodoro", mins);
        router.push("/study");
        break;
      }
      case "REVIEW_MISTAKES": {
        router.push("/mistakes");
        break;
      }
      case "ADD_REVISION": {
        router.push("/revisions");
        break;
      }
      case "PRACTICE_QUESTIONS": {
        handleSendMessage(`Give me 3 practice questions on ${action.payload?.chapter || activeChapter} with full solutions.`);
        break;
      }
      case "OPEN_CHAPTER": {
        router.push("/jee");
        break;
      }
      default:
        handleSendMessage(`Explain ${action.label} in depth.`);
        break;
    }
  };

  // Message Feedback Handlers
  const handleFeedback = (messageId: string, type: "helpful" | "unhelpful") => {
    soundManager.play("click");
    setChatMessages((prev) =>
      prev.map((m) => (m.id === messageId ? { ...m, feedback: type } : m))
    );
  };

  return (
    <WorkspaceLayout title="AI Study Coach">
      <div className="space-y-6 max-w-[1600px] mx-auto pb-10">

        {/* ========================================================================= */}
        {/* ZONE A: COACH HEADER */}
        {/* ========================================================================= */}
        <header className="rounded-2xl border border-white/10 bg-[#0c101a]/90 backdrop-blur-xl p-5 shadow-2xl relative overflow-hidden">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            
            {/* Left: Branding & Status */}
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-purple-600/30 to-cyan-600/20 border border-purple-500/30 flex items-center justify-center text-purple-300 shadow-inner shrink-0">
                <Bot className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center gap-2.5 flex-wrap">
                  <h1 className="text-lg font-bold text-white tracking-tight">ForgeCoach</h1>
                  <span className="text-xs px-2.5 py-0.5 rounded-full bg-purple-500/15 border border-purple-500/30 text-purple-300 font-semibold tracking-wide">
                    AI Study Intelligence
                  </span>
                  
                  {/* Status Indicator */}
                  {hasActiveSession ? (
                    <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 font-medium flex items-center gap-1.5 animate-pulse">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block" /> Session Active
                    </span>
                  ) : (
                    <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-cyan-500/15 border border-cyan-500/30 text-cyan-300 font-medium flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-cyan-400 inline-block" /> Context Synced
                    </span>
                  )}
                </div>

                {/* Compact User Stream Metadata (Never Hardcoded JEE) */}
                <p className="text-xs text-gray-400 mt-1 flex items-center gap-2">
                  <span className="font-semibold text-gray-300">{profileStreamLabel}</span>
                  <span className="text-gray-600">•</span>
                  <span>Academic Year 2026–27</span>
                </p>
              </div>
            </div>

            {/* Right: Academic Command Center / Modes */}
            <div className="flex items-center gap-1.5 bg-[#101422] p-1.5 rounded-xl border border-white/5 overflow-x-auto">
              {(["ASK", "SOLVE", "EXPLAIN", "PRACTICE", "REVISE", "ANALYZE"] as CoachMode[]).map((mode) => (
                <button
                  key={mode}
                  type="button"
                  onClick={() => {
                    setSelectedMode(mode);
                    soundManager.play("click");
                  }}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer shrink-0 ${
                    selectedMode === mode
                      ? "bg-purple-600 text-white shadow-lg shadow-purple-600/30"
                      : "text-gray-400 hover:text-white hover:bg-white/5"
                  }`}
                >
                  {mode === "ASK" && "Ask"}
                  {mode === "SOLVE" && "Solve"}
                  {mode === "EXPLAIN" && "Explain"}
                  {mode === "PRACTICE" && "Quiz"}
                  {mode === "REVISE" && "Revise"}
                  {mode === "ANALYZE" && "Analyze"}
                </button>
              ))}
            </div>

          </div>
        </header>

        {/* ========================================================================= */}
        {/* MAIN TWO-COLUMN WORKSPACE: LEFT INSIGHT PANEL + RIGHT CHAT ZONE */}
        {/* ========================================================================= */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">

          {/* ======================================================================= */}
          {/* ZONE D: INSIGHT PANEL (4 Cols on Large Screens) */}
          {/* ======================================================================= */}
          <aside className="lg:col-span-4 space-y-5">

            {/* 1. Proactive Forge Insight Card */}
            {proactiveInsight && (
              <div className="rounded-2xl border border-purple-500/30 bg-gradient-to-br from-purple-950/40 to-[#0c101a] p-4.5 space-y-3 shadow-xl relative overflow-hidden">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-purple-300 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-purple-400" /> FORGE INSIGHT
                  </span>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-200 border border-purple-500/30 font-semibold">
                    Data Grounded
                  </span>
                </div>

                <h4 className="text-xs font-bold text-white leading-snug">{proactiveInsight.title}</h4>
                <p className="text-xs text-gray-300 leading-relaxed">{proactiveInsight.message}</p>

                <div className="p-2.5 rounded-xl bg-black/40 border border-white/5 text-[11px] text-gray-400 font-mono">
                  <span className="text-purple-300 font-semibold">Evidence:</span> {proactiveInsight.evidence}
                </div>

                <button
                  type="button"
                  onClick={() => handleSendMessage(proactiveInsight.actionPrompt)}
                  className="w-full py-2 px-3 rounded-xl bg-purple-600/30 hover:bg-purple-600/50 border border-purple-500/40 text-purple-200 text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  <span>{proactiveInsight.actionLabel}</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {/* 2. Observable Study Diagnostics (Replacing Fake Burnout / Fake Readiness) */}
            <div className="rounded-2xl border border-white/10 bg-[#0c101a]/90 p-5 space-y-4 shadow-xl">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-gray-300 uppercase tracking-wider flex items-center gap-2">
                  <Activity className="w-4 h-4 text-cyan-400" /> STUDY LOAD & ERROR DIAGNOSTICS
                </h3>
              </div>

              {/* A. Study Load Signal */}
              <div className="p-3.5 bg-[#101422] border border-white/5 rounded-xl space-y-1.5">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-gray-400 font-medium">Study Load Signal</span>
                  <span className={`font-semibold px-2 py-0.5 rounded-md ${
                    studyLoadSignal.signal === "Heavy"
                      ? "bg-amber-500/20 text-amber-300 border border-amber-500/30"
                      : studyLoadSignal.signal === "Light"
                      ? "bg-blue-500/20 text-blue-300 border border-blue-500/30"
                      : studyLoadSignal.signal === "Balanced"
                      ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
                      : "bg-gray-800 text-gray-400"
                  }`}>
                    {studyLoadSignal.signal}
                  </span>
                </div>
                <p className="text-[11px] text-gray-400 leading-relaxed">
                  {studyLoadSignal.explanation}
                </p>
              </div>

              {/* B. Mistake Trend */}
              <div className="p-3.5 bg-[#101422] border border-white/5 rounded-xl space-y-1.5">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-gray-400 font-medium">Mistake Trend</span>
                  {mistakeTrend.hasEnoughData ? (
                    <span className="font-semibold text-purple-300 flex items-center gap-1">
                      {mistakeTrend.trendPctVsLastWeek !== null && mistakeTrend.trendPctVsLastWeek < 0 ? (
                        <TrendingDown className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <TrendingUp className="w-3.5 h-3.5 text-amber-400" />
                      )}
                      {mistakeTrend.mistakesPerDay}/day
                    </span>
                  ) : (
                    <span className="text-[11px] text-gray-500">Not enough data yet</span>
                  )}
                </div>
                <p className="text-[11px] text-gray-400 leading-relaxed">
                  {mistakeTrend.summaryText}
                </p>
              </div>

              {/* C. Preparation Snapshot */}
              <div className="p-3.5 bg-[#17122b]/80 border border-purple-500/30 rounded-xl space-y-2.5">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-purple-300 font-bold">Preparation Snapshot</span>
                  {prepSnapshot.readinessEstimate !== null ? (
                    <span className="font-bold text-white px-2 py-0.5 rounded bg-purple-500/30 border border-purple-400/40">
                      {prepSnapshot.readinessEstimate}% Score
                    </span>
                  ) : (
                    <span className="text-[10px] text-purple-400">Baseline in Progress</span>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-2 pt-1 text-[11px]">
                  <div className="p-2 rounded-lg bg-black/40 border border-white/5">
                    <span className="text-gray-400 block text-[10px]">Syllabus Coverage</span>
                    <span className="font-bold text-white text-xs">{prepSnapshot.syllabusCoveragePct}%</span>
                  </div>
                  <div className="p-2 rounded-lg bg-black/40 border border-white/5">
                    <span className="text-gray-400 block text-[10px]">Solved PYQs</span>
                    <span className="font-bold text-emerald-400 text-xs">{prepSnapshot.recentPracticeQuestions}</span>
                  </div>
                  <div className="p-2 rounded-lg bg-black/40 border border-white/5">
                    <span className="text-gray-400 block text-[10px]">Weak Topics</span>
                    <span className="font-bold text-amber-400 text-xs">{prepSnapshot.weakTopicsCount}</span>
                  </div>
                  <div className="p-2 rounded-lg bg-black/40 border border-white/5">
                    <span className="text-gray-400 block text-[10px]">Revisions Due</span>
                    <span className="font-bold text-cyan-400 text-xs">{prepSnapshot.revisionsDueCount}</span>
                  </div>
                </div>

                <p className="text-[10px] text-gray-400 italic leading-snug">
                  {prepSnapshot.explanation}
                </p>
              </div>
            </div>

            {/* 3. Dynamic Intelligent Quick Action Cards */}
            <div className="rounded-2xl border border-white/10 bg-[#0c101a]/90 p-5 space-y-3 shadow-xl">
              <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider">
                INTELLIGENT QUICK ACTIONS
              </h3>

              <div className="space-y-2.5">
                {quickActionCards.map((card) => (
                  <button
                    key={card.id}
                    type="button"
                    onClick={() => handleSendMessage(card.actionPrompt)}
                    className="w-full text-left p-3 rounded-xl border border-white/5 bg-[#101422] hover:bg-[#151b2e] hover:border-purple-500/30 transition-all cursor-pointer group space-y-1 block"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-purple-400">
                        {card.badge}
                      </span>
                      <ChevronRight className="w-3.5 h-3.5 text-gray-500 group-hover:text-purple-300 transition-colors" />
                    </div>
                    <div className="text-xs font-bold text-white group-hover:text-purple-200 transition-colors">
                      {card.title}
                    </div>
                    <div className="text-[11px] text-gray-400">
                      {card.subtitle}
                    </div>
                  </button>
                ))}
              </div>
            </div>

          </aside>

          {/* ======================================================================= */}
          {/* RIGHT SIDE: ZONE B (LIVE CONTEXT) + ZONE C (INTELLIGENT CHAT) (8 Cols) */}
          {/* ======================================================================= */}
          <main className="lg:col-span-8 space-y-4">

            {/* ===================================================================== */}
            {/* ZONE B: LIVE STUDY CONTEXT BAR */}
            {/* ===================================================================== */}
            <div className="rounded-2xl border border-white/10 bg-[#0c101a]/95 p-4 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-3">
              <div className="space-y-1">
                <span className="text-[10px] font-bold uppercase tracking-wider text-cyan-400 flex items-center gap-1.5">
                  <Compass className="w-3.5 h-3.5 text-cyan-400" />
                  {hasActiveSession ? "CURRENT STUDY CONTEXT" : "CURRENT CONTEXT"}
                </span>

                <div className="text-xs font-semibold text-white flex items-center gap-2 flex-wrap">
                  {hasActiveSession ? (
                    <>
                      <span className="text-cyan-300 font-bold">{activeSubject}</span>
                      <span className="text-gray-500">→</span>
                      <span className="text-gray-200">{activeChapter}</span>
                      <span className="text-gray-500">→</span>
                      <span className="text-gray-400 text-[11px]">{activeTopic}</span>
                    </>
                  ) : (
                    <>
                      <span className="text-gray-400 font-medium">No active study session</span>
                      <span className="text-gray-600">•</span>
                      <span className="text-gray-300">Last studied: {activeSubject} → {activeChapter}</span>
                    </>
                  )}
                </div>
              </div>

              {/* Progress Counters */}
              <div className="flex items-center gap-2 flex-wrap shrink-0">
                {hasActiveSession && (
                  <div className="px-3 py-1.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-semibold flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5" />
                    <span>Session: {activeElapsedMinutes}m</span>
                  </div>
                )}

                <div className="px-3 py-1.5 rounded-xl bg-[#101422] border border-white/5 text-gray-300 text-xs flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Today: <strong className="text-white">{todayHours}h</strong></span>
                </div>

                <div className="px-3 py-1.5 rounded-xl bg-[#101422] border border-white/5 text-gray-300 text-xs flex items-center gap-1.5">
                  <Flame className="w-3.5 h-3.5 text-amber-400" />
                  <span>Streak: <strong className="text-white">{streak}d</strong></span>
                </div>
              </div>
            </div>

            {/* ===================================================================== */}
            {/* ZONE C: INTELLIGENT CHAT PANEL */}
            {/* ===================================================================== */}
            <div className="rounded-2xl border border-white/10 bg-[#0c101a]/90 flex flex-col h-[650px] shadow-2xl overflow-hidden relative">

              {/* Dynamic Contextual Prompt Suggestions */}
              <div className="px-5 py-2.5 bg-[#090d16] border-b border-white/5 flex items-center gap-2 overflow-x-auto text-[11px]">
                <span className="text-gray-500 font-semibold uppercase text-[10px] shrink-0">Suggested:</span>
                {promptSuggestions.map((prompt, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => handleSendMessage(prompt)}
                    className="px-3 py-1 rounded-full bg-[#101422] hover:bg-[#181f33] border border-white/5 hover:border-purple-500/30 text-gray-300 hover:text-white transition-all whitespace-nowrap cursor-pointer shrink-0"
                  >
                    {prompt}
                  </button>
                ))}
              </div>

              {/* Chat Message Stream */}
              <div
                ref={chatScrollRef}
                className="flex-1 p-5 overflow-y-auto space-y-5 scroll-smooth"
              >
                {chatMessages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex ${msg.sender === "user" ? "justify-end" : "justify-start"}`}
                  >
                    {msg.sender === "user" ? (
                      /* USER MESSAGE BUBBLE */
                      <div className="max-w-[85%] rounded-2xl rounded-tr-sm p-4 bg-gradient-to-r from-purple-700/80 to-purple-600/90 text-white text-xs leading-relaxed shadow-lg space-y-2">
                        {msg.imageUrl && (
                          <div className="rounded-lg overflow-hidden border border-white/20 max-w-xs mb-2">
                            <img src={msg.imageUrl} alt="Uploaded Problem" className="w-full object-cover max-h-48" />
                          </div>
                        )}
                        <p className="whitespace-pre-line">{msg.text}</p>
                      </div>
                    ) : (
                      /* COACH STRUCTURED RESPONSE CARD */
                      <div className="max-w-[90%] md:max-w-[85%] rounded-2xl rounded-tl-sm p-5 bg-[#101422] border border-white/10 text-gray-200 text-xs leading-relaxed shadow-xl space-y-4">
                        
                        {/* Header Badge */}
                        <div className="flex items-center justify-between border-b border-white/5 pb-2.5">
                          <div className="flex items-center gap-2">
                            <div className="w-5 h-5 rounded-md bg-purple-500/20 border border-purple-500/30 flex items-center justify-center text-purple-300">
                              <Bot className="w-3.5 h-3.5" />
                            </div>
                            <span className="text-[11px] font-bold text-white">ForgeCoach</span>
                            {msg.structuredResponse?.intent && (
                              <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-500/15 text-purple-300 font-semibold border border-purple-500/20">
                                {msg.structuredResponse.intent}
                              </span>
                            )}
                          </div>

                          {/* Confidence Tag */}
                          {msg.structuredResponse?.confidence && (
                            <span className="text-[10px] text-gray-400 flex items-center gap-1 font-mono">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block" />
                              Confidence: {msg.structuredResponse.confidence}
                            </span>
                          )}
                        </div>

                        {/* 1. Main Answer Block (Rendered with KaTeX MathText) */}
                        <div className="text-gray-100 text-xs leading-relaxed">
                          <MathText content={msg.text} />
                        </div>

                        {/* 2. Key Idea Callout Box */}
                        {msg.structuredResponse?.keyIdea && (
                          <div className="p-3 rounded-xl bg-purple-950/30 border border-purple-500/30 space-y-1">
                            <span className="text-[10px] font-bold uppercase tracking-wider text-purple-300 block">
                              KEY CONCEPT
                            </span>
                            <MathText content={msg.structuredResponse.keyIdea} className="text-xs text-purple-100" />
                          </div>
                        )}

                        {/* 3. Standalone Formula Block */}
                        {msg.structuredResponse?.formula && (
                          <div className="p-3 rounded-xl bg-black/40 border border-white/10 space-y-1 text-center">
                            <span className="text-[10px] font-bold uppercase tracking-wider text-cyan-400 block text-left">
                              GOVERNING RELATION
                            </span>
                            <MathText content={`$$${msg.structuredResponse.formula}$$`} className="text-sm font-semibold" />
                          </div>
                        )}

                        {/* 4. Step-by-Step Numerical/Derivation Breakdown */}
                        {msg.structuredResponse?.steps && msg.structuredResponse.steps.length > 0 && (
                          <div className="p-3.5 rounded-xl bg-[#090d16] border border-white/5 space-y-2">
                            <span className="text-[10px] font-bold uppercase tracking-wider text-gray-400 block">
                              DERIVATION & SOLUTION STEPS
                            </span>
                            <div className="space-y-1.5">
                              {msg.structuredResponse.steps.map((step, idx) => (
                                <div key={idx} className="flex items-start gap-2 text-xs text-gray-300">
                                  <span className="w-4 h-4 rounded-full bg-white/5 text-[10px] flex items-center justify-center font-bold text-gray-400 shrink-0 mt-0.5">
                                    {idx + 1}
                                  </span>
                                  <MathText content={step} className="flex-1" />
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        {/* 5. Common Mistake Callout Box */}
                        {msg.structuredResponse?.commonMistake && (
                          <div className="p-3 rounded-xl bg-amber-950/20 border border-amber-500/30 space-y-1">
                            <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                              <AlertTriangle className="w-3.5 h-3.5 text-amber-400" /> COMMON EXAM MISTAKE
                            </span>
                            <MathText content={msg.structuredResponse.commonMistake} className="text-xs text-amber-100/90" />
                          </div>
                        )}

                        {/* 6. Exam Note Box */}
                        {msg.structuredResponse?.examNote && (
                          <div className="p-3 rounded-xl bg-emerald-950/20 border border-emerald-500/30 space-y-1">
                            <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> EXAM & MARKING NOTE
                            </span>
                            <MathText content={msg.structuredResponse.examNote} className="text-xs text-emerald-100/90" />
                          </div>
                        )}

                        {/* 7. Official Source Citations */}
                        {msg.structuredResponse?.sources && msg.structuredResponse.sources.length > 0 && (
                          <div className="pt-1 border-t border-white/5 flex items-center gap-2 flex-wrap text-[10px]">
                            <span className="text-gray-500 font-semibold uppercase text-[10px]">Sources:</span>
                            {msg.structuredResponse.sources.map((src, idx) => (
                              <span
                                key={idx}
                                className="px-2.5 py-1 rounded-md bg-white/5 border border-white/10 text-gray-300 font-mono flex items-center gap-1"
                              >
                                <BookOpen className="w-3 h-3 text-cyan-400" />
                                <span>{src.title}</span>
                              </span>
                            ))}
                          </div>
                        )}

                        {/* 8. Interactive Suggested Actions */}
                        {msg.structuredResponse?.suggestedActions && msg.structuredResponse.suggestedActions.length > 0 && (
                          <div className="pt-2 flex items-center gap-2 flex-wrap">
                            {msg.structuredResponse.suggestedActions.map((act) => (
                              <button
                                key={act.id}
                                type="button"
                                onClick={() => handleExecuteAction(act)}
                                className="px-3 py-1.5 rounded-xl bg-purple-600/30 hover:bg-purple-600/50 border border-purple-500/40 text-purple-200 text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
                              >
                                <Play className="w-3 h-3" />
                                <span>{act.label}</span>
                              </button>
                            ))}
                          </div>
                        )}

                        {/* 9. Answer Feedback Buttons */}
                        <div className="pt-2 border-t border-white/5 flex items-center justify-between text-[11px] text-gray-400">
                          <span className="text-[10px] text-gray-500">Was this explanation helpful?</span>
                          <div className="flex items-center gap-2">
                            <button
                              type="button"
                              onClick={() => handleFeedback(msg.id, "helpful")}
                              className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                                msg.feedback === "helpful"
                                  ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/40"
                                  : "bg-white/5 text-gray-400 hover:text-white border-transparent"
                              }`}
                              title="Helpful"
                            >
                              <ThumbsUp className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleFeedback(msg.id, "unhelpful")}
                              className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                                msg.feedback === "unhelpful"
                                  ? "bg-amber-500/20 text-amber-300 border-amber-500/40"
                                  : "bg-white/5 text-gray-400 hover:text-white border-transparent"
                              }`}
                              title="Not helpful"
                            >
                              <ThumbsDown className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                      </div>
                    )}
                  </div>
                ))}

                {/* Thinking / Tool Execution State */}
                {isTyping && (
                  <div className="flex justify-start">
                    <div className="bg-[#101422] border border-white/10 rounded-2xl p-4 text-xs text-purple-300 flex items-center gap-3 shadow-xl">
                      <span className="w-2 h-2 rounded-full bg-purple-400 animate-ping" />
                      <span className="font-medium animate-pulse">{thinkingStage || "ForgeCoach is calculating & verifying sources..."}</span>
                    </div>
                  </div>
                )}
              </div>

              {/* Image Upload Preview Bar */}
              {uploadedImage && (
                <div className="px-5 py-2 bg-[#090d16] border-t border-white/5 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg overflow-hidden border border-purple-500/40 shrink-0">
                      <img src={uploadedImage} alt="Preview" className="w-full h-full object-cover" />
                    </div>
                    <span className="text-xs text-purple-300 font-semibold">Question screenshot attached</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setUploadedImage(null)}
                    className="p-1 rounded-md hover:bg-white/10 text-gray-400 hover:text-white cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              )}

              {/* Chat Input Bar */}
              <div className="p-3.5 border-t border-white/10 bg-[#0c101a] space-y-2">
                <div className="flex gap-2.5 items-center">
                  
                  {/* Hidden File Input for Question Upload */}
                  <input
                    type="file"
                    ref={fileInputRef}
                    accept="image/*"
                    onChange={handleImageSelect}
                    className="hidden"
                  />

                  {/* Upload Question Button */}
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="p-2.5 rounded-xl border border-white/10 bg-[#101422] hover:bg-[#151b2e] text-gray-400 hover:text-purple-300 transition-colors cursor-pointer shrink-0"
                    title="Upload Question Screenshot / Diagram"
                  >
                    <Upload className="w-4 h-4" />
                  </button>

                  {/* Mode Indicator Pill */}
                  <span className="text-[10px] font-bold px-2 py-1 rounded-lg bg-purple-950/60 border border-purple-500/30 text-purple-300 uppercase shrink-0 hidden sm:inline-block">
                    {selectedMode}
                  </span>

                  {/* Main Input Textbox */}
                  <input
                    type="text"
                    value={inputText}
                    onChange={(e) => {
                      setInputText(e.target.value);
                      soundManager.playTyping();
                    }}
                    onKeyDown={(e) => e.key === "Enter" && handleSendMessage()}
                    placeholder="Ask ForgeCoach anything about your study, a question, chapter, mistake, revision plan, or syllabus..."
                    className="flex-1 bg-[#101422] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-purple-500/50 transition-colors"
                  />

                  {/* Send Button */}
                  <button
                    type="button"
                    onClick={() => handleSendMessage()}
                    disabled={isTyping || (!inputText.trim() && !uploadedImage)}
                    className="coach-send-btn disabled:opacity-40 disabled:cursor-not-allowed shrink-0"
                    title="Send Message"
                  >
                    <Send className="w-4 h-4 text-white" />
                  </button>
                </div>
              </div>

            </div>

          </main>

        </div>

      </div>
    </WorkspaceLayout>
  );
}
