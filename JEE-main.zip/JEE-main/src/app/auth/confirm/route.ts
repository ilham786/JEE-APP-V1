import { NextResponse, type NextRequest } from "next/server";
import { createServerClient } from "@supabase/ssr";

/**
 * Supabase Auth Confirmation Route (/auth/confirm)
 * Handles both PKCE authorization codes (?code=...) and Token Hashes (?token_hash=...&type=recovery|email)
 * Sets session cookies securely with path="/" on the outgoing redirect response object.
 */
export async function GET(request: NextRequest) {
  const requestUrl = new URL(request.url);
  const code = requestUrl.searchParams.get("code");
  const token_hash = requestUrl.searchParams.get("token_hash");
  const type = requestUrl.searchParams.get("type");
  const next = requestUrl.searchParams.get("next") || "/reset-password";
  const error = requestUrl.searchParams.get("error");
  const errorDescription = requestUrl.searchParams.get("error_description");

  // Prevent open redirect vulnerabilities:
  // Enforce that `next` is a relative path starting with a single '/' and not '//'
  const isSafeRelativePath =
    typeof next === "string" &&
    next.startsWith("/") &&
    !next.startsWith("//") &&
    !next.includes("\\") &&
    !next.includes(":");
  const sanitizedNext = isSafeRelativePath ? next : "/reset-password";

  if (error) {
    console.warn("Auth confirm error from Supabase:", error, errorDescription);
    return NextResponse.redirect(
      new URL(
        `/reset-password?error=${encodeURIComponent(errorDescription || error)}`,
        requestUrl.origin
      )
    );
  }

  // Pre-create redirect response so cookies are bound directly
  const response = NextResponse.redirect(new URL(sanitizedNext, requestUrl.origin));

  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || "https://yhcowzmcvlsmcffbqryb.supabase.co";
  const supabaseAnonKey =
    process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY ||
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ||
    "sb_publishable_F20ljth7U20W5cxupHPQiw_btbZuvGk";

  const supabase = createServerClient(supabaseUrl, supabaseAnonKey, {
    cookies: {
      getAll() {
        return request.cookies.getAll();
      },
      setAll(cookiesToSet) {
        cookiesToSet.forEach(({ name, value, options }) => {
          response.cookies.set(name, value, {
            ...options,
            path: "/",
          });
        });
      },
    },
  });

  if (code) {
    const { error: exchangeError } = await supabase.auth.exchangeCodeForSession(code);
    if (exchangeError) {
      console.warn("Auth confirm exchangeCodeForSession error:", exchangeError.message);
      return NextResponse.redirect(
        new URL(
          `/reset-password?error=${encodeURIComponent(
            "This password reset link is invalid or has expired. Please request a new one."
          )}`,
          requestUrl.origin
        )
      );
    }
    return response;
  }

  if (token_hash && (type === "recovery" || type === "email")) {
    const { error: otpError } = await supabase.auth.verifyOtp({
      token_hash,
      type: type as "recovery" | "email",
    });
    if (otpError) {
      console.warn("Auth confirm verifyOtp error:", otpError.message);
      return NextResponse.redirect(
        new URL(
          `/reset-password?error=${encodeURIComponent(
            "This password reset link is invalid or has expired. Please request a new one."
          )}`,
          requestUrl.origin
        )
      );
    }
    return response;
  }

  return response;
}
