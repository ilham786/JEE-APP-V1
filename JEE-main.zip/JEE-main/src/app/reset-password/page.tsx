"use client";

import React, { useState, useEffect, useRef, useId, Suspense } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import confetti from "canvas-confetti";
import { supabase } from "@/lib/supabase/client";
import { useAuth } from "@/context/AuthContext";
import { soundManager } from "@/lib/sound-manager";
import {
  Lock,
  Eye,
  EyeOff,
  ArrowRight,
  CheckCircle2,
  AlertCircle,
  Zap,
  ShieldCheck,
  AlertTriangle,
  RotateCcw,
  KeyRound,
  Mail,
  ShieldAlert,
} from "lucide-react";

function ResetPasswordContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { updatePassword, logout } = useAuth();

  const newPasswordId = useId();
  const confirmPasswordId = useId();
  const otpEmailId = useId();
  const otpCodeId = useId();

  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const [isLoading, setIsLoading] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [isVerifying, setIsVerifying] = useState(true);
  const [hasInvalidSession, setHasInvalidSession] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [redirectCountdown, setRedirectCountdown] = useState(5);

  // Synchronous atomic submission locks
  const isSubmittingRef = useRef<boolean>(false);
  const isVerifyingOtpRef = useRef<boolean>(false);

  // OTP Fallback state (in case email scanner pre-fetched/consumed link)
  const [showOtpFallback, setShowOtpFallback] = useState(false);
  const [otpEmail, setOtpEmail] = useState("");
  const [otpCode, setOtpCode] = useState("");
  const [isVerifyingOtp, setIsVerifyingOtp] = useState(false);
  const [otpMessage, setOtpMessage] = useState("");

  // Primary recovery flow verification & code exchange
  useEffect(() => {
    let isMounted = true;

    async function initializeRecoveryFlow() {
      // 1. Inspect URL Search Params for errors
      const qError = searchParams.get("error_description") || searchParams.get("error");

      // 2. Inspect URL Hash Fragment for errors (Supabase frequently returns errors in hash)
      let hashError: string | null = null;
      let hashType: string | null = null;
      let hasHashAccessToken = false;

      if (typeof window !== "undefined" && window.location.hash) {
        try {
          const hashStr = window.location.hash.startsWith("#")
            ? window.location.hash.substring(1)
            : window.location.hash;
          const hashParams = new URLSearchParams(hashStr);
          hashError = hashParams.get("error_description") || hashParams.get("error");
          hashType = hashParams.get("type");
          hasHashAccessToken = !!hashParams.get("access_token");
        } catch {
          // Ignore URLSearchParams parse failures
        }
      }

      const effectiveError = hashError || qError;
      if (effectiveError) {
        if (!isMounted) return;
        const decoded = decodeURIComponent(effectiveError);
        const lower = decoded.toLowerCase();
        setHasInvalidSession(true);
        setErrorMessage(
          lower.includes("expired") || lower.includes("invalid") || lower.includes("token not found")
            ? "This password reset link is invalid or has expired. Please request a new one."
            : decoded
        );
        setIsVerifying(false);
        return;
      }

      // 3. Handle PKCE authorization code in query string (?code=xxxx)
      const code = searchParams.get("code");
      if (code) {
        try {
          const { data, error } = await supabase.auth.exchangeCodeForSession(code);
          if (!isMounted) return;

          if (error) {
            console.warn("PKCE code exchange error on reset page:", error.message);
            // Check if there is already an active valid session
            const { data: sessionCheck } = await supabase.auth.getSession();
            if (sessionCheck.session) {
              setHasInvalidSession(false);
              setIsVerifying(false);
              return;
            }

            setHasInvalidSession(true);
            setErrorMessage("This password reset link is invalid or has expired. Please request a new one.");
            setIsVerifying(false);
            return;
          }

          if (data.session) {
            setHasInvalidSession(false);
            setIsVerifying(false);
            // Clean code query parameter from address bar without reloading
            if (typeof window !== "undefined") {
              window.history.replaceState({}, document.title, window.location.pathname);
            }
            return;
          }
        } catch (exchangeErr) {
          console.error("Unexpected error exchanging PKCE code:", exchangeErr);
        }
      }

      // 4. Handle token_hash in query string (?token_hash=xxxx&type=recovery)
      const tokenHash = searchParams.get("token_hash");
      const paramType = searchParams.get("type") || "recovery";
      if (tokenHash) {
        try {
          const { data, error } = await supabase.auth.verifyOtp({
            token_hash: tokenHash,
            type: paramType as "recovery" | "email",
          });
          if (!isMounted) return;

          if (error) {
            console.warn("token_hash verifyOtp error on reset page:", error.message);
            setHasInvalidSession(true);
            setErrorMessage("This password reset link is invalid or has expired. Please request a new one.");
            setIsVerifying(false);
            return;
          }

          if (data.session) {
            setHasInvalidSession(false);
            setIsVerifying(false);
            if (typeof window !== "undefined") {
              window.history.replaceState({}, document.title, window.location.pathname);
            }
            return;
          }
        } catch (otpErr) {
          console.error("Unexpected error verifying token hash:", otpErr);
        }
      }

      // 5. Check if user already has an active session (e.g. from /auth/callback or refresh)
      const { data: initialSessionData } = await supabase.auth.getSession();
      if (initialSessionData?.session) {
        if (!isMounted) return;
        setHasInvalidSession(false);
        setIsVerifying(false);
        return;
      }

      // 6. Listen for real-time Auth State changes (e.g. Implicit flow PASSWORD_RECOVERY)
      const {
        data: { subscription },
      } = supabase.auth.onAuthStateChange((event, newSession) => {
        if (!isMounted) return;

        if (
          event === "PASSWORD_RECOVERY" ||
          (newSession && (event === "SIGNED_IN" || event === "INITIAL_SESSION"))
        ) {
          setHasInvalidSession(false);
          setIsVerifying(false);
          // Clean hash tokens from address bar if present
          if (typeof window !== "undefined" && window.location.hash) {
            window.history.replaceState({}, document.title, window.location.pathname);
          }
        }
      });

      // 7. Non-racy fallback window: allow Supabase client 3.5s to complete hash/network sync
      const fallbackTimer = setTimeout(async () => {
        if (!isMounted) return;
        const { data: finalCheck } = await supabase.auth.getSession();
        if (!isMounted) return;

        if (finalCheck?.session) {
          setHasInvalidSession(false);
        } else {
          setHasInvalidSession(true);
          setErrorMessage("This password reset link is invalid or has expired. Please request a new one.");
        }
        setIsVerifying(false);
      }, 3500);

      return () => {
        subscription.unsubscribe();
        clearTimeout(fallbackTimer);
      };
    }

    initializeRecoveryFlow();

    return () => {
      isMounted = false;
    };
  }, [searchParams]);

  // Handle OTP Code Fallback Verification (eliminates link scanner failure)
  const handleVerifyOtpCode = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isVerifyingOtpRef.current || isVerifyingOtp) return;

    if (!otpEmail.trim() || !otpCode.trim()) {
      setOtpMessage("Please enter both your email address and the 6-digit code.");
      return;
    }

    isVerifyingOtpRef.current = true;
    setIsVerifyingOtp(true);
    setOtpMessage("");
    soundManager.play("select");

    try {
      const cleanEmail = otpEmail.trim().toLowerCase();
      const cleanToken = otpCode.trim();

      const { data, error } = await supabase.auth.verifyOtp({
        email: cleanEmail,
        token: cleanToken,
        type: "recovery",
      });

      if (error) {
        soundManager.play("error");
        setOtpMessage("Invalid or expired code. Please request a new code or link.");
      } else if (data.session) {
        soundManager.play("success");
        setHasInvalidSession(false);
        setErrorMessage("");
        setShowOtpFallback(false);
      }
    } catch {
      soundManager.play("error");
      setOtpMessage("Could not verify code. Please try again.");
    } finally {
      isVerifyingOtpRef.current = false;
      setIsVerifyingOtp(false);
    }
  };

  // Password Strength Evaluation
  const criteria = {
    length: newPassword.length >= 8,
    uppercase: /[A-Z]/.test(newPassword),
    number: /[0-9]/.test(newPassword),
    special: /[^A-Za-z0-9]/.test(newPassword),
  };

  const strengthScore = Object.values(criteria).filter(Boolean).length;

  const strengthConfig = React.useMemo(() => {
    if (!newPassword) {
      return { label: "Enter Password", color: "text-gray-500", barColor: "bg-gray-700", percent: 0 };
    }
    if (strengthScore <= 1 || newPassword.length < 8) {
      return { label: "Weak", color: "text-rose-400", barColor: "bg-rose-500", percent: 25 };
    }
    if (strengthScore <= 3) {
      return { label: "Fair", color: "text-amber-400", barColor: "bg-amber-500", percent: 65 };
    }
    return { label: "Strong", color: "text-emerald-400", barColor: "bg-emerald-500", percent: 100 };
  }, [newPassword, strengthScore]);

  // Auto-redirect countdown on success
  useEffect(() => {
    if (!isSuccess) return;
    const interval = setInterval(() => {
      setRedirectCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          router.push("/login?password_reset=true");
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [isSuccess, router]);

  const toggleNewPasswordVisibility = () => {
    const next = !showNewPassword;
    setShowNewPassword(next);
    soundManager.play(next ? "toggle-on" : "toggle-off");
  };

  const toggleConfirmPasswordVisibility = () => {
    const next = !showConfirmPassword;
    setShowConfirmPassword(next);
    soundManager.play(next ? "toggle-on" : "toggle-off");
  };

  // Primary Password Update Submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmittingRef.current || isLoading) return;
    setErrorMessage("");

    if (!newPassword || !confirmPassword) {
      soundManager.play("error");
      setErrorMessage("Please fill out both password fields.");
      return;
    }

    if (newPassword.length < 8) {
      soundManager.play("error");
      setErrorMessage("Your password doesn't meet the required security requirements (minimum 8 characters).");
      return;
    }

    if (newPassword !== confirmPassword) {
      soundManager.play("error");
      setErrorMessage("Passwords don't match.");
      return;
    }

    if (strengthScore < 2) {
      soundManager.play("error");
      setErrorMessage("Your password doesn't meet the required security requirements. Please include numbers or symbols.");
      return;
    }

    // Explicitly verify that recovery session is established before calling updateUser
    const { data: sessionData } = await supabase.auth.getSession();
    if (!sessionData?.session) {
      soundManager.play("error");
      setErrorMessage("Your recovery session has expired or is invalid. Please request a new password reset link.");
      setHasInvalidSession(true);
      return;
    }

    isSubmittingRef.current = true;
    setIsLoading(true);
    soundManager.play("select");

    try {
      await updatePassword(newPassword);

      soundManager.play("level-up");
      setIsSuccess(true);
      confetti({
        particleCount: 120,
        spread: 85,
        origin: { y: 0.6 },
        colors: ["#10b981", "#8b5cf6", "#06b6d4", "#ffffff"],
      });

      // Clear the temporary recovery session locally so user logs in with new credentials
      await logout({ redirect: false }).catch(() => {});
    } catch (err: unknown) {
      soundManager.play("error");
      const errorObj = err as { message?: string };
      const rawMsg = errorObj?.message || "";
      const lower = rawMsg.toLowerCase();

      if (
        lower.includes("recovery link is invalid") ||
        lower.includes("expired") ||
        lower.includes("otp expired") ||
        lower.includes("auth session missing") ||
        lower.includes("session missing") ||
        lower.includes("not authenticated")
      ) {
        setErrorMessage("This password reset link is invalid or has expired. Please request a new one.");
        setHasInvalidSession(true);
      } else if (lower.includes("different")) {
        setErrorMessage("New password should be different from your old password.");
      } else if (lower.includes("rate limit")) {
        setErrorMessage("Too many requests. Please wait a moment and try again.");
      } else {
        setErrorMessage(rawMsg || "Something went wrong. Please try again.");
      }
    } finally {
      isSubmittingRef.current = false;
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen w-full bg-[#08090d] text-gray-100 flex flex-col justify-between font-sans antialiased selection:bg-purple-500/30 selection:text-purple-200">
      {/* Background Ambience Gradients */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute -top-40 left-1/2 -translate-x-1/2 w-[700px] h-[500px] bg-gradient-to-b from-purple-600/10 via-indigo-600/5 to-transparent rounded-full blur-3xl opacity-70" />
        <div className="absolute -bottom-40 right-10 w-[500px] h-[400px] bg-gradient-to-t from-cyan-600/10 to-transparent rounded-full blur-3xl opacity-50" />
      </div>

      {/* Top Header / Branding */}
      <header className="relative z-10 w-full max-w-5xl mx-auto px-6 py-6 sm:py-8 flex items-center justify-between">
        <Link
          href="/"
          className="flex items-center gap-2.5 group transition-transform hover:scale-[1.02] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-purple-400 rounded-xl"
        >
          <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-2xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-cyan-500 text-white flex items-center justify-center font-black shadow-lg shadow-purple-950/40 border border-white/10 shrink-0">
            <Zap className="w-4 h-4 sm:w-5 sm:h-5 fill-white" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-bold text-lg tracking-tight text-white">FocusForge</span>
              <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-purple-500/10 text-purple-300 border border-purple-500/20">
                Security
              </span>
            </div>
            <span className="text-[10px] font-mono text-cyan-400 block -mt-0.5">Cloud Study OS</span>
          </div>
        </Link>

        <Link
          href="/login"
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 text-xs font-medium text-gray-300 hover:text-white transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-purple-400"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Login Page</span>
        </Link>
      </header>

      {/* Main Content Area */}
      <main className="relative z-10 w-full max-w-md mx-auto px-4 sm:px-6 my-auto py-8">
        <div className="glass-panel p-6 sm:p-8 rounded-3xl border border-white/10 shadow-2xl relative overflow-hidden backdrop-blur-2xl bg-slate-950/80">
          <div className="absolute -top-12 -right-12 w-32 h-32 bg-purple-500/15 rounded-full blur-2xl pointer-events-none" />

          {isVerifying ? (
            /* Verifying Session Spinner */
            <div className="py-12 flex flex-col items-center justify-center text-center space-y-4">
              <div className="w-8 h-8 border-2 border-purple-400 border-t-transparent rounded-full animate-spin" />
              <div className="space-y-1">
                <p className="text-sm font-semibold text-white">Authenticating Recovery Link...</p>
                <p className="text-xs text-gray-400 font-mono">Verifying secure cryptographic signature</p>
              </div>
            </div>
          ) : hasInvalidSession ? (
            /* Expired or Invalid Recovery Token View with OTP Fallback */
            <motion.div
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center py-2"
            >
              <div className="w-13 h-13 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-400 flex items-center justify-center mx-auto mb-4">
                <AlertTriangle className="w-6 h-6" />
              </div>

              <h2 className="text-lg sm:text-xl font-bold text-white mb-2 uppercase tracking-tight">
                Reset Link Expired or Invalid
              </h2>

              <p className="text-xs sm:text-sm text-gray-400 leading-relaxed mb-5">
                {errorMessage || "This password reset link is invalid or has expired. Please request a new recovery link."}
              </p>

              {/* Expandable OTP Fallback Box */}
              {!showOtpFallback ? (
                <div className="space-y-3">
                  <Link
                    href="/forgot-password"
                    className="w-full py-3.5 px-5 rounded-xl bg-gradient-to-r from-purple-600 via-indigo-600 to-cyan-500 text-white font-bold text-sm tracking-wide shadow-xl shadow-purple-950/50 hover:brightness-110 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <span>Request a New Reset Link</span>
                    <ArrowRight className="w-4 h-4" />
                  </Link>

                  <button
                    type="button"
                    onClick={() => setShowOtpFallback(true)}
                    className="w-full py-2.5 px-4 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] text-gray-300 font-semibold text-xs transition-all flex items-center justify-center gap-2 border border-white/10 cursor-pointer"
                  >
                    <KeyRound className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Have a 6-digit code? Enter here</span>
                  </button>

                  <Link
                    href="/login"
                    className="inline-block pt-1 text-xs text-gray-500 hover:text-gray-300 transition-colors"
                  >
                    Back to Login
                  </Link>
                </div>
              ) : (
                /* Enter 6-digit verification code directly */
                <form onSubmit={handleVerifyOtpCode} className="space-y-3.5 text-left pt-2">
                  <div className="p-3 rounded-xl bg-purple-500/10 border border-purple-500/20 text-purple-300 text-xs flex items-center gap-2">
                    <ShieldAlert className="w-4 h-4 shrink-0 text-purple-400" />
                    <span>Enter your email and the 6-digit code sent in your recovery email.</span>
                  </div>

                  {otpMessage && (
                    <div className="p-2.5 rounded-lg bg-red-500/10 border border-red-500/30 text-red-300 text-xs flex items-center gap-2">
                      <AlertCircle className="w-3.5 h-3.5 text-red-400 shrink-0" />
                      <span>{otpMessage}</span>
                    </div>
                  )}

                  <div>
                    <label htmlFor={otpEmailId} className="block text-[11px] font-bold uppercase tracking-wider text-gray-400 mb-1">
                      Email Address
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-500">
                        <Mail className="w-3.5 h-3.5" />
                      </div>
                      <input
                        id={otpEmailId}
                        type="email"
                        required
                        value={otpEmail}
                        onChange={(e) => setOtpEmail(e.target.value)}
                        placeholder="aspirant@focusforge.app"
                        className="w-full pl-9 pr-3 py-2 rounded-xl text-xs bg-slate-900 border border-white/10 text-white focus:outline-none focus:border-purple-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label htmlFor={otpCodeId} className="block text-[11px] font-bold uppercase tracking-wider text-gray-400 mb-1">
                      6-Digit Recovery Code
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-500">
                        <KeyRound className="w-3.5 h-3.5" />
                      </div>
                      <input
                        id={otpCodeId}
                        type="text"
                        maxLength={8}
                        required
                        value={otpCode}
                        onChange={(e) => setOtpCode(e.target.value.trim())}
                        placeholder="123456"
                        className="w-full pl-9 pr-3 py-2 rounded-xl text-xs font-mono tracking-wider bg-slate-900 border border-white/10 text-white focus:outline-none focus:border-purple-500"
                      />
                    </div>
                  </div>

                  <div className="flex gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => setShowOtpFallback(false)}
                      className="flex-1 py-2.5 rounded-xl border border-white/10 text-xs font-semibold text-gray-400 hover:text-white"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={isVerifyingOtp}
                      className="flex-1 py-2.5 rounded-xl bg-purple-600 text-xs font-bold text-white hover:bg-purple-500 disabled:opacity-50"
                    >
                      {isVerifyingOtp ? "Verifying..." : "Verify Code"}
                    </button>
                  </div>
                </form>
              )}
            </motion.div>
          ) : isSuccess ? (
            /* Success State */
            <motion.div
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center py-2"
            >
              <div className="w-14 h-14 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center mx-auto mb-4">
                <CheckCircle2 className="w-7 h-7" />
              </div>

              <h2 className="text-xl sm:text-2xl font-black text-white uppercase tracking-tight mb-2">
                Password Updated Successfully
              </h2>

              <p className="text-xs sm:text-sm text-gray-300 leading-relaxed mb-6">
                Your Focus Forge password has been changed. You can now sign in to your study workspace with your new password.
              </p>

              <div className="space-y-3">
                <Link
                  href="/login?password_reset=true"
                  className="w-full py-3.5 px-5 rounded-xl bg-gradient-to-r from-purple-600 via-indigo-600 to-cyan-500 text-white font-bold text-sm tracking-wide shadow-xl shadow-purple-950/50 hover:brightness-110 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <span>Continue to Login</span>
                  <ArrowRight className="w-4 h-4" />
                </Link>

                <p className="text-[11px] text-gray-500 font-mono">
                  Auto-redirecting in {redirectCountdown}s...
                </p>
              </div>
            </motion.div>
          ) : (
            /* New Password Input Form */
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.25 }}
            >
              <div className="w-11 h-11 rounded-2xl bg-purple-500/10 border border-purple-500/20 text-purple-400 flex items-center justify-center mb-5">
                <ShieldCheck className="w-5 h-5" />
              </div>

              <div className="mb-6">
                <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white uppercase mb-2">
                  Reset Your Password
                </h1>
                <p className="text-xs sm:text-sm text-gray-400 leading-relaxed font-normal">
                  Create a new password for your Focus Forge account.
                </p>
              </div>

              {/* Error Banner */}
              {errorMessage && (
                <motion.div
                  initial={{ opacity: 0, y: -4 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mb-5 p-3.5 rounded-xl bg-red-500/10 border border-red-500/30 text-red-300 text-xs font-medium flex items-start gap-2.5"
                  role="alert"
                >
                  <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                  <span className="leading-relaxed">{errorMessage}</span>
                </motion.div>
              )}

              <form onSubmit={handleSubmit} className="space-y-4" noValidate>
                {/* New Password Field */}
                <div>
                  <label
                    htmlFor={newPasswordId}
                    className="block text-[11px] font-bold uppercase tracking-wider text-gray-300 mb-1.5"
                  >
                    New Password
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-500">
                      <Lock className="w-4 h-4" />
                    </div>
                    <input
                      id={newPasswordId}
                      type={showNewPassword ? "text" : "password"}
                      required
                      value={newPassword}
                      onChange={(e) => {
                        setNewPassword(e.target.value);
                        if (errorMessage) setErrorMessage("");
                      }}
                      placeholder="••••••••••••"
                      className="w-full pl-10 pr-10 py-3 rounded-xl text-sm font-medium transition-all focus:outline-none bg-slate-900/80 border border-white/10 text-white placeholder-gray-500 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20"
                      disabled={isLoading}
                    />
                    <button
                      type="button"
                      onClick={toggleNewPasswordVisibility}
                      className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-gray-400 hover:text-white transition-colors cursor-pointer"
                      aria-label={showNewPassword ? "Hide new password" : "Show new password"}
                    >
                      {showNewPassword ? <EyeOff className="w-4 h-4 text-cyan-400" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>

                  {/* Clean Password Strength Indicator */}
                  {newPassword && (
                    <div className="mt-2.5 p-3 rounded-xl bg-slate-900/60 border border-white/[0.06] space-y-2">
                      <div className="flex items-center justify-between text-[10px] font-mono">
                        <span className="text-gray-400">Password strength</span>
                        <span className={`font-bold flex items-center gap-1.5 ${strengthConfig.color}`}>
                          <span>●</span>
                          <span>{strengthConfig.label}</span>
                        </span>
                      </div>

                      {/* Visual Strength Meter Bar */}
                      <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden">
                        <motion.div
                          className={`h-full ${strengthConfig.barColor}`}
                          initial={{ width: 0 }}
                          animate={{ width: `${strengthConfig.percent}%` }}
                          transition={{ duration: 0.3 }}
                        />
                      </div>

                      {/* Criteria Grid */}
                      <div className="grid grid-cols-4 gap-1.5 text-[9px] font-mono pt-1">
                        <div
                          className={`p-1 rounded text-center border ${
                            criteria.length
                              ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-300"
                              : "bg-white/[0.02] border-white/[0.06] text-gray-500"
                          }`}
                        >
                          8+ Chars
                        </div>
                        <div
                          className={`p-1 rounded text-center border ${
                            criteria.uppercase
                              ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-300"
                              : "bg-white/[0.02] border-white/[0.06] text-gray-500"
                          }`}
                        >
                          Uppercase
                        </div>
                        <div
                          className={`p-1 rounded text-center border ${
                            criteria.number
                              ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-300"
                              : "bg-white/[0.02] border-white/[0.06] text-gray-500"
                          }`}
                        >
                          Number
                        </div>
                        <div
                          className={`p-1 rounded text-center border ${
                            criteria.special
                              ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-300"
                              : "bg-white/[0.02] border-white/[0.06] text-gray-500"
                          }`}
                        >
                          Symbol
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Confirm Password Field */}
                <div>
                  <label
                    htmlFor={confirmPasswordId}
                    className="block text-[11px] font-bold uppercase tracking-wider text-gray-300 mb-1.5"
                  >
                    Confirm New Password
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-500">
                      <Lock className="w-4 h-4" />
                    </div>
                    <input
                      id={confirmPasswordId}
                      type={showConfirmPassword ? "text" : "password"}
                      required
                      value={confirmPassword}
                      onChange={(e) => {
                        setConfirmPassword(e.target.value);
                        if (errorMessage) setErrorMessage("");
                      }}
                      placeholder="••••••••••••"
                      className="w-full pl-10 pr-10 py-3 rounded-xl text-sm font-medium transition-all focus:outline-none bg-slate-900/80 border border-white/10 text-white placeholder-gray-500 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20"
                      disabled={isLoading}
                    />
                    <button
                      type="button"
                      onClick={toggleConfirmPasswordVisibility}
                      className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-gray-400 hover:text-white transition-colors cursor-pointer"
                      aria-label={showConfirmPassword ? "Hide confirm password" : "Show confirm password"}
                    >
                      {showConfirmPassword ? <EyeOff className="w-4 h-4 text-cyan-400" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>

                  {confirmPassword && newPassword && confirmPassword !== newPassword && (
                    <p className="mt-1.5 text-[11px] text-rose-400 font-mono">Passwords do not match.</p>
                  )}
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full mt-2 py-3.5 px-5 rounded-xl bg-gradient-to-r from-purple-600 via-indigo-600 to-cyan-500 text-white font-bold text-sm tracking-wide shadow-xl shadow-purple-950/50 hover:brightness-110 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isLoading ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      <span>Updating password...</span>
                    </>
                  ) : (
                    <>
                      <span>Update Password</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>
            </motion.div>
          )}
        </div>
      </main>

      {/* Footer */}
      <footer className="relative z-10 w-full max-w-md mx-auto px-6 py-4 text-center">
        <p className="text-[11px] text-gray-500 font-mono">
          FocusForge Cloud Operating System • Developed for JEE Aspirants
        </p>
      </footer>
    </div>
  );
}

export default function ResetPasswordPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen w-full bg-[#08090d] flex items-center justify-center text-cyan-400 font-mono text-xs">
          <div className="w-5 h-5 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin mr-3" />
          <span>Securing Recovery Channel...</span>
        </div>
      }
    >
      <ResetPasswordContent />
    </Suspense>
  );
}
