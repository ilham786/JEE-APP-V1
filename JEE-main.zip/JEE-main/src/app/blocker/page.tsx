"use client";

import { useState, useEffect, useMemo } from "react";
import { WorkspaceLayout } from "@/components/workspace-layout";
import { Card } from "@/components/ui/card";
import { Button, Badge } from "@/components/ui/controls";
import { useIsClient } from "@/hooks/use-is-client";
import { useStudyStore } from "@/store/use-study-store";
import { extensionService, ExtensionStateDoc } from "@/services/extensionService";
import { deviceService, BrowserDeviceDoc } from "@/services/deviceService";
import { useAuth } from "@/context/AuthContext";
import { DEFAULT_DISTRACTION_CATALOG, DistractionCategory } from "@/services/blockerService";
import { downloadExtension } from "@/lib/extension-download";
import {
  youtubeGuardService,
  SEEDED_ACADEMIC_TAXONOMY,
  SEEDED_TRUSTED_CHANNELS,
  YouTubeGuardMode,
  TrustedChannelEntry,
  AllowedVideoEntry,
  AcademicSubject,
  YouTubeGuardSettings,
  TAXONOMY_VERSION,
  CLASSIFIER_VERSION,
} from "@/services/youtubeGuardService";
import {
  Globe,
  Plus,
  Trash2,
  Lock,
  Unlock,
  ShieldAlert,
  Clock,
  Puzzle,
  RefreshCw,
  CheckCircle2,
  Download,
  Laptop,
  Monitor,
  Check,
  Shield,
  Video,
  Eye,
  EyeOff,
  Search,
  Sparkles,
  BookOpen,
  Filter,
  ExternalLink,
  Layers,
  AlertTriangle,
  Play,
  Terminal,
  Activity,
  Cpu,
} from "lucide-react";
import { soundManager } from "@/lib/sound-manager";

type BlockerTab = "youtube" | "shields" | "extension";

export default function BlockerSettingsPage() {
  const isMounted = useIsClient();
  const { uid, userProfile } = useAuth();
  const {
    status,
    activeSession,
    blockedWebsites,
    addBlockedWebsite,
    removeBlockedWebsite,
    whitelistOnly,
    setWhitelistOnly,
    examModeEnabled,
    setExamModeEnabled,
    whitelistedWebsites = [],
    addWhitelistedWebsite,
    removeWhitelistedWebsite,
  } = useStudyStore();

  const [activeTab, setActiveTab] = useState<BlockerTab>("youtube");

  // Website blocker state
  const [newDomain, setNewDomain] = useState("");
  const [newWhitelistedDomain, setNewWhitelistedDomain] = useState("");
  const [scheduleSlots, setScheduleSlots] = useState([
    { id: "s1", start: "09:00", end: "14:00", days: "Mon-Sat", active: true },
    { id: "s2", start: "16:00", end: "21:00", days: "All Days", active: true },
  ]);

  const toggleSchedule = (id: string) => {
    soundManager.play("select");
    setScheduleSlots((prev) =>
      prev.map((s) => (s.id === id ? { ...s, active: !s.active } : s))
    );
  };

  // Extension status state
  const [extState, setExtState] = useState<ExtensionStateDoc>({
    userId: uid || "guest",
    connected: false,
    browser: "Chrome Desktop",
    version: "1.1.0",
    lastSync: new Date().toISOString(),
    syncHealth: "Offline",
    currentFocusStatus: status === "focus" ? "Focus Zone Active" : "Idle",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  });

  const [isSyncing, setIsSyncing] = useState(false);
  const [devices, setDevices] = useState<BrowserDeviceDoc[]>([]);

  // YouTube Study Guard State
  const [ytMode, setYtMode] = useState<YouTubeGuardMode>("balanced");
  const [academicScope, setAcademicScope] = useState<string[]>([
    "JEE Main",
    "JEE Advanced",
    "NEET",
    "CBSE Class 12",
    "Physics",
    "Chemistry",
    "Mathematics",
    "Biology",
    "English",
  ]);
  const [trustedChannels, setTrustedChannels] = useState<TrustedChannelEntry[]>(SEEDED_TRUSTED_CHANNELS);
  const [allowedVideos, setAllowedVideos] = useState<AllowedVideoEntry[]>([]);
  const [newChannelName, setNewChannelName] = useState("");
  const [newVideoUrl, setNewVideoUrl] = useState("");
  const [newVideoTitle, setNewVideoTitle] = useState("");
  const [newVideoSubject, setNewVideoSubject] = useState<AcademicSubject>("Physics");
  const [searchTopicQuery, setSearchTopicQuery] = useState("");
  const [selectedSubjectFilter, setSelectedSubjectFilter] = useState<string>("All");
  const [studyVideoQuery, setStudyVideoQuery] = useState("");
  const [studyVideoResults, setStudyVideoResults] = useState<any[]>([]);
  const [isSearchingVideos, setIsSearchingVideos] = useState(false);
  const [activeWatchModalVideo, setActiveWatchModalVideo] = useState<any | null>(null);

  // Developer Diagnostics State (Section 48 & 49)
  const [diagVideoQuery, setDiagVideoQuery] = useState("wJ8Wd6Lq4K0");
  const [diagResult, setDiagResult] = useState<any>(null);
  const [isDiagRunning, setIsDiagRunning] = useState(false);

  // Derive YouTube Guard Master Rule Status
  const isFocusActive = status === "focus";
  const isPaused = status === "paused";
  const youtubeGuardActive = isFocusActive && !!activeSession;

  const handleRunDiagnostics = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!diagVideoQuery.trim()) return;
    setIsDiagRunning(true);
    let vid = diagVideoQuery.trim();
    if (vid.includes("v=")) {
      vid = vid.split("v=")[1].split("&")[0];
    } else if (vid.includes("youtu.be/")) {
      vid = vid.split("youtu.be/")[1].split("?")[0];
    }
    try {
      const res = await fetch("/api/youtube/classify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          videoId: vid,
          title: "",
          guardMode: ytMode,
          activeSessionSubject: activeSession?.subject,
          activeSessionChapter: activeSession?.chapter,
        }),
      });
      const data = await res.json();
      if (data?.result) {
        setDiagResult(data.result);
      }
    } catch (err) {
      console.error("Diagnostic error:", err);
    } finally {
      setIsDiagRunning(false);
    }
  };

  useEffect(() => {
    // 1. Handshake with extension
    if (typeof window !== "undefined") {
      window.postMessage({ type: "FOCUSFORGE_REQUEST_AUTH_SESSION" }, "*");
      window.postMessage({ type: "FOCUSFORGE_PING_EXTENSION" }, "*");

      if (document.documentElement.getAttribute("data-focusforge-extension")) {
        setExtState((prev) => ({
          ...prev,
          connected: true,
          syncHealth: "Optimal",
          version: document.documentElement.getAttribute("data-focusforge-extension") || prev.version,
        }));
      }

      const handleExtensionMessage = (e: MessageEvent) => {
        if (e.data?.type === "FOCUSFORGE_EXTENSION_PONG" || e.data?.type === "FOCUSFORGE_LIVE_TRACKING") {
          setExtState((prev) => ({
            ...prev,
            connected: true,
            syncHealth: "Optimal",
            version: e.data.version || prev.version,
            lastSync: new Date().toISOString(),
          }));
        }
      };
      window.addEventListener("message", handleExtensionMessage);
      return () => window.removeEventListener("message", handleExtensionMessage);
    }
  }, []);

  useEffect(() => {
    if (!uid) return;
    const unsubExt = extensionService.subscribeExtensionState(uid, (docData) => {
      if (docData) setExtState(docData);
    });
    const unsubDev = deviceService.subscribeUserDevices(uid, (devList) => {
      setDevices(devList);
    });

    // Fetch YouTube Guard settings and allowed videos
    youtubeGuardService.getSettings(uid).then((settings) => {
      setYtMode(settings.mode);
      if (settings.academicScope?.length) {
        setAcademicScope(settings.academicScope);
      }
    });

    youtubeGuardService.getAllowedVideos(uid).then((vids) => {
      setAllowedVideos(vids);
    });

    youtubeGuardService.getTrustedChannels().then((chans) => {
      setTrustedChannels(chans);
    });

    return () => {
      unsubExt();
      unsubDev();
    };
  }, [uid]);

  // Initial load of study search results
  useEffect(() => {
    fetch(`/api/youtube/search?q=${encodeURIComponent(studyVideoQuery || "Rotational Motion")}`)
      .then((r) => r.json())
      .then((data) => {
        if (data?.results) setStudyVideoResults(data.results);
      })
      .catch(() => {});
  }, []);

  const handleModeChange = async (newMode: YouTubeGuardMode) => {
    setYtMode(newMode);
    soundManager.play("select");
    if (typeof window !== "undefined") {
      window.postMessage({ type: "FOCUSFORGE_SET_YT_GUARD_MODE", mode: newMode }, "*");
    }
    if (uid) {
      await youtubeGuardService.updateSettings(uid, { mode: newMode, academicScope });
    }
  };

  const handleToggleScope = async (item: string) => {
    soundManager.play("select");
    const nextScope = academicScope.includes(item)
      ? academicScope.filter((s) => s !== item)
      : [...academicScope, item];
    setAcademicScope(nextScope);
    if (uid) {
      await youtubeGuardService.updateSettings(uid, { mode: ytMode, academicScope: nextScope });
    }
  };

  const handleAddCustomChannel = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newChannelName.trim()) return;
    soundManager.play("check");
    const name = newChannelName.trim();
    const newEntry: Omit<TrustedChannelEntry, "id"> = {
      channelId: `ch_${Date.now()}`,
      channelName: name,
      subjects: ["General Academic"],
      exams: ["JEE Main", "CBSE Class 12"],
      trustStatus: "user_added",
    };
    await youtubeGuardService.addTrustedChannel(newEntry);
    setTrustedChannels((prev) => [...prev, { ...newEntry, id: `ch_${Date.now()}` }]);
    setNewChannelName("");
  };

  const handleAddApprovedVideo = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newVideoUrl.trim() || !newVideoTitle.trim() || !uid) return;
    soundManager.play("check");

    // Extract ID from URL if full URL is pasted
    let videoId = newVideoUrl.trim();
    if (videoId.includes("youtube.com/watch")) {
      try {
        const u = new URL(videoId);
        videoId = u.searchParams.get("v") || videoId;
      } catch {}
    } else if (videoId.includes("youtu.be/")) {
      videoId = videoId.split("youtu.be/")[1]?.split("?")[0] || videoId;
    }

    const success = await youtubeGuardService.approveVideo(uid, {
      videoId,
      title: newVideoTitle.trim(),
      subject: newVideoSubject,
    });

    if (success) {
      const refreshed = await youtubeGuardService.getAllowedVideos(uid);
      setAllowedVideos(refreshed);
      setNewVideoUrl("");
      setNewVideoTitle("");
    }
  };

  const handleRevokeVideo = async (videoId: string) => {
    if (!uid) return;
    soundManager.play("delete");
    await youtubeGuardService.revokeVideoApproval(uid, videoId);
    setAllowedVideos((prev) => prev.filter((v) => v.videoId !== videoId));
  };

  const handleStudySearch = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSearchingVideos(true);
    soundManager.play("select");
    try {
      const res = await fetch(`/api/youtube/search?q=${encodeURIComponent(studyVideoQuery)}`);
      const data = await res.json();
      if (data?.results) {
        setStudyVideoResults(data.results);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsSearchingVideos(false);
    }
  };

  // Filtered topics taxonomy
  const filteredTaxonomy = useMemo(() => {
    let list = SEEDED_ACADEMIC_TAXONOMY;
    if (selectedSubjectFilter !== "All") {
      list = list.filter((t) => t.subject === selectedSubjectFilter);
    }
    if (searchTopicQuery.trim()) {
      const q = searchTopicQuery.toLowerCase();
      list = list.filter(
        (t) =>
          t.chapter.toLowerCase().includes(q) ||
          t.topic.toLowerCase().includes(q) ||
          t.keywords.some((k) => k.toLowerCase().includes(q))
      );
    }
    return list;
  }, [selectedSubjectFilter, searchTopicQuery]);

  // Website Blocker Handlers
  const handleAddWebsite = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDomain.trim()) return;
    let domain = newDomain.trim().toLowerCase().replace(/^(https?:\/\/)?(www\.)?/, "");
    addBlockedWebsite(domain);
    soundManager.play("lock");
    setNewDomain("");
  };

  const handleRemove = (domain: string) => {
    soundManager.play("unlock");
    removeBlockedWebsite(domain);
  };

  const handleAddWhitelistedWebsite = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newWhitelistedDomain.trim()) return;
    let domain = newWhitelistedDomain.trim().toLowerCase().replace(/^(https?:\/\/)?(www\.)?/, "").split("/")[0];
    if (domain) {
      addWhitelistedWebsite(domain);
      soundManager.play("check");
      setNewWhitelistedDomain("");
    }
  };

  const handleRemoveWhitelisted = (domain: string) => {
    soundManager.play("delete");
    removeWhitelistedWebsite(domain);
  };

  const handleManualSync = async () => {
    setIsSyncing(true);
    soundManager.play("connect");
    if (typeof window !== "undefined") {
      window.postMessage({ type: "FOCUSFORGE_REQUEST_AUTH_SESSION" }, "*");
      window.postMessage({ type: "FOCUSFORGE_PING_EXTENSION" }, "*");
    }
    if (uid) {
      const fresh = await extensionService.getExtensionState(uid);
      if (fresh) setExtState(fresh);
    }
    setTimeout(() => setIsSyncing(false), 500);
  };

  const handleToggleDomain = (domain: string) => {
    if (blockedWebsites.includes(domain)) {
      soundManager.play("unlock");
      removeBlockedWebsite(domain);
    } else {
      soundManager.play("lock");
      addBlockedWebsite(domain);
    }
  };

  const handleToggleCategory = (category: DistractionCategory) => {
    const allBlocked = category.domains.every((d) => blockedWebsites.includes(d));
    if (allBlocked) {
      soundManager.play("unlock");
      category.domains.forEach((d) => removeBlockedWebsite(d));
    } else {
      soundManager.play("lock");
      category.domains.forEach((d) => {
        if (!blockedWebsites.includes(d)) addBlockedWebsite(d);
      });
    }
  };

  return (
    <WorkspaceLayout title="Study Protection & Content Guard">
      {/* Top Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-white/[0.08] pb-4 mb-6">
        <button
          onClick={() => {
            setActiveTab("youtube");
            soundManager.play("select");
          }}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeTab === "youtube"
              ? "bg-purple-600/20 text-purple-300 border border-purple-500/40 shadow-[0_0_20px_rgba(147,51,234,0.25)]"
              : "text-gray-400 hover:text-white hover:bg-white/[0.04] border border-transparent"
          }`}
        >
          <Video className="w-4 h-4 text-purple-400" />
          <span>YouTube Study Guard</span>
          {youtubeGuardActive && (
            <span className="w-2 h-2 rounded-full bg-emerald-400 shadow-[0_0_8px_#34d399] animate-pulse" />
          )}
        </button>

        <button
          onClick={() => {
            setActiveTab("shields");
            soundManager.play("select");
          }}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeTab === "shields"
              ? "bg-purple-600/20 text-purple-300 border border-purple-500/40 shadow-[0_0_20px_rgba(147,51,234,0.25)]"
              : "text-gray-400 hover:text-white hover:bg-white/[0.04] border border-transparent"
          }`}
        >
          <Shield className="w-4 h-4 text-indigo-400" />
          <span>Distraction Shields</span>
          <span className="text-[10px] font-mono text-gray-500">({blockedWebsites.length})</span>
        </button>

        <button
          onClick={() => {
            setActiveTab("extension");
            soundManager.play("select");
          }}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeTab === "extension"
              ? "bg-purple-600/20 text-purple-300 border border-purple-500/40 shadow-[0_0_20px_rgba(147,51,234,0.25)]"
              : "text-gray-400 hover:text-white hover:bg-white/[0.04] border border-transparent"
          }`}
        >
          <Puzzle className="w-4 h-4 text-cyan-400" />
          <span>Extension Companion</span>
          <Badge variant={extState.connected ? "green" : "red"}>
            {extState.connected ? "v" + extState.version : "Offline"}
          </Badge>
        </button>
      </div>

      {/* ==================================================================== */}
      {/* TAB 1: YOUTUBE STUDY CONTENT GUARD */}
      {/* ==================================================================== */}
      {activeTab === "youtube" && (
        <div className="space-y-6">
          {/* Master Rule & Real-Time Engine Status Banner */}
          <Card
            variant="glass"
            className={`border transition-all ${
              youtubeGuardActive
                ? "border-emerald-500/40 bg-gradient-to-r from-emerald-950/30 via-slate-950/80 to-purple-950/30 shadow-[0_0_35px_rgba(16,185,129,0.15)]"
                : isPaused
                ? "border-amber-500/40 bg-gradient-to-r from-amber-950/20 via-slate-950/80 to-slate-950/80"
                : "border-white/[0.08]"
            }`}
          >
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
              <div className="space-y-1.5">
                <div className="flex items-center gap-2.5">
                  <div
                    className={`w-3 h-3 rounded-full ${
                      youtubeGuardActive
                        ? "bg-emerald-400 shadow-[0_0_12px_#34d399] animate-ping"
                        : isPaused
                        ? "bg-amber-400 shadow-[0_0_8px_#fbbf24]"
                        : "bg-slate-500"
                    }`}
                  />
                  <span className="text-sm font-black tracking-wide text-white uppercase flex items-center gap-2">
                    YouTube Content Gateway —{" "}
                    {youtubeGuardActive ? (
                      <span className="text-emerald-400">ARMED (STUDY CONTENT ONLY)</span>
                    ) : isPaused ? (
                      <span className="text-amber-400">PAUSED (UNRESTRICTED BREAK)</span>
                    ) : (
                      <span className="text-gray-400">STANDBY (NORMAL YOUTUBE)</span>
                    )}
                  </span>
                </div>
                <p className="text-xs text-gray-300 leading-relaxed max-w-2xl">
                  {youtubeGuardActive
                    ? `Session #${activeSession?.id?.slice(0, 8)} active (${activeSession?.subject} • ${activeSession?.chapter}). Layer A Pre-Navigation Firewall & Layer B DNR Video Gateway active. YouTube Home, Search, and Channels remain accessible; only verified syllabus lectures may play.`
                    : isPaused
                    ? "Study session is currently paused. YouTube is completely unrestricted so you can take an intentional break."
                    : "When no study session is running, YouTube behaves normally with zero blocking, zero classification, and zero gateway redirection."}
                </p>
              </div>

              {/* Master Rule Verification Pills */}
              <div className="flex flex-wrap items-center gap-2 shrink-0">
                <div className="p-2.5 rounded-xl bg-black/40 border border-white/[0.08] text-[11px] font-mono space-y-1">
                  <div className="flex items-center justify-between gap-3 text-gray-400">
                    <span>Authenticated:</span>
                    <span className={uid ? "text-emerald-400 font-bold" : "text-amber-400 font-bold"}>
                      {uid ? "✓ YES" : "GUEST"}
                    </span>
                  </div>
                  <div className="flex items-center justify-between gap-3 text-gray-400">
                    <span>Defense in Depth:</span>
                    <span className={youtubeGuardActive ? "text-emerald-400 font-bold" : "text-gray-500"}>
                      {youtubeGuardActive ? "Layer A + Layer B" : "Standby"}
                    </span>
                  </div>
                  <div className="flex items-center justify-between gap-3 text-gray-400">
                    <span>Session Lease:</span>
                    <span className={youtubeGuardActive ? "text-emerald-400 font-bold" : "text-gray-500"}>
                      {youtubeGuardActive ? "VALID (120s Rolling)" : "NONE"}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </Card>

          {/* Academic Intelligence Engine Status Banner */}
          <Card variant="glass" className="border-purple-500/20 bg-gradient-to-r from-purple-950/20 via-slate-900/40 to-cyan-950/20 p-5 space-y-4">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400 shrink-0">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="text-sm font-bold text-white tracking-wide">
                      FocusForge Academic Intelligence Engine
                    </h3>
                    <Badge variant="purple" className="text-[10px]">
                      {CLASSIFIER_VERSION}
                    </Badge>
                    <span className="text-[10px] px-2 py-0.5 rounded-full border border-cyan-400/30 text-cyan-300 font-mono">
                      Taxonomy v{TAXONOMY_VERSION}
                    </span>
                  </div>
                  <p className="text-xs text-gray-400 mt-0.5">
                    Curriculum knowledge graph covering JEE Main, JEE Advanced, NEET, CBSE Class 11-12, & NCERT with strict negative context dominance.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 text-[11px] font-mono shrink-0">
                <span className="px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 font-semibold">
                  0.00% False Allow Rate
                </span>
                <span className="px-2.5 py-1 rounded-lg bg-purple-500/10 border border-purple-500/20 text-purple-300 font-semibold">
                  3-Way Decision
                </span>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-xs">
              <div className="p-2.5 rounded-xl bg-black/40 border border-white/[0.06]">
                <div className="text-[10px] uppercase font-bold text-gray-500">Physics</div>
                <div className="font-semibold text-gray-200 mt-0.5 text-xs">28 Chapters • 100+ Topics</div>
              </div>
              <div className="p-2.5 rounded-xl bg-black/40 border border-white/[0.06]">
                <div className="text-[10px] uppercase font-bold text-gray-500">Chemistry</div>
                <div className="font-semibold text-gray-200 mt-0.5 text-xs">Physical, Inorganic, Organic</div>
              </div>
              <div className="p-2.5 rounded-xl bg-black/40 border border-white/[0.06]">
                <div className="text-[10px] uppercase font-bold text-gray-500">Mathematics</div>
                <div className="font-semibold text-gray-200 mt-0.5 text-xs">Calculus, Algebra, Vectors</div>
              </div>
              <div className="p-2.5 rounded-xl bg-black/40 border border-white/[0.06]">
                <div className="text-[10px] uppercase font-bold text-gray-500">Biology (NEET)</div>
                <div className="font-semibold text-gray-200 mt-0.5 text-xs">Genetics, Biotech, Physiology</div>
              </div>
              <div className="p-2.5 rounded-xl bg-black/40 border border-white/[0.06]">
                <div className="text-[10px] uppercase font-bold text-gray-500">English Core (CBSE)</div>
                <div className="font-semibold text-gray-200 mt-0.5 text-xs">Flamingo, Vistas, Writing</div>
              </div>
            </div>
          </Card>

          {/* Configuration Grid: Mode + Academic Scope */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Guard Mode Selector */}
            <Card variant="glass" className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                  <Shield className="w-4 h-4 text-purple-400" /> Guard Protection Mode
                </h3>
                <Badge variant="purple">{ytMode.toUpperCase()}</Badge>
              </div>

              <p className="text-xs text-gray-400">
                Determines how strictly video content and discovery algorithms are governed during an active study session.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {/* Strict */}
                <button
                  onClick={() => handleModeChange("strict")}
                  className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                    ytMode === "strict"
                      ? "bg-purple-600/20 border-purple-500 text-white shadow-[0_0_15px_rgba(147,51,234,0.2)]"
                      : "bg-slate-950/60 border-white/[0.08] text-gray-400 hover:border-white/20"
                  }`}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-xs font-bold text-white">Strict Mode</span>
                    {ytMode === "strict" && <Check className="w-3.5 h-3.5 text-purple-400" />}
                  </div>
                  <p className="text-[11px] leading-relaxed text-gray-400">
                    Verified academic topics only. Shorts blocked. Home feed blocked. Recommendations hidden. Unrestricted search blocked.
                  </p>
                </button>

                {/* Balanced */}
                <button
                  onClick={() => handleModeChange("balanced")}
                  className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                    ytMode === "balanced"
                      ? "bg-emerald-600/20 border-emerald-500 text-white shadow-[0_0_15px_rgba(16,185,129,0.2)]"
                      : "bg-slate-950/60 border-white/[0.08] text-gray-400 hover:border-white/20"
                  }`}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-xs font-bold text-white">Balanced</span>
                    {ytMode === "balanced" && <Check className="w-3.5 h-3.5 text-emerald-400" />}
                  </div>
                  <p className="text-[11px] leading-relaxed text-gray-400">
                    Verified academic topics and trusted educational channels allowed. Shorts blocked. Unrelated recommendations blocked.
                  </p>
                </button>

                {/* Custom */}
                <button
                  onClick={() => handleModeChange("custom")}
                  className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                    ytMode === "custom"
                      ? "bg-blue-600/20 border-blue-500 text-white shadow-[0_0_15px_rgba(59,130,246,0.2)]"
                      : "bg-slate-950/60 border-white/[0.08] text-gray-400 hover:border-white/20"
                  }`}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-xs font-bold text-white">Custom</span>
                    {ytMode === "custom" && <Check className="w-3.5 h-3.5 text-blue-400" />}
                  </div>
                  <p className="text-[11px] leading-relaxed text-gray-400">
                    User-configured rules with active session gating. Inactive when no study session is running.
                  </p>
                </button>
              </div>
            </Card>

            {/* Academic Scope */}
            <Card variant="glass" className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-cyan-400" /> Academic Scope
                </h3>
                <span className="text-[10px] text-cyan-300 font-mono font-bold">
                  {academicScope.length} Active Targets
                </span>
              </div>

              <p className="text-xs text-gray-400">
                Videos matching these examination standards and subjects receive high academic classification weighting.
              </p>

              <div className="flex flex-wrap gap-2">
                {[
                  "JEE Main",
                  "JEE Advanced",
                  "NEET",
                  "CBSE Class 12",
                  "Physics",
                  "Chemistry",
                  "Mathematics",
                  "Biology",
                  "English",
                ].map((item) => {
                  const active = academicScope.includes(item);
                  return (
                    <button
                      key={item}
                      onClick={() => handleToggleScope(item)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer flex items-center gap-1.5 ${
                        active
                          ? "bg-cyan-500/15 border border-cyan-500/40 text-cyan-300 shadow-[0_0_10px_rgba(6,182,212,0.15)]"
                          : "bg-white/[0.03] border border-white/[0.08] text-gray-400 hover:text-white hover:border-white/20"
                      }`}
                    >
                      {active ? <Check className="w-3 h-3 text-cyan-400" /> : <Plus className="w-3 h-3 text-gray-500" />}
                      <span>{item}</span>
                    </button>
                  );
                })}
              </div>
            </Card>
          </div>

          {/* Trusted Educational Channels & Explicit Approved Videos */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Trusted Channels Manager */}
            <Card variant="glass" className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-400" /> Trusted Educational Channels ({trustedChannels.length})
                </h3>
                <span className="text-[10px] text-gray-400 font-mono">Weighted Confidence</span>
              </div>

              <p className="text-xs text-gray-400 leading-relaxed">
                Trusted educational channels boost confidence, while non-study uploads (vlogs, memes, tech reviews) are still evaluated and blocked.
              </p>

              {/* Add Custom Channel Form */}
              <form onSubmit={handleAddCustomChannel} className="flex gap-2">
                <input
                  type="text"
                  placeholder="E.g. Physics Galaxy, Arvind Academy"
                  value={newChannelName}
                  onChange={(e) => setNewChannelName(e.target.value)}
                  className="flex-1 glass-input px-3 py-2 text-xs text-white focus:outline-none min-h-[40px]"
                />
                <Button type="submit" variant="primary" size="sm" className="shrink-0 cursor-pointer">
                  <Plus className="w-3.5 h-3.5" /> Add Channel
                </Button>
              </form>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-56 overflow-y-auto pr-1">
                {trustedChannels.map((ch) => (
                  <div
                    key={ch.id || ch.channelName}
                    className="p-2.5 rounded-xl bg-slate-950/60 border border-white/[0.08] flex items-center justify-between text-xs"
                  >
                    <div className="min-w-0 pr-2">
                      <p className="font-bold text-white truncate">{ch.channelName}</p>
                      <p className="text-[10px] text-gray-400 truncate font-mono">
                        {ch.subjects.slice(0, 2).join(", ")}
                      </p>
                    </div>
                    <Badge variant={ch.trustStatus === "verified" ? "green" : "purple"}>
                      {ch.trustStatus === "verified" ? "Verified" : "Custom"}
                    </Badge>
                  </div>
                ))}
              </div>
            </Card>

            {/* Explicitly Approved Videos */}
            <Card variant="glass" className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" /> Explicitly Approved Study Videos ({allowedVideos.length})
                </h3>
                <span className="text-[10px] text-gray-400 font-mono">Student Whitelist</span>
              </div>

              <p className="text-xs text-gray-400 leading-relaxed">
                Manually approved study lectures are guaranteed ALLOW during active study sessions. Still gated strictly by the active session.
              </p>

              {/* Add Video by ID/URL Form */}
              <form onSubmit={handleAddApprovedVideo} className="space-y-2">
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="YouTube Video URL or ID (e.g. wJ8Wd6Lq4K0)"
                    value={newVideoUrl}
                    onChange={(e) => setNewVideoUrl(e.target.value)}
                    className="flex-1 glass-input px-3 py-2 text-xs text-white focus:outline-none min-h-[40px]"
                  />
                  <select
                    value={newVideoSubject}
                    onChange={(e) => setNewVideoSubject(e.target.value as AcademicSubject)}
                    className="glass-input px-2 text-xs text-white bg-slate-900 border border-white/10 rounded-xl"
                  >
                    <option value="Physics">Physics</option>
                    <option value="Chemistry">Chemistry</option>
                    <option value="Mathematics">Mathematics</option>
                    <option value="Biology">Biology</option>
                    <option value="English">English</option>
                  </select>
                </div>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Lecture Title (e.g. Rotational Motion Marathon)"
                    value={newVideoTitle}
                    onChange={(e) => setNewVideoTitle(e.target.value)}
                    className="flex-1 glass-input px-3 py-2 text-xs text-white focus:outline-none min-h-[40px]"
                  />
                  <Button type="submit" variant="primary" size="sm" className="shrink-0 cursor-pointer">
                    <Plus className="w-3.5 h-3.5" /> Approve
                  </Button>
                </div>
              </form>

              <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                {allowedVideos.length === 0 ? (
                  <div className="p-4 rounded-xl bg-white/[0.02] border border-dashed border-white/10 text-center text-xs text-gray-400">
                    No explicitly approved videos yet. Add high-value study lectures above.
                  </div>
                ) : (
                  allowedVideos.map((v) => (
                    <div
                      key={v.id}
                      className="p-2.5 rounded-xl bg-slate-950/60 border border-emerald-500/20 flex items-center justify-between text-xs"
                    >
                      <div className="min-w-0 pr-2">
                        <p className="font-bold text-white truncate">{v.title}</p>
                        <p className="text-[10px] text-emerald-400 font-mono">
                          ID: {v.videoId} • {v.subject}
                        </p>
                      </div>
                      <button
                        onClick={() => handleRevokeVideo(v.videoId)}
                        className="text-gray-500 hover:text-red-400 p-1 cursor-pointer transition-colors"
                        title="Revoke Approval"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </Card>
          </div>

          {/* Interactive Study Video Search Engine (Section 17) */}
          <Card variant="glass" className="space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                  <Search className="w-4 h-4 text-purple-400" /> FocusForge Study Search (Distraction-Free)
                </h3>
                <p className="text-xs text-gray-400 mt-0.5">
                  Pre-classified candidate lectures. Only genuine verified educational content is displayed with the Watch button.
                </p>
              </div>
              <span className="text-[11px] font-mono text-purple-300">
                {studyVideoResults.length} Verified Lectures
              </span>
            </div>

            <form onSubmit={handleStudySearch} className="flex gap-2">
              <input
                type="text"
                placeholder="Search topics, e.g. Electrostatics, Reaction Mechanism, Definite Integrals, Flamingo..."
                value={studyVideoQuery}
                onChange={(e) => setStudyVideoQuery(e.target.value)}
                className="flex-1 glass-input px-3.5 py-2.5 text-xs text-white focus:outline-none min-h-[44px]"
              />
              <Button type="submit" variant="primary" size="md" className="shrink-0 cursor-pointer">
                <Search className="w-4 h-4" /> {isSearchingVideos ? "Searching..." : "Search Study Content"}
              </Button>
            </form>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {studyVideoResults.map((video) => (
                <div
                  key={video.videoId}
                  className="p-3.5 rounded-xl bg-slate-950/70 border border-white/[0.08] hover:border-purple-500/40 transition-all flex flex-col justify-between space-y-3 group"
                >
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-500/15 text-purple-300 font-bold border border-purple-500/20">
                        {video.subject}
                      </span>
                      <span className="text-[10px] font-mono text-gray-400">{video.durationFormatted}</span>
                    </div>
                    <h4 className="text-xs font-bold text-white line-clamp-2 leading-snug group-hover:text-purple-300 transition-colors">
                      {video.title}
                    </h4>
                    <p className="text-[11px] text-gray-400 truncate">{video.channelName}</p>
                    <p className="text-[10px] text-cyan-400 font-mono truncate">
                      {video.chapter} • {video.topic}
                    </p>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-white/[0.06]">
                    <span className="text-[10px] font-mono text-emerald-400 flex items-center gap-1 font-bold">
                      <CheckCircle2 className="w-3 h-3" /> {video.verificationStatus}
                    </span>
                    <button
                      onClick={() => setActiveWatchModalVideo(video)}
                      className="px-2.5 py-1 rounded-lg bg-purple-600/30 hover:bg-purple-600/50 text-white text-[11px] font-bold border border-purple-500/30 transition-all cursor-pointer flex items-center gap-1"
                    >
                      <Play className="w-3 h-3" /> Watch Lecture
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          {/* Academic Topics Taxonomy Browser */}
          <Card variant="glass" className="space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                  <Layers className="w-4 h-4 text-indigo-400" /> Academic Syllabus Topics Taxonomy
                </h3>
                <p className="text-xs text-gray-400 mt-0.5">
                  Centralized topic database with keywords, aliases, and examination tags for semantic classification.
                </p>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  placeholder="Filter topics..."
                  value={searchTopicQuery}
                  onChange={(e) => setSearchTopicQuery(e.target.value)}
                  className="glass-input px-3 py-1.5 text-xs text-white focus:outline-none min-w-[160px]"
                />
              </div>
            </div>

            {/* Subject Filters */}
            <div className="flex flex-wrap gap-1.5">
              {["All", "Physics", "Chemistry", "Mathematics", "Biology", "English"].map((sub) => (
                <button
                  key={sub}
                  onClick={() => setSelectedSubjectFilter(sub)}
                  className={`px-3 py-1 rounded-lg text-[11px] font-semibold transition-all cursor-pointer ${
                    selectedSubjectFilter === sub
                      ? "bg-purple-600 text-white font-bold"
                      : "bg-white/[0.04] text-gray-400 hover:text-white"
                  }`}
                >
                  {sub}
                </button>
              ))}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2.5 max-h-72 overflow-y-auto pr-1 text-xs">
              {filteredTaxonomy.map((entry) => (
                <div
                  key={entry.id}
                  className="p-3 rounded-xl bg-slate-950/60 border border-white/[0.08] space-y-1.5"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold text-purple-300 font-mono uppercase">
                      {entry.subject}
                    </span>
                    <span className="text-[9px] font-mono text-gray-500 px-1.5 py-0.5 rounded bg-white/[0.03]">
                      {entry.exam || "JEE"}
                    </span>
                  </div>
                  <p className="font-bold text-white truncate">{entry.chapter}</p>
                  <p className="text-[11px] text-gray-400 line-clamp-1">{entry.topic}</p>
                  <div className="flex flex-wrap gap-1 pt-1">
                    {entry.keywords.slice(0, 3).map((kw) => (
                      <span
                        key={kw}
                        className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-white/[0.04] text-gray-400"
                      >
                        #{kw}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </Card>

          {/* Developer Diagnostics & Transparent Real-Time Inspector (Section 48 & 49) */}
          <Card variant="glass" className="space-y-4 border-emerald-500/20 bg-gradient-to-r from-slate-950 via-slate-900/60 to-emerald-950/20">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                  <Terminal className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                    Developer Diagnostics & Classification Trace
                  </h3>
                  <p className="text-[11px] text-gray-400 mt-0.5">
                    Live semantic analysis, intent classification, and multi-anchor trace engine.
                  </p>
                </div>
              </div>
              <div className="flex flex-wrap items-center gap-2 text-[10px] font-mono">
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 font-bold flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" /> Classifier: ONLINE
                </span>
                <span className="px-2 py-0.5 rounded-full bg-cyan-500/15 border border-cyan-500/30 text-cyan-300">
                  Taxonomy: Loaded (v{TAXONOMY_VERSION})
                </span>
                <span className="px-2 py-0.5 rounded-full bg-purple-500/15 border border-purple-500/30 text-purple-300">
                  Scope: JEE / NEET / CBSE
                </span>
              </div>
            </div>

            {/* Interactive Inspector Form */}
            <form onSubmit={handleRunDiagnostics} className="flex gap-2">
              <input
                type="text"
                placeholder="Enter YouTube Video ID or URL (e.g. wJ8Wd6Lq4K0 or https://youtube.com/watch?v=...)"
                value={diagVideoQuery}
                onChange={(e) => setDiagVideoQuery(e.target.value)}
                className="flex-1 glass-input px-3.5 py-2 text-xs font-mono text-white focus:outline-none min-h-[40px]"
              />
              <Button type="submit" variant="primary" size="sm" className="shrink-0 cursor-pointer flex items-center gap-1.5">
                <Activity className="w-3.5 h-3.5" />
                {isDiagRunning ? "Analyzing..." : "Inspect Video"}
              </Button>
            </form>

            {/* Quick Test Preset Buttons */}
            <div className="flex flex-wrap items-center gap-1.5 text-[10px] font-mono text-gray-400">
              <span className="text-gray-500">Quick Test:</span>
              <button
                type="button"
                onClick={() => {
                  setDiagVideoQuery("phy_rot_01");
                  setDiagResult({
                    videoId: "phy_rot_01",
                    title: "Rotational Motion Class 11 Complete Lecture JEE Advanced",
                    decision: "STUDY",
                    confidenceBand: "VERY_HIGH",
                    confidence: 0.98,
                    intent: "TEACH",
                    subject: "Physics",
                    chapter: "Rotational Motion",
                    topic: "Moment of Inertia and Rolling Motion",
                    reasonCodes: ["TOPIC_MATCH", "CHAPTER_MATCH", "SUBJECT_MATCH", "ACADEMIC_INTENT", "LECTURE"],
                    reason: "Matched Physics → Rotational Motion → Moment of Inertia with verified academic lecture intent.",
                    taxonomyVersion: TAXONOMY_VERSION,
                    classifierVersion: CLASSIFIER_VERSION,
                    trace: [
                      { stage: "DETECTED", timestamp: Date.now() - 15 },
                      { stage: "METADATA_LOADED", timestamp: Date.now() - 10 },
                      { stage: "LOCAL_CLASSIFIED", timestamp: Date.now() - 5 },
                      { stage: "FINAL_DECISION", timestamp: Date.now() },
                    ],
                  });
                }}
                className="px-2 py-0.5 rounded bg-white/[0.04] hover:bg-white/[0.08] text-gray-300 border border-white/[0.08] cursor-pointer"
              >
                Physics Lecture (STUDY)
              </button>
              <button
                type="button"
                onClick={() => {
                  setDiagVideoQuery("vlog_jee_01");
                  setDiagResult({
                    videoId: "vlog_jee_01",
                    title: "My JEE Preparation Vlog: 14 Hours at Kota Hostel",
                    decision: "NON_STUDY",
                    confidenceBand: "VERY_HIGH",
                    confidence: 0.96,
                    intent: "VLOG",
                    subject: "",
                    chapter: "",
                    topic: "",
                    reasonCodes: ["VLOG", "CAMPUS_LIFESTYLE", "NON_ACADEMIC_INTENT"],
                    reason: "Detected non-academic vlog content (hostel life): no verified academic curriculum instruction.",
                    taxonomyVersion: TAXONOMY_VERSION,
                    classifierVersion: CLASSIFIER_VERSION,
                    trace: [
                      { stage: "DETECTED", timestamp: Date.now() - 15 },
                      { stage: "METADATA_LOADED", timestamp: Date.now() - 10 },
                      { stage: "LOCAL_CLASSIFIED", timestamp: Date.now() - 5 },
                      { stage: "FINAL_DECISION", timestamp: Date.now() },
                    ],
                  });
                }}
                className="px-2 py-0.5 rounded bg-white/[0.04] hover:bg-white/[0.08] text-gray-300 border border-white/[0.08] cursor-pointer"
              >
                Hostel Vlog (NON_STUDY)
              </button>
              <button
                type="button"
                onClick={() => {
                  setDiagVideoQuery("exp_phy_01");
                  setDiagResult({
                    videoId: "exp_phy_01",
                    title: "Physics Experiment",
                    decision: "REVIEW",
                    confidenceBand: "MEDIUM",
                    confidence: 0.50,
                    intent: "EXPLAIN",
                    subject: "Physics",
                    chapter: "General Physics",
                    topic: "Experimental Demonstration",
                    reasonCodes: ["AMBIGUOUS_CONTEXT", "INSUFFICIENT_EVIDENCE"],
                    reason: "Bare experiment title without explicit curriculum topic or class level. Held for review.",
                    taxonomyVersion: TAXONOMY_VERSION,
                    classifierVersion: CLASSIFIER_VERSION,
                    trace: [
                      { stage: "DETECTED", timestamp: Date.now() - 15 },
                      { stage: "METADATA_LOADED", timestamp: Date.now() - 10 },
                      { stage: "LOCAL_CLASSIFIED", timestamp: Date.now() - 5 },
                      { stage: "FINAL_DECISION", timestamp: Date.now() },
                    ],
                  });
                }}
                className="px-2 py-0.5 rounded bg-white/[0.04] hover:bg-white/[0.08] text-gray-300 border border-white/[0.08] cursor-pointer"
              >
                Physics Experiment (REVIEW)
              </button>
            </div>

            {/* Diagnostic Result View */}
            {diagResult && (
              <div className="p-4 rounded-xl bg-black/60 border border-white/[0.08] space-y-3 font-mono text-xs">
                <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-white/[0.06]">
                  <div className="flex items-center gap-2">
                    <span className="text-gray-400">Target Video:</span>
                    <span className="text-white font-bold">{diagResult.videoId}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge
                      variant={
                        diagResult.decision === "STUDY" || diagResult.decision === "ALLOW"
                          ? "green"
                          : diagResult.decision === "REVIEW"
                          ? "purple"
                          : "red"
                      }
                      className="text-xs font-bold"
                    >
                      {diagResult.decision}
                    </Badge>
                    <span className="text-[11px] px-2 py-0.5 rounded bg-white/[0.05] text-cyan-300">
                      {diagResult.confidenceBand || "HIGH"} ({diagResult.confidence || 0.95})
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-[11px]">
                  <div>
                    <span className="text-gray-500 block">Intent Class:</span>
                    <span className="text-purple-300 font-bold">{diagResult.intent || "TEACH"}</span>
                  </div>
                  <div>
                    <span className="text-gray-500 block">Subject / Chapter:</span>
                    <span className="text-gray-200">
                      {diagResult.subject ? `${diagResult.subject} • ${diagResult.chapter || ""}` : "None"}
                    </span>
                  </div>
                  <div>
                    <span className="text-gray-500 block">Detected Topic:</span>
                    <span className="text-emerald-300">{diagResult.topic || "N/A"}</span>
                  </div>
                  <div>
                    <span className="text-gray-500 block">Classifier Subsystem:</span>
                    <span className="text-gray-400">FocusForgeYouTubeGuard</span>
                  </div>
                </div>

                {/* Reason Codes */}
                {Array.isArray(diagResult.reasonCodes) && diagResult.reasonCodes.length > 0 && (
                  <div>
                    <span className="text-gray-500 text-[10px] block mb-1">Reason Codes:</span>
                    <div className="flex flex-wrap gap-1">
                      {diagResult.reasonCodes.map((code: string) => (
                        <span key={code} className="px-1.5 py-0.5 rounded bg-white/[0.04] text-[10px] text-gray-300 border border-white/[0.06]">
                          {code}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Explanation */}
                <div className="p-2.5 rounded-lg bg-white/[0.02] border border-white/[0.04] text-[11px] text-gray-300">
                  <span className="text-gray-500 font-bold block mb-0.5">Explanation:</span>
                  {diagResult.reason}
                </div>

                {/* Event Trace Stages */}
                <div>
                  <span className="text-gray-500 text-[10px] block mb-1">Event Trace:</span>
                  <div className="flex flex-wrap items-center gap-1.5 text-[10px]">
                    {["DETECTED", "METADATA_LOADED", "LOCAL_CLASSIFIED", "FINAL_DECISION"].map((stage, idx) => (
                      <div key={stage} className="flex items-center gap-1.5">
                        <span className="px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-semibold">
                          ✓ {stage}
                        </span>
                        {idx < 3 && <span className="text-gray-600">→</span>}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </Card>
        </div>
      )}

      {/* ==================================================================== */}
      {/* TAB 2: DISTRACTION SHIELDS (EXISTING SITE BLOCKER) */}
      {/* ==================================================================== */}
      {activeTab === "shields" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="space-y-6">
            <Card variant="glass" className="space-y-4">
              <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Lock className="w-4 h-4 text-purple-400" /> Mode Protections
              </h3>

              <div className="p-3.5 bg-slate-950/80 rounded-xl border border-white/[0.08] space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-xs font-bold text-white">Whitelist-Only Mode</span>
                    <p className="text-[11px] text-gray-400">Block all except whitelisted study platforms</p>
                  </div>
                  <button
                    onClick={() => {
                      soundManager.play("select");
                      setWhitelistOnly(!whitelistOnly);
                    }}
                    className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
                      whitelistOnly ? "bg-purple-600" : "bg-slate-700"
                    }`}
                  >
                    <div
                      className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-transform ${
                        whitelistOnly ? "left-6" : "left-1"
                      }`}
                    />
                  </button>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-white/[0.06]">
                  <div>
                    <span className="text-xs font-bold text-white">Exam Mode (Strict Lock)</span>
                    <p className="text-[11px] text-gray-400">Locks pause controls during active timer</p>
                  </div>
                  <button
                    onClick={() => {
                      soundManager.play("select");
                      setExamModeEnabled(!examModeEnabled);
                    }}
                    className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
                      examModeEnabled ? "bg-red-600" : "bg-slate-700"
                    }`}
                  >
                    <div
                      className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-transform ${
                        examModeEnabled ? "left-6" : "left-1"
                      }`}
                    />
                  </button>
                </div>
              </div>
            </Card>

            <Card variant="glass" className="space-y-4">
              <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Clock className="w-4 h-4 text-blue-400" /> Protection Schedule
              </h3>
              <div className="space-y-2">
                {scheduleSlots.map((slot) => (
                  <div
                    key={slot.id}
                    className="p-3 bg-slate-950/60 border border-white/[0.08] rounded-xl flex items-center justify-between text-xs"
                  >
                    <div>
                      <span className="font-bold text-white font-mono">
                        {slot.start} - {slot.end}
                      </span>
                      <span className="text-[10px] text-gray-400 block font-mono">{slot.days}</span>
                    </div>
                    <button
                      onClick={() => toggleSchedule(slot.id)}
                      className={`px-2 py-1 rounded text-[10px] font-bold cursor-pointer transition-colors ${
                        slot.active ? "bg-emerald-500/20 text-emerald-400" : "bg-white/5 text-gray-400"
                      }`}
                    >
                      {slot.active ? "Active" : "Paused"}
                    </button>
                  </div>
                ))}
              </div>
            </Card>
          </div>

          <div className="lg:col-span-2 space-y-6">
            <Card variant="glass" className="space-y-4">
              <h2 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Lock className="w-4 h-4 text-purple-400" /> Custom Blocked Domains ({blockedWebsites.length})
              </h2>

              <form onSubmit={handleAddWebsite} className="flex gap-2">
                <input
                  type="text"
                  placeholder="E.g. reddit.com, instagram.com"
                  value={newDomain}
                  onChange={(e) => setNewDomain(e.target.value)}
                  className="flex-1 glass-input px-3.5 py-2.5 text-xs text-white focus:outline-none min-h-[44px]"
                />
                <Button type="submit" variant="primary" size="md" className="shrink-0 cursor-pointer">
                  <Plus className="w-4 h-4" /> Block Domain
                </Button>
              </form>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                {blockedWebsites.map((site) => (
                  <div
                    key={site}
                    className="p-3 bg-slate-950/60 border border-white/[0.08] rounded-xl font-mono flex items-center justify-between hover:border-purple-500/30 transition-all group"
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="w-1.5 h-1.5 rounded-full bg-red-400 shrink-0" />
                      <span className="text-gray-200 font-medium truncate">{site}</span>
                    </div>
                    <button
                      onClick={() => handleRemove(site)}
                      className="text-gray-500 hover:text-red-400 p-1 cursor-pointer transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </Card>

            <Card variant="glass" className="space-y-4">
              <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Layers className="w-4 h-4 text-purple-400" /> Preloaded Distraction Catalogs
              </h3>
              <div className="space-y-3">
                {Object.values(DEFAULT_DISTRACTION_CATALOG).map((cat: DistractionCategory) => {
                  const allBlocked = cat.domains.every((d) => blockedWebsites.includes(d));
                  const countBlocked = cat.domains.filter((d) => blockedWebsites.includes(d)).length;
                  return (
                    <div key={cat.name} className="p-3.5 rounded-xl border border-white/[0.08] bg-slate-950/60 space-y-2.5">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-white">{cat.name} ({countBlocked}/{cat.domains.length})</span>
                        <button
                          onClick={() => handleToggleCategory(cat)}
                          className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                            allBlocked
                              ? "bg-red-500/20 text-red-400 border border-red-500/30"
                              : "bg-purple-500/20 text-purple-300 border border-purple-500/30"
                          }`}
                        >
                          {allBlocked ? "Unblock All" : "Block All"}
                        </button>
                      </div>
                      <div className="flex flex-wrap gap-1.5">
                        {cat.domains.map((dom) => {
                          const isBlk = blockedWebsites.includes(dom);
                          return (
                            <button
                              key={dom}
                              onClick={() => handleToggleDomain(dom)}
                              className={`px-2 py-1 rounded text-[11px] font-mono transition-all flex items-center gap-1 cursor-pointer ${
                                isBlk
                                  ? "bg-red-500/15 border border-red-500/30 text-red-300"
                                  : "bg-white/[0.03] border border-white/[0.08] text-gray-400 hover:text-white"
                              }`}
                            >
                              {isBlk ? <Check className="w-3 h-3 text-red-400" /> : <Plus className="w-3 h-3" />}
                              {dom}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </div>
            </Card>

            <Card variant="glass" className="space-y-4">
              <h2 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Unlock className="w-4 h-4 text-emerald-400" /> Whitelisted Study Domains ({whitelistedWebsites.length})
              </h2>
              <form onSubmit={handleAddWhitelistedWebsite} className="flex gap-2">
                <input
                  type="text"
                  placeholder="E.g. physicsgalaxy.com, nta.ac.in"
                  value={newWhitelistedDomain}
                  onChange={(e) => setNewWhitelistedDomain(e.target.value)}
                  className="flex-1 glass-input px-3.5 py-2.5 text-xs text-white focus:outline-none min-h-[44px]"
                />
                <Button type="submit" variant="primary" size="md" className="shrink-0 cursor-pointer">
                  <Plus className="w-4 h-4" /> Allow Domain
                </Button>
              </form>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                {whitelistedWebsites.map((site) => (
                  <div
                    key={site}
                    className="p-3 bg-emerald-500/5 border border-emerald-500/15 rounded-xl text-emerald-300 font-mono flex items-center justify-between"
                  >
                    <span className="truncate">{site}</span>
                    <button
                      onClick={() => handleRemoveWhitelisted(site)}
                      className="text-gray-500 hover:text-red-400 p-1 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        </div>
      )}

      {/* ==================================================================== */}
      {/* TAB 3: EXTENSION COMPANION */}
      {/* ==================================================================== */}
      {activeTab === "extension" && (
        <div className="max-w-2xl mx-auto space-y-6">
          <Card variant="glass" className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Puzzle className="w-4 h-4 text-purple-400" /> Companion Extension Status
              </h3>
              <Badge variant={extState.connected ? "green" : "red"}>
                {extState.connected ? "Connected" : "Disconnected"}
              </Badge>
            </div>

            <p className="text-xs text-gray-400 leading-relaxed">
              The FocusForge Companion Manifest V3 extension enforces site blocking, manages the YouTube Study Content Guard, and synchronizes active focus sessions in real time.
            </p>

            <div className="p-4 bg-slate-950/80 rounded-xl border border-white/[0.08] space-y-3 text-xs font-mono">
              <div className="flex justify-between items-center text-gray-400">
                <span>Browser Engine:</span>
                <span className="text-white font-bold">{extState.browser}</span>
              </div>
              <div className="flex justify-between items-center text-gray-400">
                <span>Extension Version:</span>
                <span className="text-purple-300 font-bold">v{extState.version}</span>
              </div>
              <div className="flex justify-between items-center text-gray-400">
                <span>Heartbeat Status:</span>
                <span className="text-emerald-400 font-bold flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" /> {extState.syncHealth}
                </span>
              </div>
              <div className="flex justify-between items-center text-gray-400">
                <span>Last Synchronized:</span>
                <span className="text-gray-300">{isMounted ? new Date(extState.lastSync).toLocaleTimeString() : "—"}</span>
              </div>
            </div>

            <div className="flex gap-2">
              <Button
                variant="secondary"
                size="md"
                className="w-full cursor-pointer flex items-center justify-center gap-2"
                onClick={handleManualSync}
                disabled={isSyncing}
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? "animate-spin" : ""}`} />
                <span>{isSyncing ? "Syncing Engine..." : "Sync Extension Now"}</span>
              </Button>
              <Button
                variant="primary"
                size="md"
                className="w-full cursor-pointer flex items-center justify-center gap-2"
                onClick={() => downloadExtension()}
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download Extension (ZIP)</span>
              </Button>
            </div>
          </Card>
        </div>
      )}

      {/* Embedded Study Video Modal (Distraction-Free) */}
      {activeWatchModalVideo && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
          <div className="max-w-3xl w-full bg-slate-900 border border-purple-500/40 rounded-2xl overflow-hidden shadow-2xl flex flex-col">
            <div className="p-4 border-b border-white/10 flex items-center justify-between">
              <div>
                <span className="text-[10px] font-mono text-emerald-400 font-bold uppercase">
                  Verified Study Lecture
                </span>
                <h3 className="text-sm font-bold text-white line-clamp-1">{activeWatchModalVideo.title}</h3>
              </div>
              <button
                onClick={() => setActiveWatchModalVideo(null)}
                className="text-gray-400 hover:text-white p-1 rounded-lg hover:bg-white/10"
              >
                ✕
              </button>
            </div>
            <div className="relative aspect-video w-full bg-black">
              <iframe
                src={`https://www.youtube.com/embed/${activeWatchModalVideo.videoId}?autoplay=1&rel=0&modestbranding=1`}
                title={activeWatchModalVideo.title}
                className="w-full h-full"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            </div>
            <div className="p-3 bg-slate-950 flex items-center justify-between text-xs">
              <span className="text-gray-400 font-mono">
                {activeWatchModalVideo.channelName} • {activeWatchModalVideo.subject} • {activeWatchModalVideo.chapter}
              </span>
              <a
                href={activeWatchModalVideo.watchUrl}
                target="_blank"
                rel="noreferrer"
                className="text-purple-400 hover:text-purple-300 font-bold flex items-center gap-1"
              >
                <span>Open in YouTube</span> <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>
        </div>
      )}
    </WorkspaceLayout>
  );
}
