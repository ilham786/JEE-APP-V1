"use client";

import { useState, useMemo } from "react";
import { WorkspaceLayout } from "@/components/workspace-layout";
import { Card } from "@/components/ui/card";
import { Button, Badge, ProgressBar } from "@/components/ui/controls";
import { useMistakeStore } from "@/store/use-mistake-store";
import { useStudyStore } from "@/store/use-study-store";
import { useExam } from "@/hooks/use-exam";
import { getSubjectTheme } from "@/lib/subjectTheme";
import { soundManager } from "@/lib/sound-manager";
import {
  getCurriculumForExam,
  getSyllabusForSubject,
  getAllChaptersForExam,
  getAllFormulas,
  getAllNotes,
  Chapter,
  Formula,
  Note
} from "@/data/syllabus";
import { NEET_SYLLABUS_DATA } from "@/data/curriculum/neet-syllabus-data";
import {
  LayoutDashboard,
  Atom,
  FlaskConical,
  Calculator,
  FileText,
  Bookmark,
  Search,
  CheckCircle2,
  Clock,
  RotateCcw,
  Star,
  ChevronDown,
  ChevronUp,
  Pin,
  Flame,
  AlertCircle,
  Plus,
  BookOpen,
  Filter,
  Eye,
  EyeOff,
  List,
  LayoutGrid,
  Kanban,
  Dna,
  Sprout,
  Activity,
  Sparkles,
  Layers,
  Award,
  BookMarked
} from "lucide-react";

export default function JeeHubPage() {
  const { examType, config, isNeet, isJee, subjects } = useExam();

  // Main Top Tab Navigation
  const [activeTab, setActiveTab] = useState<string>("tracker");

  // Subject View Mode: List, Box, Kanban
  const [subjectViewMode, setSubjectViewMode] = useState<"list" | "box" | "kanban">("list");

  // Local state for interactive bookmarks & expanded chapter breakdowns
  const [bookmarkedChapters, setBookmarkedChapters] = useState<Set<string>>(new Set());
  const [expandedChapterIds, setExpandedChapterIds] = useState<Set<string>>(new Set());

  // Local state for formula pins & bookmarking
  const [pinnedFormulas, setPinnedFormulas] = useState<Set<string>>(new Set());
  const [showOnlyPinnedFormulas, setShowOnlyPinnedFormulas] = useState(false);

  // Filters & Search Queries
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<"All" | "Completed" | "In Progress" | "Revision Due">("All");
  const [classFilter, setClassFilter] = useState<"All" | "Class 11" | "Class 12">("All");

  const [formulaSearch, setFormulaSearch] = useState("");
  const [formulaSubFilter, setFormulaSubFilter] = useState<string>("All");
  const [formulaTagFilter, setFormulaTagFilter] = useState<"All" | "Bookmarked" | "Pinned">("All");

  // NCERT Vault Filters (for NEET)
  const [ncertSearch, setNcertSearch] = useState("");
  const [ncertSubFilter, setNcertSubFilter] = useState<string>("All");
  const [ncertCategoryFilter, setNcertCategoryFilter] = useState<string>("All");

  const [notesSearch, setNotesSearch] = useState("");
  const [notesSubFilter, setNotesSubFilter] = useState<string>("All");
  const [notesTypeFilter, setNotesTypeFilter] = useState<"All" | "personal" | "revision" | "quick">("All");

  // Zustand Store Integration
  const { syllabus: storeSyllabus, addWeakTopic, removeWeakTopic, mistakes } = useMistakeStore();
  const { currentStreak: storeStreak } = useStudyStore();

  // Local state for weak topic user input tags per chapter
  const [newWeakTopicText, setNewWeakTopicText] = useState<Record<string, string>>({});
  const [weakTopicsMap, setWeakTopicsMap] = useState<Record<string, string[]>>({});

  // Active Subject Theme
  const activeTheme = useMemo(() => getSubjectTheme(activeTab), [activeTab]);

  // Compute live chapter completion state merged with store syllabus
  const completionMap = useMemo(() => {
    const map: Record<string, number> = {};

    ["Physics", "Chemistry", "Maths", "Botany", "Zoology"].forEach((subjectKey) => {
      const storeList = (storeSyllabus as Record<string, any[]>)[subjectKey] || [];
      storeList.forEach((c) => {
        map[c.id] = c.completion;
        map[c.name.toLowerCase()] = c.completion;
      });
    });

    return map;
  }, [storeSyllabus]);

  // Helper to get completion percentage for a chapter
  const getCompletion = (chapterId: string, subject: string, chapterName: string): number => {
    if (completionMap[chapterId] !== undefined) return completionMap[chapterId];
    if (completionMap[chapterName.toLowerCase()] !== undefined) return completionMap[chapterName.toLowerCase()];
    return 0;
  };

  // Helper to get weak topics for a chapter
  const getWeakTopics = (chapterId: string, subject: string, chapterName: string): string[] => {
    const storeList = (storeSyllabus as Record<string, any[]>)[subject] || [];
    const found = storeList.find((c) => c.id === chapterId || c.name.toLowerCase() === chapterName.toLowerCase());
    const storeWeak = found ? found.weakTopics : [];
    const localWeak = weakTopicsMap[chapterId] || [];
    return Array.from(new Set([...storeWeak, ...localWeak]));
  };

  // Handler: Toggle Chapter Completion
  const handleToggleCompletion = (chapterId: string, subject: string, chapterName: string) => {
    const currentComp = getCompletion(chapterId, subject, chapterName);
    const newComp = currentComp >= 100 ? 0 : 100;

    soundManager.play(newComp >= 100 ? "complete" : "toggle-off");

    useMistakeStore.getState().updateChapterSyllabus(subject, chapterId, {
      completion: newComp,
      revisionCycles: newComp >= 100 ? 1 : 0,
    });
  };

  // Handler: Toggle Bookmark
  const handleToggleBookmark = (chapterId: string) => {
    soundManager.play("check");
    setBookmarkedChapters((prev) => {
      const next = new Set(prev);
      if (next.has(chapterId)) next.delete(chapterId);
      else next.add(chapterId);
      return next;
    });
  };

  // Handler: Expand/Collapse Chapter Breakdown
  const toggleExpandChapter = (chapterId: string) => {
    soundManager.play("open");
    setExpandedChapterIds((prev) => {
      const next = new Set(prev);
      if (next.has(chapterId)) next.delete(chapterId);
      else next.add(chapterId);
      return next;
    });
  };

  // Handler: Add Weak Topic Tag
  const handleAddWeakTopic = (chapterId: string, subject: string, chapterName: string) => {
    const text = (newWeakTopicText[chapterId] || "").trim();
    if (!text) return;

    soundManager.play("check");
    addWeakTopic(subject, chapterId, text);
    setWeakTopicsMap((prev) => ({
      ...prev,
      [chapterId]: [...(prev[chapterId] || []), text],
    }));

    setNewWeakTopicText((prev) => ({ ...prev, [chapterId]: "" }));
  };

  // Handler: Remove Weak Topic Tag
  const handleRemoveWeakTopic = (chapterId: string, topic: string, subject: string) => {
    soundManager.play("delete");
    removeWeakTopic(subject, chapterId, topic);
    setWeakTopicsMap((prev) => ({
      ...prev,
      [chapterId]: (prev[chapterId] || []).filter((t) => t !== topic),
    }));
  };

  // All Chapters for current exam track
  const allExamChapters = useMemo(() => getAllChaptersForExam(examType), [examType]);

  // OVERALL TRACKER AGGREGATE METRICS
  const trackerMetrics = useMemo(() => {
    const all = allExamChapters;

    const calcSubComp = (list: Chapter[]) => {
      if (!list.length) return 0;
      const done = list.reduce((acc, c) => acc + getCompletion(c.id, c.subject, c.name), 0);
      return Math.round(done / list.length);
    };

    const phy = getSyllabusForSubject("Physics", examType);
    const chem = getSyllabusForSubject("Chemistry", examType);
    const math = isJee ? getSyllabusForSubject("Mathematics", examType) : [];
    const botany = isNeet ? getSyllabusForSubject("Botany", examType) : [];
    const zoology = isNeet ? getSyllabusForSubject("Zoology", examType) : [];
    const biology = isNeet ? [...botany, ...zoology] : [];

    const overallComp = all.length
      ? Math.round(all.reduce((acc, c) => acc + getCompletion(c.id, c.subject, c.name), 0) / all.length)
      : 0;

    const phyComp = calcSubComp(phy);
    const chemComp = calcSubComp(chem);
    const mathComp = calcSubComp(math);
    const botanyComp = calcSubComp(botany);
    const zoologyComp = calcSubComp(zoology);
    const biologyComp = calcSubComp(biology);

    const completedCount = all.filter((c) => getCompletion(c.id, c.subject, c.name) >= 100).length;
    const remainingCount = all.length - completedCount;

    // Check mistake journal due entries
    const mistakeDueChapters = new Set(
      mistakes
        .filter((m) => new Date(m.nextRevisionAt) <= new Date())
        .map((m) => m.chapter.toLowerCase())
    );

    const revisionDueList = all.filter(
      (c) =>
        (c.revisionDueDays <= 0 && getCompletion(c.id, c.subject, c.name) < 100) ||
        mistakeDueChapters.has(c.name.toLowerCase())
    );

    const weakList = all.filter((c) => {
      const comp = getCompletion(c.id, c.subject, c.name);
      const weakT = getWeakTopics(c.id, c.subject, c.name);
      return (comp > 0 && comp < 70) || weakT.length > 0 || mistakeDueChapters.has(c.name.toLowerCase());
    });

    const strongList = all.filter((c) => getCompletion(c.id, c.subject, c.name) >= 90);

    return {
      overallComp,
      phyComp,
      chemComp,
      mathComp,
      botanyComp,
      zoologyComp,
      biologyComp,
      completedCount,
      remainingCount,
      revisionDueCount: revisionDueList.length,
      revisionDueList,
      weakList,
      strongList,
      currentStreak: storeStreak || 12,
    };
  }, [allExamChapters, examType, isJee, isNeet, completionMap, mistakes, storeStreak, weakTopicsMap]);

  // ALL FORMULAS & NOTES LISTS
  const allFormulas = useMemo(() => getAllFormulas(examType), [examType]);
  const allNotes = useMemo(() => getAllNotes(examType), [examType]);

  // ALL NCERT FACTS & DIAGRAMS (for NEET)
  const allNcertFacts = useMemo(() => {
    if (!isNeet) return [];
    const chapters = [
      ...(NEET_SYLLABUS_DATA.Physics || []),
      ...(NEET_SYLLABUS_DATA.Chemistry || []),
      ...(NEET_SYLLABUS_DATA.Botany || []),
      ...(NEET_SYLLABUS_DATA.Zoology || []),
    ];
    return chapters.flatMap((c) =>
      (c.ncertFacts || []).map((f) => ({
        ...f,
        chapterId: c.id,
        chapterName: c.name,
        subject: c.subject,
      }))
    );
  }, [isNeet]);

  const allNcertDiagrams = useMemo(() => {
    if (!isNeet) return [];
    const chapters = [
      ...(NEET_SYLLABUS_DATA.Botany || []),
      ...(NEET_SYLLABUS_DATA.Zoology || []),
      ...(NEET_SYLLABUS_DATA.Physics || []),
      ...(NEET_SYLLABUS_DATA.Chemistry || []),
    ];
    return chapters.flatMap((c) =>
      (c.diagrams || []).map((d) => ({
        ...d,
        chapterId: c.id,
        chapterName: c.name,
        subject: c.subject,
      }))
    );
  }, [isNeet]);

  // FILTERED NCERT FACTS
  const filteredNcertFacts = useMemo(() => {
    return allNcertFacts.filter((item) => {
      if (ncertSearch.trim()) {
        const q = ncertSearch.toLowerCase();
        if (!item.fact.toLowerCase().includes(q) && !item.chapterName.toLowerCase().includes(q)) return false;
      }
      if (ncertSubFilter !== "All" && item.subject !== ncertSubFilter) return false;
      if (ncertCategoryFilter !== "All" && item.category !== ncertCategoryFilter) return false;
      return true;
    });
  }, [allNcertFacts, ncertSearch, ncertSubFilter, ncertCategoryFilter]);

  // FILTERED FORMULAS
  const filteredFormulas = useMemo(() => {
    return allFormulas.filter((f) => {
      if (formulaSearch.trim()) {
        const q = formulaSearch.toLowerCase();
        if (!f.name.toLowerCase().includes(q) && !f.expression.toLowerCase().includes(q) && !f.chapterName.toLowerCase().includes(q)) return false;
      }
      if (formulaSubFilter !== "All" && f.subject !== formulaSubFilter) return false;
      if (formulaTagFilter === "Bookmarked" && !f.isBookmarked) return false;
      if (formulaTagFilter === "Pinned" && !pinnedFormulas.has(f.id)) return false;
      return true;
    });
  }, [allFormulas, formulaSearch, formulaSubFilter, formulaTagFilter, pinnedFormulas]);

  // FILTERED NOTES
  const filteredNotes = useMemo(() => {
    return allNotes.filter((n) => {
      if (notesSearch.trim()) {
        const q = notesSearch.toLowerCase();
        if (!n.title.toLowerCase().includes(q) && !n.content.toLowerCase().includes(q) && !n.chapterName.toLowerCase().includes(q)) return false;
      }
      if (notesSubFilter !== "All" && n.subject !== notesSubFilter) return false;
      if (notesTypeFilter !== "All" && n.type !== notesTypeFilter) return false;
      return true;
    });
  }, [allNotes, notesSearch, notesSubFilter, notesTypeFilter]);

  // Dynamic Navigation Tabs
  const tabItems = useMemo(() => {
    if (isNeet) {
      return [
        { id: "tracker", label: "NEET Tracker", icon: LayoutDashboard },
        { id: "Physics", label: "Physics", icon: Atom, color: "text-cyan-400" },
        { id: "Chemistry", label: "Chemistry", icon: FlaskConical, color: "text-emerald-400" },
        { id: "Botany", label: "Botany", icon: Sprout, color: "text-emerald-400" },
        { id: "Zoology", label: "Zoology", icon: Dna, color: "text-purple-400" },
        { id: "biology-overview", label: "Biology 360°", icon: Activity, color: "text-teal-400" },
        { id: "ncert-vault", label: "NCERT Vault", icon: FileText, color: "text-amber-400" },
        { id: "notes", label: "Notes Hub", icon: BookOpen },
      ];
    }
    return [
      { id: "tracker", label: "JEE Tracker", icon: LayoutDashboard },
      { id: "Physics", label: "Physics", icon: Atom, color: "text-cyan-400" },
      { id: "Chemistry", label: "Chemistry", icon: FlaskConical, color: "text-emerald-400" },
      { id: "Maths", label: "Mathematics", icon: Calculator, color: "text-amber-400" },
      { id: "formulas", label: "Formula Sheets", icon: FileText },
      { id: "notes", label: "Notes Hub", icon: BookOpen },
    ];
  }, [isNeet]);

  const activeSubjectChapters = useMemo(() => {
    if (["Physics", "Chemistry", "Maths", "Botany", "Zoology"].includes(activeTab)) {
      return getSyllabusForSubject(activeTab, examType);
    }
    return [];
  }, [activeTab, examType]);

  return (
    <WorkspaceLayout title={isNeet ? "NEET UG Preparation & NCERT Portal" : "JEE Preparation & Study Portal"}>
      <div className="space-y-6">

        {/* TOP TAB BAR NAVIGATION WITH SUBJECT ACCENT UNDERLINES */}
        <div className="flex border-b border-white/10 bg-slate-950/80 rounded-2xl p-1.5 shadow-lg overflow-x-auto">
          {tabItems.map((tab) => {
            const Icon = tab.icon;
            const isSel = activeTab === tab.id;
            const tabTheme = getSubjectTheme(tab.id);

            return (
              <button
                key={tab.id}
                onClick={() => {
                  soundManager.play("select");
                  setActiveTab(tab.id);
                }}
                style={
                  isSel && (["Physics", "Chemistry", "Maths", "Botany", "Zoology"].includes(tab.id))
                    ? { backgroundColor: tabTheme.bgTint, borderColor: tabTheme.border }
                    : undefined
                }
                className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 whitespace-nowrap ${isSel
                    ? ["Physics", "Chemistry", "Maths", "Botany", "Zoology"].includes(tab.id)
                      ? `${tabTheme.textClass} shadow-md border font-extrabold`
                      : "bg-white/10 text-white shadow-md border border-white/15"
                    : "text-gray-400 hover:text-white hover:bg-white/[0.04]"
                  }`}
              >
                <Icon className={`w-4 h-4 ${tab.color || "text-gray-300"}`} />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* 1. TRACKER OVERVIEW (DYNAMIC JEE OR NEET) */}
        {activeTab === "tracker" && (
          <div className="space-y-6">

            {/* Top Stat Cards */}
            {isNeet ? (
              /* NEET Stat Cards: 5 Cards Grid (Overall, Physics, Chemistry, Botany, Zoology) */
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3.5">
                <div
                  onClick={() => setActiveTab("Physics")}
                  className="p-4 bg-slate-900/80 rounded-2xl border border-white/10 space-y-1 cursor-pointer hover:border-white/30 transition-all"
                >
                  <span className="text-[10px] text-gray-400 font-semibold uppercase tracking-wider block">Overall NEET</span>
                  <span className="text-2xl font-black text-white font-mono">{trackerMetrics.overallComp}%</span>
                  <ProgressBar value={trackerMetrics.overallComp} showPercentage={false} className="pt-1" />
                </div>

                <div
                  onClick={() => setActiveTab("Physics")}
                  className="p-4 bg-[#15222b]/40 rounded-2xl border border-[#253e50] space-y-1 cursor-pointer hover:border-cyan-500/50 transition-all"
                >
                  <span className="text-[10px] text-cyan-400 font-semibold uppercase tracking-wider block">Physics (30 Ch)</span>
                  <span className="text-2xl font-black text-cyan-300 font-mono">{trackerMetrics.phyComp}%</span>
                  <ProgressBar value={trackerMetrics.phyComp} showPercentage={false} variant="physics" className="pt-1" />
                </div>

                <div
                  onClick={() => setActiveTab("Chemistry")}
                  className="p-4 bg-[#132625]/40 rounded-2xl border border-[#1d423e] space-y-1 cursor-pointer hover:border-emerald-500/50 transition-all"
                >
                  <span className="text-[10px] text-emerald-400 font-semibold uppercase tracking-wider block">Chemistry (20 Ch)</span>
                  <span className="text-2xl font-black text-emerald-300 font-mono">{trackerMetrics.chemComp}%</span>
                  <ProgressBar value={trackerMetrics.chemComp} showPercentage={false} variant="chemistry" className="pt-1" />
                </div>

                <div
                  onClick={() => setActiveTab("Botany")}
                  className="p-4 bg-[#0d281e]/40 rounded-2xl border border-[#154d39] space-y-1 cursor-pointer hover:border-emerald-400/50 transition-all"
                >
                  <span className="text-[10px] text-emerald-300 font-semibold uppercase tracking-wider block">Botany (17 Ch)</span>
                  <span className="text-2xl font-black text-emerald-300 font-mono">{trackerMetrics.botanyComp}%</span>
                  <div className="w-full h-1.5 bg-slate-900 rounded-full overflow-hidden mt-1">
                    <div className="h-full bg-emerald-500" style={{ width: `${trackerMetrics.botanyComp}%` }} />
                  </div>
                </div>

                <div
                  onClick={() => setActiveTab("Zoology")}
                  className="p-4 bg-[#231535]/40 rounded-2xl border border-[#48286a] space-y-1 cursor-pointer hover:border-purple-400/50 transition-all"
                >
                  <span className="text-[10px] text-purple-300 font-semibold uppercase tracking-wider block">Zoology (15 Ch)</span>
                  <span className="text-2xl font-black text-purple-300 font-mono">{trackerMetrics.zoologyComp}%</span>
                  <div className="w-full h-1.5 bg-slate-900 rounded-full overflow-hidden mt-1">
                    <div className="h-full bg-purple-500" style={{ width: `${trackerMetrics.zoologyComp}%` }} />
                  </div>
                </div>
              </div>
            ) : (
              /* JEE Stat Cards: 4 Cards Grid (Overall, Physics, Chemistry, Maths) */
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div
                  onClick={() => setActiveTab("Physics")}
                  className="p-4 bg-slate-900/80 rounded-2xl border border-white/10 space-y-1 cursor-pointer hover:border-white/30 transition-all"
                >
                  <span className="text-[10px] text-gray-400 font-semibold uppercase tracking-wider block">Overall Completion</span>
                  <span className="text-2xl font-black text-white font-mono">{trackerMetrics.overallComp}%</span>
                  <ProgressBar value={trackerMetrics.overallComp} showPercentage={false} className="pt-1" />
                </div>

                <div
                  onClick={() => setActiveTab("Physics")}
                  className="p-4 bg-[#15222b]/40 rounded-2xl border border-[#253e50] space-y-1 cursor-pointer hover:border-cyan-500/50 transition-all"
                >
                  <span className="text-[10px] text-cyan-400 font-semibold uppercase tracking-wider block">Physics Progress</span>
                  <span className="text-2xl font-black text-cyan-300 font-mono">{trackerMetrics.phyComp}%</span>
                  <ProgressBar value={trackerMetrics.phyComp} showPercentage={false} variant="physics" className="pt-1" />
                </div>

                <div
                  onClick={() => setActiveTab("Chemistry")}
                  className="p-4 bg-[#132625]/40 rounded-2xl border border-[#1d423e] space-y-1 cursor-pointer hover:border-emerald-500/50 transition-all"
                >
                  <span className="text-[10px] text-emerald-400 font-semibold uppercase tracking-wider block">Chemistry Progress</span>
                  <span className="text-2xl font-black text-emerald-300 font-mono">{trackerMetrics.chemComp}%</span>
                  <ProgressBar value={trackerMetrics.chemComp} showPercentage={false} variant="chemistry" className="pt-1" />
                </div>

                <div
                  onClick={() => setActiveTab("Maths")}
                  className="p-4 bg-[#231815]/40 rounded-2xl border border-[#4a2f26] space-y-1 cursor-pointer hover:border-amber-500/50 transition-all"
                >
                  <span className="text-[10px] text-amber-400 font-semibold uppercase tracking-wider block">Maths Progress</span>
                  <span className="text-2xl font-black text-amber-300 font-mono">{trackerMetrics.mathComp}%</span>
                  <ProgressBar value={trackerMetrics.mathComp} showPercentage={false} variant="maths" className="pt-1" />
                </div>
              </div>
            )}

            {/* NEET Combined Biology Banner */}
            {isNeet && (
              <div
                onClick={() => setActiveTab("biology-overview")}
                className="p-4 rounded-2xl bg-gradient-to-r from-emerald-950/60 via-slate-900/80 to-purple-950/60 border border-emerald-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 cursor-pointer hover:border-emerald-500/60 transition-all shadow-lg"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center shrink-0">
                    <Activity className="w-5 h-5 text-emerald-400" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white flex items-center gap-2">
                      Biology 360° Combined Mastery • 360/720 Marks (50% Weightage)
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-semibold">
                        90 Questions
                      </span>
                    </h3>
                    <p className="text-xs text-gray-400 font-sans">
                      Combined Botany ({trackerMetrics.botanyComp}%) & Zoology ({trackerMetrics.zoologyComp}%) mastery progress.
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-4 shrink-0">
                  <div className="text-right font-mono">
                    <span className="text-xs text-gray-400 block">Total Biology</span>
                    <span className="text-xl font-bold text-emerald-300">{trackerMetrics.biologyComp}%</span>
                  </div>
                  <Button variant="secondary" size="sm" className="pointer-events-none text-xs">
                    View 360° Hub →
                  </Button>
                </div>
              </div>
            )}

            {/* Quick Metrics Strip */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div
                onClick={() => {
                  setActiveTab("Physics");
                  setStatusFilter("Revision Due");
                }}
                className="p-3.5 bg-slate-900/60 rounded-xl border border-white/[0.08] hover:border-amber-500/40 flex items-center justify-between cursor-pointer transition-all"
              >
                <div>
                  <span className="text-[10px] text-gray-400 uppercase font-medium block">Revision Due</span>
                  <span className="text-lg font-bold text-amber-400 font-mono">{trackerMetrics.revisionDueCount} Chapters</span>
                </div>
                <Clock className="w-5 h-5 text-amber-400/80" />
              </div>

              <div
                onClick={() => {
                  setActiveTab("Physics");
                  setStatusFilter("In Progress");
                }}
                className="p-3.5 bg-slate-900/60 rounded-xl border border-white/[0.08] hover:border-cyan-500/40 flex items-center justify-between cursor-pointer transition-all"
              >
                <div>
                  <span className="text-[10px] text-gray-400 uppercase font-medium block">Weak Chapters</span>
                  <span className="text-lg font-bold text-cyan-400 font-mono">{trackerMetrics.weakList.length} Chapters</span>
                </div>
                <AlertCircle className="w-5 h-5 text-cyan-400/80" />
              </div>

              <div className="p-3.5 bg-slate-900/60 rounded-xl border border-white/[0.08] flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-gray-400 uppercase font-medium block">Current Streak</span>
                  <span className="text-lg font-bold text-rose-400 font-mono">🔥 {trackerMetrics.currentStreak} Days</span>
                </div>
                <Flame className="w-5 h-5 text-rose-400/80" />
              </div>

              <div
                onClick={() => {
                  setActiveTab("Physics");
                  setStatusFilter("Completed");
                }}
                className="p-3.5 bg-slate-900/60 rounded-xl border border-white/[0.08] hover:border-emerald-500/40 flex items-center justify-between cursor-pointer transition-all"
              >
                <div>
                  <span className="text-[10px] text-gray-400 uppercase font-medium block">Completed / Total</span>
                  <span className="text-lg font-bold text-white font-mono">{trackerMetrics.completedCount} / {allExamChapters.length}</span>
                </div>
                <CheckCircle2 className="w-5 h-5 text-emerald-400/80" />
              </div>
            </div>

            {/* Historical Weightage Disclaimer Bar */}
            <div className="flex items-center gap-2 text-xs text-gray-400 bg-slate-900/60 border border-white/[0.08] px-3.5 py-2 rounded-xl">
              <Sparkles className="w-4 h-4 text-purple-400 shrink-0" />
              <span>{config.weightageDisclaimer}</span>
            </div>

            {/* COMPLETED CHAPTERS SECTION */}
            <Card variant="glass" className="space-y-4">
              <div className="flex items-center justify-between border-b border-white/[0.08] pb-3">
                <h3 className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-2">
                  <CheckCircle2 className="w-4.5 h-4.5 text-emerald-400" /> COMPLETED CHAPTERS ({config.shortName})
                </h3>
                <span className="text-xs font-mono font-bold text-gray-300 bg-white/10 px-2.5 py-0.5 rounded-full">
                  {trackerMetrics.completedCount} / {allExamChapters.length} Completed
                </span>
              </div>

              {allExamChapters.filter((ch) => getCompletion(ch.id, ch.subject, ch.name) >= 100).length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  {allExamChapters
                    .filter((ch) => getCompletion(ch.id, ch.subject, ch.name) >= 100)
                    .map((ch) => {
                      const chTheme = getSubjectTheme(ch.subject);
                      return (
                        <div
                          key={ch.id}
                          onClick={() => {
                            setActiveTab(ch.subject);
                            setExpandedChapterIds(new Set([ch.id]));
                          }}
                          style={{ backgroundColor: chTheme.bgTint, borderColor: chTheme.border }}
                          className="p-3.5 rounded-xl border flex items-center justify-between text-xs transition-all cursor-pointer hover:bg-white/[0.02]"
                        >
                          <div className="space-y-1 min-w-0 pr-2">
                            <span className="font-bold text-white block truncate">{ch.name}</span>
                            <div className="flex items-center gap-1.5 text-[10px] text-gray-400">
                              <span className={`px-1.5 py-0.2 rounded font-semibold ${chTheme.subchapterClass}`}>
                                {ch.subject}
                              </span>
                              <span>• {ch.classLevel}</span>
                            </div>
                          </div>
                          <span className={`font-mono font-bold shrink-0 px-2 py-0.5 rounded border ${chTheme.badgeClass}`}>
                            [ {ch.weightage}% ]
                          </span>
                        </div>
                      );
                    })}
                </div>
              ) : (
                <div className="py-8 text-center space-y-1">
                  <p className="text-xs font-semibold text-gray-300">No completed chapters yet.</p>
                  <p className="text-[11px] text-gray-500">
                    Open the subject tabs above and mark chapters as completed to track them here!
                  </p>
                </div>
              )}
            </Card>
          </div>
        )}

        {/* 2. BIOLOGY 360° OVERVIEW (NEET ONLY) */}
        {isNeet && activeTab === "biology-overview" && (
          <div className="space-y-6">
            <div className="p-5 rounded-2xl bg-gradient-to-r from-emerald-950/70 via-slate-900 to-purple-950/70 border border-emerald-500/30 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <Badge variant="green">NEET UG 2026 Core Domain</Badge>
                  <span className="text-[10px] font-mono text-emerald-300 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/30">
                    90 Questions • 360 Marks
                  </span>
                </div>
                <h2 className="text-xl font-black text-white">Biology 360° Comprehensive Command Center</h2>
                <p className="text-xs text-gray-400">
                  Botany (17 Chapters) + Zoology (15 Chapters) • 100% NCERT Word-to-Word Alignment
                </p>
              </div>

              <div className="text-right font-mono shrink-0">
                <span className="text-xs text-gray-400 block">Overall Biology Mastery</span>
                <span className="text-3xl font-extrabold text-emerald-300">{trackerMetrics.biologyComp}%</span>
              </div>
            </div>

            {/* Botany vs Zoology Side-by-Side Breakdown */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Botany Card */}
              <Card variant="glass" className="space-y-4">
                <div className="flex items-center justify-between border-b border-white/[0.08] pb-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center">
                      <Sprout className="w-4.5 h-4.5 text-emerald-400" />
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-white">Botany (Plant Sciences)</h3>
                      <span className="text-[10px] text-gray-400 font-mono">17 Chapters • ~45 Questions</span>
                    </div>
                  </div>
                  <span className="text-lg font-mono font-bold text-emerald-300">{trackerMetrics.botanyComp}%</span>
                </div>

                <div className="space-y-2">
                  <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">
                    Highest-Yield Botany Units:
                  </span>
                  <div className="space-y-2 text-xs">
                    {(NEET_SYLLABUS_DATA.Botany || [])
                      .filter((c) => c.weightageTier === "Very High" || c.weightageTier === "High")
                      .slice(0, 5)
                      .map((c) => (
                        <div
                          key={c.id}
                          onClick={() => {
                            setActiveTab("Botany");
                            setExpandedChapterIds(new Set([c.id]));
                          }}
                          className="p-2.5 rounded-xl bg-slate-900/70 border border-white/[0.06] hover:border-emerald-500/40 flex items-center justify-between cursor-pointer transition-all"
                        >
                          <span className="font-semibold text-white truncate pr-2">{c.name}</span>
                          <span className="text-[10px] font-mono text-emerald-400 font-bold shrink-0">
                            ~{c.estimatedQuestions} Qs ({c.trendWeightage}%)
                          </span>
                        </div>
                      ))}
                  </div>
                </div>

                <Button
                  onClick={() => setActiveTab("Botany")}
                  variant="secondary"
                  size="sm"
                  className="w-full text-xs font-bold"
                >
                  Explore All 17 Botany Chapters →
                </Button>
              </Card>

              {/* Zoology Card */}
              <Card variant="glass" className="space-y-4">
                <div className="flex items-center justify-between border-b border-white/[0.08] pb-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-purple-500/10 border border-purple-500/30 flex items-center justify-center">
                      <Dna className="w-4.5 h-4.5 text-purple-400" />
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-white">Zoology (Animal & Human Biology)</h3>
                      <span className="text-[10px] text-gray-400 font-mono">15 Chapters • ~45 Questions</span>
                    </div>
                  </div>
                  <span className="text-lg font-mono font-bold text-purple-300">{trackerMetrics.zoologyComp}%</span>
                </div>

                <div className="space-y-2">
                  <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">
                    Highest-Yield Zoology Units:
                  </span>
                  <div className="space-y-2 text-xs">
                    {(NEET_SYLLABUS_DATA.Zoology || [])
                      .filter((c) => c.weightageTier === "Very High" || c.weightageTier === "High")
                      .slice(0, 5)
                      .map((c) => (
                        <div
                          key={c.id}
                          onClick={() => {
                            setActiveTab("Zoology");
                            setExpandedChapterIds(new Set([c.id]));
                          }}
                          className="p-2.5 rounded-xl bg-slate-900/70 border border-white/[0.06] hover:border-purple-500/40 flex items-center justify-between cursor-pointer transition-all"
                        >
                          <span className="font-semibold text-white truncate pr-2">{c.name}</span>
                          <span className="text-[10px] font-mono text-purple-400 font-bold shrink-0">
                            ~{c.estimatedQuestions} Qs ({c.trendWeightage}%)
                          </span>
                        </div>
                      ))}
                  </div>
                </div>

                <Button
                  onClick={() => setActiveTab("Zoology")}
                  variant="secondary"
                  size="sm"
                  className="w-full text-xs font-bold"
                >
                  Explore All 15 Zoology Chapters →
                </Button>
              </Card>
            </div>

            {/* Essential NCERT Biology Diagrams Checklist */}
            <Card variant="glass" className="space-y-4">
              <div className="flex items-center justify-between border-b border-white/[0.08] pb-3">
                <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                  <Award className="w-4 h-4 text-emerald-400" /> High-Yield NCERT Diagrams & Labeling Guide
                </h3>
                <span className="text-xs text-gray-400 font-mono">Mandatory for Assertion-Reasoning</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {allNcertDiagrams.slice(0, 9).map((diag, idx) => (
                  <div key={idx} className="p-3 bg-slate-900/70 rounded-xl border border-white/[0.08] space-y-1 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-white truncate">{diag.name}</span>
                      <span className="text-[10px] text-amber-400 font-semibold font-mono">{diag.highYieldLabel}</span>
                    </div>
                    <span className="text-[10px] text-emerald-400 font-medium block">{diag.chapterName}</span>
                    <p className="text-[11px] text-gray-400 line-clamp-2 leading-relaxed">{diag.description}</p>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        )}

        {/* 3. DYNAMIC SUBJECT PAGES (PHYSICS, CHEMISTRY, MATHS, BOTANY, ZOOLOGY) */}
        {["Physics", "Chemistry", "Maths", "Botany", "Zoology"].includes(activeTab) && (
          <div className="space-y-6">
            {/* Subject Overview Hero Card */}
            <div
              style={{ backgroundColor: activeTheme.bgTint, borderColor: activeTheme.border }}
              className="p-5 border rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 transition-all"
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <Badge variant={activeTab === "Physics" ? "physics" : activeTab === "Chemistry" ? "chemistry" : "maths"}>
                    {activeTab} • {config.defaultSyllabusVersion} Official Curriculum
                  </Badge>
                </div>
                <h2 className="text-xl font-black text-white">{activeTab} Syllabus & Chapter Tracker</h2>
                <p className="text-xs text-gray-400">Total Chapters: {activeSubjectChapters.length}</p>
              </div>

              <div className="flex items-center gap-3">
                <div className="text-right font-mono">
                  <span className="text-[10px] text-gray-400 uppercase font-semibold block">Subject Progress</span>
                  <span className={`text-xl font-bold ${activeTheme.textClass}`}>
                    {activeTab === "Physics"
                      ? trackerMetrics.phyComp
                      : activeTab === "Chemistry"
                      ? trackerMetrics.chemComp
                      : activeTab === "Maths"
                      ? trackerMetrics.mathComp
                      : activeTab === "Botany"
                      ? trackerMetrics.botanyComp
                      : trackerMetrics.zoologyComp}%
                  </span>
                </div>
              </div>
            </div>

            {/* SEARCH & FILTERS BAR WITH VIEW MODE TOGGLE */}
            <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 bg-slate-900/60 border border-white/10 p-3 rounded-xl">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder={`Search ${activeTab} chapters, topics, subtopics...`}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className={`w-full bg-slate-950 border border-white/10 rounded-lg pl-9 pr-3 py-1.5 text-xs text-white placeholder-gray-500 focus:outline-none ${activeTheme.focusClass}`}
                />
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <select
                  value={classFilter}
                  onChange={(e) => setClassFilter(e.target.value as "All" | "Class 11" | "Class 12")}
                  className="bg-slate-950 border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-gray-300 focus:outline-none"
                >
                  <option value="All">All Classes</option>
                  <option value="Class 11">Class 11</option>
                  <option value="Class 12">Class 12</option>
                </select>

                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value as "All" | "Completed" | "In Progress" | "Revision Due")}
                  className="bg-slate-950 border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-gray-300 focus:outline-none"
                >
                  <option value="All">All Statuses</option>
                  <option value="Completed">Completed</option>
                  <option value="In Progress">In Progress</option>
                  <option value="Revision Due">Revision Due</option>
                </select>

                {/* View Mode Toggle: List / Box / Kanban */}
                <div className="flex items-center bg-slate-950 border border-white/10 rounded-lg p-0.5 text-xs">
                  <button
                    onClick={() => setSubjectViewMode("list")}
                    className={`flex items-center gap-1 px-2.5 py-1 rounded-md transition-all cursor-pointer ${
                      subjectViewMode === "list" ? "bg-white/10 text-white font-bold" : "text-gray-400 hover:text-white"
                    }`}
                    title="Compact List View"
                  >
                    <List className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">List</span>
                  </button>
                  <button
                    onClick={() => setSubjectViewMode("box")}
                    className={`flex items-center gap-1 px-2.5 py-1 rounded-md transition-all cursor-pointer ${
                      subjectViewMode === "box" ? "bg-white/10 text-white font-bold" : "text-gray-400 hover:text-white"
                    }`}
                    title="List by Box Cards Grid"
                  >
                    <LayoutGrid className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Box</span>
                  </button>
                  <button
                    onClick={() => setSubjectViewMode("kanban")}
                    className={`flex items-center gap-1 px-2.5 py-1 rounded-md transition-all cursor-pointer ${
                      subjectViewMode === "kanban" ? "bg-white/10 text-white font-bold" : "text-gray-400 hover:text-white"
                    }`}
                    title="Kanban Board View"
                  >
                    <Kanban className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Kanban</span>
                  </button>
                </div>

                {/* Expand All / Collapse All Breakdowns Toggle */}
                <button
                  type="button"
                  onClick={() => {
                    const currentIds = activeSubjectChapters.map((c) => c.id);
                    const allExpanded = currentIds.length > 0 && currentIds.every((id) => expandedChapterIds.has(id));
                    if (allExpanded) {
                      setExpandedChapterIds(new Set());
                    } else {
                      setExpandedChapterIds(new Set([...Array.from(expandedChapterIds), ...currentIds]));
                    }
                  }}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border ${activeTheme.accentBorder} ${activeTheme.accentBg} ${activeTheme.textClass} text-xs font-bold transition-all cursor-pointer shadow-sm`}
                >
                  <ChevronDown
                    className={`w-3.5 h-3.5 transition-transform ${
                      activeSubjectChapters.length > 0 && activeSubjectChapters.every((c) => expandedChapterIds.has(c.id)) ? "rotate-180" : ""
                    }`}
                  />
                  <span>
                    {activeSubjectChapters.length > 0 && activeSubjectChapters.every((c) => expandedChapterIds.has(c.id))
                      ? "Collapse All"
                      : "Expand All"}
                  </span>
                </button>
              </div>
            </div>

            {/* CHAPTERS DISPLAY - LIST / BOX GRID / KANBAN */}
            <div className="space-y-3">
              {activeSubjectChapters
                .filter((ch) => {
                  if (searchQuery.trim()) {
                    const q = searchQuery.toLowerCase();
                    const matchName = ch.name.toLowerCase().includes(q);
                    const matchTopics = ch.topics.some((t) => t.toLowerCase().includes(q));
                    const matchSub = ch.subchapters.some((s) => s.name.toLowerCase().includes(q));
                    if (!matchName && !matchTopics && !matchSub) return false;
                  }
                  if (classFilter !== "All" && ch.classLevel !== classFilter) return false;
                  const comp = getCompletion(ch.id, ch.subject, ch.name);
                  if (statusFilter === "Completed" && comp < 100) return false;
                  if (statusFilter === "In Progress" && (comp <= 0 || comp >= 100)) return false;
                  if (statusFilter === "Revision Due" && ch.revisionDueDays > 0) return false;
                  return true;
                })
                .map((chapter) => {
                  const comp = getCompletion(chapter.id, chapter.subject, chapter.name);
                  const isComp = comp >= 100;
                  const isExp = expandedChapterIds.has(chapter.id);
                  const isBook = bookmarkedChapters.has(chapter.id);
                  const chTheme = getSubjectTheme(chapter.subject);

                  return (
                    <div
                      key={chapter.id}
                      className={`border rounded-2xl transition-all overflow-hidden bg-slate-900/60 ${
                        isComp ? "border-emerald-500/30" : "border-white/[0.08]"
                      }`}
                    >
                      <div className="p-4 flex items-center justify-between gap-3">
                        <div className="flex items-center gap-3 min-w-0 flex-1">
                          <button
                            type="button"
                            onClick={() => handleToggleCompletion(chapter.id, chapter.subject, chapter.name)}
                            className={`w-6 h-6 rounded-lg border flex items-center justify-center shrink-0 transition-colors cursor-pointer ${
                              isComp
                                ? "bg-emerald-500 border-emerald-400 text-white"
                                : "border-white/20 bg-slate-950 hover:border-emerald-400"
                            }`}
                          >
                            {isComp && <CheckCircle2 className="w-4 h-4" />}
                          </button>

                          <div className="min-w-0 flex-1 space-y-1">
                            <div className="flex items-center gap-2 flex-wrap">
                              <h3 className={`text-sm font-bold truncate ${isComp ? "text-gray-400 line-through" : "text-white"}`}>
                                {chapter.name}
                              </h3>
                              <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold border ${chTheme.badgeClass}`}>
                                {chapter.weightage}% {isNeet ? "PYQ Trend" : "Weightage"}
                              </span>
                              {chapter.importanceBadge && (
                                <span className={`text-[9px] font-mono px-1.5 py-0.2 rounded font-bold border ${
                                  chapter.importanceBadge === "Critical" ? "bg-rose-500/10 border-rose-500/30 text-rose-300" : "bg-cyan-500/10 border-cyan-500/30 text-cyan-300"
                                }`}>
                                  {chapter.importanceBadge}
                                </span>
                              )}
                            </div>
                            <div className="flex items-center gap-2 text-[10px] text-gray-400">
                              <span>{chapter.classLevel}</span>
                              <span>•</span>
                              <span>{chapter.subchapters.length} Subtopics</span>
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          <button
                            onClick={() => handleToggleBookmark(chapter.id)}
                            className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                              isBook ? `${chTheme.textClass} ${chTheme.accentBg}` : "text-gray-500 hover:text-gray-300"
                            }`}
                          >
                            <Bookmark className="w-4 h-4 fill-current" />
                          </button>

                          <button
                            onClick={() => toggleExpandChapter(chapter.id)}
                            className="p-1.5 text-gray-400 hover:text-white transition-colors cursor-pointer"
                          >
                            {isExp ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                          </button>
                        </div>
                      </div>

                      {/* Expandable Chapter Content */}
                      {isExp && (
                        <div className="p-4 bg-slate-950 border-t border-white/10 space-y-4 text-xs font-sans">
                          {/* Official Topics List */}
                          <div>
                            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-2 font-mono">
                              Official Topics & Subchapters
                            </span>
                            <div className="flex flex-wrap gap-1.5">
                              {chapter.topics.map((t, idx) => (
                                <span key={idx} className={`px-2 py-1 rounded text-xs border ${chTheme.subchapterClass}`}>
                                  • {t}
                                </span>
                              ))}
                            </div>
                          </div>

                          {/* NEET NCERT Quick Facts & Key Takeaways (if available) */}
                          {chapter.ncertFacts && chapter.ncertFacts.length > 0 && (
                            <div className="p-3 bg-amber-500/5 border border-amber-500/20 rounded-xl space-y-2">
                              <span className="text-[10px] font-mono uppercase tracking-wider text-amber-400 font-bold flex items-center gap-1.5">
                                <Sparkles className="w-3.5 h-3.5 text-amber-400" /> High-Yield NCERT Facts
                              </span>
                              <div className="space-y-1.5">
                                {chapter.ncertFacts.map((fact, fIdx) => (
                                  <div key={fIdx} className="text-xs text-gray-200 flex items-start gap-2">
                                    <span className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-1.5 shrink-0" />
                                    <span>{fact.fact}</span>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}

                          {/* Common Mistakes & Pitfalls (if available) */}
                          {chapter.commonMistakes && chapter.commonMistakes.length > 0 && (
                            <div className="p-3 bg-rose-500/5 border border-rose-500/20 rounded-xl space-y-1.5">
                              <span className="text-[10px] font-mono uppercase tracking-wider text-rose-400 font-bold flex items-center gap-1.5">
                                <AlertCircle className="w-3.5 h-3.5 text-rose-400" /> Common Exam Pitfalls
                              </span>
                              <div className="space-y-1 text-xs text-gray-300">
                                {chapter.commonMistakes.map((m, mIdx) => (
                                  <p key={mIdx}>⚠️ {m}</p>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
            </div>
          </div>
        )}

        {/* 4. NCERT FACT & DIAGRAM VAULT (NEET ONLY) */}
        {isNeet && activeTab === "ncert-vault" && (
          <div className="space-y-6">
            <div className="p-5 rounded-2xl bg-slate-900/80 border border-amber-500/30 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <Badge variant="amber">NCERT Master Repository</Badge>
                  <span className="text-[10px] font-mono text-amber-300 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/30">
                    High-Yield Verified
                  </span>
                </div>
                <h2 className="text-xl font-black text-white">NEET NCERT Fact & Exception Vault</h2>
                <p className="text-xs text-gray-400">
                  Every definition, direct NCERT line, statement question, and labeled diagram cataloged.
                </p>
              </div>

              <div className="flex gap-2">
                <span className="text-xs font-mono font-bold text-amber-300 bg-amber-500/10 border border-amber-500/30 px-3 py-1.5 rounded-xl">
                  {filteredNcertFacts.length} High-Yield Facts Available
                </span>
              </div>
            </div>

            {/* Search & Filters */}
            <div className="flex flex-col sm:flex-row gap-3 bg-slate-900/60 border border-white/10 p-3 rounded-xl">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Search NCERT lines, definitions, exceptions..."
                  value={ncertSearch}
                  onChange={(e) => setNcertSearch(e.target.value)}
                  className="w-full bg-slate-950 border border-white/10 rounded-lg pl-9 pr-3 py-1.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-amber-500"
                />
              </div>

              <select
                value={ncertSubFilter}
                onChange={(e) => setNcertSubFilter(e.target.value)}
                className="bg-slate-950 border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-gray-300 focus:outline-none"
              >
                <option value="All">All Subjects</option>
                <option value="Botany">Botany</option>
                <option value="Zoology">Zoology</option>
                <option value="Physics">Physics</option>
                <option value="Chemistry">Chemistry</option>
              </select>

              <select
                value={ncertCategoryFilter}
                onChange={(e) => setNcertCategoryFilter(e.target.value)}
                className="bg-slate-950 border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-gray-300 focus:outline-none"
              >
                <option value="All">All Categories</option>
                <option value="high-yield">High-Yield Only</option>
                <option value="exception">Exceptions</option>
                <option value="definition">Definitions</option>
                <option value="example">Key Examples</option>
              </select>
            </div>

            {/* Grid of NCERT Facts */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {filteredNcertFacts.map((item, idx) => {
                const subTheme = getSubjectTheme(item.subject);
                return (
                  <div
                    key={idx}
                    className="p-4 bg-slate-900/70 rounded-2xl border border-white/[0.08] hover:border-amber-500/40 transition-all space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border ${subTheme.badgeClass}`}>
                        {item.subject} • {item.chapterName}
                      </span>
                      <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-amber-500/10 text-amber-300 border border-amber-500/30 uppercase font-semibold">
                        {item.category}
                      </span>
                    </div>
                    <p className="text-xs text-gray-200 leading-relaxed font-sans font-medium">
                      "{item.fact}"
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* 5. FORMULA VAULT (JEE ONLY) */}
        {isJee && activeTab === "formulas" && (
          <div className="space-y-6">
            <div className="p-5 rounded-2xl bg-slate-900/80 border border-white/10 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div className="space-y-1">
                <Badge variant="physics">Master Formula Compendium</Badge>
                <h2 className="text-xl font-black text-white">JEE Main & Advanced Formula Sheets</h2>
                <p className="text-xs text-gray-400">
                  Physics, Chemistry, and Mathematics equations indexed for instant recall.
                </p>
              </div>

              <span className="text-xs font-mono font-bold text-cyan-300 bg-cyan-500/10 border border-cyan-500/30 px-3 py-1.5 rounded-xl">
                {filteredFormulas.length} Formulas Available
              </span>
            </div>

            {/* Formula Filters */}
            <div className="flex flex-col sm:flex-row gap-3 bg-slate-900/60 border border-white/10 p-3 rounded-xl">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Search formula name, expression, chapter..."
                  value={formulaSearch}
                  onChange={(e) => setFormulaSearch(e.target.value)}
                  className="w-full bg-slate-950 border border-white/10 rounded-lg pl-9 pr-3 py-1.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <select
                value={formulaSubFilter}
                onChange={(e) => setFormulaSubFilter(e.target.value)}
                className="bg-slate-950 border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-gray-300 focus:outline-none"
              >
                <option value="All">All Subjects</option>
                <option value="Physics">Physics</option>
                <option value="Chemistry">Chemistry</option>
                <option value="Maths">Mathematics</option>
              </select>
            </div>

            {/* Formulas Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredFormulas.map((form) => {
                const subTheme = getSubjectTheme(form.subject);
                return (
                  <div
                    key={form.id}
                    className="p-4 bg-slate-900/70 rounded-2xl border border-white/[0.08] hover:border-cyan-500/40 transition-all space-y-2.5"
                  >
                    <div className="flex items-center justify-between">
                      <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border ${subTheme.badgeClass}`}>
                        {form.subject} • {form.chapterName}
                      </span>
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white mb-1">{form.name}</h4>
                      <div className="p-3 bg-slate-950 rounded-xl border border-white/[0.06] text-center font-mono text-cyan-300 text-sm font-bold">
                        {form.expression}
                      </div>
                    </div>
                    {form.description && (
                      <p className="text-[11px] text-gray-400 font-sans">{form.description}</p>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* 6. STUDY NOTES HUB (BOTH TRACKS) */}
        {activeTab === "notes" && (
          <div className="space-y-6">
            <div className="p-5 rounded-2xl bg-slate-900/80 border border-white/10 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div className="space-y-1">
                <Badge variant="purple">{config.shortName} Concept Notes</Badge>
                <h2 className="text-xl font-black text-white">{config.displayName} Study Notes</h2>
                <p className="text-xs text-gray-400">
                  Rapid revision points, key mechanisms, and chapter summaries.
                </p>
              </div>

              <span className="text-xs font-mono font-bold text-purple-300 bg-purple-500/10 border border-purple-500/30 px-3 py-1.5 rounded-xl">
                {filteredNotes.length} Notes Available
              </span>
            </div>

            {/* Notes Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredNotes.map((note) => {
                const subTheme = getSubjectTheme(note.subject);
                return (
                  <div
                    key={note.id}
                    className="p-4 bg-slate-900/70 rounded-2xl border border-white/[0.08] hover:border-purple-500/40 transition-all space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border ${subTheme.badgeClass}`}>
                        {note.subject} • {note.chapterName}
                      </span>
                    </div>
                    <h4 className="text-xs font-bold text-white">{note.title}</h4>
                    <p className="text-xs text-gray-300 leading-relaxed font-sans">{note.content}</p>
                  </div>
                );
              })}
            </div>
          </div>
        )}

      </div>
    </WorkspaceLayout>
  );
}
