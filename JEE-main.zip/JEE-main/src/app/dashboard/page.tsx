"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { WorkspaceLayout } from "@/components/workspace-layout";
import { Card, CardHeader, CardBody } from "@/components/ui/card";
import { Button, ProgressBar, Badge, Carousel } from "@/components/ui/controls";
import { useStudyStore } from "@/store/use-study-store";
import { useMistakeStore } from "@/store/use-mistake-store";
import { analyticsService, TrendTimeframe, getLocalDateKey } from "@/services/analyticsService";
import { soundManager } from "@/lib/sound-manager";
import { Magnetic } from "@/components/ui/magnetic";
import { motion } from "framer-motion";
import {
  Timer,
  TrendingUp,
  Award,
  Flame,
  CheckCircle2,
  Sparkles,
  AlertCircle,
  BarChart3,
  Calendar,
  Target,
  ArrowUpRight,
} from "lucide-react";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import { ConsistencyGrid } from "@/components/consistency-grid";
import { useIsClient } from "@/hooks/use-is-client";
import { useUserProfile, useXpProgress, useStudyStreak } from "@/hooks/use-user-profile";
import { useExam } from "@/hooks/use-exam";

export default function Dashboard() {
  const { examType, config, isNeet, isJee } = useExam();
  const { status, activeSession, sessionHistory = [] } = useStudyStore();
  const { mistakes, syllabus } = useMistakeStore();
  const { userProfile, loading } = useUserProfile();
  const { totalXp, level, xpIntoCurrentLevel, xpRequiredForNextLevel, progressPercent } = useXpProgress();
  const { streak } = useStudyStreak();
  const isMounted = useIsClient();
  const [timeframe, setTimeframe] = useState<TrendTimeframe>("7d");

  // Compute analytics dynamically from real-time session history
  const analyticsMetrics = useMemo(() => {
    return analyticsService.calculateAnalyticsMetrics(sessionHistory, mistakes, syllabus, timeframe, examType);
  }, [sessionHistory, mistakes, syllabus, timeframe, examType]);

  const {
    trendData,
    subjectBreakdown,
    totalStudyHours,
    avgFocusScore,
    consistencyScore,
  } = analyticsMetrics;

  // Dynamic today study hours
  const todayKey = getLocalDateKey(new Date());
  const todaySessions = sessionHistory.filter(
    (s) => s && s.completed !== false && (s.date === todayKey || (s.startTime && getLocalDateKey(s.startTime) === todayKey))
  );
  const loggedTodayMins = todaySessions.reduce((acc, curr) => acc + (curr.totalDurationMinutes || 0), 0);
  const todayStudyHours = parseFloat((loggedTodayMins / 60).toFixed(1));
  const parsedGoal = parseFloat(userProfile?.studyGoal || "6") || 6.0;
  const targetStudyHours = parsedGoal > 0 ? parsedGoal : 6.0;

  const focusScore = avgFocusScore;
  const hasSessions = sessionHistory.filter((s) => s && s.completed !== false && s.totalDurationMinutes > 0).length > 0;

  // Dynamic Monk Warrior Challenge progress (2 deep work sessions today)
  const todayDeepWorkCount = todaySessions.filter(
    (s) => (s.mode === "DeepWork" || s.totalDurationMinutes >= 85) && s.completed !== false
  ).length;
  const challengeProgress = Math.min(2, todayDeepWorkCount);
  const challengePct = Math.round((challengeProgress / 2) * 100);

  return (
    <WorkspaceLayout title="Productivity Dashboard">
      {/* Top Welcome Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6 pb-4 border-b border-white/[0.08]">
        <div>
          {loading ? (
            <div className="space-y-2">
              <div className="h-8 w-64 bg-white/[0.06] rounded-xl animate-pulse" />
              <div className="h-4 w-48 bg-white/[0.04] rounded-lg animate-pulse" />
            </div>
          ) : (
            <>
              <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight flex items-center gap-2">
                Welcome back, {userProfile?.displayName || "Aspirant"}!
                <span className={`text-xs font-mono font-medium px-2.5 py-0.5 rounded-full border ${isNeet ? "bg-teal-500/15 text-teal-300 border-teal-500/25" : "bg-purple-500/15 text-purple-300 border-purple-500/25"}`}>
                  {userProfile?.targetExam || config.displayName}
                </span>
              </h1>
              <p className="text-xs sm:text-sm text-gray-400 mt-0.5">
                Target Year: <span className="text-cyan-400 font-semibold">{userProfile?.targetYear || "Upcoming"}</span> • Daily Goal: <span className="text-emerald-400 font-semibold">{userProfile?.studyGoal || "6 Hours Daily"}</span>
              </p>
            </>
          )}
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <Link href="/study">
            <Button variant="primary" size="sm" className="font-bold shadow-lg shadow-purple-950/40 gap-1.5 cursor-pointer">
              <span>Start Focus Session</span>
              <ArrowUpRight className="w-4 h-4" />
            </Button>
          </Link>
        </div>
      </div>

      {/* Top Active Session Banner */}
      {activeSession && status === "focus" && (
        <div className="mb-6 p-4 rounded-2xl bg-gradient-to-r from-purple-900/40 via-purple-600/20 to-blue-900/40 border border-purple-500/30 flex flex-wrap items-center justify-between gap-4 backdrop-blur-md">
          <div className="flex items-center gap-3">
            <div className="w-3 h-3 rounded-full bg-emerald-400 animate-pulse" />
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                Active Session: {activeSession.subject}
                <Badge variant="purple">{activeSession.chapter}</Badge>
              </h3>
              <p className="text-xs text-gray-300">
                Mode: {activeSession.mode} • Type: {activeSession.taskType}
              </p>
            </div>
          </div>

          <Link href="/study">
            <Button variant="primary" size="sm" className="bg-purple-600 hover:bg-purple-500 text-white font-bold gap-2">
              Return to Session <ArrowUpRight className="w-4 h-4" />
            </Button>
          </Link>
        </div>
      )}

      {/* Core KPI cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card variant="glass">
          <div className="flex items-center justify-between">
            {loading ? (
              <div className="space-y-2 w-full pr-4">
                <div className="h-3 w-20 bg-white/[0.06] rounded animate-pulse" />
                <div className="h-7 w-24 bg-white/[0.06] rounded-lg animate-pulse" />
                <div className="w-28 h-1.5 bg-white/10 rounded-full animate-pulse" />
              </div>
            ) : (
              <div className="space-y-1">
                <span className="text-xs text-gray-400 font-semibold uppercase tracking-wider block">Today&apos;s Study</span>
                <div className="flex items-baseline gap-1.5">
                  <span className="text-2xl font-black text-white">{todayStudyHours}h</span>
                  <span className="text-xs text-gray-400">/ {targetStudyHours}h target</span>
                </div>
                <div className="w-28 h-1.5 bg-white/10 rounded-full overflow-hidden mt-2">
                  <div
                    className="h-full bg-gradient-to-r from-blue-500 to-cyan-400 rounded-full transition-all duration-300"
                    style={{ width: `${Math.min(100, (todayStudyHours / targetStudyHours) * 100)}%` }}
                  />
                </div>
              </div>
            )}
            <div className="w-12 h-12 rounded-2xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400 shrink-0 shadow-inner">
              <Timer className="w-6 h-6" />
            </div>
          </div>
        </Card>

        <Card variant="glass">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <span className="text-xs text-gray-400 font-semibold uppercase tracking-wider block">Avg Focus Score</span>
              <div className="flex items-baseline gap-1.5">
                <span className="text-2xl font-black text-white">{focusScore}%</span>
                <span className="text-xs text-emerald-400 font-semibold flex items-center gap-0.5">
                  <TrendingUp className="w-3.5 h-3.5" /> Real-time
                </span>
              </div>
              <p className="text-[11px] text-gray-400 mt-1">Calculated from completed sessions</p>
            </div>
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 shrink-0 shadow-inner">
              <Sparkles className="w-6 h-6" />
            </div>
          </div>
        </Card>

        <Card variant="glass">
          <div className="flex items-center justify-between">
            {loading ? (
              <div className="space-y-2 w-full pr-4">
                <div className="h-3 w-16 bg-white/[0.06] rounded animate-pulse" />
                <div className="h-7 w-20 bg-white/[0.06] rounded-lg animate-pulse" />
                <div className="h-3 w-28 bg-white/[0.04] rounded animate-pulse" />
              </div>
            ) : (
              <div className="space-y-1">
                <span className="text-xs text-gray-400 font-semibold uppercase tracking-wider block">Daily Streak</span>
                <div className="flex items-baseline gap-1.5">
                  <span className="text-2xl font-black text-white">{streak} Days</span>
                  <span className="text-xs text-amber-400 font-medium">Consistency: {consistencyScore}%</span>
                </div>
                <p className="text-[11px] text-gray-400 mt-1">Consistent daily momentum</p>
              </div>
            )}
            <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 shrink-0 shadow-inner">
              <Flame className="w-6 h-6 fill-amber-500/20" />
            </div>
          </div>
        </Card>

        <Card variant="glass">
          <div className="flex items-center justify-between">
            {loading ? (
              <div className="space-y-2 w-full pr-4">
                <div className="h-3 w-14 bg-white/[0.06] rounded animate-pulse" />
                <div className="h-7 w-24 bg-white/[0.06] rounded-lg animate-pulse" />
                <div className="w-28 h-1.5 bg-white/10 rounded-full animate-pulse" />
              </div>
            ) : (
              <div className="space-y-1">
                <span className="text-xs text-gray-400 font-semibold uppercase tracking-wider block">XP Level</span>
                <div className="flex items-baseline gap-1.5">
                  <span className="text-2xl font-black text-white">Lvl {level}</span>
                  <span className="text-xs text-gray-400 font-mono">{totalXp} XP</span>
                </div>
                <div className="w-28 h-1.5 bg-white/10 rounded-full overflow-hidden mt-2">
                  <div
                    className="h-full bg-gradient-to-r from-purple-500 to-indigo-500 rounded-full transition-all duration-300"
                    style={{ width: `${progressPercent}%` }}
                  />
                </div>
                <p className="text-[10px] text-gray-400 font-mono mt-0.5">
                  {xpIntoCurrentLevel}/{xpRequiredForNextLevel} to next level
                </p>
              </div>
            )}
            <div className="w-12 h-12 rounded-2xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400 shrink-0 shadow-inner">
              <Award className="w-6 h-6" />
            </div>
          </div>
        </Card>
      </div>

      {/* Main Grid: Analytical trend charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Real-time Study Sessions Trend Chart */}
        <Card variant="glass" className="lg:col-span-2 space-y-4">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-purple-400" />
                Study Sessions Trend
              </h2>
              <p className="text-xs text-gray-400">
                {timeframe === "7d" && "Total deep work hours logged over the past 7 days"}
                {timeframe === "30d" && "Total deep work hours logged over the past 30 days"}
                {timeframe === "90d" && "3-day aggregated study velocity over 90 days"}
                {timeframe === "1y" && "Monthly aggregated deep work hours over 12 months"}
              </p>
            </div>

            {/* Timeframe Selector Pills */}
            <div className="flex items-center gap-1 bg-slate-900/80 p-1 rounded-xl border border-white/10">
              {(["7d", "30d", "90d", "1y"] as TrendTimeframe[]).map((tf) => (
                <button
                  key={tf}
                  onClick={() => {
                    soundManager.play("select");
                    setTimeframe(tf);
                  }}
                  className={`px-2.5 py-1 text-[11px] font-bold rounded-lg transition-all cursor-pointer ${timeframe === tf
                    ? "bg-purple-600 text-white shadow-md shadow-purple-900/40"
                    : "text-gray-400 hover:text-white hover:bg-white/5"
                    }`}
                >
                  {tf.toUpperCase()}
                </button>
              ))}
            </div>
          </div>

          <div className="h-72 w-full relative">
            {isMounted ? (
              <>
                <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
                  <AreaChart data={trendData} margin={{ top: 10, right: 5, left: -20, bottom: 0 }}>
                    <defs>
                      <linearGradient id="hoursGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.35} />
                        <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <XAxis dataKey="date" stroke="#6b7280" fontSize={11} tickLine={false} />
                    <YAxis stroke="#6b7280" fontSize={11} tickLine={false} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "#0f1118",
                        borderColor: "rgba(255,255,255,0.12)",
                        borderRadius: 12,
                        boxShadow: "0 8px 32px rgba(0,0,0,0.5)",
                        fontSize: "12px",
                      }}
                      labelStyle={{ color: "#fff", fontWeight: "bold" }}
                      formatter={(val: unknown) => [`${val} hrs`, "Study Duration"]}
                    />
                    <Area
                      type="monotone"
                      dataKey="Hours"
                      stroke="#8b5cf6"
                      strokeWidth={2.5}
                      fillOpacity={1}
                      fill="url(#hoursGrad)"
                      name="Hours"
                      dot={{ fill: "#8b5cf6", strokeWidth: 0, r: 3 }}
                      activeDot={{ r: 6, fill: "#a78bfa" }}
                    />
                  </AreaChart>
                </ResponsiveContainer>

                {/* Empty State Overlay */}
                {!hasSessions && (
                  <div className="absolute inset-0 bg-slate-950/40 backdrop-blur-[2px] rounded-2xl flex flex-col items-center justify-center text-center p-4 border border-dashed border-white/10">
                    <AlertCircle className="w-8 h-8 text-purple-400 mb-2 animate-bounce" />
                    <p className="text-sm font-bold text-white">No completed study sessions yet.</p>
                    <p className="text-xs text-gray-400 mt-1 max-w-xs">
                      Start your first focus session to build your study trend graph in real time.
                    </p>
                    <Link href="/study" className="mt-3">
                      <Button size="sm" variant="primary">
                        <Timer className="w-3.5 h-3.5" /> Start Focus Session
                      </Button>
                    </Link>
                  </div>
                )}
              </>
            ) : (
              <div className="h-72 w-full rounded-2xl bg-white/[0.02] animate-pulse" />
            )}
          </div>
        </Card>

        {/* Donut Chart: Real-time Subject Breakdown */}
        <Card variant="glass" className="space-y-4 flex flex-col justify-between">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <Target className="w-4 h-4 text-blue-400" />
              Subject Breakdown
            </h2>
            <p className="text-xs text-gray-400">Relative allocation of study time</p>
          </div>

          <div className="h-44 flex items-center justify-center relative">
            {isMounted ? (
              <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
                <PieChart>
                  <Pie
                    data={subjectBreakdown}
                    cx="50%"
                    cy="50%"
                    innerRadius={55}
                    outerRadius={75}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {subjectBreakdown.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-44 w-full rounded-2xl bg-white/[0.02] animate-pulse" />
            )}
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none text-center">
              <span className="text-[10px] text-gray-400 uppercase tracking-wider block font-semibold">Today</span>
              <span className="text-2xl font-black text-white">{todayStudyHours}h</span>
            </div>
          </div>

          <div className={`grid ${isNeet ? "grid-cols-2 sm:grid-cols-4" : "grid-cols-3"} gap-2 text-center text-xs`}>
            {subjectBreakdown.map((sub) => (
              <div key={sub.name} className="p-2.5 rounded-xl bg-white/[0.03] border border-white/[0.08]">
                <span className="block font-bold text-white">{sub.value}%</span>
                <span className="text-[11px] font-semibold block truncate" style={{ color: sub.color }}>
                  {sub.name}
                </span>
                <span className="text-[10px] text-gray-400 font-mono block mt-0.5">{sub.hours}h</span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Heatmap & Gamification */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Real-Time Consistency Grid */}
        <div className="lg:col-span-2">
          <ConsistencyGrid />
        </div>

        {/* Gamification & Active Challenge */}
        <Card variant="glass" className="space-y-4">
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Award className="w-5 h-5 text-purple-400" /> Active Challenge
          </h2>

          <div className="p-4 rounded-xl border border-purple-500/30 bg-purple-500/10 space-y-3 shadow-inner">
            <div className="flex justify-between text-xs items-center">
              <span className="font-bold text-white">Monk Warrior Challenge</span>
              <Badge variant="purple">+400 XP</Badge>
            </div>
            <p className="text-xs text-gray-300 leading-relaxed">
              Complete two 90-minute Deep Work sessions without trigger log violations today.
            </p>
            <ProgressBar value={challengePct} label={`Progress: ${challengeProgress} / 2 sessions`} showPercentage={false} variant="primary" />
          </div>

          {/* Study Strategy Carousel */}
          <div className="pt-2 border-t border-white/[0.08]">
            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-2">Daily Study Insight</span>
            <Carousel
              showControls={false}
              slides={
                isNeet
                  ? [
                      {
                        id: "tip-neet-1",
                        content: (
                          <div className="p-3.5 rounded-xl bg-teal-500/10 border border-teal-500/20 text-xs space-y-1">
                            <span className="font-bold text-teal-300 block">🩺 NCERT Line-by-Line Mastery</span>
                            <p className="text-gray-300 leading-relaxed">
                              Biology carries 360/720 marks. Read every line of NCERT Botany & Zoology, especially footnotes, summary tables & scientist bios.
                            </p>
                          </div>
                        ),
                      },
                      {
                        id: "tip-neet-2",
                        content: (
                          <div className="p-3.5 rounded-xl bg-purple-500/10 border border-purple-500/20 text-xs space-y-1">
                            <span className="font-bold text-purple-300 block">🧬 High-Yield Genetics & Ecology</span>
                            <p className="text-gray-300 leading-relaxed">
                              Genetics, Biotech & Ecology historically account for ~35% of NEET Biology questions. Practice pedigree diagrams thoroughly!
                            </p>
                          </div>
                        ),
                      },
                      {
                        id: "tip-neet-3",
                        content: (
                          <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-xs space-y-1">
                            <span className="font-bold text-emerald-300 block">🧘 Focus Discipline</span>
                            <p className="text-gray-300 leading-relaxed">
                              Use Monk Mode during 90m Deep Work blocks to eliminate background visual clutter and maximize retention.
                            </p>
                          </div>
                        ),
                      },
                    ]
                  : [
                      {
                        id: "tip-1",
                        content: (
                          <div className="p-3.5 rounded-xl bg-purple-500/10 border border-purple-500/20 text-xs space-y-1">
                            <span className="font-bold text-purple-300 block">💡 Spaced Repetition Pro-Tip</span>
                            <p className="text-gray-300 leading-relaxed">
                              Always analyze WHY a mistake occurred (calculation vs conceptual) before marking it revised.
                            </p>
                          </div>
                        ),
                      },
                      {
                        id: "tip-2",
                        content: (
                          <div className="p-3.5 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-xs space-y-1">
                            <span className="font-bold text-cyan-300 block">🎯 JEE Physics Strategy</span>
                            <p className="text-gray-300 leading-relaxed">
                              Master Mechanics free-body diagrams first. 40% of Advanced problems build on Newton&apos;s laws.
                            </p>
                          </div>
                        ),
                      },
                      {
                        id: "tip-3",
                        content: (
                          <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-xs space-y-1">
                            <span className="font-bold text-emerald-300 block">🧘 Focus Discipline</span>
                            <p className="text-gray-300 leading-relaxed">
                              Use Monk Mode during 90m Deep Work blocks to eliminate background visual clutter.
                            </p>
                          </div>
                        ),
                      },
                    ]
              }
            />
          </div>

          <Link href="/mistakes" className="block pt-2">
            <Button variant="secondary" size="sm" className="w-full justify-between">
              <span>Review Mistake Journal</span>
              <ArrowUpRight className="w-4 h-4" />
            </Button>
          </Link>
        </Card>
      </div>
    </WorkspaceLayout>
  );
}
