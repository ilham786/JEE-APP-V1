"use client";

import React, { useState, useRef, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import dynamic from "next/dynamic";
import { motion, AnimatePresence } from "framer-motion";
import confetti from "canvas-confetti";
import { useAuth } from "@/context/AuthContext";
import { getUpcomingExamYears, getExamTargetOptions, type ExamType } from "@/lib/exam-config";
import { Magnetic } from "@/components/ui/magnetic";
import { soundManager } from "@/lib/sound-manager";
import { ThinkingOrb } from "thinking-orbs";
import { BorderBeam } from "border-beam";
import type { RobotStatus } from "@/components/3d/RobotScene";
import {
  User,
  Mail,
  Lock,
  Eye,
  EyeOff,
  ArrowRight,
  ShieldCheck,
  Sparkles,
  Bot,
  Globe,
  Moon,
  Sun,
  UserPlus,
  CheckCircle,
  AtSign,
  Check,
  AlertCircle,
  Zap,
} from "lucide-react";

// Dynamically import 3D WebGL Canvas Scene with SSR disabled
const RobotScene = dynamic(() => import("@/components/3d/RobotScene"), {
  ssr: false,
  loading: () => (
    <div className="w-full h-full flex items-center justify-center bg-gray-950 text-cyan-400 font-mono text-xs">
      <div className="flex items-center gap-2">
        <div className="w-4 h-4 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin" />
        <span>Initializing 3D Kinematics Engine...</span>
      </div>
    </div>
  ),
});

export default function LoginPage() {
  const router = useRouter();
  const { login, signup, loginWithGoogle, loginAsGuest, resetPassword, checkUsernameAvailability } = useAuth();

  const upcomingYears = React.useMemo(() => getUpcomingExamYears(4), []);
  const [selectedExamType, setSelectedExamType] = useState<ExamType>("JEE");
  const [isSignUpMode, setIsSignUpMode] = useState(false);
  const [name, setName] = useState("");
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [targetYear, setTargetYear] = useState(String(upcomingYears[0]));
  const [targetExam, setTargetExam] = useState(`JEE Main & Advanced ${upcomingYears[0]}`);
  const [country, setCountry] = useState("India");
  const [dailyGoal, setDailyGoal] = useState("6 Hours Daily");
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [isGoogleLoading, setIsGoogleLoading] = useState(false);
  const [isGuestLoading, setIsGuestLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [robotStatus, setRobotStatus] = useState<RobotStatus>("focused");
  const [darkMode, setDarkMode] = useState(true);
  const [language, setLanguage] = useState("EN");
  const [passwordFocused, setPasswordFocused] = useState(false);

  // Real-time username validation state
  const [usernameStatus, setUsernameStatus] = useState<"idle" | "checking" | "available" | "taken">("idle");
  const [usernameSuggestions, setUsernameSuggestions] = useState<string[]>([]);

  const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Check for logout notifications from URL query params
  useEffect(() => {
    if (typeof window !== "undefined") {
      const params = new URLSearchParams(window.location.search);
      if (params.get("logged_out") === "true") {
        setSuccessMessage("You have been signed out. Your study progress and vault are securely synced.");
      } else if (params.get("reason") === "multi_tab_logout") {
        setSuccessMessage("Signed out from another browser tab. Please sign in again to continue.");
      }
    }
  }, []);

  const isTypingRef = useRef(false);

  // Throttled typing notification: triggers state transition once, resets 700ms after typing stops
  const notifyTyping = () => {
    soundManager.playTyping();
    if (!isTypingRef.current) {
      isTypingRef.current = true;
      setRobotStatus("typing");
    }
    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
    typingTimeoutRef.current = setTimeout(() => {
      isTypingRef.current = false;
      setRobotStatus(passwordFocused ? (showPassword ? "peek" : "stealth") : "focused");
    }, 700);
  };

  // Real-time username availability checker with debounce
  useEffect(() => {
    if (!isSignUpMode || !username.trim()) {
      setUsernameStatus((prev) => (prev === "idle" ? prev : "idle"));
      setUsernameSuggestions((prev) => (prev.length === 0 ? prev : []));
      return;
    }

    const timer = setTimeout(async () => {
      setUsernameStatus("checking");
      const clean = username.replace(/^@/, "").toLowerCase().trim();
      const isAvail = await checkUsernameAvailability(clean);

      if (isAvail) {
        setUsernameStatus("available");
        setUsernameSuggestions((prev) => (prev.length === 0 ? prev : []));
      } else {
        setUsernameStatus("taken");
        setRobotStatus("error");
        setTimeout(() => setRobotStatus("focused"), 900);
        setUsernameSuggestions([
          `${clean}_${upcomingYears[0]}`,
          `iit_${clean}`,
          `${clean}_air1`,
          `real_${clean}`,
        ]);
      }
    }, 400);

    return () => clearTimeout(timer);
  }, [username, isSignUpMode, checkUsernameAvailability, upcomingYears]);

  const handleEmailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setEmail(e.target.value);
    notifyTyping();
  };

  const handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPassword(e.target.value);
    notifyTyping();
  };

  const handlePasswordFocus = () => {
    setPasswordFocused(true);
    setRobotStatus(showPassword ? "peek" : "stealth");
  };

  const handlePasswordBlur = () => {
    setPasswordFocused(false);
    setRobotStatus("focused");
  };

  const togglePasswordVisibility = () => {
    const nextShow = !showPassword;
    setShowPassword(nextShow);
    soundManager.play(nextShow ? "toggle-on" : "toggle-off");
    if (passwordFocused) {
      setRobotStatus(nextShow ? "peek" : "stealth");
    }
  };

  // Primary Login / Signup Submit Handler
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage("");
    setSuccessMessage("");

    const normalizedEmail = email.trim().toLowerCase();
    if (!normalizedEmail || !password) {
      soundManager.play("error");
      setErrorMessage("Please enter both email and password.");
      setRobotStatus("error");
      setTimeout(() => setRobotStatus("focused"), 1000);
      return;
    }

    if (isSignUpMode && usernameStatus === "taken") {
      soundManager.play("error");
      setErrorMessage("Please select an available unique username.");
      setRobotStatus("error");
      setTimeout(() => setRobotStatus("focused"), 1000);
      return;
    }

    setIsLoading(true);

    try {
      if (isSignUpMode) {
        await signup(normalizedEmail, password, name, username, targetExam, country, targetYear, dailyGoal, selectedExamType);
        setSuccessMessage("Account created! Welcome to FocusForge.");
      } else {
        await login(normalizedEmail, password);
      }

      soundManager.play("level-up");
      setRobotStatus("celebrate");
      confetti({
        particleCount: 130,
        spread: 85,
        origin: { y: 0.6 },
        colors: ["#06b6d4", "#8b5cf6", "#3b82f6", "#ffffff", "#10b981"],
      });

      await new Promise((res) => setTimeout(res, 650));
      router.push("/dashboard");
    } catch (err: unknown) {
      soundManager.play("error");
      const errorObj = err as { message?: string };
      console.error("Authentication error:", err);
      const rawMsg = errorObj?.message || "";
      if (
        rawMsg.toLowerCase().includes("already registered") ||
        rawMsg.toLowerCase().includes("already exists") ||
        rawMsg.toLowerCase().includes("account with this email")
      ) {
        setErrorMessage("An account with this email already exists. Please log in instead.");
      } else {
        setErrorMessage(rawMsg || "Failed to authenticate. Please check credentials.");
      }
      setRobotStatus("error");
      setTimeout(() => setRobotStatus("focused"), 1200);
      setIsLoading(false);
    }
  };

  // Google Login Handler
  const handleGoogleLogin = async () => {
    soundManager.play("select");
    setIsGoogleLoading(true);
    setErrorMessage("");
    try {
      await loginWithGoogle();
      soundManager.play("level-up");
      setRobotStatus("celebrate");
      confetti({
        particleCount: 110,
        spread: 75,
        origin: { y: 0.6 },
        colors: ["#ea4335", "#fbbc05", "#34a853", "#4285f4"],
      });
      await new Promise((res) => setTimeout(res, 500));
      router.push("/dashboard");
    } catch (err: unknown) {
      soundManager.play("error");
      const errorObj = err as { message?: string };
      console.error("Google Login Error:", err);
      setErrorMessage(errorObj?.message || "Google Authentication failed.");
      setRobotStatus("error");
      setTimeout(() => setRobotStatus("focused"), 1000);
      setIsGoogleLoading(false);
    }
  };

  // Guest Login Handler
  const handleGuestLogin = async () => {
    soundManager.play("select");
    setIsGuestLoading(true);
    setErrorMessage("");
    try {
      await loginAsGuest();
      soundManager.play("level-up");
      setRobotStatus("celebrate");
      confetti({
        particleCount: 90,
        spread: 65,
        origin: { y: 0.6 },
        colors: ["#06b6d4", "#8b5cf6"],
      });
      await new Promise((res) => setTimeout(res, 500));
      router.push("/dashboard");
    } catch (err: unknown) {
      soundManager.play("error");
      console.error("Guest login error:", err);
      setErrorMessage("Could not sign in as guest.");
      setRobotStatus("error");
      setTimeout(() => setRobotStatus("focused"), 1000);
      setIsGuestLoading(false);
    }
  };

  // Password Requirement Checks
  const passwordCriteria = {
    length: password.length >= 8,
    uppercase: /[A-Z]/.test(password),
    number: /[0-9]/.test(password),
    special: /[^A-Za-z0-9]/.test(password),
  };
  const passwordScore = Object.values(passwordCriteria).filter(Boolean).length;

  return (
    <div className={`min-h-screen w-full font-sans antialiased overflow-x-hidden md:overflow-hidden select-none ${darkMode ? "bg-slate-950 text-gray-100" : "bg-gray-50 text-gray-900"}`}>
      <div className="w-full min-h-screen flex flex-col md:flex-row">

        {/* LEFT PANEL: 3D WEBGL ROBOT SCENE */}
        <div className="hidden md:flex w-full md:w-3/5 h-screen relative bg-black items-center justify-center border-r border-white/[0.08] overflow-hidden">
          {/* Top-Right Quick Controls */}
          <div className="absolute top-6 right-6 z-20 flex items-center gap-2">
            <button
              type="button"
              onClick={() => setLanguage(language === "EN" ? "HI" : "EN")}
              className="px-3 py-1.5 rounded-full bg-slate-900/80 border border-white/10 text-xs font-mono text-gray-300 hover:text-white transition-all flex items-center gap-1.5 backdrop-blur-md cursor-pointer"
            >
              <Globe className="w-3.5 h-3.5 text-purple-400" />
              <span>{language}</span>
            </button>

            <button
              type="button"
              onClick={() => setDarkMode(!darkMode)}
              className="p-2 rounded-full bg-slate-900/80 border border-white/10 text-xs text-gray-300 hover:text-white transition-all backdrop-blur-md cursor-pointer"
              aria-label="Toggle theme"
            >
              {darkMode ? <Sun className="w-3.5 h-3.5 text-amber-400" /> : <Moon className="w-3.5 h-3.5 text-indigo-400" />}
            </button>
          </div>

          {/* 3D WebGL Canvas Component */}
          <RobotScene
            status={robotStatus}
            isPasswordVisible={showPassword}
            onPoke={() => {
              setRobotStatus("typing");
              setTimeout(() => setRobotStatus("focused"), 600);
            }}
          />
        </div>

        {/* RIGHT PANEL: GLASSMORPHISM AUTH FORM */}
        <div className={`w-full md:w-2/5 min-h-[100dvh] md:h-screen md:overflow-y-auto flex flex-col justify-between px-4 py-6 sm:px-8 sm:py-8 md:p-8 lg:p-10 ${darkMode ? "bg-slate-950/95 backdrop-blur-2xl text-white" : "bg-white text-gray-900"}`}>

          <div className="w-full max-w-md mx-auto my-auto md:my-0 min-w-0">

            {/* Header / Brand */}
            <div className="flex items-center justify-between mb-5 sm:mb-6 gap-2 min-w-0">
              <Link href="/" className="flex items-center gap-2.5 group shrink-0 min-w-0">
                <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-2xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-cyan-500 text-white flex items-center justify-center font-black text-lg sm:text-xl group-hover:scale-105 transition-transform shadow-lg shadow-purple-950/40 border border-white/10 shrink-0">
                  <Zap className="w-4 h-4 sm:w-5 sm:h-5 fill-white" />
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className={`font-bold text-lg sm:text-xl tracking-tight block truncate ${darkMode ? "text-white" : "text-gray-900"}`}>FocusForge</span>
                    <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-purple-500/10 text-purple-300 border border-purple-500/20">
                      {upcomingYears[0]}
                    </span>
                  </div>
                  <span className="text-[10px] font-mono text-cyan-400 block -mt-0.5 truncate">Cloud JEE Study OS</span>
                </div>
              </Link>

              {/* Mobile and Desktop Header Controls */}
              <div className="flex items-center gap-1.5 shrink-0">
                {/* Mobile Reactive Companion Indicator */}
                <div className="flex md:hidden items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-900/80 border border-cyan-500/30 text-[11px] font-mono text-cyan-300 backdrop-blur-md">
                  <ThinkingOrb
                    state={
                      robotStatus === "stealth"
                        ? "shaping"
                        : robotStatus === "peek"
                          ? "connecting"
                          : robotStatus === "typing"
                            ? "working"
                            : robotStatus === "celebrate"
                              ? "weaving"
                              : robotStatus === "error"
                                ? "searching"
                                : "breathing"
                    }
                    size={20}
                    theme="dark"
                  />
                  <span className="text-[10px] font-bold text-cyan-400">ForgeBot</span>
                </div>

                <div className="flex md:hidden items-center gap-1">
                  <button
                    type="button"
                    onClick={() => setLanguage(language === "EN" ? "HI" : "EN")}
                    className="px-2 py-1 rounded-full bg-slate-900/80 border border-white/10 text-[10px] font-mono text-gray-300 hover:text-white transition-all flex items-center gap-1 backdrop-blur-md cursor-pointer"
                    aria-label="Toggle language"
                  >
                    <Globe className="w-3 h-3 text-purple-400" />
                    <span>{language}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setDarkMode(!darkMode)}
                    className="p-1.5 rounded-full bg-slate-900/80 border border-white/10 text-xs text-gray-300 hover:text-white transition-all backdrop-blur-md cursor-pointer"
                    aria-label="Toggle theme"
                  >
                    {darkMode ? <Sun className="w-3.5 h-3.5 text-amber-400" /> : <Moon className="w-3.5 h-3.5 text-indigo-400" />}
                  </button>
                </div>
              </div>
            </div>

            {/* Mode Switcher Tabs with Sliding Pill */}
            <div className="grid grid-cols-2 p-1 rounded-2xl bg-slate-900/90 border border-white/10 mb-5 shadow-inner w-full min-w-0">
              <button
                type="button"
                id="btn-tab-signin"
                data-testid="tab-signin"
                onClick={() => {
                  setIsSignUpMode(false);
                  setErrorMessage("");
                  setSuccessMessage("");
                  setRobotStatus("focused");
                }}
                className={`relative py-2.5 rounded-xl text-xs font-bold transition-colors cursor-pointer z-10 text-center ${!isSignUpMode ? "text-white" : "text-gray-400 hover:text-white"
                  }`}
              >
                {!isSignUpMode && (
                  <motion.div
                    layoutId="auth-tab-indicator"
                    className="absolute inset-0 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 shadow-md shadow-purple-950/50"
                    transition={{ type: "spring", stiffness: 450, damping: 30 }}
                  />
                )}
                <span className="relative z-10">Sign In</span>
              </button>

              <button
                type="button"
                id="btn-tab-create-account"
                data-testid="tab-create-account"
                onClick={() => {
                  setIsSignUpMode(true);
                  setErrorMessage("");
                  setSuccessMessage("");
                  setRobotStatus("focused");
                }}
                className={`relative py-2.5 rounded-xl text-xs font-bold transition-colors cursor-pointer z-10 text-center ${isSignUpMode ? "text-white" : "text-gray-400 hover:text-white"
                  }`}
              >
                {isSignUpMode && (
                  <motion.div
                    layoutId="auth-tab-indicator"
                    className="absolute inset-0 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 shadow-md shadow-purple-950/50"
                    transition={{ type: "spring", stiffness: 450, damping: 30 }}
                  />
                )}
                <span className="relative z-10">Create Account</span>
              </button>
            </div>

            {/* Header Titles */}
            <div className="mb-5">
              <h1 className={`text-2xl sm:text-3xl font-black tracking-tight mb-1 ${darkMode ? "text-white" : "text-gray-900"}`}>
                {isSignUpMode ? "Create Aspirant Profile" : "Welcome Back"}
              </h1>
              <p className="text-xs sm:text-sm text-gray-400 font-normal leading-relaxed">
                {isSignUpMode
                  ? "Claim your unique @username to sync focus sessions, mistake vaults, and distraction guards."
                  : "Access your cloud workspace, spaced repetition queue, and mock analytics."}
              </p>
            </div>

            {/* Alerts */}
            {errorMessage && (
              <motion.div
                initial={{ opacity: 0, y: -6 }}
                animate={{ opacity: 1, y: 0 }}
                className="mb-5 p-3.5 rounded-2xl bg-red-500/10 border border-red-500/30 text-red-300 text-xs font-medium flex items-center justify-between gap-3 min-w-0"
              >
                <div className="flex items-center gap-2 min-w-0">
                  <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
                  <span className="break-words">{errorMessage}</span>
                </div>
                {(errorMessage.toLowerCase().includes("already exists") ||
                  errorMessage.toLowerCase().includes("log in instead") ||
                  errorMessage.toLowerCase().includes("login instead")) && (
                    <button
                      type="button"
                      onClick={() => {
                        setIsSignUpMode(false);
                        setErrorMessage("");
                        setRobotStatus("focused");
                      }}
                      className="shrink-0 px-3 py-1.5 rounded-xl bg-purple-600 text-white font-bold text-xs hover:bg-purple-500 transition-all cursor-pointer shadow-sm"
                    >
                      Log In Now
                    </button>
                  )}
              </motion.div>
            )}

            {successMessage && (
              <motion.div
                initial={{ opacity: 0, y: -6 }}
                animate={{ opacity: 1, y: 0 }}
                className="mb-5 p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-medium flex items-center gap-2 min-w-0"
              >
                <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                <span className="break-words">{successMessage}</span>
              </motion.div>
            )}

            {/* Main Form */}
            <form onSubmit={handleSubmit} className="space-y-4">

              {/* Full Name & Username (Only on Signup) */}
              {isSignUpMode && (
                <div className="space-y-3.5 pb-1">
                  <div className="text-[10px] font-mono uppercase tracking-widest text-purple-400 font-semibold mb-2">
                    01. Account Credentials
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold uppercase tracking-wider text-gray-400 mb-1.5">
                      Full Name
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-500">
                        <User className="w-4 h-4" />
                      </div>
                      <input
                        type="text"
                        required
                        value={name}
                        onChange={(e) => {
                          setName(e.target.value);
                          notifyTyping();
                        }}
                        onFocus={() => setRobotStatus("focused")}
                        placeholder="e.g. Rahul Sharma"
                        className="w-full pl-10 pr-4 py-2.5 sm:py-3 rounded-xl text-sm font-medium transition-all focus:outline-none bg-slate-900/80 border border-white/10 text-white focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20"
                      />
                    </div>
                  </div>

                  {/* Unique Username Input & Availability Checker */}
                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <label className="block text-[11px] font-bold uppercase tracking-wider text-gray-400">
                        Unique Handle
                      </label>
                      {usernameStatus === "checking" && <span className="text-[10px] text-purple-400 font-mono animate-pulse">Checking availability...</span>}
                      {usernameStatus === "available" && <span className="text-[10px] text-emerald-400 font-mono font-bold flex items-center gap-1"><Check className="w-3 h-3" /> Available</span>}
                      {usernameStatus === "taken" && <span className="text-[10px] text-red-400 font-mono font-bold">Already Taken</span>}
                    </div>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-purple-400 font-bold font-mono">
                        <AtSign className="w-4 h-4" />
                      </div>
                      <input
                        type="text"
                        required
                        value={username}
                        onChange={(e) => {
                          setUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ""));
                          notifyTyping();
                        }}
                        onFocus={() => setRobotStatus("focused")}
                        placeholder="aspirant_jee"
                        className={`w-full pl-10 pr-4 py-2.5 sm:py-3 rounded-xl text-sm font-mono font-semibold transition-all focus:outline-none ${usernameStatus === "available"
                          ? "bg-emerald-500/5 border border-emerald-500/40 text-emerald-300"
                          : usernameStatus === "taken"
                            ? "bg-red-500/5 border border-red-500/40 text-red-300"
                            : "bg-slate-900/80 border border-white/10 text-white focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20"
                          }`}
                      />
                    </div>

                    {/* Username Suggestion Pills */}
                    {usernameSuggestions.length > 0 && (
                      <div className="mt-2 space-y-1">
                        <span className="text-[10px] text-gray-400 block font-mono">Suggested available handles:</span>
                        <div className="flex flex-wrap gap-1.5">
                          {usernameSuggestions.map((sug) => (
                            <button
                              type="button"
                              key={sug}
                              onClick={() => {
                                setUsername(sug);
                                notifyTyping();
                              }}
                              className="px-2.5 py-1 rounded-lg bg-purple-500/10 border border-purple-500/20 text-purple-300 font-mono text-[10px] hover:bg-purple-500/25 transition-colors cursor-pointer"
                            >
                              @{sug}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Email Input */}
              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-gray-400 mb-1.5">
                  Email Address
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-500">
                    <Mail className="w-4 h-4" />
                  </div>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={handleEmailChange}
                    onFocus={() => setRobotStatus("focused")}
                    placeholder="aspirant@focusforge.app"
                    className="w-full pl-10 pr-4 py-2.5 sm:py-3 rounded-xl text-sm font-medium transition-all focus:outline-none bg-slate-900/80 border border-white/10 text-white focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20"
                  />
                </div>
              </div>

              {/* Password Input & Privacy Stealth Shutter */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label htmlFor="login-password-input" className="block text-[11px] font-bold uppercase tracking-wider text-gray-400">
                    Password
                  </label>
                </div>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-500">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    id="login-password-input"
                    type={showPassword ? "text" : "password"}
                    required
                    value={password}
                    onChange={handlePasswordChange}
                    onFocus={handlePasswordFocus}
                    onBlur={handlePasswordBlur}
                    placeholder="••••••••••••"
                    className="w-full pl-10 pr-10 py-2.5 sm:py-3 rounded-xl text-sm font-medium transition-all focus:outline-none bg-slate-900/80 border border-white/10 text-white focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20"
                  />
                  <button
                    type="button"
                    onClick={togglePasswordVisibility}
                    className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-gray-400 hover:text-white transition-colors cursor-pointer"
                    aria-label={showPassword ? "Hide password" : "Show password"}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4 text-cyan-400" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>

                {/* Polished Forgot Password link below the password field */}
                {!isSignUpMode && (
                  <div className="flex justify-end mt-2">
                    <Link
                      href="/forgot-password"
                      id="link-forgot-password"
                      className="text-xs font-medium text-purple-400 hover:text-purple-300 transition-colors inline-block cursor-pointer focus-visible:ring-1 focus-visible:ring-purple-400 rounded"
                    >
                      Forgot password?
                    </Link>
                  </div>
                )}

                {/* Password Strength Indicator (Signup Mode) */}
                {isSignUpMode && password && (
                  <div className="mt-2.5 p-2.5 rounded-xl bg-slate-900/60 border border-white/[0.06] space-y-2">
                    <div className="flex justify-between text-[10px] text-gray-400 font-mono">
                      <span>Security Strength</span>
                      <span className={passwordScore >= 3 ? "text-emerald-400 font-bold" : passwordScore >= 2 ? "text-amber-400" : "text-rose-400"}>
                        {passwordScore === 4 ? "Excellent" : passwordScore >= 3 ? "Strong" : passwordScore >= 2 ? "Moderate" : "Weak"}
                      </span>
                    </div>

                    <div className="grid grid-cols-4 gap-1.5 text-[9px] font-mono">
                      <div className={`p-1 rounded text-center border ${passwordCriteria.length ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-300" : "bg-white/[0.02] border-white/[0.06] text-gray-500"}`}>
                        8+ Chars
                      </div>
                      <div className={`p-1 rounded text-center border ${passwordCriteria.uppercase ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-300" : "bg-white/[0.02] border-white/[0.06] text-gray-500"}`}>
                        Uppercase
                      </div>
                      <div className={`p-1 rounded text-center border ${passwordCriteria.number ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-300" : "bg-white/[0.02] border-white/[0.06] text-gray-500"}`}>
                        Number
                      </div>
                      <div className={`p-1 rounded text-center border ${passwordCriteria.special ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-300" : "bg-white/[0.02] border-white/[0.06] text-gray-500"}`}>
                        Symbol
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Dynamic Target Exam & Year Selectors (Only on Signup) */}
              {isSignUpMode && (
                <div className="space-y-3.5 pt-2">
                  <div className="text-[10px] font-mono uppercase tracking-widest text-cyan-400 font-semibold mb-2">
                    02. Preparation Track & Target
                  </div>

                  {/* Exam Track Switcher */}
                  <div>
                    <label className="block text-[11px] font-bold uppercase tracking-wider text-gray-400 mb-1.5">
                      What are you preparing for?
                    </label>
                    <div className="grid grid-cols-2 gap-2.5">
                      <button
                        type="button"
                        onClick={() => {
                          setSelectedExamType("JEE");
                          const options = getExamTargetOptions("JEE", targetYear);
                          setTargetExam(options[0]?.value || `JEE Main & Advanced ${targetYear}`);
                        }}
                        className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col gap-0.5 ${
                          selectedExamType === "JEE"
                            ? "bg-purple-600/20 border-purple-500 shadow-md shadow-purple-950/40 text-white ring-1 ring-purple-500/50"
                            : "bg-slate-900/80 border-white/10 text-gray-400 hover:text-white hover:border-white/20"
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-bold text-white flex items-center gap-1.5">
                            ⚡ JEE
                          </span>
                          {selectedExamType === "JEE" && (
                            <span className="w-2 h-2 rounded-full bg-purple-400 animate-pulse" />
                          )}
                        </div>
                        <span className="text-[10px] text-gray-400">Engineering • PCM</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setSelectedExamType("NEET");
                          const options = getExamTargetOptions("NEET", targetYear);
                          setTargetExam(options[0]?.value || `NEET UG ${targetYear}`);
                        }}
                        className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col gap-0.5 ${
                          selectedExamType === "NEET"
                            ? "bg-emerald-600/20 border-emerald-500 shadow-md shadow-emerald-950/40 text-white ring-1 ring-emerald-500/50"
                            : "bg-slate-900/80 border-white/10 text-gray-400 hover:text-white hover:border-white/20"
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-bold text-white flex items-center gap-1.5">
                            🩺 NEET
                          </span>
                          {selectedExamType === "NEET" && (
                            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                          )}
                        </div>
                        <span className="text-[10px] text-gray-400">Medical • PCB</span>
                      </button>
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <label className="block text-[11px] font-bold uppercase tracking-wider text-gray-400">
                        Target Exam Year
                      </label>
                      <span className="text-[10px] text-purple-400 font-mono font-medium">
                        {selectedExamType === "NEET" ? "NEET UG Cycle" : "IIT-JEE Cycle"}
                      </span>
                    </div>
                    <div className="grid grid-cols-4 gap-2">
                      {upcomingYears.map((yr) => {
                        const isSelected = targetYear === String(yr);
                        return (
                          <button
                            type="button"
                            key={yr}
                            onClick={() => {
                              setTargetYear(String(yr));
                              const options = getExamTargetOptions(selectedExamType, yr);
                              setTargetExam(options[0]?.value || `${selectedExamType === "NEET" ? "NEET UG" : "JEE Main & Advanced"} ${yr}`);
                            }}
                            className={`py-2 px-1 rounded-xl text-xs font-bold transition-all text-center border cursor-pointer ${
                              isSelected
                                ? selectedExamType === "NEET"
                                  ? "bg-emerald-600 border-emerald-500 text-white shadow-md shadow-emerald-950/40 scale-[1.02]"
                                  : "bg-purple-600 border-purple-500 text-white shadow-md shadow-purple-950/40 scale-[1.02]"
                                : "bg-slate-900/80 border-white/10 text-gray-400 hover:text-white hover:border-white/20"
                            }`}
                          >
                            {yr}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold uppercase tracking-wider text-gray-400 mb-1.5">
                      Target Examination
                    </label>
                    <select
                      value={targetExam}
                      onChange={(e) => setTargetExam(e.target.value)}
                      className="w-full px-3.5 py-2.5 sm:py-3 rounded-xl text-xs sm:text-sm font-medium transition-all focus:outline-none bg-slate-900/80 border border-white/10 text-white focus:border-purple-500"
                    >
                      {getExamTargetOptions(selectedExamType, Number(targetYear)).map((opt) => (
                        <option key={opt.value} value={opt.value} className="bg-slate-900 text-white">
                          {opt.label}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-bold uppercase tracking-wider text-gray-400 mb-1.5">
                        Country
                      </label>
                      <select
                        value={country}
                        onChange={(e) => setCountry(e.target.value)}
                        className="w-full px-3 py-2.5 sm:py-3 rounded-xl text-xs font-medium transition-all focus:outline-none bg-slate-900/80 border border-white/10 text-white focus:border-purple-500"
                      >
                        <option value="India">India</option>
                        <option value="United Arab Emirates">UAE (Dubai/Abu Dhabi)</option>
                        <option value="Saudi Arabia">Saudi Arabia</option>
                        <option value="Singapore">Singapore</option>
                        <option value="Qatar">Qatar</option>
                        <option value="Oman">Oman</option>
                        <option value="Kuwait">Kuwait</option>
                        <option value="United States">United States</option>
                        <option value="Nepal">Nepal</option>
                        <option value="Other">Other / International</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold uppercase tracking-wider text-gray-400 mb-1.5">
                        Daily Study Goal
                      </label>
                      <select
                        value={dailyGoal}
                        onChange={(e) => setDailyGoal(e.target.value)}
                        className="w-full px-3 py-2.5 sm:py-3 rounded-xl text-xs font-medium transition-all focus:outline-none bg-slate-900/80 border border-white/10 text-white focus:border-purple-500"
                      >
                        <option value="4 Hours Daily">4 Hours Daily</option>
                        <option value="6 Hours Daily">6 Hours Daily (Rec.)</option>
                        <option value="8 Hours Daily">8 Hours Daily</option>
                        <option value="10+ Hours Daily">10+ Hours Daily</option>
                      </select>
                    </div>
                  </div>
                </div>
              )}

              {/* Remember Me Toggle */}
              <div className="flex items-center justify-between pt-1">
                <label className="flex items-center gap-2.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="w-4 h-4 text-purple-600 border-gray-700 rounded bg-slate-900 focus:ring-purple-500 cursor-pointer"
                  />
                  <span className="text-xs text-gray-400 font-medium">Remember session on this device</span>
                </label>
              </div>

              {/* Primary Submit Button with Magnetic Physics */}
              <div className="pt-2">
                <Magnetic strength={0.2}>
                  <button
                    type="submit"
                    disabled={isLoading || isGoogleLoading || isGuestLoading}
                    className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-purple-600 via-indigo-600 to-cyan-500 text-white font-bold text-sm tracking-wide shadow-xl shadow-purple-950/50 hover:brightness-110 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                  >
                    {isLoading ? (
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    ) : (
                      <>
                        {isSignUpMode ? <UserPlus className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
                        <span>{isSignUpMode ? "Initialize Aspirant Account" : "Enter Study Workspace"}</span>
                      </>
                    )}
                  </button>
                </Magnetic>
              </div>

              {/* Subtle Divider */}
              <div className="flex items-center my-3">
                <div className="flex-1 border-t border-white/[0.08]" />
                <span className="px-3 text-[10px] text-gray-500 font-mono uppercase">Or Quick Connect</span>
                <div className="flex-1 border-t border-white/[0.08]" />
              </div>

              {/* Secondary Actions Block: Google + Demo Aspirant */}
              <div className="space-y-2.5">
                {/* Social Google Login Button */}
                <button
                  type="button"
                  onClick={handleGoogleLogin}
                  disabled={isLoading || isGoogleLoading || isGuestLoading}
                  className="w-full py-2.5 px-4 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] text-gray-200 font-semibold text-xs transition-all flex items-center justify-center gap-2.5 border border-white/10 cursor-pointer disabled:opacity-50"
                >
                  {isGoogleLoading ? (
                    <div className="w-4 h-4 border-2 border-gray-400 border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <>
                      <svg className="w-4 h-4" viewBox="0 0 24 24">
                        <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                        <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                        <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                        <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                      </svg>
                      <span>Continue with Google</span>
                    </>
                  )}
                </button>

                {/* Instant Demo Option (Framed with BorderBeam & ThinkingOrb) */}
                <BorderBeam
                  colorVariant="ocean"
                  size="sm"
                  strength={0.7}
                  duration={3.2}
                  className="w-full rounded-xl"
                >
                  <button
                    type="button"
                    onClick={handleGuestLogin}
                    disabled={isLoading || isGoogleLoading || isGuestLoading}
                    className="w-full py-2.5 px-3.5 rounded-xl bg-slate-900/90 hover:bg-slate-850 border border-purple-500/25 hover:border-purple-400/40 text-white font-medium text-xs transition-all flex items-center justify-between cursor-pointer group disabled:opacity-50"
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <div className="w-6 h-6 rounded-lg bg-purple-500/20 border border-purple-400/30 flex items-center justify-center shrink-0">
                        <ThinkingOrb state="solving" size={20} theme="dark" />
                      </div>
                      <div className="text-left min-w-0">
                        <span className="text-xs font-semibold text-white group-hover:text-cyan-300 transition-colors block truncate">
                          Explore as Demo Aspirant
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0 text-[10px] text-gray-400 group-hover:text-white font-mono">
                      <span>1-Click Access</span>
                      <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
                    </div>
                  </button>
                </BorderBeam>
              </div>
            </form>

          </div>

          {/* Footer */}
          <div className="w-full max-w-md mx-auto pt-5 pb-4 sm:pb-2 border-t border-white/[0.08] text-center">
            <p className="text-xs text-gray-400 font-medium mb-1">
              {isSignUpMode ? "Already have an account?" : "Don't have an account?"}{" "}
              <button
                type="button"
                onClick={() => {
                  setIsSignUpMode(!isSignUpMode);
                  setErrorMessage("");
                  setRobotStatus("focused");
                }}
                className="font-bold text-purple-400 hover:text-purple-300 transition-colors cursor-pointer ml-1"
              >
                {isSignUpMode ? "Sign In" : "Sign Up"}
              </button>
            </p>
            <p className="text-[11px] text-gray-500 font-mono">
              FocusForge Cloud Operating System • Developed for JEE Aspirants
            </p>
          </div>

        </div>

      </div>
    </div>
  );
}
