"use client";

import { useState, useMemo, useEffect } from "react";
import { WorkspaceLayout } from "@/components/workspace-layout";
import { Card } from "@/components/ui/card";
import { Button, Badge } from "@/components/ui/controls";
import { useMistakeStore } from "@/store/use-mistake-store";
import { useStudyStore } from "@/store/use-study-store";
import { getCurrentUserId } from "@/lib/supabase/client";
import { revisionService } from "@/services/revisionService";
import { schedulerService } from "@/services/schedulerService";
import { historyService } from "@/services/historyService";
import { dashboardService } from "@/services/dashboardService";
import { randomRevisionService, RandomRecommendation } from "@/services/randomRevisionService";
import { customRevisionService, CustomRevisionPlanDoc } from "@/services/customRevisionService";
import { calendarService } from "@/services/calendarService";
import { notificationService } from "@/services/notificationService";
import { getSyllabusForSubject } from "@/data/syllabus";
import { useExam } from "@/hooks/use-exam";
import { soundManager } from "@/lib/sound-manager";
import { motion, AnimatePresence } from "framer-motion";
import {
  Clock,
  CalendarRange,
  Flame,
  CheckCircle2,
  Calendar,
  Search,
  BookOpen,
  ArrowLeft,
  RotateCcw,
  Check,
  X,
  AlertCircle,
  Loader2,
  Sparkles,
  Dices,
  SlidersHorizontal,
  Zap,
  Plus,
  Trash2,
  Tag,
  TrendingUp,
} from "lucide-react";

type FilterTab = "all" | "today" | "upcoming" | "completed" | "manual";

interface RevisionItem {
  id: string;
  subject: string;
  chapter: string;
  topic: string;
  notes?: string;
  formula?: string;
  lastRevisedAt: string;
  nextRevisionAt: string;
  timesRevised: number;
  completed: boolean;
  status: "Due Today" | "Upcoming" | "Completed" | "Rescheduled";
  isManual?: boolean;
  priority?: "Low" | "Medium" | "High";
  tag?: string;
  estimatedTime?: number;
}

export default function RevisionPlanPage() {
  const { mistakes, reviseMistake, skipMistake } = useMistakeStore();
  const { addXp } = useStudyStore();
  const { examType, subjects, isNeet } = useExam();

  const [activeFilter, setActiveFilter] = useState<FilterTab>("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [activeReviewItem, setActiveReviewItem] = useState<RevisionItem | null>(null);
  const [skipDialogItem, setSkipDialogItem] = useState<RevisionItem | null>(null);

  // Async processing loading state to prevent double clicks
  const [processingId, setProcessingId] = useState<string | null>(null);

  // Toast feedback state
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3200);
  };

  // Local state arrays for real-time optimistic lifecycle state machine
  const [localCompletedIds, setLocalCompletedIds] = useState<Record<string, boolean>>({});
  const [localRescheduledDates, setLocalRescheduledDates] = useState<Record<string, string>>({});

  // ---- RANDOM REVISION PICKER STATE ----
  const [randomRecommendations, setRandomRecommendations] = useState<RandomRecommendation[]>([]);
  const [showPickerFilters, setShowPickerFilters] = useState(false);
  const [pickerSubject, setPickerSubject] = useState<string>("All");
  const [pickerDifficulty, setPickerDifficulty] = useState<"All" | "Easy" | "Medium" | "Hard">("All");
  const [pickerWeightage, setPickerWeightage] = useState<"All" | "High">("All");
  const [isGeneratingRandom, setIsGeneratingRandom] = useState(false);

  // ---- CUSTOM REVISION PLANNER STATE ----
  const [customPlans, setCustomPlans] = useState<CustomRevisionPlanDoc[]>([]);

  const [showPlanModal, setShowPlanModal] = useState(false);
  const [editingPlanId, setEditingPlanId] = useState<string | null>(null);
  const [deleteConfirmPlan, setDeleteConfirmPlan] = useState<CustomRevisionPlanDoc | null>(null);

  // Form State
  const [formSubject, setFormSubject] = useState<string>("Physics");
  const [formChapter, setFormChapter] = useState("");
  const [formSubchapter, setFormSubchapter] = useState("");
  const [formTitle, setFormTitle] = useState("");
  const [formNotes, setFormNotes] = useState("");
  const [formPriority, setFormPriority] = useState<"Low" | "Medium" | "High">("Medium");
  const [formEstimatedTime, setFormEstimatedTime] = useState(15);
  const [formScheduledDate, setFormScheduledDate] = useState(() => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    return tomorrow.toISOString().split("T")[0];
  });
  const [formRepeat, setFormRepeat] = useState<"None" | "Daily" | "Weekly" | "Monthly">("None");
  const [formTag, setFormTag] = useState<"Formula" | "Theory" | "PYQ" | "Weak Topic" | "Mock Test" | "Concept">("Formula");
  const [showChapterSuggestions, setShowChapterSuggestions] = useState(false);

  // Dynamic chapter autocomplete suggestions based on subject & user query
  const chapterSuggestions = useMemo(() => {
    if (!formChapter.trim()) return [];
    const query = formChapter.toLowerCase();
    const subjectChapters = getSyllabusForSubject(formSubject, examType);
    return subjectChapters
      .filter((c) => c.name.toLowerCase().includes(query))
      .slice(0, 6);
  }, [formChapter, formSubject, examType]);

  // Keep form subject aligned with active exam track
  useEffect(() => {
    if (subjects.length > 0 && !subjects.includes(formSubject)) {
      setFormSubject(subjects[0]);
      setFormChapter("");
      setFormSubchapter("");
    }
  }, [subjects, formSubject]);

  const openCreateModal = () => {
    soundManager.play("open");
    setEditingPlanId(null);
    setFormSubject("Physics");
    setFormChapter("");
    setFormSubchapter("");
    setFormTitle("");
    setFormNotes("");
    setFormPriority("Medium");
    setFormEstimatedTime(15);
    const todayStr = new Date().toISOString().split("T")[0];
    setFormScheduledDate(todayStr);
    setFormRepeat("None");
    setFormTag("Formula");
    setShowPlanModal(true);
  };

  const openEditModal = (plan: CustomRevisionPlanDoc) => {
    soundManager.play("open");
    setEditingPlanId(plan.id);
    setFormSubject(plan.subjectName);
    setFormChapter(plan.chapterName);
    setFormSubchapter(plan.subchapterName);
    setFormTitle(plan.title);
    setFormNotes(plan.notes || "");
    setFormPriority(plan.priority);
    setFormEstimatedTime(plan.estimatedTime);
    setFormScheduledDate(plan.scheduledDate.split("T")[0]);
    setFormRepeat(plan.repeat);
    setFormTag(plan.tag);
    setShowPlanModal(true);
  };

  const handleSaveCustomPlan = async () => {
    if (!formChapter.trim() || !formTitle.trim()) {
      soundManager.play("warning");
      showToast("⚠️ Please enter a Chapter and Plan Title.");
      return;
    }

    soundManager.play("check");

    const uid = getCurrentUserId() || "guest-user";
    const dateObj = new Date(formScheduledDate);
    const isoDate = dateObj.toISOString();

    if (editingPlanId) {
      // Edit existing plan
      setCustomPlans((prev) =>
        prev.map((p) =>
          p.id === editingPlanId
            ? {
              ...p,
              subjectName: formSubject,
              chapterName: formChapter,
              subchapterName: formSubchapter || formChapter,
              title: formTitle,
              notes: formNotes,
              priority: formPriority,
              estimatedTime: formEstimatedTime,
              scheduledDate: isoDate,
              repeat: formRepeat,
              tag: formTag,
              updatedAt: new Date().toISOString(),
            }
            : p
        )
      );

      await customRevisionService.updateCustomPlan(editingPlanId, {
        subjectName: formSubject,
        chapterName: formChapter,
        subchapterName: formSubchapter || formChapter,
        title: formTitle,
        notes: formNotes,
        priority: formPriority,
        estimatedTime: formEstimatedTime,
        scheduledDate: isoDate,
        repeat: formRepeat,
        tag: formTag,
      });

      showToast("✓ Custom Revision Plan updated!");
    } else {
      // Create new plan
      const newDocId = `plan-${Date.now()}`;
      const newPlan: CustomRevisionPlanDoc = {
        id: newDocId,
        userId: uid,
        subjectName: formSubject,
        chapterName: formChapter,
        subchapterName: formSubchapter || formChapter,
        title: formTitle,
        notes: formNotes,
        priority: formPriority,
        estimatedTime: formEstimatedTime,
        scheduledDate: isoDate,
        repeat: formRepeat,
        tag: formTag,
        status: "pending",
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        createdBy: "user",
      };

      setCustomPlans((prev) => [newPlan, ...prev]);
      await customRevisionService.createCustomPlan(newPlan);

      // Schedule reminder
      notificationService.scheduleReminder(formTitle, isoDate);

      showToast("📅 Custom Revision Plan created!");
    }

    setShowPlanModal(false);
  };

  const handleDeleteCustomPlan = async (plan: CustomRevisionPlanDoc) => {
    setCustomPlans((prev) => prev.filter((p) => p.id !== plan.id));
    await customRevisionService.deleteCustomPlan(plan.id);
    setDeleteConfirmPlan(null);
    showToast("🗑️ Revision plan deleted.");
  };

  const handleGenerateRandom = () => {
    soundManager.play("start");
    setIsGeneratingRandom(true);
    setTimeout(() => {
      const recs = randomRevisionService.getRandomRecommendations({
        subject: pickerSubject,
        difficulty: pickerDifficulty,
        weightage: pickerWeightage,
        count: 2,
        examType,
      });
      setRandomRecommendations(recs);
      setIsGeneratingRandom(false);

      const uid = getCurrentUserId() || "guest-user";
      recs.forEach((rec) => {
        randomRevisionService.logGeneratedSession(uid, rec);
      });

      showToast("🎲 Random revision topics generated!");
    }, 300);
  };

  // Synthesize unified list of revision items from Mistakes, Core Formulae & Manual Plans
  const items: RevisionItem[] = useMemo(() => {
    const list: RevisionItem[] = [];
    const now = new Date();

    // 1. Mistake Entries (Auto SM-2)
    mistakes.forEach((m) => {
      const isComp = !!localCompletedIds[m.id];
      const reschDate = localRescheduledDates[m.id];
      const effectiveNextDate = reschDate || m.nextRevisionAt;
      const isDue = new Date(effectiveNextDate) <= now;

      let status: "Due Today" | "Upcoming" | "Completed" | "Rescheduled" = "Upcoming";
      if (isComp) status = "Completed";
      else if (reschDate) status = "Rescheduled";
      else if (isDue) status = "Due Today";

      list.push({
        id: m.id,
        subject: m.subject as "Physics" | "Chemistry" | "Maths",
        chapter: m.chapter,
        topic: m.description,
        notes: m.explanation,
        lastRevisedAt: m.createdAt,
        nextRevisionAt: effectiveNextDate,
        timesRevised: m.timesRevised,
        completed: isComp,
        status,
        isManual: false,
      });
    });

    // 2. Manual Custom Revision Plans
    customPlans.forEach((cp) => {
      const isComp = cp.status === "completed" || !!localCompletedIds[cp.id];
      const reschDate = localRescheduledDates[cp.id];
      const effectiveNextDate = reschDate || cp.scheduledDate;
      const isDue = new Date(effectiveNextDate) <= now;

      let status: "Due Today" | "Upcoming" | "Completed" | "Rescheduled" = "Upcoming";
      if (isComp) status = "Completed";
      else if (reschDate) status = "Rescheduled";
      else if (isDue) status = "Due Today";

      list.push({
        id: cp.id,
        subject: cp.subjectName,
        chapter: cp.chapterName,
        topic: cp.title,
        notes: cp.notes,
        lastRevisedAt: cp.createdAt,
        nextRevisionAt: effectiveNextDate,
        timesRevised: 1,
        completed: isComp,
        status,
        isManual: true,
        priority: cp.priority,
        tag: cp.tag,
        estimatedTime: cp.estimatedTime,
      });
    });

    return list;
  }, [mistakes, localCompletedIds, localRescheduledDates, customPlans]);

  // Metrics
  const dueTodayItems = useMemo(
    () => items.filter((item) => !item.completed && item.status === "Due Today"),
    [items]
  );

  const upcomingItems = useMemo(
    () => items.filter((item) => !item.completed && item.status !== "Due Today"),
    [items]
  );

  // Filtered List based on Tab State
  const filteredItems = useMemo(() => {
    return items.filter((item) => {
      // Filter tab
      if (activeFilter === "today" && (item.completed || item.status !== "Due Today")) return false;
      if (activeFilter === "upcoming" && (item.completed || item.status === "Due Today")) return false;
      if (activeFilter === "completed" && !item.completed) return false;
      if (activeFilter === "manual" && !item.isManual) return false;

      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchTopic = item.topic.toLowerCase().includes(q);
        const matchChapter = item.chapter.toLowerCase().includes(q);
        const matchSubject = item.subject.toLowerCase().includes(q);
        if (!matchTopic && !matchChapter && !matchSubject) return false;
      }

      return true;
    });
  }, [items, activeFilter, searchQuery]);

  // Handler: Complete Revision Workflow
  const handleMarkComplete = async (item: RevisionItem) => {
    if (processingId) return;
    setProcessingId(item.id);

    try {
      soundManager.play("checkpoint");
      setLocalCompletedIds((prev) => ({ ...prev, [item.id]: true }));

      if (item.isManual) {
        await customRevisionService.markCustomPlanCompleted(item.id);
        setCustomPlans((prev) =>
          prev.map((p) => (p.id === item.id ? { ...p, status: "completed" } : p))
        );
      } else {
        const sched = schedulerService.calculateSchedule(item.timesRevised, "Complete");
        reviseMistake(item.id);

        const uid = getCurrentUserId() || "guest-user";
        await revisionService.markRevisionCompleted(item.id, {
          userId: uid,
          subject: item.subject,
          chapter: item.chapter,
          scheduledDate: sched.nextReviewDate.toISOString(),
          revisionCycle: sched.nextCycle,
          intervalDays: sched.intervalDays,
        });

        await historyService.logHistory({
          id: `hist-${Date.now()}-${item.id}`,
          userId: uid,
          revisionId: item.id,
          action: "completed",
          subject: item.subject,
          chapter: item.chapter,
          topic: item.topic,
          stageReached: sched.nextCycle,
        });
      }

      addXp(100);

      const uid = getCurrentUserId() || "guest-user";
      await dashboardService.updateDashboardStats(uid, {
        dueTodayCount: Math.max(0, dueTodayItems.length - 1),
        completedTodayCount: items.filter((i) => i.completed).length + 1,
        streakDays: 7,
      });

      showToast("✓ Revision Completed (+100 XP)");

      if (activeReviewItem?.id === item.id) {
        setActiveReviewItem(null);
      }
    } catch (err) {
      console.error("Error in complete revision workflow:", err);
      soundManager.play("error");
      setLocalCompletedIds((prev) => ({ ...prev, [item.id]: false }));
      showToast("❌ Could not complete revision. Please try again.");
    } finally {
      setProcessingId(null);
    }
  };

  // Handler: Skip Revision Workflow
  const handleSkipConfirm = async (item: RevisionItem) => {
    if (processingId) return;
    setProcessingId(item.id);

    try {
      soundManager.play("toggle-off");
      const sched = schedulerService.calculateSchedule(item.timesRevised, "Skip");
      const tomorrowISO = sched.nextReviewDate.toISOString();

      setLocalRescheduledDates((prev) => ({ ...prev, [item.id]: tomorrowISO }));

      if (item.isManual) {
        await customRevisionService.updateCustomPlan(item.id, { scheduledDate: tomorrowISO });
      } else {
        skipMistake(item.id, "Skipped to tomorrow");
        await revisionService.rescheduleRevision(item.id, tomorrowISO, "Skipped to tomorrow");
      }

      showToast("Revision moved to tomorrow.");

      if (skipDialogItem?.id === item.id) {
        setSkipDialogItem(null);
      }
    } catch (err) {
      console.error("Error in skip revision workflow:", err);
      showToast("❌ Reschedule failed. Try again.");
    } finally {
      setProcessingId(null);
    }
  };

  // Handler: Mark Remembered in Review Modal
  const handleMarkRemembered = async (item: RevisionItem) => {
    if (processingId) return;
    setProcessingId(item.id);

    try {
      const sched = schedulerService.calculateSchedule(item.timesRevised, "Easy");
      const nextISO = sched.nextReviewDate.toISOString();

      setLocalRescheduledDates((prev) => ({ ...prev, [item.id]: nextISO }));
      reviseMistake(item.id);
      addXp(100);

      showToast("✓ Marked Remembered (+100 XP)");
      setActiveReviewItem(null);
    } catch (err) {
      console.error("Error marking remembered:", err);
      showToast("❌ Action failed. Try again.");
    } finally {
      setProcessingId(null);
    }
  };

  // 7-Day Agenda Calendar derived from calendarService
  const next7Days = useMemo(() => {
    const autoList = items.filter((i) => !i.isManual);
    const manualList = customPlans.map((cp) => ({ scheduledDate: cp.scheduledDate, status: cp.status }));
    return calendarService.get7DayAgenda(autoList, manualList);
  }, [items, customPlans]);

  const formatDate = (dateStr: string) => {
    if (!dateStr) return "—";
    const d = new Date(dateStr.includes("T") ? dateStr : `${dateStr}T12:00:00Z`);
    if (isNaN(d.getTime())) return dateStr;
    return d.toLocaleDateString("en-US", { month: "short", day: "numeric", timeZone: "UTC" });
  };

  return (
    <WorkspaceLayout title="Revision Plan">

      {/* TOAST FEEDBACK FLOATING BANNER */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="fixed bottom-6 right-6 z-50 bg-slate-900 border border-purple-500/40 text-white px-4 py-3 rounded-xl shadow-xl flex items-center gap-2 text-xs font-semibold"
          >
            <Sparkles className="w-4 h-4 text-purple-400" />
            <span>{toastMessage}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* TOP ACTION BAR: ➕ CREATE REVISION PLAN */}
      <div className="flex items-center justify-between gap-4 pb-2 border-b border-white/[0.06]">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Calendar className="w-5 h-5 text-purple-400" />
            Smart & Custom Revision Hub
          </h2>
          <p className="text-xs text-gray-400">
            Coexisting automatic SM-2 spaced repetition and manual custom revision plans.
          </p>
        </div>

        <Button
          onClick={openCreateModal}
          variant="primary"
          size="sm"
          className="font-bold shrink-0 shadow-lg shadow-purple-600/20"
        >
          <Plus className="w-4 h-4" /> ➕ Create Revision Plan
        </Button>
      </div>

      {/* TOP SECTION: 3 COMPACT STAT CARDS */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Due Today */}
        <Card variant="glass" className="p-4 border-l-4 border-l-red-500 flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider block">Due Today</span>
            <span className="text-2xl font-black text-white">{dueTodayItems.length}</span>
            <p className="text-[10px] text-red-400 font-medium">Needs review</p>
          </div>
          <div className="w-10 h-10 rounded-xl bg-red-500/10 border border-red-500/20 flex items-center justify-center text-red-400 shrink-0">
            <Clock className="w-5 h-5" />
          </div>
        </Card>

        {/* Scheduled Ahead */}
        <Card variant="glass" className="p-4 border-l-4 border-l-blue-500 flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider block">Upcoming</span>
            <span className="text-2xl font-black text-white">{upcomingItems.length}</span>
            <p className="text-[10px] text-blue-400 font-medium">In spaced cycles</p>
          </div>
          <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400 shrink-0">
            <CalendarRange className="w-5 h-5" />
          </div>
        </Card>

        {/* Revision Streak */}
        <Card variant="glass" className="p-4 border-l-4 border-l-amber-500 flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider block">Streak</span>
            <span className="text-2xl font-black text-white">7 Days</span>
            <p className="text-[10px] text-amber-400 font-medium">Consistent daily revisions</p>
          </div>
          <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 shrink-0">
            <Flame className="w-5 h-5 fill-amber-500/20" />
          </div>
        </Card>
      </div>

      {/* ---- RANDOM REVISION PICKER CARD (QUICK REVISION) ---- */}
      <Card variant="glass" className="p-4 md:p-5 border-l-4 border-l-purple-500 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="space-y-1">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Dices className="w-4 h-4 text-purple-400" />
              🎲 Random Revision
            </h3>
            <p className="text-xs text-gray-400">
              Not sure what to revise? Let FocusForge choose one or two topics for a quick revision session.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <Button
              onClick={() => setShowPickerFilters(!showPickerFilters)}
              variant="ghost"
              size="sm"
              className="text-xs text-gray-400 hover:text-white"
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              {showPickerFilters ? "Hide Filters" : "Filters"}
            </Button>

            <Button
              onClick={handleGenerateRandom}
              disabled={isGeneratingRandom}
              variant="primary"
              size="sm"
              className="font-bold"
            >
              {isGeneratingRandom ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Dices className="w-4 h-4" />
              )}
              🎲 {randomRecommendations.length > 0 ? "Generate Again" : "Generate"}
            </Button>

            {randomRecommendations.length > 0 && (
              <Button
                onClick={() => setRandomRecommendations([])}
                variant="ghost"
                size="sm"
                className="text-xs text-gray-400 hover:text-white hover:bg-white/10"
                title="Minimize Random Revision"
              >
                <X className="w-3.5 h-3.5" />
                Close
              </Button>
            )}
          </div>
        </div>

        {/* Optional Collapsible Filter Options */}
        {showPickerFilters && (
          <div className="p-3 bg-slate-900/80 rounded-xl border border-white/[0.08] grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <div>
              <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1">Subject</label>
              <select
                value={pickerSubject}
                onChange={(e) => setPickerSubject(e.target.value)}
                className="w-full bg-slate-950 border border-white/10 rounded-lg p-1.5 text-xs text-white"
              >
                <option value="All">All Subjects</option>
                {subjects.map((s) => (
                  <option key={s} value={s}>
                    {s === "Maths" ? "Mathematics" : s}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1">Difficulty</label>
              <select
                value={pickerDifficulty}
                onChange={(e) => setPickerDifficulty(e.target.value as "All" | "Easy" | "Medium" | "Hard")}
                className="w-full bg-slate-950 border border-white/10 rounded-lg p-1.5 text-xs text-white"
              >
                <option value="All">All Difficulties</option>
                <option value="Easy">Easy</option>
                <option value="Medium">Medium</option>
                <option value="Hard">Hard</option>
              </select>
            </div>

            <div>
              <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1">Weightage</label>
              <select
                value={pickerWeightage}
                onChange={(e) => setPickerWeightage(e.target.value as "All" | "High")}
                className="w-full bg-slate-950 border border-white/10 rounded-lg p-1.5 text-xs text-white"
              >
                <option value="All">All Weightages</option>
                <option value="High">High Weightage Only</option>
              </select>
            </div>
          </div>
        )}

        {/* Recommendations Output Area */}
        {randomRecommendations.length === 0 ? (
          <div className="p-6 bg-slate-900/40 border border-dashed border-white/[0.08] rounded-xl text-center text-xs text-gray-400">
            Press <span className="font-bold text-purple-300">Generate</span> to receive random revision topics.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
            {randomRecommendations.map((rec) => (
              <div
                key={rec.id}
                className="p-3.5 bg-slate-900/80 border border-purple-500/20 rounded-xl space-y-2.5 flex flex-col justify-between"
              >
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-1.5">
                      <Badge
                        variant={
                          rec.subject === "Physics"
                            ? "cyan"
                            : rec.subject === "Chemistry"
                              ? "green"
                              : "amber"
                        }
                      >
                        {rec.subject}
                      </Badge>
                      <Badge variant="gray">{rec.difficulty}</Badge>
                    </div>

                    <span className="text-[10px] font-mono text-purple-300 font-semibold flex items-center gap-1">
                      <TrendingUp className="w-3 h-3 text-purple-400" /> {rec.weightagePct}% Weight
                    </span>
                  </div>

                  <h4 className="text-xs font-bold text-white">{rec.chapter}</h4>
                  <p className="text-xs text-purple-200 font-semibold">{rec.subchapter}</p>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-white/[0.06] text-[11px]">
                  <span className="text-gray-400 font-mono">Est: {rec.estimatedMinutes} min</span>

                  <div className="flex items-center gap-1.5">
                    <Button
                      onClick={() =>
                        setActiveReviewItem({
                          id: rec.id,
                          subject: rec.subject,
                          chapter: rec.chapter,
                          topic: rec.subchapter,
                          formula: rec.formula,
                          notes: rec.notes,
                          lastRevisedAt: new Date().toISOString(),
                          nextRevisionAt: new Date().toISOString(),
                          timesRevised: 1,
                          completed: false,
                          status: "Due Today",
                        })
                      }
                      variant="primary"
                      size="sm"
                    >
                      <Zap className="w-3 h-3" />
                      Start
                    </Button>

                    <Button
                      onClick={handleGenerateRandom}
                      variant="ghost"
                      size="sm"
                      className="text-gray-400 hover:text-white"
                    >
                      Again
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      {/* MAIN CONTENT: REVISION QUEUE (LEFT) + MINI CALENDAR (RIGHT) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

        {/* LEFT COLUMN: FILTERS & REVISION CARDS (2 COLS) */}
        <div className="lg:col-span-2 space-y-4">

          {/* FILTER BAR & SEARCH */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            {/* Filter Tabs */}
            <div className="flex items-center gap-1.5 p-1 bg-slate-900/60 rounded-xl border border-white/[0.08] w-fit flex-wrap">
              {[
                { id: "all", label: "All" },
                { id: "today", label: "Today" },
                { id: "upcoming", label: "Upcoming" },
                { id: "completed", label: "Completed" },
                { id: "manual", label: "🟣 Manual" },
              ].map((tab) => {
                const active = activeFilter === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveFilter(tab.id as FilterTab)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${active
                        ? "bg-purple-600 text-white shadow-sm"
                        : "text-gray-400 hover:text-white"
                      }`}
                  >
                    {tab.label}
                  </button>
                );
              })}
            </div>

            {/* Search Input */}
            <div className="relative w-full sm:w-64">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Search topics..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 bg-slate-900/60 border border-white/[0.08] rounded-xl text-xs text-white placeholder-gray-500 focus:outline-none focus:border-purple-500 transition-colors"
              />
            </div>
          </div>

          {/* REVISION CARDS QUEUE */}
          <div className="space-y-3">
            {filteredItems.length === 0 ? (
              <Card variant="glass" className="p-10 text-center text-xs text-gray-400 space-y-2">
                <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto opacity-80" />
                <p className="text-sm font-semibold text-white">No Revisions Found</p>
                <p className="text-gray-400">All set! Revisions for this filter are complete.</p>
              </Card>
            ) : (
              filteredItems.map((item) => {
                const isProcessing = processingId === item.id;

                return (
                  <Card
                    key={item.id}
                    variant="glass"
                    className={`p-4 border-l-4 transition-all ${item.subject === "Physics"
                        ? "border-l-[#3b82f6] bg-[#15222b]/30"
                        : item.subject === "Chemistry"
                          ? "border-l-[#10b981] bg-[#132625]/30"
                          : item.subject === "Botany"
                            ? "border-l-[#10b981] bg-[#0f241d]/30"
                            : item.subject === "Zoology"
                              ? "border-l-[#8b5cf6] bg-[#221633]/30"
                              : "border-l-[#f59e0b] bg-[#231815]/30"
                      }`}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      {/* Left Details */}
                      <div className="space-y-1.5">
                        <div className="flex items-center gap-2 flex-wrap">
                          <Badge
                            variant={
                              item.subject === "Physics"
                                ? "physics"
                                : item.subject === "Chemistry"
                                  ? "chemistry"
                                  : item.subject === "Botany"
                                    ? "botany"
                                    : item.subject === "Zoology"
                                      ? "zoology"
                                      : "maths"
                            }
                          >
                            {item.subject}
                          </Badge>

                          {item.isManual ? (
                            <span className="px-2 py-0.5 rounded-md bg-purple-500/20 border border-purple-500/30 text-purple-300 text-[10px] font-bold flex items-center gap-1">
                              🟣 Manual Plan
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded-md bg-blue-500/20 border border-blue-500/30 text-blue-300 text-[10px] font-bold flex items-center gap-1">
                              🔵 Auto Plan
                            </span>
                          )}

                          {item.priority && (
                            <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${item.priority === "High" ? "bg-red-500/20 text-red-300" : "bg-gray-500/20 text-gray-300"
                              }`}>
                              {item.priority} Priority
                            </span>
                          )}

                          {item.tag && (
                            <span className="px-1.5 py-0.5 rounded bg-slate-800 text-gray-400 text-[10px] font-mono flex items-center gap-0.5">
                              <Tag className="w-2.5 h-2.5" /> {item.tag}
                            </span>
                          )}
                        </div>

                        <h3 className="text-sm font-bold text-white">{item.topic}</h3>
                        <p className="text-xs text-gray-300 font-medium">{item.chapter}</p>

                        <div className="flex items-center gap-4 text-[11px] text-gray-400 font-mono">
                          <span>Scheduled: {formatDate(item.nextRevisionAt)}</span>
                          {item.estimatedTime && <span>· Est: {item.estimatedTime} min</span>}
                        </div>
                      </div>

                      {/* Right Action Buttons */}
                      <div className="flex items-center gap-2 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-white/[0.06] flex-wrap">
                        <Button
                          onClick={() => setActiveReviewItem(item)}
                          disabled={isProcessing}
                          variant="primary"
                          size="sm"
                        >
                          <BookOpen className="w-3.5 h-3.5" />
                          Review
                        </Button>

                        {item.isManual && (
                          <Button
                            onClick={() => {
                              const plan = customPlans.find((p) => p.id === item.id);
                              if (plan) openEditModal(plan);
                            }}
                            variant="ghost"
                            size="sm"
                            className="text-gray-400 hover:text-white"
                            title="Reschedule / Edit Plan"
                          >
                            <Calendar className="w-3.5 h-3.5 text-purple-400" />
                            Reschedule
                          </Button>
                        )}

                        <Button
                          onClick={() => handleMarkComplete(item)}
                          disabled={isProcessing || item.completed}
                          variant="secondary"
                          size="sm"
                        >
                          {isProcessing ? (
                            <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          ) : (
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                          )}
                          {item.completed ? "Completed" : "Complete"}
                        </Button>

                        <Button
                          onClick={() => setSkipDialogItem(item)}
                          disabled={isProcessing || item.completed}
                          variant="ghost"
                          size="sm"
                          className="text-gray-400 hover:text-white"
                        >
                          <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
                          Skip
                        </Button>

                        {item.isManual && (
                          <Button
                            onClick={() => {
                              const plan = customPlans.find((p) => p.id === item.id);
                              if (plan) setDeleteConfirmPlan(plan);
                            }}
                            variant="ghost"
                            size="sm"
                            className="text-red-400 hover:text-red-300"
                            title="Delete Plan"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        )}
                      </div>
                    </div>
                  </Card>
                );
              })
            )}
          </div>
        </div>

        {/* RIGHT COLUMN: MINI 7-DAY CALENDAR (1 COL) */}
        <div className="space-y-4">
          <Card variant="glass" className="p-4 space-y-4">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center justify-between">
              <span className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-purple-400" /> 7-Day Agenda
              </span>
              <span className="text-[10px] text-purple-300 font-mono">🟣 Manual + 🔵 Auto</span>
            </h3>

            <div className="grid grid-cols-7 gap-1.5 text-center">
              {next7Days.map((day, i) => (
                <div
                  key={i}
                  className={`p-2 rounded-xl border transition-all text-center ${day.isToday
                      ? "bg-purple-600 border-purple-400 text-white font-bold"
                      : day.totalCount > 0
                        ? "bg-purple-500/20 border-purple-500/40 text-white"
                        : "bg-white/[0.02] border-white/[0.06] text-gray-400"
                    }`}
                >
                  <span className="text-[9px] block uppercase font-bold text-gray-400">{day.dayName}</span>
                  <span className="text-xs font-black block mt-0.5 font-mono">{day.dayNum}</span>
                  {day.totalCount > 0 && (
                    <div className="flex items-center justify-center gap-0.5 mt-1">
                      {day.manualCount > 0 && <span className="w-1.5 h-1.5 rounded-full bg-purple-400" />}
                      {day.autoCount > 0 && <span className="w-1.5 h-1.5 rounded-full bg-blue-400" />}
                    </div>
                  )}
                </div>
              ))}
            </div>

            <p className="text-[11px] text-gray-400 leading-relaxed pt-2 border-t border-white/[0.06]">
              Keep your revision streak active by resolving all items due today.
            </p>
          </Card>
        </div>
      </div>

      {/* ---- ➕ CREATE / EDIT CUSTOM REVISION PLAN MODAL ---- */}
      <AnimatePresence>
        {showPlanModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4 overflow-y-auto"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-[#0f1117] border border-white/15 rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl space-y-0"
            >
              {/* Modal Header */}
              <div className="p-4 bg-slate-900/90 border-b border-white/10 flex items-center justify-between">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-purple-400" />
                  {editingPlanId ? "Edit Revision Plan" : "📅 Create Custom Revision Plan"}
                </h3>
                <button onClick={() => setShowPlanModal(false)} className="text-gray-400 hover:text-white">
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Modal Form Body */}
              <div className="p-5 space-y-3.5 text-xs max-h-[75vh] overflow-y-auto">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1">Subject</label>
                    <select
                      value={formSubject}
                      onChange={(e) => setFormSubject(e.target.value)}
                      className="w-full bg-slate-950 border border-white/10 rounded-xl p-2 text-xs text-white"
                    >
                      {subjects.map((s) => (
                        <option key={s} value={s}>
                          {s === "Maths" ? "Mathematics" : s}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1">Priority</label>
                    <select
                      value={formPriority}
                      onChange={(e) => setFormPriority(e.target.value as "Low" | "Medium" | "High")}
                      className="w-full bg-slate-950 border border-white/10 rounded-xl p-2 text-xs text-white"
                    >
                      <option value="Low">Low Priority</option>
                      <option value="Medium">Medium Priority</option>
                      <option value="High">High Priority</option>
                    </select>
                  </div>
                </div>

                <div className="relative">
                  <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1">Chapter Name *</label>
                  <input
                    type="text"
                    placeholder="Type e.g. Electrostatics, Chemical Bonding..."
                    value={formChapter}
                    onFocus={() => setShowChapterSuggestions(true)}
                    onChange={(e) => {
                      setFormChapter(e.target.value);
                      setShowChapterSuggestions(true);
                    }}
                    className="w-full bg-slate-950 border border-white/10 rounded-xl p-2 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-purple-500"
                  />

                  {/* Autocomplete Dropdown Suggestions */}
                  {showChapterSuggestions && chapterSuggestions.length > 0 && (
                    <div className="absolute left-0 right-0 top-full mt-1 bg-slate-900 border border-purple-500/40 rounded-xl shadow-2xl z-50 max-h-48 overflow-y-auto divide-y divide-white/[0.06]">
                      {chapterSuggestions.map((chap) => {
                        const firstTopic = chap.topics && chap.topics.length > 0
                          ? chap.topics[0]
                          : chap.subchapters && chap.subchapters.length > 0
                            ? chap.subchapters[0].name
                            : "";
                        return (
                          <button
                            key={chap.id}
                            type="button"
                            onClick={() => {
                              setFormChapter(chap.name);
                              if (!formSubchapter && firstTopic) {
                                setFormSubchapter(firstTopic);
                              }
                              if (!formTitle) {
                                setFormTitle(`${chap.name} Revision`);
                              }
                              setShowChapterSuggestions(false);
                            }}
                            className="w-full text-left p-2.5 hover:bg-purple-600/20 text-xs text-white flex items-center justify-between transition-colors"
                          >
                            <span className="font-semibold text-purple-200">{chap.name}</span>
                            <span className="text-[10px] text-gray-400 font-mono">
                              {chap.classLevel} · {chap.weightage}% Weight
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>

                <div>
                  <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1">Subchapter / Topic (Optional)</label>
                  <input
                    type="text"
                    placeholder="e.g. Electric Dipole, Hybridization..."
                    value={formSubchapter}
                    onChange={(e) => setFormSubchapter(e.target.value)}
                    className="w-full bg-slate-950 border border-white/10 rounded-xl p-2 text-xs text-white placeholder-gray-500"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1">Revision Title *</label>
                  <input
                    type="text"
                    placeholder="e.g. Formula Recap & PYQ Practice..."
                    value={formTitle}
                    onChange={(e) => setFormTitle(e.target.value)}
                    className="w-full bg-slate-950 border border-white/10 rounded-xl p-2 text-xs text-white placeholder-gray-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1">Scheduled Date *</label>
                    <input
                      type="date"
                      min={new Date().toISOString().split("T")[0]}
                      value={formScheduledDate}
                      onChange={(e) => setFormScheduledDate(e.target.value)}
                      className="w-full bg-slate-950 border border-white/10 rounded-xl p-2 text-xs text-white"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1">Est. Duration (Min)</label>
                    <input
                      type="number"
                      min={5}
                      max={120}
                      value={formEstimatedTime}
                      onChange={(e) => setFormEstimatedTime(Number(e.target.value))}
                      className="w-full bg-slate-950 border border-white/10 rounded-xl p-2 text-xs text-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1">Repeat</label>
                    <select
                      value={formRepeat}
                      onChange={(e) => setFormRepeat(e.target.value as "None" | "Daily" | "Weekly" | "Monthly")}
                      className="w-full bg-slate-950 border border-white/10 rounded-xl p-2 text-xs text-white"
                    >
                      <option value="None">None</option>
                      <option value="Daily">Daily</option>
                      <option value="Weekly">Weekly</option>
                      <option value="Monthly">Monthly</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1">Custom Tag</label>
                    <select
                      value={formTag}
                      onChange={(e) => setFormTag(e.target.value as "Formula" | "Theory" | "PYQ" | "Weak Topic" | "Mock Test")}
                      className="w-full bg-slate-950 border border-white/10 rounded-xl p-2 text-xs text-white"
                    >
                      <option value="Formula">Formula</option>
                      <option value="Theory">Theory</option>
                      <option value="PYQ">PYQ</option>
                      <option value="Weak Topic">Weak Topic</option>
                      <option value="Mock Test">Mock Test</option>
                      <option value="Concept">Concept</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1">Revision Notes (Optional)</label>
                  <textarea
                    rows={2}
                    placeholder="Add specific notes or focus points..."
                    value={formNotes}
                    onChange={(e) => setFormNotes(e.target.value)}
                    className="w-full bg-slate-950 border border-white/10 rounded-xl p-2 text-xs text-white placeholder-gray-500"
                  />
                </div>
              </div>

              {/* Modal Footer */}
              <div className="p-4 bg-slate-950 border-t border-white/10 flex items-center justify-end gap-2">
                <Button onClick={() => setShowPlanModal(false)} variant="ghost" size="sm" className="text-gray-400">
                  Cancel
                </Button>
                <Button onClick={handleSaveCustomPlan} variant="primary" size="sm" className="font-bold">
                  <Check className="w-4 h-4" /> Save Revision Plan
                </Button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ---- DELETE CONFIRMATION DIALOG MODAL ---- */}
      <AnimatePresence>
        {deleteConfirmPlan && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-[#0f1117] border border-white/15 rounded-2xl w-full max-w-md p-6 space-y-4 shadow-2xl"
            >
              <div className="flex items-center gap-3 text-red-400">
                <AlertCircle className="w-6 h-6 shrink-0" />
                <h3 className="text-base font-bold text-white">Delete Custom Revision Plan</h3>
              </div>

              <p className="text-xs text-gray-300 leading-relaxed">
                Are you sure you want to delete <span className="font-bold text-white">{`"${deleteConfirmPlan.title}"`}</span>? This action cannot be undone.
              </p>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-white/[0.08]">
                <Button onClick={() => setDeleteConfirmPlan(null)} variant="ghost" size="sm" className="text-gray-400">
                  Cancel
                </Button>
                <Button onClick={() => handleDeleteCustomPlan(deleteConfirmPlan)} variant="primary" size="sm" className="bg-red-600 hover:bg-red-500 text-white font-bold">
                  Delete Plan
                </Button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ---- REVIEW MODE OVERLAY MODAL ---- */}
      <AnimatePresence>
        {activeReviewItem && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-[#0f1117] border border-white/15 rounded-2xl w-full max-w-xl overflow-hidden shadow-2xl space-y-0"
            >
              {/* Modal Header */}
              <div className="p-4 bg-slate-900/90 border-b border-white/10 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Badge
                    variant={
                      activeReviewItem.subject === "Physics"
                        ? "cyan"
                        : activeReviewItem.subject === "Chemistry"
                          ? "green"
                          : "amber"
                    }
                  >
                    {activeReviewItem.subject}
                  </Badge>
                  <span className="text-xs font-bold text-white">{activeReviewItem.chapter}</span>
                </div>

                <button onClick={() => setActiveReviewItem(null)} className="text-gray-400 hover:text-white">
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Modal Body */}
              <div className="p-6 space-y-4">
                <div>
                  <span className="text-[10px] font-bold text-purple-400 uppercase tracking-wider block mb-1">
                    Topic / Concept:
                  </span>
                  <h3 className="text-base font-bold text-white leading-relaxed">
                    {activeReviewItem.topic}
                  </h3>
                </div>

                {activeReviewItem.formula && (
                  <div className="p-3 bg-purple-500/10 border border-purple-500/20 rounded-xl space-y-1">
                    <span className="text-[10px] font-bold text-purple-300 uppercase tracking-wider block">
                      Key Formula:
                    </span>
                    <p className="text-sm font-mono text-white font-semibold">
                      {activeReviewItem.formula}
                    </p>
                  </div>
                )}

                {activeReviewItem.notes && (
                  <div className="p-3.5 bg-slate-900/80 border border-white/[0.08] rounded-xl space-y-1">
                    <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">
                      Study Notes & Key Concept:
                    </span>
                    <p className="text-xs text-gray-200 leading-relaxed whitespace-pre-line">
                      {activeReviewItem.notes}
                    </p>
                  </div>
                )}
              </div>

              {/* Modal Footer Actions */}
              <div className="p-4 bg-slate-950 border-t border-white/10 flex flex-wrap items-center justify-between gap-2">
                <Button onClick={() => setActiveReviewItem(null)} variant="ghost" size="sm" className="text-gray-400">
                  <ArrowLeft className="w-4 h-4" /> Close
                </Button>

                <div className="flex items-center gap-2">
                  <Button
                    onClick={() => handleSkipConfirm(activeReviewItem)}
                    disabled={!!processingId}
                    variant="secondary"
                    size="sm"
                  >
                    <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
                    Needs Revision Again
                  </Button>

                  <Button
                    onClick={() => handleMarkRemembered(activeReviewItem)}
                    disabled={!!processingId}
                    variant="primary"
                    size="sm"
                  >
                    <Check className="w-3.5 h-3.5" />
                    Mark Remembered
                  </Button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ---- SKIP CONFIRMATION DIALOG MODAL ---- */}
      <AnimatePresence>
        {skipDialogItem && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-[#0f1117] border border-white/15 rounded-2xl w-full max-w-md p-6 space-y-4 shadow-2xl"
            >
              <div className="flex items-center gap-3 text-amber-400">
                <AlertCircle className="w-6 h-6 shrink-0" />
                <h3 className="text-base font-bold text-white">Skip Revision Confirmation</h3>
              </div>

              <p className="text-xs text-gray-300 leading-relaxed">
                Postpone revision for <span className="font-bold text-white">{`"${skipDialogItem.topic}"`}</span>? This will move the item to tomorrow&apos;s queue without marking it complete.
              </p>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-white/[0.08]">
                <Button onClick={() => setSkipDialogItem(null)} variant="ghost" size="sm" className="text-gray-400">
                  Cancel
                </Button>

                <Button
                  onClick={() => handleSkipConfirm(skipDialogItem)}
                  disabled={!!processingId}
                  variant="secondary"
                  size="sm"
                >
                  {processingId === skipDialogItem.id ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
                  )}
                  Skip Today
                </Button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </WorkspaceLayout>
  );
}
