"use client";

import React, { useState, useEffect, useRef, useId, Suspense } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@/context/AuthContext";
import { soundManager } from "@/lib/sound-manager";
import {
  Mail,
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  AlertCircle,
  Zap,
  RefreshCw,
  Clock,
  Shield,
} from "lucide-react";

// RFC-compliant practical email validation pattern
const EMAIL_REGEX = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

function ForgotPasswordContent() {
  const searchParams = useSearchParams();
  const { resetPassword } = useAuth();
  const emailInputId = useId();

  const [email, setEmail] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [cooldown, setCooldown] = useState(0);

  // Synchronous atomic submission lock to prevent double-clicks, Enter key races, and concurrent calls
  const isSubmittingRef = useRef<boolean>(false);

  // Check for any callback error in query params (e.g. invalid/expired link redirect)
  useEffect(() => {
    const errorParam = searchParams.get("error");
    if (errorParam) {
      setErrorMessage(decodeURIComponent(errorParam));
    }
  }, [searchParams]);

  // Resend cooldown timer (purely client-side UI counter; does NOT touch network)
  useEffect(() => {
    if (cooldown <= 0) return;
    const timer = setInterval(() => {
      setCooldown((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, [cooldown]);

  const validateEmail = (val: string): boolean => {
    return EMAIL_REGEX.test(val.trim());
  };

  const handleSendReset = async (targetEmail: string) => {
    // 1. Synchronous gatekeeper: guarantee 1 user action = 1 network request
    if (isSubmittingRef.current || cooldown > 0) {
      return;
    }

    const cleanEmail = targetEmail.trim().toLowerCase();

    if (!cleanEmail) {
      soundManager.play("error");
      setErrorMessage("Please enter your email address.");
      return;
    }

    if (!validateEmail(cleanEmail)) {
      soundManager.play("error");
      setErrorMessage("Please enter a valid email address.");
      return;
    }

    // Acquire lock immediately and synchronously before any async tick
    isSubmittingRef.current = true;
    setIsLoading(true);
    setErrorMessage("");
    soundManager.play("select");

    try {
      await resetPassword(cleanEmail);
      // Supabase succeeded or accepted request
      soundManager.play("success");
      setIsSubmitted(true);
      setCooldown(60);
    } catch (err: unknown) {
      const errorObj = err as { message?: string; status?: number; code?: string };
      const rawMsg = errorObj?.message || "";
      const lower = rawMsg.toLowerCase();

      // Specifically differentiate Supabase rate limits (429 / over_email_send_rate_limit / over_request_rate_limit)
      if (
        lower.includes("rate limit") ||
        lower.includes("too many requests") ||
        lower.includes("over_email_send_rate_limit") ||
        lower.includes("over_request_rate_limit") ||
        errorObj?.status === 429
      ) {
        soundManager.play("error");
        setErrorMessage(
          "Too many reset requests were made recently. Supabase limits email delivery to protect your account. Please wait before requesting another email."
        );
        // Start a 60s cooldown lock on the form itself so user cannot hammer the button
        setCooldown(60);
      } else if (
        lower.includes("network") ||
        lower.includes("failed to fetch") ||
        lower.includes("connection")
      ) {
        soundManager.play("error");
        setErrorMessage("Network error. Please check your internet connection and try again.");
      } else {
        // ANTI-ENUMERATION: Present uniform confirmation screen to protect user privacy
        soundManager.play("success");
        setIsSubmitted(true);
        setCooldown(60);
      }
    } finally {
      isSubmittingRef.current = false;
      setIsLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmittingRef.current || isLoading || cooldown > 0) return;
    await handleSendReset(email);
  };

  const handleResend = async () => {
    if (isSubmittingRef.current || isLoading || cooldown > 0) return;
    await handleSendReset(email);
  };

  return (
    <div className="min-h-screen w-full bg-[#08090d] text-gray-100 flex flex-col justify-between font-sans antialiased selection:bg-purple-500/30 selection:text-purple-200">
      {/* Background Ambience Gradients */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute -top-40 left-1/2 -translate-x-1/2 w-[700px] h-[500px] bg-gradient-to-b from-purple-600/10 via-indigo-600/5 to-transparent rounded-full blur-3xl opacity-70" />
        <div className="absolute -bottom-40 right-10 w-[500px] h-[400px] bg-gradient-to-t from-cyan-600/10 to-transparent rounded-full blur-3xl opacity-50" />
      </div>

      {/* Top Header / Branding */}
      <header className="relative z-10 w-full max-w-5xl mx-auto px-6 py-6 sm:py-8 flex items-center justify-between">
        <Link
          href="/"
          className="flex items-center gap-2.5 group transition-transform hover:scale-[1.02] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-purple-400 rounded-xl"
        >
          <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-2xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-cyan-500 text-white flex items-center justify-center font-black shadow-lg shadow-purple-950/40 border border-white/10 shrink-0">
            <Zap className="w-4 h-4 sm:w-5 sm:h-5 fill-white" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-bold text-lg tracking-tight text-white">FocusForge</span>
              <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-purple-500/10 text-purple-300 border border-purple-500/20">
                Security
              </span>
            </div>
            <span className="text-[10px] font-mono text-cyan-400 block -mt-0.5">Cloud Study OS</span>
          </div>
        </Link>

        <Link
          href="/login"
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 text-xs font-medium text-gray-300 hover:text-white transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-purple-400"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back to Login</span>
        </Link>
      </header>

      {/* Main Content Area */}
      <main className="relative z-10 w-full max-w-md mx-auto px-4 sm:px-6 my-auto py-8">
        <div className="glass-panel p-6 sm:p-8 rounded-3xl border border-white/10 shadow-2xl relative overflow-hidden backdrop-blur-2xl bg-slate-950/80">
          {/* Subtle Corner Glow */}
          <div className="absolute -top-12 -right-12 w-32 h-32 bg-purple-500/15 rounded-full blur-2xl pointer-events-none" />

          <AnimatePresence mode="wait">
            {!isSubmitted ? (
              /* Request Reset Form */
              <motion.div
                key="form"
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.25 }}
              >
                <div className="w-11 h-11 rounded-2xl bg-purple-500/10 border border-purple-500/20 text-purple-400 flex items-center justify-center mb-5">
                  <Shield className="w-5 h-5" />
                </div>

                <div className="mb-6">
                  <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white uppercase mb-2">
                    Forgot Your Password?
                  </h1>
                  <p className="text-xs sm:text-sm text-gray-400 leading-relaxed font-normal">
                    Enter the email associated with your Focus Forge account and we&apos;ll send you a secure password reset link.
                  </p>
                </div>

                {/* Error Banner */}
                {errorMessage && (
                  <motion.div
                    initial={{ opacity: 0, y: -4 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mb-5 p-3.5 rounded-xl bg-red-500/10 border border-red-500/30 text-red-300 text-xs font-medium flex items-start gap-2.5"
                    role="alert"
                  >
                    <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                    <span className="leading-relaxed">{errorMessage}</span>
                  </motion.div>
                )}

                <form onSubmit={handleSubmit} className="space-y-5" noValidate>
                  <div>
                    <label
                      htmlFor={emailInputId}
                      className="block text-[11px] font-bold uppercase tracking-wider text-gray-300 mb-2"
                    >
                      Email Address
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-500">
                        <Mail className="w-4 h-4" />
                      </div>
                      <input
                        id={emailInputId}
                        type="email"
                        autoComplete="email"
                        required
                        value={email}
                        onChange={(e) => {
                          setEmail(e.target.value);
                          if (errorMessage) setErrorMessage("");
                        }}
                        placeholder="aspirant@focusforge.app"
                        className="w-full pl-10 pr-4 py-3 rounded-xl text-sm font-medium transition-all focus:outline-none bg-slate-900/80 border border-white/10 text-white placeholder-gray-500 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20"
                        disabled={isLoading || cooldown > 0}
                        aria-invalid={!!errorMessage}
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={isLoading || cooldown > 0}
                    className="w-full py-3.5 px-5 rounded-xl bg-gradient-to-r from-purple-600 via-indigo-600 to-cyan-500 text-white font-bold text-sm tracking-wide shadow-xl shadow-purple-950/50 hover:brightness-110 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isLoading ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        <span>Sending reset link...</span>
                      </>
                    ) : cooldown > 0 ? (
                      <>
                        <Clock className="w-4 h-4 text-purple-200" />
                        <span>Please wait ({cooldown}s)</span>
                      </>
                    ) : (
                      <>
                        <span>Send Reset Link</span>
                        <ArrowRight className="w-4 h-4" />
                      </>
                    )}
                  </button>

                  <div className="pt-2 text-center">
                    <Link
                      href="/login"
                      className="inline-flex items-center gap-1.5 text-xs font-semibold text-gray-400 hover:text-white transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-purple-400 rounded"
                    >
                      <ArrowLeft className="w-3.5 h-3.5" />
                      <span>Back to Login</span>
                    </Link>
                  </div>
                </form>
              </motion.div>
            ) : (
              /* Confirmation State (Anti-Enumeration Secure Screen) */
              <motion.div
                key="confirmed"
                initial={{ opacity: 0, scale: 0.96 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.96 }}
                transition={{ duration: 0.25 }}
                className="text-center"
              >
                <div className="w-14 h-14 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center mx-auto mb-5">
                  <CheckCircle2 className="w-7 h-7" />
                </div>

                <h2 className="text-xl sm:text-2xl font-black tracking-tight text-white uppercase mb-2">
                  Check Your Email
                </h2>

                <p className="text-xs sm:text-sm text-gray-300 leading-relaxed mb-3">
                  If an account exists for <span className="font-semibold text-white">{email}</span>, we&apos;ve sent a password reset link.
                </p>

                <p className="text-xs text-gray-400 leading-relaxed mb-6 bg-slate-900/60 border border-white/[0.06] p-3 rounded-xl">
                  You may need to check your spam or junk folder. The link will remain valid for a limited time.
                </p>

                <div className="space-y-3">
                  <Link
                    href="/login"
                    className="w-full py-3.5 px-5 rounded-xl bg-gradient-to-r from-purple-600 via-indigo-600 to-cyan-500 text-white font-bold text-sm tracking-wide shadow-xl shadow-purple-950/50 hover:brightness-110 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <span>Back to Login</span>
                    <ArrowRight className="w-4 h-4" />
                  </Link>

                  <button
                    type="button"
                    onClick={handleResend}
                    disabled={cooldown > 0 || isLoading}
                    className="w-full py-2.5 px-4 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] text-gray-300 font-semibold text-xs transition-all flex items-center justify-center gap-2 border border-white/10 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {cooldown > 0 ? (
                      <>
                        <Clock className="w-3.5 h-3.5 text-purple-400" />
                        <span>Resend in {cooldown}s</span>
                      </>
                    ) : (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 text-cyan-400" />
                        <span>Send Again</span>
                      </>
                    )}
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>

      {/* Footer */}
      <footer className="relative z-10 w-full max-w-md mx-auto px-6 py-4 text-center">
        <p className="text-[11px] text-gray-500 font-mono">
          FocusForge Cloud Operating System • Developed for JEE Aspirants
        </p>
      </footer>
    </div>
  );
}

export default function ForgotPasswordPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen w-full bg-[#08090d] flex items-center justify-center text-cyan-400 font-mono text-xs">
          <div className="w-5 h-5 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin mr-3" />
          <span>Loading Recovery Portal...</span>
        </div>
      }
    >
      <ForgotPasswordContent />
    </Suspense>
  );
}
