"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Sidebar } from "./sidebar";
import { Header } from "./header";
import { SoundPlayer } from "./sound-player";
import { SoundOnboardingToast } from "./ui/sound-onboarding-toast";
import { StudySessionSummaryModal } from "./study/study-session-summary-modal";
import { ExamTrackSelectionModal } from "./modals/exam-track-selection-modal";
import { useStudyStore } from "@/store/use-study-store";
import { useAuth } from "@/context/AuthContext";
import { useKeyboardShortcuts } from "@/hooks/use-keyboard-shortcuts";
import { motion, AnimatePresence } from "framer-motion";

interface WorkspaceLayoutProps {
  children: React.ReactNode;
  title: string;
}

export function WorkspaceLayout({ children, title }: WorkspaceLayoutProps) {
  const { monkModeEnabled, tick, status, coolingBlockUntil } = useStudyStore();
  const { loading, uid } = useAuth();
  const router = useRouter();

  // Mobile sidebar drawer state
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  // Guard against unauthenticated visits to protected workspace
  useEffect(() => {
    if (!loading && !uid) {
      router.replace("/login");
    }
  }, [loading, uid, router]);

  // Register workspace-wide keyboard shortcuts
  useKeyboardShortcuts();

  // Run global study timer tick countdown and cooling block countdown
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;

    if (status === "focus" || status === "break" || !!coolingBlockUntil) {
      interval = setInterval(() => {
        tick();
      }, 1000);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [status, coolingBlockUntil, tick]);

  // Instant timer catch-up when tab becomes visible or receives window focus
  useEffect(() => {
    const handleTabRevisit = () => {
      if (document.visibilityState === "visible" && (status === "focus" || status === "break" || !!coolingBlockUntil)) {
        tick();
      }
    };
    document.addEventListener("visibilitychange", handleTabRevisit);
    window.addEventListener("focus", handleTabRevisit);
    return () => {
      document.removeEventListener("visibilitychange", handleTabRevisit);
      window.removeEventListener("focus", handleTabRevisit);
    };
  }, [status, coolingBlockUntil, tick]);

  // Listen for distraction shield events relayed from the Chrome extension
  useEffect(() => {
    const handleWindowMessage = (event: MessageEvent) => {
      if (event.data?.type === "FOCUSFORGE_DISTRACTION_LOGGED" && event.data.log) {
        const { id, domain, durationSeconds, durationMinutes, blocked, website } = event.data.log;
        const finalSeconds = durationSeconds ?? ((durationMinutes || 0) * 60);
        useStudyStore.getState().recordDistractionTime(
          domain || "unknown",
          finalSeconds,
          id,
          !!blocked,
          website
        );
      } else if (event.data?.type === "FOCUSFORGE_WASTE_TIME_UPDATE" && event.data.log) {
        const { id, domain, durationSeconds, blocked, website } = event.data.log;
        useStudyStore.getState().recordDistractionTime(
          domain || "unknown",
          durationSeconds || 0,
          id,
          !!blocked,
          website
        );
      }
    };

    window.addEventListener("message", handleWindowMessage);
    return () => {
      window.removeEventListener("message", handleWindowMessage);
    };
  }, []);

  if (loading) {
    return (
      <div className="flex h-screen w-screen items-center justify-center bg-[#08090d] text-foreground select-none">
        <div className="flex flex-col items-center gap-4">
          <div className="w-10 h-10 border-2 border-cyan-500/30 border-t-cyan-500 rounded-full animate-spin" />
          <p className="text-xs uppercase tracking-widest text-zinc-400 font-mono">
            Initializing secure session...
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen overflow-hidden bg-[#08090d] text-foreground select-none relative">
      {/* Background ambient glow mesh */}
      <div className="absolute top-[-15%] left-[-15%] w-[55%] h-[55%] rounded-full bg-purple-600/[0.06] blur-[140px] pointer-events-none z-0" />
      <div className="absolute bottom-[-15%] right-[-15%] w-[55%] h-[55%] rounded-full bg-blue-600/[0.06] blur-[140px] pointer-events-none z-0" />

      {/* ---- Mobile backdrop overlay ---- */}
      <AnimatePresence>
        {mobileSidebarOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm md:hidden z-40 cursor-pointer"
            onClick={() => setMobileSidebarOpen(false)}
            aria-hidden="true"
          />
        )}
      </AnimatePresence>

      {/* ---- Sidebar Off-canvas Drawer ---- */}
      <div
        className={`
          fixed inset-y-0 left-0 z-50 md:relative md:flex md:z-auto
          transition-transform duration-300 ease-[cubic-bezier(0.16,1,0.3,1)]
          ${mobileSidebarOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"}
        `}
      >
        <Sidebar onMobileClose={() => setMobileSidebarOpen(false)} />
      </div>

      {/* Main workspace display panel */}
      <div className="flex flex-col flex-1 overflow-hidden relative z-10 min-w-0">
        <Header
          title={title}
          onMobileMenuToggle={() => setMobileSidebarOpen((prev) => !prev)}
        />

        <main
          className={`flex-1 overflow-y-auto relative ${monkModeEnabled ? "bg-black/90 p-3 md:p-4" : "p-3 md:p-6"
            }`}
        >
          {/* Global Ambient Audio Synthesis */}
          <SoundPlayer />

          {/* Global Study Session Summary Modal */}
          <StudySessionSummaryModal />

          {/* First-time Sound Onboarding Prompt */}
          <SoundOnboardingToast />

          {/* First-time Track Onboarding Modal */}
          <ExamTrackSelectionModal />

          <div className="max-w-7xl mx-auto space-y-4 md:space-y-6">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}

export default WorkspaceLayout;

