"use client";

import React, { useState, useEffect } from "react";
import { soundManager, type SoundCategory, type PackName } from "@/lib/sound-manager";
import { Card } from "@/components/ui/card";
import { motion } from "framer-motion";
import {
  Volume2,
  VolumeX,
  Volume1,
  Sliders,
  RotateCcw,
  Sparkles,
  Play,
  Check,
  Shield,
  GraduationCap,
  Bell,
  MousePointer,
  Radio,
  Info,
} from "lucide-react";

interface SoundSettingsPanelProps {
  className?: string;
}

const SOUND_PACKS: Array<{ id: PackName; name: string; desc: string; vibe: string }> = [
  { id: "glass", name: "Glass", desc: "Crystalline, modern, transparent", vibe: "Default" },
  { id: "minimal", name: "Minimal", desc: "Pure, quiet, low-profile sine", vibe: "Calm" },
  { id: "soft", name: "Soft", desc: "Warm felt-padded, organic response", vibe: "Gentle" },
  { id: "zen", name: "Zen", desc: "Acoustic wood & mindful harmonics", vibe: "Focus" },
];

const PREVIEW_CUES: Array<{
  id: string;
  name: string;
  category: SoundCategory;
  cue: string;
  desc: string;
}> = [
  { id: "study-start", name: "Study Session Start", category: "study", cue: "start", desc: "Subtle acoustic commitment tone" },
  { id: "study-check", name: "Focus Milestone", category: "study", cue: "checkpoint", desc: "Mid-session achievement chime" },
  { id: "study-complete", name: "Session Complete", category: "study", cue: "complete", desc: "Satisfying conclusion cadence" },
  { id: "mistake-log", name: "Mistake Journal Log", category: "ui", cue: "stash", desc: "Tactile archive confirmation" },
  { id: "blocker-shield", name: "Distraction Shield", category: "extension", cue: "lock", desc: "Firm defensive lock acoustic" },
  { id: "coach-reply", name: "AI Study Coach Reply", category: "notification", cue: "receive", desc: "Gentle conversational arrival" },
  { id: "level-up", name: "Rank Milestone Up", category: "study", cue: "level-up", desc: "Harmonic victory overtone" },
  { id: "subtle-tap", name: "UI Micro-Tap", category: "ui", cue: "select", desc: "Ultra-brief 80ms interaction response" },
];

export function SoundSettingsPanel({ className = "" }: SoundSettingsPanelProps) {
  const [enabled, setEnabled] = useState(true);
  const [masterVolume, setMasterVolume] = useState(0.7);
  const [activePack, setActivePack] = useState<PackName>("glass");
  const [categoryStates, setCategoryStates] = useState<Record<SoundCategory, boolean>>({
    ui: true,
    study: true,
    navigation: true,
    notification: true,
    extension: true,
    system: true,
  });
  const [categoryVols, setCategoryVols] = useState<Record<SoundCategory, number>>({
    ui: 0.8,
    study: 0.9,
    navigation: 0.7,
    notification: 0.85,
    extension: 0.8,
    system: 0.85,
  });
  const [previewingId, setPreviewingId] = useState<string | null>(null);
  const [resetSuccess, setResetSuccess] = useState(false);

  // Sync state from soundManager on client mount
  useEffect(() => {
    setEnabled(soundManager.isEnabled());
    setMasterVolume(soundManager.getVolume());
    setActivePack(soundManager.getPack());
    const settings = soundManager.getAllCategorySettings();
    setCategoryStates(settings.enabled);
    setCategoryVols(settings.volumes);
  }, []);

  const handleToggleMaster = () => {
    const next = !enabled;
    setEnabled(next);
    soundManager.setEnabled(next);
    if (next) {
      soundManager.previewCue("toggle-on");
    }
  };

  const handleMasterVolume = (val: number) => {
    setMasterVolume(val);
    soundManager.setVolume(val);
    soundManager.playThrottled("volume-change", 120);
  };

  const handlePackChange = (pack: PackName) => {
    setActivePack(pack);
    soundManager.setPack(pack);
    soundManager.previewCue("select");
  };

  const handleCategoryToggle = (category: SoundCategory) => {
    const next = !categoryStates[category];
    setCategoryStates((prev) => ({ ...prev, [category]: next }));
    soundManager.setCategoryEnabled(category, next);
    if (next) {
      soundManager.previewCue("toggle-on");
    }
  };

  const handleCategoryVolume = (category: SoundCategory, val: number) => {
    setCategoryVols((prev) => ({ ...prev, [category]: val }));
    soundManager.setCategoryVolume(category, val);
    soundManager.playThrottled("volume-change", 120);
  };

  const handlePreviewCue = (item: typeof PREVIEW_CUES[0]) => {
    setPreviewingId(item.id);
    soundManager.previewCue(item.cue, item.category);
    setTimeout(() => {
      setPreviewingId(null);
    }, 600);
  };

  const handleTestMaster = () => {
    setPreviewingId("test-master");
    soundManager.previewCue("complete");
    setTimeout(() => {
      setPreviewingId(null);
    }, 700);
  };

  const handleResetDefaults = () => {
    soundManager.resetToDefaults();
    setEnabled(true);
    setMasterVolume(0.7);
    setActivePack("glass");
    const settings = soundManager.getAllCategorySettings();
    setCategoryStates(settings.enabled);
    setCategoryVols(settings.volumes);
    setResetSuccess(true);
    soundManager.previewCue("checkpoint");
    setTimeout(() => setResetSuccess(false), 2000);
  };

  return (
    <div className={`space-y-6 ${className}`}>
      {/* Master Audio Controller Card */}
      <Card
        variant="glass"
        className="p-6 border-purple-500/20 bg-gradient-to-br from-purple-500/10 via-[#0d101d] to-[#08090f] relative overflow-hidden"
      >
        <div className="absolute top-0 right-0 w-80 h-80 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-white/[0.08] relative z-10">
          <div className="flex items-center gap-3.5">
            <div className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-all ${
              enabled
                ? "bg-purple-500/20 border border-purple-500/40 text-purple-300 shadow-[0_0_20px_rgba(147,51,234,0.3)]"
                : "bg-white/[0.04] border border-white/10 text-gray-500"
            }`}>
              {enabled ? <Volume2 className="w-6 h-6" /> : <VolumeX className="w-6 h-6" />}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-white tracking-tight">
                  Master Sound System
                </h3>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase tracking-wider border ${
                  enabled
                    ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-400"
                    : "bg-slate-800 border-white/10 text-gray-500"
                }`}>
                  {enabled ? "Active" : "Muted"}
                </span>
              </div>
              <p className="text-xs text-gray-400 mt-0.5">
                Centralized Web Audio engine powering micro-interactions and focus feedback.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={handleTestMaster}
              disabled={!enabled}
              className="px-3.5 py-2 rounded-xl text-xs font-semibold border border-white/10 bg-white/[0.04] hover:bg-white/[0.08] disabled:opacity-40 disabled:pointer-events-none text-white transition-all flex items-center gap-2 cursor-pointer shadow-sm"
              aria-label="Test master audio cue"
            >
              <Play className={`w-3.5 h-3.5 text-cyan-400 ${previewingId === "test-master" ? "animate-pulse" : ""}`} />
              <span>Test Audio</span>
            </button>

            <button
              type="button"
              role="switch"
              aria-checked={enabled}
              onClick={handleToggleMaster}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all border cursor-pointer ${
                enabled
                  ? "bg-emerald-500/20 border-emerald-500/40 text-emerald-300 shadow-[0_0_15px_rgba(16,185,129,0.25)]"
                  : "bg-slate-900 border-white/10 text-gray-400 hover:text-white"
              }`}
            >
              {enabled ? "Mute All" : "Unmute All"}
            </button>
          </div>
        </div>

        {/* Master Volume & Sound Theme Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-6 relative z-10">
          {/* Master Volume Slider */}
          <div className="space-y-2.5">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-gray-300 flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5 text-purple-400" /> Master Output Volume
              </span>
              <span className="font-mono text-cyan-300 font-bold">{Math.round(masterVolume * 100)}%</span>
            </div>
            <div className="flex items-center gap-3">
              <VolumeX className="w-4 h-4 text-gray-500 shrink-0" />
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={masterVolume}
                disabled={!enabled}
                onChange={(e) => handleMasterVolume(parseFloat(e.target.value))}
                aria-label="Master volume level"
                className="flex-1 h-2 bg-white/10 rounded-full appearance-none cursor-pointer accent-purple-500 disabled:opacity-40"
              />
              <Volume2 className="w-4 h-4 text-purple-400 shrink-0" />
            </div>
            <p className="text-[11px] text-gray-400">
              Scales audio output across all categories proportionally without clipping.
            </p>
          </div>

          {/* Sound Theme / Pack Selector */}
          <div className="space-y-2.5">
            <label className="text-xs font-semibold text-gray-300 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" /> Acoustic Theme Language
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {SOUND_PACKS.map((pack) => (
                <button
                  key={pack.id}
                  type="button"
                  onClick={() => handlePackChange(pack.id)}
                  className={`p-2 rounded-xl text-left border transition-all cursor-pointer ${
                    activePack === pack.id
                      ? "bg-purple-500/20 border-purple-500/50 text-white shadow-md shadow-purple-950/40"
                      : "bg-slate-950/60 border-white/[0.06] text-gray-400 hover:text-white hover:border-white/20"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold block">{pack.name}</span>
                    {activePack === pack.id && (
                      <span className="w-1.5 h-1.5 rounded-full bg-purple-400 shadow-[0_0_6px_rgba(168,85,247,0.8)]" />
                    )}
                  </div>
                  <span className="text-[10px] text-gray-400 block line-clamp-1 mt-0.5">{pack.vibe}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </Card>

      {/* Category Routing Matrix */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* UI Interaction Category */}
        <Card variant="glass" className="space-y-3 p-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-blue-500/15 border border-blue-500/30 flex items-center justify-center text-blue-400">
                <MousePointer className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-white">UI Interaction Sounds</h4>
                <p className="text-[11px] text-gray-400">Button taps, switches, tab selections</p>
              </div>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={categoryStates.ui}
              onClick={() => handleCategoryToggle("ui")}
              className={`px-2.5 py-1 rounded-full text-[10px] font-bold border transition-all cursor-pointer ${
                categoryStates.ui
                  ? "bg-blue-500/20 border-blue-500/40 text-blue-300"
                  : "bg-slate-900 border-white/10 text-gray-500"
              }`}
            >
              {categoryStates.ui ? "ON" : "OFF"}
            </button>
          </div>

          <div className="pt-2 flex items-center gap-3">
            <span className="text-[10px] font-mono text-gray-400 shrink-0">VOL</span>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={categoryVols.ui}
              disabled={!categoryStates.ui}
              onChange={(e) => handleCategoryVolume("ui", parseFloat(e.target.value))}
              aria-label="UI interaction volume"
              className="flex-1 h-1.5 bg-white/10 rounded-full appearance-none cursor-pointer accent-blue-400 disabled:opacity-30"
            />
            <span className="text-[10px] font-mono text-blue-300 font-bold w-7 text-right">
              {Math.round(categoryVols.ui * 100)}%
            </span>
          </div>
        </Card>

        {/* Study & Focus Category */}
        <Card variant="glass" className="space-y-3 p-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-purple-500/15 border border-purple-500/30 flex items-center justify-center text-purple-400">
                <GraduationCap className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-white">Study & Focus Sounds</h4>
                <p className="text-[11px] text-gray-400">Session start, timer milestones, completion</p>
              </div>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={categoryStates.study}
              onClick={() => handleCategoryToggle("study")}
              className={`px-2.5 py-1 rounded-full text-[10px] font-bold border transition-all cursor-pointer ${
                categoryStates.study
                  ? "bg-purple-500/20 border-purple-500/40 text-purple-300"
                  : "bg-slate-900 border-white/10 text-gray-500"
              }`}
            >
              {categoryStates.study ? "ON" : "OFF"}
            </button>
          </div>

          <div className="pt-2 flex items-center gap-3">
            <span className="text-[10px] font-mono text-gray-400 shrink-0">VOL</span>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={categoryVols.study}
              disabled={!categoryStates.study}
              onChange={(e) => handleCategoryVolume("study", parseFloat(e.target.value))}
              aria-label="Study sounds volume"
              className="flex-1 h-1.5 bg-white/10 rounded-full appearance-none cursor-pointer accent-purple-400 disabled:opacity-30"
            />
            <span className="text-[10px] font-mono text-purple-300 font-bold w-7 text-right">
              {Math.round(categoryVols.study * 100)}%
            </span>
          </div>
        </Card>

        {/* Notification & Alerts Category */}
        <Card variant="glass" className="space-y-3 p-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                <Bell className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-white">Notifications & Alerts</h4>
                <p className="text-[11px] text-gray-400">Coach responses, warnings, XP achievements</p>
              </div>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={categoryStates.notification}
              onClick={() => handleCategoryToggle("notification")}
              className={`px-2.5 py-1 rounded-full text-[10px] font-bold border transition-all cursor-pointer ${
                categoryStates.notification
                  ? "bg-emerald-500/20 border-emerald-500/40 text-emerald-300"
                  : "bg-slate-900 border-white/10 text-gray-500"
              }`}
            >
              {categoryStates.notification ? "ON" : "OFF"}
            </button>
          </div>

          <div className="pt-2 flex items-center gap-3">
            <span className="text-[10px] font-mono text-gray-400 shrink-0">VOL</span>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={categoryVols.notification}
              disabled={!categoryStates.notification}
              onChange={(e) => handleCategoryVolume("notification", parseFloat(e.target.value))}
              aria-label="Notification volume"
              className="flex-1 h-1.5 bg-white/10 rounded-full appearance-none cursor-pointer accent-emerald-400 disabled:opacity-30"
            />
            <span className="text-[10px] font-mono text-emerald-300 font-bold w-7 text-right">
              {Math.round(categoryVols.notification * 100)}%
            </span>
          </div>
        </Card>

        {/* Extension & Shield Category */}
        <Card variant="glass" className="space-y-3 p-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                <Shield className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-white">Extension & Shield Sounds</h4>
                <p className="text-[11px] text-gray-400">Companion extension link, domain blocking</p>
              </div>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={categoryStates.extension}
              onClick={() => handleCategoryToggle("extension")}
              className={`px-2.5 py-1 rounded-full text-[10px] font-bold border transition-all cursor-pointer ${
                categoryStates.extension
                  ? "bg-cyan-500/20 border-cyan-500/40 text-cyan-300"
                  : "bg-slate-900 border-white/10 text-gray-500"
              }`}
            >
              {categoryStates.extension ? "ON" : "OFF"}
            </button>
          </div>

          <div className="pt-2 flex items-center gap-3">
            <span className="text-[10px] font-mono text-gray-400 shrink-0">VOL</span>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={categoryVols.extension}
              disabled={!categoryStates.extension}
              onChange={(e) => handleCategoryVolume("extension", parseFloat(e.target.value))}
              aria-label="Extension sound volume"
              className="flex-1 h-1.5 bg-white/10 rounded-full appearance-none cursor-pointer accent-cyan-400 disabled:opacity-30"
            />
            <span className="text-[10px] font-mono text-cyan-300 font-bold w-7 text-right">
              {Math.round(categoryVols.extension * 100)}%
            </span>
          </div>
        </Card>
      </div>

      {/* Interactive Cue Preview Suite */}
      <Card variant="glass" className="space-y-4 p-5 sm:p-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Radio className="w-4 h-4 text-cyan-400" /> Interactive Cue Audition Suite
            </h3>
            <p className="text-[11px] text-gray-400 mt-0.5">
              Preview individual sound signals directly. Sounds in this suite test audio regardless of current mute state.
            </p>
          </div>
          <span className="text-[10px] font-mono text-gray-500">8 Curated Signals</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-2">
          {PREVIEW_CUES.map((item) => {
            const isPlaying = previewingId === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handlePreviewCue(item)}
                className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between min-h-[90px] relative overflow-hidden group ${
                  isPlaying
                    ? "bg-purple-500/20 border-purple-500/60 text-white shadow-lg shadow-purple-950/40"
                    : "bg-slate-950/80 border-white/[0.06] text-gray-300 hover:border-white/20 hover:bg-slate-900/90"
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <span className="text-xs font-bold block leading-snug group-hover:text-purple-300 transition-colors">
                    {item.name}
                  </span>
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 transition-all ${
                    isPlaying
                      ? "bg-purple-500 text-white scale-110"
                      : "bg-white/[0.06] text-gray-400 group-hover:text-white"
                  }`}>
                    {isPlaying ? <Volume2 className="w-3 h-3" /> : <Play className="w-2.5 h-2.5 ml-0.5" />}
                  </div>
                </div>
                <span className="text-[10px] text-gray-400 line-clamp-1 mt-2">
                  {item.desc}
                </span>
              </button>
            );
          })}
        </div>
      </Card>

      {/* Accessibility Guarantee & Defaults Reset */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4 rounded-2xl bg-white/[0.02] border border-white/[0.06] text-xs">
        <div className="flex items-start gap-2.5 text-gray-400">
          <Info className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
          <div>
            <span className="text-gray-200 font-semibold block">Sensory Accessibility Guarantee</span>
            Sound is strictly secondary. Every critical notification and state change provides synchronized visual feedback, and respects system <span className="text-gray-300 font-mono">prefers-reduced-motion</span> preferences.
          </div>
        </div>

        <button
          type="button"
          onClick={handleResetDefaults}
          className="shrink-0 px-3.5 py-2 rounded-xl text-xs font-semibold text-gray-400 hover:text-white hover:bg-white/[0.06] border border-white/[0.08] transition-all flex items-center gap-1.5 cursor-pointer"
        >
          {resetSuccess ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <RotateCcw className="w-3.5 h-3.5 text-gray-400" />}
          <span>{resetSuccess ? "Restored" : "Reset Defaults"}</span>
        </button>
      </div>
    </div>
  );
}
