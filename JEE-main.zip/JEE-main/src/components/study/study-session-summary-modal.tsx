"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useStudyStore, CompletedSessionRecord } from "@/store/use-study-store";
import { Button } from "@/components/ui/controls";
import { Sparkles, CheckCircle2, Award, Clock, BookOpen, Layers, X } from "lucide-react";
import { triggerConfetti } from "@/lib/sound-effects";
import { xpService } from "@/services/xpService";

interface ModalContentProps {
  record: CompletedSessionRecord;
  onClose: () => void;
  onSave: (updates: Partial<CompletedSessionRecord>) => void;
}

function SessionSummaryModalContent({ record, onClose, onSave }: ModalContentProps) {
  const [productivityRating, setProductivityRating] = useState(record.productivityRating || 5);
  const [difficulty, setDifficulty] = useState<string>(
    record.difficulty || "Medium"
  );
  const [mood, setMood] = useState<"Focused" | "Calm" | "Tired" | "Stressed" | "Energized">(
    record.mood || "Focused"
  );
  const [focusScore, setFocusScore] = useState(record.focusScore ?? 90);
  const [wasGoalCompleted, setWasGoalCompleted] = useState(record.wasGoalCompleted !== false);
  const [notes, setNotes] = useState(record.notes || "Full focus zone completed successfully.");
  const [hasSavedUpdates, setHasSavedUpdates] = useState(false);

  const xpEarned = xpService.calculateSessionXp(
    record.totalDurationMinutes,
    focusScore,
    record.mode === "DeepWork",
    wasGoalCompleted
  );

  const handleSaveAndClose = () => {
    onSave({
      productivityRating,
      difficulty,
      mood,
      focusScore,
      wasGoalCompleted,
      notes,
    });
    setHasSavedUpdates(true);
    triggerConfetti();
    setTimeout(() => {
      onClose();
    }, 400);
  };

  return (
    <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-[100] flex items-center justify-center p-3 sm:p-4 md:p-6 overflow-y-auto select-none">
      <motion.div
        initial={{ opacity: 0, scale: 0.94, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.94, y: 20 }}
        transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
        className="glass-panel p-5 sm:p-7 md:p-8 rounded-3xl max-w-xl w-full space-y-6 border border-white/20 shadow-2xl shadow-purple-950/40 relative my-6 max-h-[92vh] overflow-y-auto"
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-1.5 text-gray-400 hover:text-white rounded-full bg-white/[0.06] hover:bg-white/15 border border-white/10 transition-all cursor-pointer"
          title="Close summary"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header: Badge, Title & Date */}
        <div className="space-y-2 pr-8">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-bold uppercase tracking-wider bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
              <CheckCircle2 className="w-3.5 h-3.5" />
              Session Complete
            </span>
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold text-amber-300 bg-amber-500/15 border border-amber-500/30 font-mono">
              <Award className="w-3.5 h-3.5" />
              +{xpEarned} XP Earned
            </span>
          </div>

          <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-purple-400 animate-pulse" />
            Study Session Summary
          </h2>
          <div className="flex flex-wrap items-center gap-2 pt-0.5">
            {(() => {
              const startD = record.startTime ? new Date(record.startTime) : null;
              const endD = record.endTime ? new Date(record.endTime) : (startD ? new Date(startD.getTime() + record.totalDurationMinutes * 60000) : null);
              const formatT = (d: Date) => d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: true });
              const timeStr = startD && endD && !isNaN(startD.getTime()) && !isNaN(endD.getTime())
                ? `${formatT(startD)} → ${formatT(endD)}`
                : `${record.totalDurationMinutes} min duration`;

              return (
                <div className="flex items-center gap-2 text-xs font-mono text-gray-300 bg-white/[0.04] px-3 py-1.5 rounded-xl border border-white/[0.08]">
                  <Clock className="w-3.5 h-3.5 text-cyan-400" />
                  <span className="font-bold text-white">{timeStr}</span>
                  <span className="text-gray-500">•</span>
                  <span className="text-purple-300">{record.date || "Today"}</span>
                </div>
              );
            })()}
          </div>
        </div>

        {/* Key Session Details Matrix */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs">
          <div className="p-3 bg-white/[0.03] border border-white/[0.08] rounded-xl space-y-1">
            <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider flex items-center gap-1">
              <BookOpen className="w-3 h-3 text-cyan-400" /> Subject
            </span>
            <span className="font-bold text-white text-sm block truncate">
              {record.subject}
            </span>
          </div>

          <div className="p-3 bg-white/[0.03] border border-white/[0.08] rounded-xl space-y-1">
            <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider flex items-center gap-1">
              <Clock className="w-3 h-3 text-emerald-400" /> Duration
            </span>
            <span className="font-bold text-emerald-400 text-sm font-mono block">
              {record.totalDurationMinutes} min
            </span>
          </div>

          <div className="p-3 bg-white/[0.03] border border-white/[0.08] rounded-xl space-y-1">
            <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider flex items-center gap-1">
              <Layers className="w-3 h-3 text-purple-400" /> Mode
            </span>
            <span className="font-bold text-purple-300 text-sm block truncate">
              {record.taskType}
            </span>
          </div>

          <div className="p-3 bg-white/[0.03] border border-white/[0.08] rounded-xl space-y-1">
            <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider flex items-center gap-1">
              <Award className="w-3 h-3 text-amber-400" /> Focus Score
            </span>
            <span className="font-bold text-amber-300 text-sm font-mono block">
              {focusScore}%
            </span>
          </div>
        </div>

        {/* Chapter & Subchapter Focus Banner */}
        <div className="p-3 bg-slate-950/70 border border-white/10 rounded-xl space-y-0.5">
          <span className="text-[10px] font-semibold text-gray-500 uppercase tracking-wider block">
            Chapter Studied
          </span>
          <p className="text-sm font-bold text-white truncate">
            {record.chapter}
            {record.subchapter && record.subchapter !== "General Practice" && (
              <span className="text-cyan-300 font-mono font-medium text-xs ml-2">
                • {record.subchapter}
              </span>
            )}
          </p>
        </div>

        {/* Productivity Star Rating (1 - 5) */}
        <div className="space-y-2">
          <label className="text-xs text-gray-300 font-semibold block">
            Rate Session Productivity
          </label>
          <div className="flex items-center gap-2">
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                type="button"
                onClick={() => setProductivityRating(star)}
                className={`flex-1 py-2 px-1 rounded-xl border text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                  productivityRating >= star
                    ? "bg-amber-500/20 border-amber-500/50 text-amber-300 shadow-sm shadow-amber-950"
                    : "bg-white/[0.04] border-white/10 text-gray-500 hover:text-gray-300"
                }`}
              >
                ★ {star}
              </button>
            ))}
          </div>
        </div>

        {/* Difficulty & Mood Attributes */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Difficulty Selection */}
          <div className="space-y-1.5">
            <label className="text-xs text-gray-300 font-semibold block">Concept Difficulty</label>
            <div className="grid grid-cols-2 gap-1.5">
              {(["Easy", "Medium", "Hard", "JEE Advanced"] as const).map((diff) => (
                <button
                  key={diff}
                  type="button"
                  onClick={() => setDifficulty(diff)}
                  className={`px-2.5 py-1.5 rounded-lg border text-[11px] font-semibold transition-all cursor-pointer truncate text-center ${
                    difficulty === diff
                      ? "bg-cyan-500/20 border-cyan-500/50 text-cyan-300"
                      : "bg-white/[0.04] border-white/10 text-gray-400 hover:text-white"
                  }`}
                >
                  {diff}
                </button>
              ))}
            </div>
          </div>

          {/* Mood Selection */}
          <div className="space-y-1.5">
            <label className="text-xs text-gray-300 font-semibold block">Study Mindset / Mood</label>
            <div className="grid grid-cols-3 gap-1.5">
              {(["Focused", "Calm", "Tired", "Stressed", "Energized"] as const).map((m) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => setMood(m)}
                  className={`px-2 py-1.5 rounded-lg border text-[11px] font-semibold transition-all cursor-pointer truncate text-center ${
                    mood === m
                      ? "bg-purple-500/20 border-purple-500/50 text-purple-300"
                      : "bg-white/[0.04] border-white/10 text-gray-400 hover:text-white"
                  }`}
                >
                  {m}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Focus Quality Slider & Goal Met Toggle */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
          <div className="p-3 bg-slate-950/70 rounded-xl border border-white/10 space-y-2">
            <div className="flex justify-between items-center">
              <label className="text-xs text-gray-300 font-semibold">Focus Quality</label>
              <span className="text-xs font-mono font-bold text-purple-300">{focusScore}%</span>
            </div>
            <input
              type="range"
              min="30"
              max="100"
              value={focusScore}
              onChange={(e) => setFocusScore(parseInt(e.target.value))}
              className="w-full h-1.5 bg-white/10 rounded-full appearance-none cursor-pointer accent-purple-500"
            />
          </div>

          <div className="p-3 bg-slate-950/70 rounded-xl border border-white/10 flex items-center justify-between">
            <div>
              <span className="text-xs font-semibold text-gray-300 block">Session Goal</span>
              <span className="text-[10px] text-gray-500">Target completed?</span>
            </div>
            <button
              type="button"
              onClick={() => setWasGoalCompleted(!wasGoalCompleted)}
              className={`px-3 py-1.5 rounded-lg font-bold border text-xs transition-all cursor-pointer ${
                wasGoalCompleted
                  ? "bg-emerald-500/20 border-emerald-500/40 text-emerald-400"
                  : "bg-rose-500/20 border-rose-500/40 text-rose-400"
              }`}
            >
              {wasGoalCompleted ? "✓ Goal Met" : "✕ Partial"}
            </button>
          </div>
        </div>

        {/* Session Notes & Output Textarea */}
        <div className="space-y-1.5">
          <label className="text-xs text-gray-300 font-semibold block">
            Session Notes & Key Learnings
          </label>
          <textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="E.g. Solved 15 PYQs on conservation of momentum. Formulated key formula sheet notes."
            rows={2}
            className="w-full glass-input p-3 text-xs text-white focus:outline-none min-h-[68px] rounded-xl resize-none"
          />
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-between gap-3 pt-3 border-t border-white/10">
          <Button
            onClick={onClose}
            variant="ghost"
            size="sm"
            className="cursor-pointer text-gray-400 hover:text-white"
          >
            Close Summary
          </Button>

          <Button
            onClick={handleSaveAndClose}
            variant="primary"
            size="md"
            className="cursor-pointer px-6"
          >
            <CheckCircle2 className="w-4 h-4 mr-1.5" />
            {hasSavedUpdates ? "Saved!" : "Save & Continue"}
          </Button>
        </div>
      </motion.div>
    </div>
  );
}

export function StudySessionSummaryModal() {
  const {
    showSummaryModal,
    closeSummaryModal,
    latestCompletedSession,
    sessionHistory,
    updateCompletedSession,
  } = useStudyStore();

  const currentRecord: CompletedSessionRecord | undefined =
    latestCompletedSession || (sessionHistory.length > 0 ? sessionHistory[0] : undefined);

  if (!showSummaryModal || !currentRecord) return null;

  return (
    <AnimatePresence>
      {showSummaryModal && (
        <SessionSummaryModalContent
          key={currentRecord.id}
          record={currentRecord}
          onClose={closeSummaryModal}
          onSave={(updates) => updateCompletedSession(currentRecord.id, updates)}
        />
      )}
    </AnimatePresence>
  );
}
