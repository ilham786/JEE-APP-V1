"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useExam } from "@/hooks/use-exam";
import { useUserProfile } from "@/hooks/use-user-profile";
import { ExamType, getUpcomingExamYears } from "@/lib/exam-config";
import { soundManager } from "@/lib/sound-manager";
import { Zap, Stethoscope, CheckCircle2, ArrowRight, Sparkles, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/controls";

export function ExamTrackSelectionModal() {
  const { userProfile, loading } = useUserProfile();
  const { examType, switchExamTrack } = useExam();
  const [isOpen, setIsOpen] = useState(false);
  const [selectedTrack, setSelectedTrack] = useState<ExamType>("JEE");
  const upcomingYears = getUpcomingExamYears(4);
  const [selectedYear, setSelectedYear] = useState<number>(upcomingYears[0]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    // Only prompt logged-in users who do not have an explicit examType set yet
    if (!loading && userProfile && userProfile.uid && userProfile.uid !== "guest-user") {
      const hasTrack = !!userProfile.examType;
      const dismissed = typeof window !== "undefined" && sessionStorage.getItem("ff_track_modal_dismissed");
      if (!hasTrack && !dismissed) {
        setIsOpen(true);
      }
    }
  }, [userProfile, loading]);

  if (!isOpen) return null;

  const handleConfirm = async () => {
    soundManager.play("checkpoint");
    setIsSubmitting(true);
    try {
      await switchExamTrack(selectedTrack, selectedYear);
      if (typeof window !== "undefined") {
        sessionStorage.setItem("ff_track_modal_dismissed", "true");
      }
      setIsOpen(false);
    } catch (err) {
      console.error("Failed to set preparation track:", err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDismiss = () => {
    soundManager.play("close");
    if (typeof window !== "undefined") {
      sessionStorage.setItem("ff_track_modal_dismissed", "true");
    }
    setIsOpen(false);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
        <motion.div
          initial={{ opacity: 0, scale: 0.94, y: 16 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.94, y: 16 }}
          transition={{ duration: 0.28, ease: [0.16, 1, 0.3, 1] }}
          className="relative max-w-xl w-full bg-slate-950 border border-white/15 rounded-3xl p-6 sm:p-8 shadow-2xl shadow-purple-950/60 space-y-6 overflow-hidden"
        >
          {/* Subtle background mesh */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />

          {/* Header */}
          <div className="space-y-2 text-center relative z-10">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/[0.06] border border-white/10 text-xs font-semibold text-purple-300">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Multi-Exam Experience</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              Select Your Preparation Track
            </h2>
            <p className="text-xs sm:text-sm text-gray-400 max-w-md mx-auto leading-relaxed">
              FocusForge dynamically adapts its curriculum, syllabus trackers, mistake diagnostics, and deep work timers to your target examination.
            </p>
          </div>

          {/* Track Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 relative z-10">
            {/* JEE Option */}
            <button
              type="button"
              onClick={() => {
                soundManager.play("select");
                setSelectedTrack("JEE");
              }}
              className={`p-5 rounded-2xl border text-left transition-all cursor-pointer relative overflow-hidden flex flex-col justify-between h-full ${
                selectedTrack === "JEE"
                  ? "bg-purple-950/40 border-purple-500 shadow-xl shadow-purple-950/50 ring-2 ring-purple-500/30"
                  : "bg-white/[0.02] border-white/10 hover:border-white/20 hover:bg-white/[0.04]"
              }`}
            >
              <div className="space-y-3">
                <div className="w-10 h-10 rounded-xl bg-purple-500/15 border border-purple-500/30 flex items-center justify-center text-purple-300">
                  <Zap className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    IIT-JEE Track
                    {selectedTrack === "JEE" && (
                      <CheckCircle2 className="w-4 h-4 text-purple-400" />
                    )}
                  </h3>
                  <p className="text-xs text-gray-400 mt-1 leading-relaxed">
                    Main & Advanced. Physics, Chemistry, and Advanced Mathematics with calculus & algebra mastery.
                  </p>
                </div>
              </div>

              <div className="pt-4 mt-3 border-t border-white/[0.06] text-[11px] font-mono text-purple-300 font-semibold">
                3 Subjects • 74 Chapters
              </div>
            </button>

            {/* NEET Option */}
            <button
              type="button"
              onClick={() => {
                soundManager.play("select");
                setSelectedTrack("NEET");
              }}
              className={`p-5 rounded-2xl border text-left transition-all cursor-pointer relative overflow-hidden flex flex-col justify-between h-full ${
                selectedTrack === "NEET"
                  ? "bg-teal-950/40 border-teal-500 shadow-xl shadow-teal-950/50 ring-2 ring-teal-500/30"
                  : "bg-white/[0.02] border-white/10 hover:border-white/20 hover:bg-white/[0.04]"
              }`}
            >
              <div className="space-y-3">
                <div className="w-10 h-10 rounded-xl bg-teal-500/15 border border-teal-500/30 flex items-center justify-center text-teal-300">
                  <Stethoscope className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    NEET-UG Track
                    {selectedTrack === "NEET" && (
                      <CheckCircle2 className="w-4 h-4 text-teal-400" />
                    )}
                  </h3>
                  <p className="text-xs text-gray-400 mt-1 leading-relaxed">
                    Medical Entrance. Physics, Chemistry, Botany (17 ch) & Zoology (15 ch) with NCERT Fact Vault.
                  </p>
                </div>
              </div>

              <div className="pt-4 mt-3 border-t border-white/[0.06] text-[11px] font-mono text-teal-300 font-semibold">
                4 Subjects • 82 Chapters
              </div>
            </button>
          </div>

          {/* Target Exam Year */}
          <div className="space-y-2 relative z-10">
            <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider block">
              Target Exam Year
            </label>
            <div className="grid grid-cols-4 gap-2">
              {upcomingYears.map((yr) => (
                <button
                  key={yr}
                  type="button"
                  onClick={() => {
                    soundManager.play("choose");
                    setSelectedYear(yr);
                  }}
                  className={`py-2 px-3 rounded-xl text-xs font-mono font-bold transition-all cursor-pointer text-center ${
                    selectedYear === yr
                      ? selectedTrack === "NEET"
                        ? "bg-teal-500 text-black shadow-lg shadow-teal-500/30"
                        : "bg-purple-600 text-white shadow-lg shadow-purple-600/30"
                      : "bg-white/[0.03] border border-white/10 text-gray-300 hover:text-white hover:bg-white/[0.06]"
                  }`}
                >
                  {yr}
                </button>
              ))}
            </div>
          </div>

          {/* Data Preservation Guarantee */}
          <div className="p-3 bg-white/[0.03] border border-white/[0.08] rounded-xl flex items-center gap-2.5 text-xs text-gray-300 relative z-10">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>
              All your study hours, XP streaks, and mistake notes are permanently preserved when switching tracks.
            </span>
          </div>

          {/* Footer Actions */}
          <div className="flex items-center justify-end gap-3 pt-2 relative z-10">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleDismiss}
              className="text-gray-400 hover:text-white"
            >
              Decide Later
            </Button>
            <Button
              variant="primary"
              size="md"
              disabled={isSubmitting}
              onClick={handleConfirm}
              className={`font-bold gap-2 ${
                selectedTrack === "NEET"
                  ? "bg-teal-500 hover:bg-teal-400 text-black shadow-teal-500/30"
                  : "bg-purple-600 hover:bg-purple-500 text-white"
              }`}
            >
              <span>{isSubmitting ? "Configuring Track..." : `Confirm ${selectedTrack} Track`}</span>
              <ArrowRight className="w-4 h-4" />
            </Button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
