"use client";

import { useIsClient } from "@/hooks/use-is-client";

import { useState, useMemo, useEffect } from "react";
import { createPortal } from "react-dom";
import { motion, AnimatePresence } from "framer-motion";
import Link from "next/link";
import { Card } from "@/components/ui/card";
import { Button, ProgressBar } from "@/components/ui/controls";
import {
  consistencyGridService,
  HeatmapRange,
  DailyConsistencyRecord,
  UserGoalsDoc,
  DEFAULT_GOALS,
} from "@/services/consistencyGridService";
import { useStudyStore } from "@/store/use-study-store";
import { getCurrentUserId } from "@/lib/supabase/client";
import {
  Calendar,
  Clock,
  Flame,
  Award,
  X,
  Target,
  Sparkles,
  Settings,
  Zap,
  AlertCircle,
  Timer,
} from "lucide-react";

export function ConsistencyGrid() {
  const { sessionHistory = [] } = useStudyStore();

  const mounted = useIsClient();
  const [hoveredTarget, setHoveredTarget] = useState<{
    record: DailyConsistencyRecord;
    rect: DOMRect;
  } | null>(null);

  // Selected date range (7, 30, 90, 365)
  const [range, setRange] = useState<HeatmapRange>(30);

  // Selected day for detail modal
  const [selectedDay, setSelectedDay] = useState<DailyConsistencyRecord | null>(null);

  // Goal config state
  const [showGoalModal, setShowGoalModal] = useState(false);
  const [goals, setGoals] = useState<UserGoalsDoc>(DEFAULT_GOALS);
  const [dailyInput, setDailyInput] = useState(DEFAULT_GOALS.dailyHours);
  const [monthlyInput, setMonthlyInput] = useState(DEFAULT_GOALS.monthlyHours);

  // Dismiss portal popup on window scroll or resize
  useEffect(() => {
    if (!hoveredTarget) return;
    const handleScrollOrResize = () => setHoveredTarget(null);
    window.addEventListener("scroll", handleScrollOrResize, { capture: true, passive: true });
    window.addEventListener("resize", handleScrollOrResize, { passive: true });
    return () => {
      window.removeEventListener("scroll", handleScrollOrResize, { capture: true });
      window.removeEventListener("resize", handleScrollOrResize);
    };
  }, [hoveredTarget]);

  // Fetch user goals on mount
  useEffect(() => {
    const initGoals = async () => {
      const uid = getCurrentUserId();
      if (uid) {
        const userG = await consistencyGridService.getUserGoals(uid);
        setGoals(userG);
        setDailyInput(userG.dailyHours);
        setMonthlyInput(userG.monthlyHours);
      }
    };
    initGoals();
  }, []);

  // Filter completed sessions
  const validSessions = useMemo(() => {
    return (sessionHistory || []).filter(
      (s) => s && s.completed !== false && Number(s.totalDurationMinutes || 0) > 0
    );
  }, [sessionHistory]);

  const hasAnySessions = validSessions.length > 0;

  // Generate grid records dynamically from real session history
  const gridRecords = useMemo(() => {
    return consistencyGridService.generateGridRecords(validSessions, range, goals.dailyHours);
  }, [validSessions, range, goals.dailyHours]);

  // Calculate dynamic streaks & stats chips
  const streaks = useMemo(() => {
    return consistencyGridService.calculateStreaks(gridRecords);
  }, [gridRecords]);

  // Calculate dynamic monthly insights
  const monthlyInsights = useMemo(() => {
    return consistencyGridService.generateMonthlyInsights(gridRecords, goals.monthlyHours, validSessions);
  }, [gridRecords, goals.monthlyHours, validSessions]);

  // Monthly target progress %
  const monthlyCompletionPct = useMemo(() => {
    if (goals.monthlyHours <= 0) return 0;
    return Math.min(100, Math.round((monthlyInsights.totalMonthlyHours / goals.monthlyHours) * 100));
  }, [monthlyInsights.totalMonthlyHours, goals.monthlyHours]);

  // Save goal changes
  const handleSaveGoals = async (e: React.FormEvent) => {
    e.preventDefault();
    const newGoals: UserGoalsDoc = {
      dailyHours: dailyInput,
      weeklyHours: dailyInput * 7,
      monthlyHours: monthlyInput,
      updatedAt: new Date().toISOString(),
    };
    setGoals(newGoals);
    setShowGoalModal(false);

    const uid = getCurrentUserId();
    if (uid) {
      await consistencyGridService.saveUserGoals(uid, newGoals);
    }
  };

  return (
    <Card variant="glass" className="space-y-5 p-5 relative overflow-visible">
      {/* 1. Spacious Header & Timeframe Switcher Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-white/[0.08] pb-4">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Calendar className="w-4.5 h-4.5 text-purple-400" />
            Consistency Grid
          </h2>
          <p className="text-xs text-gray-400 mt-0.5">
            Real-time GitHub-style study contribution graph powered by backend sessions
          </p>
        </div>

        {/* Timeframe Selector Pills & Target Settings */}
        <div className="flex items-center gap-2 shrink-0">
          <div className="flex items-center gap-1 bg-slate-900/90 p-1 rounded-xl border border-white/10 shadow-inner">
            {([7, 30, 90, 365] as HeatmapRange[]).map((r) => (
              <button
                key={r}
                onClick={() => setRange(r)}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                  range === r
                    ? "bg-purple-600 text-white shadow-md shadow-purple-900/40"
                    : "text-gray-400 hover:text-white hover:bg-white/[0.05]"
                }`}
              >
                {r === 365 ? "1Y" : `${r}D`}
              </button>
            ))}
          </div>

          <Button
            onClick={() => setShowGoalModal(true)}
            variant="ghost"
            size="sm"
            className="p-2 text-gray-400 hover:text-white rounded-xl border border-white/10 hover:border-white/20"
            title="Configure Study Targets"
          >
            <Settings className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* 2. GitHub Contribution Grid (Front-and-Center with Full Tooltip Clearance) */}
      <div className="space-y-3.5 relative min-h-[140px] pt-1">
        <div className="mobile-scroll-x py-1 flex justify-center">
          <AnimatePresence mode="wait">
            <motion.div
              key={range}
              initial={{ opacity: 0, y: 3 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -3 }}
              transition={{ duration: 0.2, ease: "easeInOut" }}
              className={`grid gap-[8px] sm:gap-[10px] shrink-0 justify-center ${
                range === 7
                  ? "grid-cols-7 w-fit mx-auto"
                  : range === 30
                  ? "grid-cols-6 w-fit mx-auto"
                  : range === 90
                  ? "grid-cols-15 sm:grid-cols-15 w-fit mx-auto"
                  : "grid-cols-13 sm:grid-cols-26 md:grid-cols-52"
              }`}
            >
              {gridRecords.map((record) => {
                const lvl = record.intensityLevel;
                const levelClasses =
                  lvl === 5
                    ? "bg-[#A855F7] border-purple-300 shadow-[0_0_12px_rgba(168,85,247,0.4)] text-white"
                    : lvl === 4
                    ? "bg-[#8B5CF6] border-purple-400/60 text-white"
                    : lvl === 3
                    ? "bg-[#6D28D9] border-purple-500/50 text-white"
                    : lvl === 2
                    ? "bg-[#4C1D95] border-purple-600/40 text-white"
                    : lvl === 1
                    ? "bg-[#2E1A47] border-purple-700/40 text-purple-200"
                    : "bg-[#171923] border-[rgba(255,255,255,0.06)] hover:bg-[#252733]";

                const dateFormatted = new Date(`${record.date}T12:00:00Z`).toLocaleDateString("en-US", {
                  month: "long",
                  day: "numeric",
                  timeZone: "UTC",
                });

                return (
                  <motion.div
                    key={record.date}
                    tabIndex={0}
                    role="button"
                    aria-label={`Study record for ${dateFormatted}: ${record.studyHours} hours, ${record.completedSessions} sessions`}
                    whileHover={{ scale: 1.08 }}
                    transition={{ duration: 0.15, ease: "easeOut" }}
                    onClick={() => setSelectedDay(record)}
                    onMouseEnter={(e) => {
                      const rect = e.currentTarget.getBoundingClientRect();
                      setHoveredTarget({ record, rect });
                    }}
                    onMouseLeave={() => setHoveredTarget(null)}
                    onFocus={(e) => {
                      const rect = e.currentTarget.getBoundingClientRect();
                      setHoveredTarget({ record, rect });
                    }}
                    onBlur={() => setHoveredTarget(null)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter" || e.key === " ") {
                        e.preventDefault();
                        setSelectedDay(record);
                      }
                    }}
                    className={`w-[22px] h-[22px] min-w-[22px] min-h-[22px] rounded-[8px] border transition-all cursor-pointer relative group focus:outline-none focus:ring-2 focus:ring-purple-400 focus:ring-offset-2 focus:ring-offset-slate-950 ${levelClasses}`}
                  />
                );
              })}
            </motion.div>
          </AnimatePresence>
        </div>

        {/* 3. Compact Centered Intensity Legend */}
        <div className="flex items-center justify-center gap-3 text-[11px] text-gray-400 pt-1.5 border-t border-white/[0.05]">
          <span className="font-medium">Less</span>
          <div className="flex items-center gap-1.5">
            <span className="w-3.5 h-3.5 rounded-[4px] bg-[#171923] border border-[rgba(255,255,255,0.06)]" title="0 hours (Empty)" />
            <span className="w-3.5 h-3.5 rounded-[4px] bg-[#2E1A47] border border-purple-700/40" title="0-1 hour (Level 1)" />
            <span className="w-3.5 h-3.5 rounded-[4px] bg-[#4C1D95] border border-purple-600/40" title="1-2 hours (Level 2)" />
            <span className="w-3.5 h-3.5 rounded-[4px] bg-[#6D28D9] border border-purple-500/50" title="2-4 hours (Level 3)" />
            <span className="w-3.5 h-3.5 rounded-[4px] bg-[#8B5CF6] border border-purple-400/60" title="4-6 hours (Level 4)" />
            <span className="w-3.5 h-3.5 rounded-[4px] bg-[#A855F7] border border-purple-300 shadow-[0_0_8px_rgba(168,85,247,0.4)]" title="6h+ (Level 5)" />
          </div>
          <span className="font-medium">More (6h+)</span>
        </div>

        {/* Empty State Overlay */}
        {!hasAnySessions && (
          <div className="absolute inset-0 bg-slate-950/50 backdrop-blur-[2px] rounded-2xl flex flex-col items-center justify-center text-center p-4 border border-dashed border-white/10 z-10">
            <AlertCircle className="w-7 h-7 text-purple-400 mb-1.5 animate-bounce" />
            <p className="text-xs font-bold text-white">No completed study sessions yet.</p>
            <p className="text-[11px] text-gray-400 mt-0.5 max-w-xs">
              Complete your first focus session to start building your GitHub-style contribution graph.
            </p>
            <Link href="/study" className="mt-2.5">
              <Button size="sm" variant="primary">
                <Timer className="w-3 h-3" /> Start Focus Session
              </Button>
            </Link>
          </div>
        )}
      </div>

      {/* 4. Relocated & Re-imagined Telemetry Stat Chips Ribbon (Placed Below Grid to Eliminate Tooltip Collision) */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5 pt-2 border-t border-white/[0.08]">
        <div className="h-[58px] p-2.5 rounded-xl bg-slate-900/60 border border-white/[0.08] hover:border-amber-500/30 transition-all flex items-center gap-2.5 shadow-sm">
          <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 shrink-0">
            <Flame className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <span className="text-[10px] text-gray-400 uppercase font-semibold tracking-wider block truncate">Daily Streak</span>
            <span className="text-xs font-black text-white font-mono block leading-tight">{streaks.currentStreak} Days</span>
            <span className="text-[9px] text-gray-500 block truncate">Consecutive days</span>
          </div>
        </div>

        <div className="h-[58px] p-2.5 rounded-xl bg-slate-900/60 border border-white/[0.08] hover:border-purple-500/30 transition-all flex items-center gap-2.5 shadow-sm">
          <div className="w-8 h-8 rounded-lg bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400 shrink-0">
            <Award className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <span className="text-[10px] text-gray-400 uppercase font-semibold tracking-wider block truncate">Longest</span>
            <span className="text-xs font-black text-purple-300 font-mono block leading-tight">{streaks.longestStreak} Days</span>
            <span className="text-[9px] text-gray-500 block truncate">All-time record</span>
          </div>
        </div>

        <div className="h-[58px] p-2.5 rounded-xl bg-slate-900/60 border border-white/[0.08] hover:border-cyan-500/30 transition-all flex items-center gap-2.5 shadow-sm">
          <div className="w-8 h-8 rounded-lg bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400 shrink-0">
            <Zap className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <span className="text-[10px] text-gray-400 uppercase font-semibold tracking-wider block truncate">Weekly</span>
            <span className="text-xs font-black text-cyan-300 font-mono block leading-tight">{streaks.weeklySessionsCount} Sess</span>
            <span className="text-[9px] text-gray-500 block truncate">Past 7 days</span>
          </div>
        </div>

        <div className="h-[58px] p-2.5 rounded-xl bg-slate-900/60 border border-white/[0.08] hover:border-emerald-500/30 transition-all flex items-center gap-2.5 shadow-sm">
          <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 shrink-0">
            <Calendar className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <span className="text-[10px] text-gray-400 uppercase font-semibold tracking-wider block truncate">Monthly</span>
            <span className="text-xs font-black text-emerald-300 font-mono block leading-tight">{streaks.monthlySessionsCount} Sess</span>
            <span className="text-[9px] text-gray-500 block truncate">Past 30 days</span>
          </div>
        </div>

        <div className="h-[58px] p-2.5 rounded-xl bg-slate-900/60 border border-white/[0.08] hover:border-rose-500/30 transition-all flex items-center gap-2.5 shadow-sm col-span-2 sm:col-span-1">
          <div className="w-8 h-8 rounded-lg bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-rose-400 shrink-0">
            <Clock className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <span className="text-[10px] text-gray-400 uppercase font-semibold tracking-wider block truncate">Missed Days</span>
            <span className="text-xs font-black text-rose-300 font-mono block leading-tight">{streaks.missedDaysCount} Days</span>
            <span className="text-[9px] text-gray-500 block truncate">Zero study days</span>
          </div>
        </div>
      </div>

      {/* 5. Monthly Goal Progress & Intelligent Generated Insights */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 border-t border-white/[0.08] pt-3.5">
        {/* Progress Bar */}
        <div className="space-y-2.5">
          <div className="flex items-center justify-between text-xs font-semibold">
            <span className="text-gray-300 flex items-center gap-1.5">
              <Target className="w-4 h-4 text-purple-400" />
              Monthly Goal Progress
            </span>
            <span className="text-white font-mono font-bold">
              {monthlyInsights.totalMonthlyHours} / {goals.monthlyHours} Hours ({monthlyCompletionPct}%)
            </span>
          </div>
          <ProgressBar value={monthlyCompletionPct} showPercentage={false} variant="primary" />
          <div className="flex justify-between text-[11px] text-gray-400">
            <span>Daily Avg: {monthlyInsights.avgDailyHours}h/day</span>
            <span className="text-purple-300 font-semibold">
              Consistency: {monthlyInsights.consistencyPct}%
            </span>
          </div>
        </div>

        {/* Intelligent Insights Text List */}
        <div className="p-3 rounded-xl bg-purple-500/10 border border-purple-500/20 text-xs space-y-1.5">
          <span className="font-bold text-purple-300 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-purple-400" />
            Intelligent Monthly Insights
          </span>
          {monthlyInsights.hasData ? (
            <ul className="space-y-1 text-gray-300 text-[11px]">
              <li className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-purple-400 shrink-0" />
                Studied <strong className="text-white">{monthlyInsights.totalMonthlyHours}h</strong> this month across {monthlyInsights.totalSessionsCount} sessions.
              </li>
              <li className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 shrink-0" />
                Top Subject: <strong className="text-cyan-300">{monthlyInsights.topSubject}</strong> ({monthlyInsights.topSubjectPct}% of study time).
              </li>
              <li className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 shrink-0" />
                Most Productive: <strong className="text-emerald-300">{monthlyInsights.bestDayOfWeek}s</strong> (highest focus score & duration).
              </li>
              {monthlyInsights.longestSessionMins > 0 && (
                <li className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-purple-300 shrink-0" />
                  Longest Session: <strong className="text-white">{monthlyInsights.longestSessionMins} min</strong>.
                </li>
              )}
              {monthlyInsights.highestXpDay !== "N/A" && (
                <li className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-400 shrink-0" />
                  Highest XP Day: <strong className="text-amber-300">{monthlyInsights.highestXpDay}</strong>.
                </li>
              )}
            </ul>
          ) : (
            <p className="text-gray-400 text-[11px] py-1">
              No study sessions recorded yet this month. Complete a focus session to generate intelligent consistency insights.
            </p>
          )}
        </div>
      </div>

      {/* ==================================================== */}
      {/* DAY DETAIL MODAL                                     */}
      {/* ==================================================== */}
      <AnimatePresence>
        {selectedDay && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-lg bg-slate-900 border border-white/10 rounded-2xl p-6 space-y-5 shadow-2xl"
            >
              <div className="flex items-start justify-between pb-3 border-b border-white/[0.08]">
                <div>
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-purple-400" />
                    Study Details for {selectedDay.date}
                  </h3>
                  <p className="text-xs text-gray-400">{selectedDay.dayOfWeek} • {selectedDay.studyHours} Hours Logged</p>
                </div>
                <button
                  onClick={() => setSelectedDay(null)}
                  className="p-1 text-gray-400 hover:text-white rounded-lg hover:bg-white/10"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                <div className="p-2.5 rounded-xl bg-white/[0.03] border border-white/[0.06]">
                  <span className="text-[10px] text-gray-400 block font-semibold uppercase">Total Hours</span>
                  <span className="text-base font-bold text-white font-mono">{selectedDay.studyHours}h</span>
                </div>
                <div className="p-2.5 rounded-xl bg-white/[0.03] border border-white/[0.06]">
                  <span className="text-[10px] text-gray-400 block font-semibold uppercase">Sessions</span>
                  <span className="text-base font-bold text-purple-300 font-mono">{selectedDay.completedSessions}</span>
                </div>
                <div className="p-2.5 rounded-xl bg-white/[0.03] border border-white/[0.06]">
                  <span className="text-[10px] text-gray-400 block font-semibold uppercase">Focus Score</span>
                  <span className="text-base font-bold text-emerald-400 font-mono">{selectedDay.focusScore}%</span>
                </div>
                <div className="p-2.5 rounded-xl bg-white/[0.03] border border-white/[0.06]">
                  <span className="text-[10px] text-gray-400 block font-semibold uppercase">XP Earned</span>
                  <span className="text-base font-bold text-amber-300 font-mono">+{selectedDay.xpEarned} XP</span>
                </div>
              </div>

              {selectedDay.subjects.length > 0 && (
                <div className="space-y-1.5">
                  <span className="text-xs font-bold text-gray-300 block">Subjects & Topics</span>
                  <div className="flex flex-wrap gap-1.5">
                    {selectedDay.subjects.map((sub) => (
                      <span key={sub} className="px-2.5 py-1 rounded-lg text-xs font-bold bg-purple-500/10 border border-purple-500/20 text-purple-300">
                        {sub}
                      </span>
                    ))}
                    {selectedDay.chapters.map((chap) => (
                      <span key={chap} className="px-2.5 py-1 rounded-lg text-xs font-medium bg-white/[0.04] border border-white/[0.08] text-gray-300">
                        {chap}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {selectedDay.notes.length > 0 && (
                <div className="space-y-1.5">
                  <span className="text-xs font-bold text-gray-300 block">Logged Notes</span>
                  <div className="p-3 rounded-xl bg-slate-950 border border-white/[0.08] text-xs text-gray-300 space-y-1 max-h-32 overflow-y-auto">
                    {selectedDay.notes.map((n, idx) => (
                      <p key={idx} className="leading-relaxed">• {n}</p>
                    ))}
                  </div>
                </div>
              )}

              <div className="pt-2 flex justify-end">
                <Button size="sm" variant="secondary" onClick={() => setSelectedDay(null)}>
                  Close Details
                </Button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ==================================================== */}
      {/* GOAL CONFIGURATION MODAL                             */}
      {/* ==================================================== */}
      <AnimatePresence>
        {showGoalModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-md bg-slate-900 border border-white/10 rounded-2xl p-6 space-y-5 shadow-2xl"
            >
              <div className="flex items-center justify-between pb-3 border-b border-white/[0.08]">
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Settings className="w-4 h-4 text-purple-400" />
                  Configure Study Targets
                </h3>
                <button
                  onClick={() => setShowGoalModal(false)}
                  className="p-1 text-gray-400 hover:text-white rounded-lg hover:bg-white/10"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSaveGoals} className="space-y-4 text-xs">
                <div className="space-y-1.5">
                  <label className="font-bold text-gray-300 block">Daily Target Hours</label>
                  <input
                    type="number"
                    step="0.5"
                    min="1"
                    max="16"
                    value={dailyInput}
                    onChange={(e) => setDailyInput(parseFloat(e.target.value) || 6)}
                    className="w-full p-2.5 rounded-xl bg-slate-950 border border-white/10 text-white font-mono focus:outline-none focus:border-purple-500"
                  />
                  <p className="text-[11px] text-gray-400">Target study hours per day for streak qualification.</p>
                </div>

                <div className="space-y-1.5">
                  <label className="font-bold text-gray-300 block">Monthly Target Hours</label>
                  <input
                    type="number"
                    step="5"
                    min="30"
                    max="500"
                    value={monthlyInput}
                    onChange={(e) => setMonthlyInput(parseFloat(e.target.value) || 180)}
                    className="w-full p-2.5 rounded-xl bg-slate-950 border border-white/10 text-white font-mono focus:outline-none focus:border-purple-500"
                  />
                  <p className="text-[11px] text-gray-400">Total deep work target hours per month.</p>
                </div>

                <div className="pt-3 flex justify-end gap-2">
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowGoalModal(false)}
                  >
                    Cancel
                  </Button>
                  <Button type="submit" variant="primary" size="sm">
                    Save Targets
                  </Button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* High-Level Fixed Portal Tooltip rendering directly into document.body */}
      {mounted &&
        hoveredTarget &&
        createPortal(
          (() => {
            const targetRect = hoveredTarget.rect;
            const spaceAbove = targetRect.top;
            const showBelow = spaceAbove < 170;

            const centerX = targetRect.left + targetRect.width / 2;
            const topY = targetRect.top;
            const bottomY = targetRect.bottom;

            const windowWidth = typeof window !== "undefined" ? window.innerWidth : 1200;
            const clampedX = Math.max(150, Math.min(windowWidth - 150, centerX));
            const arrowLeftOffset = centerX - clampedX;

            const hoveredDateFormatted = new Date(`${hoveredTarget.record.date}T12:00:00Z`).toLocaleDateString("en-US", {
              month: "long",
              day: "numeric",
              timeZone: "UTC",
            });

            return (
              <div
                className="fixed z-[99999] pointer-events-none transition-opacity duration-150"
                style={{
                  left: `${clampedX}px`,
                  top: `${showBelow ? bottomY + 10 : topY - 10}px`,
                  transform: showBelow ? "translate(-50%, 0)" : "translate(-50%, -100%)",
                }}
              >
                <div className="relative bg-slate-950/95 border border-purple-500/30 text-[11px] p-3.5 rounded-xl text-white whitespace-nowrap shadow-[0_10px_38px_rgba(0,0,0,0.8),0_0_20px_rgba(168,85,247,0.2)] space-y-1.5 backdrop-blur-xl ring-1 ring-white/10 max-w-xs animate-in fade-in zoom-in-95 duration-100">
                  {/* Pointer Arrow */}
                  <div
                    className={`absolute left-1/2 w-2.5 h-2.5 bg-slate-950 border border-purple-500/30 rotate-45 ${
                      showBelow
                        ? "-top-1.5 border-b-0 border-r-0"
                        : "-bottom-1.5 border-t-0 border-l-0"
                    }`}
                    style={{
                      transform: `translateX(calc(-50% + ${arrowLeftOffset}px)) rotate(45deg)`,
                    }}
                  />

                  <p className="font-bold text-purple-300 border-b border-white/10 pb-1 flex items-center gap-1.5">
                    <span>📅</span> {hoveredDateFormatted}
                  </p>

                  {hoveredTarget.record.studyHours > 0 ? (
                    <div className="space-y-1">
                      <p className="font-semibold text-white flex items-center gap-1.5">
                        <span>⏱</span> Study Time: <span className="font-mono text-purple-200">{hoveredTarget.record.studyHours} Hours</span>
                      </p>
                      <p className="text-gray-300 flex items-center gap-1.5">
                        <span>📊</span> Sessions: <span className="font-mono">{hoveredTarget.record.completedSessions}</span>
                      </p>
                      <p className="text-emerald-400 font-mono font-bold flex items-center gap-1.5">
                        <span>⚡</span> Average Focus: <span>{hoveredTarget.record.focusScore}%</span>
                      </p>
                      <p className="text-amber-300 font-mono font-bold flex items-center gap-1.5">
                        <span>⭐</span> XP Earned: <span>+{hoveredTarget.record.xpEarned} XP</span>
                      </p>
                      {hoveredTarget.record.subjects.length > 0 && (
                        <p className="text-cyan-300 font-medium flex items-center gap-1.5 max-w-[220px] truncate">
                          <span>📚</span> Subjects: <span className="truncate">{hoveredTarget.record.subjects.join(", ")}</span>
                        </p>
                      )}
                      {hoveredTarget.record.mistakesReviewedCount > 0 && (
                        <p className="text-rose-300 font-medium flex items-center gap-1.5">
                          <span>✍</span> Mistakes Revised: <span>{hoveredTarget.record.mistakesReviewedCount}</span>
                        </p>
                      )}
                    </div>
                  ) : (
                    <p className="text-gray-400 italic">No study recorded.</p>
                  )}
                </div>
              </div>
            );
          })(),
          document.body
        )}
    </Card>
  );
}
