"use client";

import { useState } from "react";
import { useStudyStore, AmbientSound } from "@/store/use-study-store";
import { useXpProgress, useStudyStreak } from "@/hooks/use-user-profile";
import { useAuth } from "@/context/AuthContext";
import { soundManager } from "@/lib/sound-manager";
import { motion, AnimatePresence } from "framer-motion";
import {
  Flame,
  Volume2,
  VolumeX,
  EyeOff,
  Eye,
  Music,
  Coffee,
  Brain,
  Wind,
  Menu,
} from "lucide-react";

interface HeaderProps {
  title: string;
  onMobileMenuToggle?: () => void;
}

export function Header({ title, onMobileMenuToggle }: HeaderProps) {
  const {
    monkModeEnabled,
    toggleMonkMode,
    ambientSound,
    setAmbientSound,
    volume,
    setVolume,
  } = useStudyStore();
  const { level } = useXpProgress();
  const { streak } = useStudyStreak();
  const { loading } = useAuth();

  const [soundMenuOpen, setSoundMenuOpen] = useState(false);
  const [sfxEnabled, setSfxEnabled] = useState(() => soundManager.isEnabled());
  const [sfxVolume, setSfxVolume] = useState(() => soundManager.getVolume());

  const sounds: Array<{ id: AmbientSound; name: string; icon: React.ReactNode }> = [
    { id: "none", name: "Silence", icon: <VolumeX className="w-4 h-4" /> },
    { id: "rain", name: "Rainfall", icon: <Wind className="w-4 h-4 text-blue-400" /> },
    { id: "white-noise", name: "White Noise", icon: <Coffee className="w-4 h-4 text-amber-400" /> },
    { id: "lofi", name: "Focus Drone", icon: <Brain className="w-4 h-4 text-purple-400" /> },
  ];

  const activeSound = sounds.find((s) => s.id === ambientSound);

  const toggleSoundMenu = () => {
    const next = !soundMenuOpen;
    setSoundMenuOpen(next);
    soundManager.play(next ? "open" : "close");
  };

  const handleToggleSfx = () => {
    const next = !sfxEnabled;
    setSfxEnabled(next);
    soundManager.setEnabled(next);
    if (next) {
      soundManager.play("toggle-on");
    }
  };

  const handleSfxVolumeChange = (newVol: number) => {
    setSfxVolume(newVol);
    soundManager.setVolume(newVol);
    soundManager.playThrottled("volume-change", 120);
  };

  const handleMonkModeToggle = () => {
    soundManager.play(monkModeEnabled ? "toggle-off" : "toggle-on");
    toggleMonkMode();
  };

  return (
    <header className="flex items-center justify-between h-14 md:h-16 px-3 md:px-6 border-b border-white/[0.08] bg-slate-950/80 backdrop-blur-xl relative z-40 gap-2 shadow-sm">
      <div className="flex items-center gap-2 md:gap-3 min-w-0">
        {/* Mobile hamburger menu button */}
        {onMobileMenuToggle && (
          <button
            type="button"
            onClick={onMobileMenuToggle}
            className="md:hidden flex items-center justify-center relative z-50 w-12 h-12 min-h-[48px] min-w-[48px] p-3 rounded-xl text-gray-400 hover:text-white hover:bg-white/[0.06] active:bg-white/[0.10] transition-colors shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-purple-500/50 touch-manipulation cursor-pointer pointer-events-auto"
            aria-label="Open navigation menu"
          >
            <Menu className="w-5 h-5 pointer-events-none" />
          </button>
        )}

        <h1 className="text-sm md:text-lg font-bold text-white tracking-tight truncate">{title}</h1>
      </div>

      <div className="flex items-center gap-2 md:gap-3 shrink-0">
        {/* Ambient Audio Panel */}
        <div className="relative">
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.97 }}
            onClick={toggleSoundMenu}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-full border text-xs font-semibold transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-purple-500/50 cursor-pointer ${ambientSound !== "none"
                ? "border-purple-500/30 bg-[#1c0f30] text-purple-200 shadow-sm"
                : "border-white/10 bg-[#0f1118]/80 text-gray-300 hover:text-white hover:bg-white/[0.07]"
              }`}
            aria-expanded={soundMenuOpen}
            aria-label="Ambient and UI sound controls"
          >
            <Music className={`w-3.5 h-3.5 ${ambientSound !== "none" ? "text-purple-400" : "text-gray-400"}`} />
            <span className="hidden sm:inline">
              {activeSound ? activeSound.name : "Sounds"}
            </span>
          </motion.button>

          <AnimatePresence>
            {soundMenuOpen && (
              <>
                <div
                  className="fixed inset-0 z-10"
                  onClick={() => {
                    setSoundMenuOpen(false);
                    soundManager.play("close");
                  }}
                />
                <motion.div
                  initial={{ opacity: 0, y: 8, scale: 0.96 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 8, scale: 0.96 }}
                  transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
                  className="absolute right-0 mt-2 w-72 rounded-2xl border border-white/[0.12] bg-[#0c0e17]/95 p-4 shadow-2xl shadow-black/90 z-50 backdrop-blur-2xl pointer-events-auto"
                >
                  {/* Ambient Focus Audio Section */}
                  <div className="flex items-center justify-between mb-2.5">
                    <p className="text-[11px] font-bold text-gray-400 uppercase tracking-wider">Ambient Focus Audio</p>
                    {ambientSound !== "none" && (
                      <span className="w-2 h-2 rounded-full bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)]" />
                    )}
                  </div>

                  <div className="space-y-1">
                    {sounds.map((sound) => (
                      <button
                        key={sound.id}
                        onClick={() => {
                          soundManager.play("select");
                          setAmbientSound(sound.id);
                        }}
                        className={`flex items-center justify-between w-full px-3 py-2 min-h-[38px] rounded-xl text-xs font-medium transition-all cursor-pointer ${ambientSound === sound.id
                            ? "bg-purple-500/20 text-purple-300 border border-purple-500/30"
                            : "text-gray-300 hover:text-white hover:bg-white/[0.05]"
                          }`}
                      >
                        <div className="flex items-center gap-2.5">
                          {sound.icon}
                          <span>{sound.name}</span>
                        </div>
                        {ambientSound === sound.id && (
                          <span className="w-1.5 h-1.5 rounded-full bg-purple-400 shadow-sm" />
                        )}
                      </button>
                    ))}
                  </div>

                  {ambientSound !== "none" && (
                    <div className="mt-3 pt-2.5 border-t border-white/[0.08]">
                      <div className="flex items-center justify-between text-xs text-gray-400 mb-1.5 font-medium">
                        <span>Ambient Volume</span>
                        <span className="font-mono text-purple-300 font-bold">{Math.round(volume * 100)}%</span>
                      </div>
                      <div className="flex items-center gap-2.5">
                        <VolumeX className="w-3.5 h-3.5 text-gray-500 shrink-0" />
                        <input
                          type="range"
                          min="0"
                          max="1"
                          step="0.05"
                          value={volume}
                          onChange={(e) => setVolume(parseFloat(e.target.value))}
                          aria-label="Ambient volume slider"
                          className="flex-1 h-1.5 bg-white/10 rounded-full appearance-none cursor-pointer accent-purple-500"
                        />
                        <Volume2 className="w-3.5 h-3.5 text-gray-300 shrink-0" />
                      </div>
                    </div>
                  )}

                  {/* UI Sound Effects (UI SFX) Section */}
                  <div className="mt-4 pt-3 border-t border-white/[0.10]">
                    <div className="flex items-center justify-between mb-2">
                      <div>
                        <span className="text-[11px] font-bold text-gray-300 uppercase tracking-wider block">UI Sound Effects</span>
                        <span className="text-[10px] text-gray-500 font-mono">uisfx • glass pack</span>
                      </div>
                      <button
                        type="button"
                        role="switch"
                        aria-checked={sfxEnabled}
                        aria-label="Toggle UI sound effects"
                        onClick={handleToggleSfx}
                        className={`px-2.5 py-1 rounded-full text-[10px] font-bold transition-all cursor-pointer border ${
                          sfxEnabled
                            ? "bg-emerald-950/60 border-emerald-500/40 text-emerald-400 shadow-[0_0_10px_rgba(16,185,129,0.2)]"
                            : "bg-slate-900 border-white/10 text-gray-500"
                        }`}
                      >
                        {sfxEnabled ? "ON" : "MUTED"}
                      </button>
                    </div>

                    {sfxEnabled && (
                      <div className="space-y-1 pt-1">
                        <div className="flex items-center justify-between text-xs text-gray-400 font-medium">
                          <span>SFX Volume</span>
                          <span className="font-mono text-cyan-300 font-bold">{Math.round(sfxVolume * 100)}%</span>
                        </div>
                        <div className="flex items-center gap-2.5">
                          <VolumeX className="w-3.5 h-3.5 text-gray-500 shrink-0" />
                          <input
                            type="range"
                            min="0"
                            max="1"
                            step="0.05"
                            value={sfxVolume}
                            onChange={(e) => handleSfxVolumeChange(parseFloat(e.target.value))}
                            aria-label="UI SFX volume slider"
                            className="flex-1 h-1.5 bg-white/10 rounded-full appearance-none cursor-pointer accent-cyan-400"
                          />
                          <Volume2 className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                        </div>
                      </div>
                    )}

                    {/* Link to Full Audio Settings in Profile */}
                    <div className="mt-3 pt-2.5 border-t border-white/[0.08] flex items-center justify-between text-[11px]">
                      <span className="text-gray-500 font-mono capitalize">Theme: {soundManager.getPack()}</span>
                      <a
                        href="/profile#sound-settings"
                        onClick={() => {
                          setSoundMenuOpen(false);
                          soundManager.play("select");
                        }}
                        className="text-purple-400 hover:text-purple-300 font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                      >
                        <span>Sound Settings</span>
                        <span>→</span>
                      </a>
                    </div>
                  </div>
                </motion.div>
              </>
            )}
          </AnimatePresence>
        </div>

        {/* Monk Mode Toggle Button */}
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.97 }}
          onClick={handleMonkModeToggle}
          className={`flex items-center gap-2 px-3 py-1.5 rounded-full border text-xs font-semibold transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-purple-500/50 cursor-pointer ${monkModeEnabled
              ? "bg-purple-500/20 border-purple-500/40 text-purple-300 shadow-md shadow-purple-950/40"
              : "bg-[#0f1118]/80 border-white/10 text-gray-300 hover:text-white hover:bg-white/[0.07]"
            }`}
          title={monkModeEnabled ? "Disable Monk Mode" : "Enable Monk Mode (Hides distracting elements)"}
          aria-label={monkModeEnabled ? "Disable Monk Mode" : "Enable Monk Mode"}
        >
          {monkModeEnabled ? (
            <>
              <Eye className="w-3.5 h-3.5 text-purple-400" />
              <span className="hidden sm:inline">Monk Mode On</span>
            </>
          ) : (
            <>
              <EyeOff className="w-3.5 h-3.5 text-gray-400" />
              <span className="hidden sm:inline">Monk Mode Off</span>
            </>
          )}
        </motion.button>

        {/* Level and Streak */}
        {!monkModeEnabled && (
          <div className="hidden sm:flex items-center gap-2 pl-1">
            {loading ? (
              <div className="flex items-center gap-2">
                <div className="h-7 w-20 bg-white/[0.06] rounded-full animate-pulse" />
                <div className="h-7 w-16 bg-white/[0.06] rounded-full animate-pulse" />
              </div>
            ) : (
              <>
                <div className="flex items-center gap-1.5 text-amber-400 font-bold text-xs tracking-tight bg-[#241708] px-3 py-1.5 rounded-full border border-amber-500/30">
                  <Flame className="w-3.5 h-3.5 fill-amber-500/20 text-amber-400" />
                  <span>{streak}d Streak</span>
                </div>

                <div className="flex items-center text-xs">
                  <span className="px-3 py-1.5 rounded-full border border-blue-500/30 bg-[#0e172e] text-blue-400 font-bold tracking-wide">
                    Lvl {level}
                  </span>
                </div>
              </>
            )}
          </div>
        )}
      </div>
    </header>
  );
}

