"use client";

import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Volume2, VolumeX, X, Sparkles } from "lucide-react";
import { soundManager } from "@/lib/sound-manager";

export function SoundOnboardingToast() {
  const [visible, setVisible] = useState(false);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    try {
      const onboarded = localStorage.getItem("focusforge:sfx-onboarded");
      if (!onboarded) {
        // Show after a gentle pause so the initial page render is calm and uncluttered
        const timer = setTimeout(() => {
          setVisible(true);
        }, 1200);
        return () => clearTimeout(timer);
      }
    } catch {
      // Storage unavailable fallback
    }
  }, []);

  if (!mounted || !visible) return null;

  const handleEnable = async () => {
    try {
      await soundManager.unlock();
      soundManager.setEnabled(true);
      soundManager.play("start");
      localStorage.setItem("focusforge:sfx-onboarded", "true");
    } catch {}
    setVisible(false);
  };

  const handleMute = () => {
    try {
      soundManager.setEnabled(false);
      localStorage.setItem("focusforge:sfx-onboarded", "true");
    } catch {}
    setVisible(false);
  };

  const handleDismiss = () => {
    try {
      localStorage.setItem("focusforge:sfx-onboarded", "true");
    } catch {}
    setVisible(false);
  };

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ opacity: 0, y: 24, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 20, scale: 0.95 }}
          transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
          className="fixed bottom-5 right-5 z-50 max-w-sm w-[calc(100vw-2.5rem)] rounded-2xl border border-purple-500/30 bg-[#0c0e18]/95 p-4 shadow-2xl shadow-purple-950/50 backdrop-blur-2xl text-white"
          role="region"
          aria-label="Sound preferences notification"
        >
          <div className="flex items-start justify-between gap-3">
            <div className="w-9 h-9 rounded-xl bg-purple-500/15 border border-purple-500/30 flex items-center justify-center text-purple-400 shrink-0">
              <Volume2 className="w-4 h-4" />
            </div>

            <div className="flex-1 space-y-1 min-w-0 pr-1">
              <div className="flex items-center gap-1.5">
                <h4 className="text-xs font-bold text-white tracking-tight">
                  Acoustic Feedback
                </h4>
                <span className="text-[10px] px-1.5 py-0.2 rounded bg-purple-500/20 text-purple-300 font-mono flex items-center gap-0.5">
                  <Sparkles className="w-2.5 h-2.5" /> Subtle
                </span>
              </div>
              <p className="text-[11px] text-gray-300 leading-relaxed font-sans">
                Enable soft, non-distracting sound cues for focus milestones, timer ticks, and achievements?
              </p>
            </div>

            <button
              type="button"
              onClick={handleDismiss}
              aria-label="Dismiss sound preference prompt"
              className="text-gray-400 hover:text-white p-1 rounded-lg hover:bg-white/[0.06] transition-colors shrink-0 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="mt-3.5 pt-3 border-t border-white/[0.08] flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={handleMute}
              className="px-3 py-1.5 rounded-xl text-xs font-semibold text-gray-400 hover:text-white hover:bg-white/[0.06] transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <VolumeX className="w-3.5 h-3.5" />
              <span>Keep Silent</span>
            </button>

            <button
              type="button"
              onClick={handleEnable}
              className="px-3.5 py-1.5 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 shadow-md shadow-purple-900/30 transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Volume2 className="w-3.5 h-3.5" />
              <span>Enable Audio</span>
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
