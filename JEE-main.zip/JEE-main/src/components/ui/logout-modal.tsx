"use client";

import React, { useState, useEffect } from "react";
import { createPortal } from "react-dom";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@/context/AuthContext";
import { useStudyStore } from "@/store/use-study-store";
import { Button } from "@/components/ui/controls";
import { Magnetic } from "@/components/ui/magnetic";
import { ThinkingOrb } from "thinking-orbs";
import { useIsClient } from "@/hooks/use-is-client";
import {
  LogOut,
  AlertTriangle,
  ShieldAlert,
  X,
  User,
} from "lucide-react";
import { soundManager } from "@/lib/sound-manager";

interface LogoutModalProps {
  isOpen: boolean;
  onClose: () => void;
}

/**
 * LogoutModal
 * Minimal, high-craft confirmation modal for user sign-out in FocusForge.
 * Portaled to document.body to span the entire display viewport.
 * Features:
 * - Centered full-screen backdrop with blur
 * - Non-overlapping flex header with safe close button
 * - Active focus session detection & hazard warning
 * - Minimal account identity strip (Avatar, Name, Handle, Cloud Synced badge)
 * - Tactile Magnetic action buttons
 * - Live revocation state with ThinkingOrb
 * - Keyboard accessibility (Escape to cancel)
 */
export function LogoutModal({ isOpen, onClose }: LogoutModalProps) {
  const isClient = useIsClient();
  const { userProfile, currentUser, logout } = useAuth();
  const { status, activeSession } = useStudyStore();
  const [isLoggingOut, setIsLoggingOut] = useState(false);

  const isActiveFocusSession = status === "focus" && !!activeSession;

  // Sound cue on modal open
  useEffect(() => {
    if (isOpen) {
      soundManager.play("open");
    }
  }, [isOpen]);

  const handleDismiss = () => {
    soundManager.play("cancel");
    onClose();
  };

  // Handle Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape" && isOpen && !isLoggingOut) {
        handleDismiss();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, isLoggingOut]);

  const handleConfirmLogout = async () => {
    setIsLoggingOut(true);
    soundManager.play("disconnect");
    soundManager.stopAll();
    try {
      // Small intentional delay for smooth micro-interaction feedback
      await new Promise((resolve) => setTimeout(resolve, 600));
      await logout({ redirect: true });
    } catch {
      setIsLoggingOut(false);
    }
  };

  const displayName = userProfile?.displayName || currentUser?.user_metadata?.full_name || "Aspirant";
  const username = userProfile?.username ? `@${userProfile.username}` : currentUser?.email || "";
  const initials = displayName
    .split(" ")
    .map((n: string) => n[0])
    .filter(Boolean)
    .join("")
    .slice(0, 2)
    .toUpperCase();

  if (!isClient || typeof document === "undefined") {
    return null;
  }

  return createPortal(
    <AnimatePresence>
      {isOpen && (
        <div
          className="fixed inset-0 z-[9999] flex items-center justify-center p-4 sm:p-6"
          role="dialog"
          aria-modal="true"
          aria-labelledby="logout-dialog-title"
        >
          {/* Full-Display Backdrop */}
          <motion.div
            key="logout-backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm"
            onClick={() => {
              if (!isLoggingOut) handleDismiss();
            }}
          />

          {/* Minimal Dialog Card */}
          <motion.div
            key="logout-dialog-card"
            initial={{ opacity: 0, scale: 0.94, y: 12 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.94, y: 12 }}
            transition={{ type: "spring", stiffness: 420, damping: 28 }}
            style={{ maxWidth: "410px" }}
            className="relative w-full max-w-sm sm:max-w-md rounded-2xl bg-gradient-to-b from-slate-900/98 via-slate-950/98 to-black border border-white/10 p-5 sm:p-6 shadow-2xl shadow-black/90 z-10 overflow-hidden"
          >
            {/* Ambient Danger & Purple Glows */}
            <div className="absolute top-0 right-0 w-36 h-36 rounded-full bg-red-600/10 blur-2xl pointer-events-none" />
            <div className="absolute bottom-0 left-0 w-36 h-36 rounded-full bg-purple-600/10 blur-2xl pointer-events-none" />

            {/* Header: Icon, Titles, and Close Button in one flex row */}
            <div className="flex items-start justify-between gap-3 mb-4.5">
              <div className="flex items-center gap-3.5 min-w-0">
                <div
                  className={`w-11 h-11 rounded-2xl border flex items-center justify-center shrink-0 shadow-lg ${
                    isActiveFocusSession
                      ? "bg-amber-500/15 border-amber-500/30 text-amber-400 shadow-amber-950/50"
                      : "bg-red-500/15 border-red-500/30 text-red-400 shadow-red-950/50"
                  }`}
                >
                  {isActiveFocusSession ? (
                    <AlertTriangle className="w-5 h-5 animate-pulse" />
                  ) : (
                    <LogOut className="w-5 h-5" />
                  )}
                </div>

                <div className="min-w-0">
                  <h3 id="logout-dialog-title" className="text-base sm:text-lg font-bold text-white tracking-tight leading-snug">
                    {isActiveFocusSession ? "Active Session Warning" : "Sign Out of FocusForge"}
                  </h3>
                  <p className="text-xs text-gray-400 mt-0.5 truncate">
                    {isActiveFocusSession
                      ? "Interrupting ongoing study session"
                      : "Confirm your session termination"}
                  </p>
                </div>
              </div>

              {/* Close Button */}
              {!isLoggingOut && (
                <button
                  type="button"
                  onClick={handleDismiss}
                  className="p-1.5 rounded-xl text-gray-400 hover:text-white hover:bg-white/[0.08] transition-colors cursor-pointer shrink-0 -mr-1 -mt-1"
                  aria-label="Close dialog"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Account Card Strip */}
            <div className="p-3 rounded-xl bg-white/[0.03] border border-white/[0.06] mb-4 flex items-center justify-between gap-3">
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-purple-600 via-indigo-600 to-blue-500 flex items-center justify-center text-xs font-bold text-white shadow-md border border-white/10 shrink-0">
                  {initials || <User className="w-4 h-4" />}
                </div>
                <div className="min-w-0">
                  <p className="text-xs sm:text-sm font-semibold text-white truncate">{displayName}</p>
                  <p className="text-[11px] text-cyan-400 font-mono truncate">{username}</p>
                </div>
              </div>
              <div className="px-2 py-0.5 rounded-md text-[10px] font-mono font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/25 shrink-0 flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                <span>Cloud Synced</span>
              </div>
            </div>

            {/* Active Session Warning Box (If in focus mode) */}
            {isActiveFocusSession && (
              <div className="mb-4 p-3 rounded-xl bg-amber-500/10 border border-amber-500/25 text-xs text-amber-200 space-y-1">
                <div className="flex items-center gap-2 font-bold text-amber-300">
                  <ShieldAlert className="w-4 h-4 shrink-0" />
                  <span className="truncate">
                    Study Timer Active: {activeSession.subject} ({activeSession.chapter})
                  </span>
                </div>
                <p className="leading-relaxed text-amber-200/80 text-[11px]">
                  Logging out now will forfeit this active session timer. Completed historical sessions and mistake logs are safely backed up.
                </p>
              </div>
            )}

            {!isActiveFocusSession && (
              <p className="text-xs text-gray-300 leading-relaxed mb-5">
                Your syllabus progress, spaced repetition intervals, and daily streaks remain securely saved in your cloud account. You can log back in anytime.
              </p>
            )}

            {/* Dynamic Action Buttons or Revocation Status */}
            {isLoggingOut ? (
              <div className="py-3 px-4 rounded-xl bg-purple-950/30 border border-purple-800/40 flex items-center justify-center gap-3 text-xs text-purple-300 font-medium">
                <ThinkingOrb state="working" size={20} theme="dark" />
                <span className="font-mono">Securing vault & signing out...</span>
              </div>
            ) : (
              <div className="flex items-center justify-end gap-2.5 pt-1">
                <Button
                  onClick={handleDismiss}
                  variant="secondary"
                  size="sm"
                  className="cursor-pointer font-medium text-xs px-3.5 py-2 min-h-0 h-9 rounded-xl"
                >
                  Stay in Workspace
                </Button>

                <Magnetic strength={0.2}>
                  <button
                    type="button"
                    onClick={handleConfirmLogout}
                    className="px-4 h-9 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-red-600 via-rose-600 to-red-500 hover:from-red-500 hover:to-rose-500 shadow-lg shadow-red-950/50 border border-red-500/30 transition-all flex items-center gap-2 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-red-500 active:scale-95"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>Sign Out</span>
                  </button>
                </Magnetic>
              </div>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>,
    document.body
  );
}

export default LogoutModal;
