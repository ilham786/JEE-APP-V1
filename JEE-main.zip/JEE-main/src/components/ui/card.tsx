import type { ReactNode } from "react";
import { motion } from "framer-motion";

interface CardProps {
  children: ReactNode;
  className?: string;
  variant?: "glass" | "dark" | "accent" | "physics" | "chemistry" | "maths";
  onClick?: () => void;
  hover?: boolean;
}

const variantStyles = {
  glass: "bg-gradient-to-br from-white/[0.07] to-white/[0.02] border border-white/[0.08] backdrop-blur-xl shadow-lg shadow-black/30 hover:border-white/[0.18]",
  dark: "bg-slate-900/60 border border-slate-800/90 shadow-md backdrop-blur-md hover:border-slate-700/80",
  accent: "bg-gradient-to-br from-purple-500/12 via-indigo-500/6 to-blue-500/12 border border-purple-500/25 shadow-lg shadow-purple-950/30 hover:border-purple-400/40",
  physics: "bg-gradient-to-br from-cyan-500/15 via-teal-600/5 to-cyan-400/10 border border-cyan-500/30 shadow-lg shadow-cyan-950/25 hover:border-cyan-400/50",
  chemistry: "bg-gradient-to-br from-emerald-500/12 via-teal-600/5 to-green-500/10 border border-emerald-500/25 shadow-lg shadow-emerald-950/25 hover:border-emerald-400/40",
  maths: "bg-gradient-to-br from-amber-500/12 via-yellow-600/5 to-orange-500/10 border border-amber-500/25 shadow-lg shadow-amber-950/25 hover:border-amber-400/40",
};

export function Card({
  children,
  className,
  variant = "glass",
  onClick,
  hover = true,
}: CardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
      whileHover={
        hover
          ? {
              y: -2,
              scale: 1.005,
              transition: { type: "spring", stiffness: 400, damping: 25 },
            }
          : undefined
      }
      whileTap={onClick ? { scale: 0.985 } : undefined}
      onClick={onClick}
      role={onClick ? "button" : undefined}
      tabIndex={onClick ? 0 : undefined}
      onKeyDown={
        onClick
          ? (e) => {
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                onClick();
              }
            }
          : undefined
      }
      className={`rounded-2xl p-5 transition-all duration-200 ${variantStyles[variant]} ${
        onClick || hover ? "cursor-pointer" : ""
      } ${className || ""}`}
    >
      {children}
    </motion.div>
  );
}

interface CardHeaderProps {
  title: string;
  subtitle?: string;
  icon?: ReactNode;
  action?: ReactNode;
  className?: string;
}

export function CardHeader({
  title,
  subtitle,
  icon,
  action,
  className,
}: CardHeaderProps) {
  return (
    <div className={`flex items-start justify-between mb-4 ${className || ""}`}>
      <div className="flex items-start gap-3 flex-1 min-w-0">
        {icon && (
          <div className="p-2 rounded-xl bg-purple-500/10 border border-purple-500/20 text-purple-400 shrink-0 shadow-inner">
            {icon}
          </div>
        )}
        <div className="min-w-0">
          <h3 className="font-bold text-base tracking-tight text-white truncate">{title}</h3>
          {subtitle && <p className="text-xs text-gray-400 mt-0.5 font-medium leading-relaxed">{subtitle}</p>}
        </div>
      </div>
      {action && <div className="shrink-0 ml-3">{action}</div>}
    </div>
  );
}

interface CardBodyProps {
  children: ReactNode;
  className?: string;
}

export function CardBody({ children, className }: CardBodyProps) {
  return <div className={`space-y-3.5 ${className || ""}`}>{children}</div>;
}

interface CardFooterProps {
  children: ReactNode;
  className?: string;
}

export function CardFooter({ children, className }: CardFooterProps) {
  return (
    <div className={`flex items-center gap-2 pt-4 border-t border-white/[0.08] mt-4 ${className || ""}`}>
      {children}
    </div>
  );
}

interface EmptyStateProps {
  icon?: ReactNode;
  title: string;
  description?: string;
  action?: ReactNode;
  className?: string;
}

export function EmptyState({
  icon,
  title,
  description,
  action,
  className,
}: EmptyStateProps) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.97 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
      className={`flex flex-col items-center justify-center text-center py-12 px-6 rounded-2xl bg-white/[0.02] border border-dashed border-white/10 ${className || ""}`}
    >
      {icon && (
        <div className="w-12 h-12 rounded-2xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400 mb-4 text-2xl shadow-inner">
          {icon}
        </div>
      )}
      <h3 className="text-base font-bold text-gray-200 mb-1 tracking-tight">{title}</h3>
      {description && (
        <p className="text-xs text-gray-400 mb-6 max-w-sm leading-relaxed">{description}</p>
      )}
      {action && <div>{action}</div>}
    </motion.div>
  );
}

export default { Card, CardHeader, CardBody, CardFooter, EmptyState };

