"use client";

import React, { useMemo } from "react";
import katex from "katex";
import "katex/dist/katex.min.css";

interface MathTextProps {
  content: string;
  className?: string;
}

/**
 * Renders mixed Markdown and LaTeX equations ($...$ for inline, $$...$$ for display)
 * cleanly using KaTeX with zero rendering crashes.
 */
export const MathText: React.FC<MathTextProps> = ({ content, className = "" }) => {
  const renderedHtml = useMemo(() => {
    if (!content) return "";

    try {
      // 1. First process display math ($$...$$)
      let processed = content.replace(/\$\$([\s\S]+?)\$\$/g, (_match, tex) => {
        try {
          return `<div class="my-2.5 overflow-x-auto py-1.5 px-3 rounded-lg bg-black/40 border border-white/5 text-center">${katex.renderToString(
            tex.trim(),
            { displayMode: true, throwOnError: false }
          )}</div>`;
        } catch {
          return `<div class="my-2 text-purple-300 font-mono text-xs">${tex}</div>`;
        }
      });

      // 2. Process inline math ($...$)
      processed = processed.replace(/\$([^\$\n]+?)\$/g, (_match, tex) => {
        try {
          return katex.renderToString(tex.trim(), {
            displayMode: false,
            throwOnError: false,
          });
        } catch {
          return `<span class="text-purple-300 font-mono text-xs">${tex}</span>`;
        }
      });

      // 3. Process markdown bold (**bold**)
      processed = processed.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>");

      // 4. Process line breaks (\n to <br/> when outside blocks)
      processed = processed.replace(/\n/g, "<br />");

      return processed;
    } catch {
      return content;
    }
  }, [content]);

  return (
    <div
      className={`leading-relaxed ${className}`}
      dangerouslySetInnerHTML={{ __html: renderedHtml }}
    />
  );
};
