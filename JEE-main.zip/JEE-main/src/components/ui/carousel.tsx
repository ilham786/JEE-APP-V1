"use client";

import {
  useState,
  useEffect,
  useRef,
  useCallback,
  useId,
  type ReactNode,
} from "react";
import { motion, AnimatePresence, type PanInfo } from "framer-motion";
import { ChevronLeft, ChevronRight } from "lucide-react";

export interface CarouselSlide {
  id: string | number;
  content: ReactNode;
}

export interface CarouselProps {
  slides: CarouselSlide[];
  autoPlay?: boolean;
  interval?: number; // Duration in ms per slide (default 5000)
  showControls?: boolean;
  showIndicators?: boolean;
  loop?: boolean;
  className?: string;
  slideClassName?: string;
  ariaLabel?: string;
}

export function Carousel({
  slides,
  autoPlay = true,
  interval = 5000,
  showControls = true,
  showIndicators = true,
  loop = true,
  className = "",
  slideClassName = "",
  ariaLabel = "Feature carousel",
}: CarouselProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isHovered, setIsHovered] = useState(false);
  const [direction, setDirection] = useState<number>(1);

  const carouselId = useId();
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const totalSlides = slides.length;

  const goToSlide = useCallback(
    (index: number, newDirection?: number) => {
      if (totalSlides <= 1) return;
      const targetDir = newDirection ?? (index > currentIndex ? 1 : -1);
      setDirection(targetDir);

      if (loop) {
        const nextIdx = (index + totalSlides) % totalSlides;
        setCurrentIndex(nextIdx);
      } else {
        const nextIdx = Math.max(0, Math.min(index, totalSlides - 1));
        setCurrentIndex(nextIdx);
      }
    },
    [currentIndex, loop, totalSlides]
  );

  const nextSlide = useCallback(() => {
    goToSlide(currentIndex + 1, 1);
  }, [currentIndex, goToSlide]);

  const prevSlide = useCallback(() => {
    goToSlide(currentIndex - 1, -1);
  }, [currentIndex, goToSlide]);

  // Handle Autoplay timer
  useEffect(() => {
    if (!autoPlay || isHovered || totalSlides <= 1) return;

    timerRef.current = setTimeout(() => {
      nextSlide();
    }, interval);

    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [autoPlay, currentIndex, interval, isHovered, nextSlide, totalSlides]);

  // Touch Swipe Drag Handler
  const handleDragEnd = (
    _e: MouseEvent | TouchEvent | PointerEvent,
    info: PanInfo
  ) => {
    const swipeThreshold = 40;
    if (info.offset.x < -swipeThreshold) {
      nextSlide();
    } else if (info.offset.x > swipeThreshold) {
      prevSlide();
    }
  };

  // Keyboard Arrow Key Handler
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "ArrowLeft") {
      e.preventDefault();
      prevSlide();
    } else if (e.key === "ArrowRight") {
      e.preventDefault();
      nextSlide();
    }
  };

  if (totalSlides === 0) return null;

  // Slide Animation Variants
  const slideVariants = {
    enter: (dir: number) => ({
      x: dir > 0 ? "100%" : "-100%",
      opacity: 0,
      scale: 0.96,
    }),
    center: {
      x: 0,
      opacity: 1,
      scale: 1,
    },
    exit: (dir: number) => ({
      x: dir < 0 ? "100%" : "-100%",
      opacity: 0,
      scale: 0.96,
    }),
  };

  return (
    <div
      tabIndex={0}
      onKeyDown={handleKeyDown}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className={`relative overflow-hidden group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-purple-500/50 rounded-2xl ${className}`}
      aria-label={ariaLabel}
      role="region"
    >
      {/* Carousel Track Container */}
      <div className="relative w-full h-full min-h-[140px] flex items-center justify-center">
        <AnimatePresence initial={false} custom={direction} mode="popLayout">
          <motion.div
            key={currentIndex}
            custom={direction}
            variants={slideVariants}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{
              x: { type: "spring", stiffness: 350, damping: 30 },
              opacity: { duration: 0.25 },
              scale: { duration: 0.25 },
            }}
            drag="x"
            dragConstraints={{ left: 0, right: 0 }}
            dragElastic={0.2}
            onDragEnd={handleDragEnd}
            className={`w-full h-full ${slideClassName}`}
          >
            {slides[currentIndex]?.content}
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Navigation Buttons (Previous / Next) */}
      {showControls && totalSlides > 1 && (
        <>
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={prevSlide}
            disabled={!loop && currentIndex === 0}
            className="absolute left-2 top-1/2 -translate-y-1/2 z-20 flex items-center justify-center w-9 h-9 rounded-full bg-slate-950/80 border border-white/10 text-gray-300 hover:text-white hover:bg-slate-900 transition-all opacity-0 group-hover:opacity-100 disabled:opacity-30 disabled:cursor-not-allowed focus-visible:opacity-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-purple-500/50 shadow-lg backdrop-blur-md"
            aria-label="Previous slide"
          >
            <ChevronLeft className="w-4 h-4" />
          </motion.button>

          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={nextSlide}
            disabled={!loop && currentIndex === totalSlides - 1}
            className="absolute right-2 top-1/2 -translate-y-1/2 z-20 flex items-center justify-center w-9 h-9 rounded-full bg-slate-950/80 border border-white/10 text-gray-300 hover:text-white hover:bg-slate-900 transition-all opacity-0 group-hover:opacity-100 disabled:opacity-30 disabled:cursor-not-allowed focus-visible:opacity-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-purple-500/50 shadow-lg backdrop-blur-md"
            aria-label="Next slide"
          >
            <ChevronRight className="w-4 h-4" />
          </motion.button>
        </>
      )}

      {/* Pagination Dot Indicators */}
      {showIndicators && totalSlides > 1 && (
        <div className="absolute bottom-3 left-1/2 -translate-x-1/2 z-20 flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-950/60 border border-white/10 backdrop-blur-md shadow-md">
          {slides.map((_, idx) => (
            <button
              key={`${carouselId}-dot-${idx}`}
              onClick={() => goToSlide(idx)}
              className="relative focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-purple-400 rounded-full p-1"
              aria-label={`Go to slide ${idx + 1}`}
              aria-current={idx === currentIndex ? "true" : "false"}
            >
              <span
                className={`block h-2 rounded-full transition-all duration-300 ${
                  idx === currentIndex
                    ? "w-6 bg-gradient-to-r from-purple-400 to-indigo-400 shadow-[0_0_8px_rgba(168,85,247,0.6)]"
                    : "w-2 bg-white/20 hover:bg-white/40"
                }`}
              />
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

export default Carousel;
