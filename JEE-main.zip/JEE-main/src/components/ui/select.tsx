"use client";

import {
  useState,
  useRef,
  useEffect,
  useId,
  useCallback,
  type ReactNode,
  type KeyboardEvent,
} from "react";
import { createPortal } from "react-dom";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronDown, Check, Search, X } from "lucide-react";

import { useIsClient } from "@/hooks/use-is-client";

export interface SelectOption {
  value: string;
  label: string;
  icon?: ReactNode;
  badge?: ReactNode;
  description?: string;
  disabled?: boolean;
  isHeader?: boolean;
  subject?: "Physics" | "Chemistry" | "Maths" | "Mathematics" | string;
}

export interface SelectProps {
  options: SelectOption[];
  value: string | string[];
  onChange: (value: string | string[]) => void;
  placeholder?: string;
  label?: string;
  icon?: ReactNode;
  disabled?: boolean;
  searchable?: boolean;
  searchPlaceholder?: string;
  isMulti?: boolean;
  isClearable?: boolean;
  usePortal?: boolean;
  size?: "sm" | "md" | "lg";
  variant?: "glass" | "dark" | "physics" | "chemistry" | "maths" | "botany" | "zoology" | "biology" | "accent";
  className?: string;
  error?: string;
}

const variantTriggerStyles = {
  glass: "bg-white/[0.04] border-white/10 hover:bg-white/[0.07] hover:border-white/20 text-white shadow-sm",
  dark: "bg-slate-900/90 border-white/10 hover:bg-slate-800 text-white shadow-sm",
  physics: "bg-[#15222b] border-[rgba(6,182,212,0.25)] hover:bg-[rgba(6,182,212,0.12)] text-[#67E8F9] shadow-sm",
  chemistry: "bg-[#132625] border-[rgba(16,185,129,0.25)] hover:bg-[rgba(16,185,129,0.12)] text-[#6EE7B7] shadow-sm",
  maths: "bg-[#231815] border-[rgba(245,158,11,0.25)] hover:bg-[rgba(245,158,11,0.12)] text-[#FCD34D] shadow-sm",
  botany: "bg-[#0f241d] border-[rgba(16,185,129,0.25)] hover:bg-[rgba(16,185,129,0.12)] text-[#34D399] shadow-sm",
  zoology: "bg-[#221633] border-[rgba(139,92,246,0.25)] hover:bg-[rgba(139,92,246,0.12)] text-[#C4B5FD] shadow-sm",
  biology: "bg-[#0f2324] border-[rgba(20,184,166,0.25)] hover:bg-[rgba(20,184,166,0.12)] text-[#5EEAD4] shadow-sm",
  accent: "bg-purple-500/10 border-purple-500/30 hover:bg-purple-500/15 text-purple-200 shadow-sm shadow-purple-950/20",
};

const sizeStyles = {
  sm: "min-h-[36px] text-xs px-3 py-1.5 rounded-lg gap-2",
  md: "min-h-[44px] text-sm px-3.5 py-2 rounded-xl gap-2.5",
  lg: "min-h-[48px] text-base px-4 py-2.5 rounded-xl gap-3",
};

export function Select({
  options,
  value,
  onChange,
  placeholder = "Select an option...",
  label,
  icon,
  disabled = false,
  searchable = false,
  searchPlaceholder = "Search options...",
  isMulti = false,
  isClearable = false,
  usePortal = true,
  size = "md",
  variant = "glass",
  className = "",
  error,
}: SelectProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [focusedIndex, setFocusedIndex] = useState<number>(-1);
  const [placement, setPlacement] = useState<"bottom" | "top">("bottom");
  const [coords, setCoords] = useState<{ top: number; left: number; width: number }>({
    top: 0,
    left: 0,
    width: 0,
  });
  const isMounted = useIsClient();

  const containerRef = useRef<HTMLDivElement>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);
  const listboxRef = useRef<HTMLDivElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);

  const selectId = useId();
  const listboxId = `${selectId}-listbox`;

  // Filter options based on search query
  const filteredOptions = options.filter(
    (opt) =>
      opt.label.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (opt.description && opt.description.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  // Normalize selected values
  const selectedValues = Array.isArray(value) ? value : value ? [value] : [];
  const selectedOptions = options.filter((opt) => selectedValues.includes(opt.value));
  const singleSelectedOption = !isMulti ? selectedOptions[0] : null;

  // Calculate coordinates and placement (flip to top if near bottom boundary)
  const updatePosition = useCallback(() => {
    if (triggerRef.current) {
      const rect = triggerRef.current.getBoundingClientRect();
      const popoverHeight = 280; // Estimated popover height
      const spaceBelow = window.innerHeight - rect.bottom;
      const shouldFlipTop = spaceBelow < popoverHeight && rect.top > popoverHeight;

      const topPos = shouldFlipTop
        ? rect.top - 8
        : rect.bottom + 8;

      setPlacement(shouldFlipTop ? "top" : "bottom");
      setCoords({
        top: topPos,
        left: rect.left,
        width: Math.max(rect.width, 220),
      });
    }
  }, []);

  const handleOpen = () => {
    if (disabled) return;
    updatePosition();
    setIsOpen(true);
    setSearchQuery("");
    const initialIndex = filteredOptions.findIndex((opt) => selectedValues.includes(opt.value));
    setFocusedIndex(initialIndex >= 0 ? initialIndex : 0);
  };

  const handleClose = () => {
    setIsOpen(false);
    setFocusedIndex(-1);
    setSearchQuery("");
  };

  const handleSelect = (optionValue: string) => {
    if (isMulti) {
      const exists = selectedValues.includes(optionValue);
      const newValues = exists
        ? selectedValues.filter((v) => v !== optionValue)
        : [...selectedValues, optionValue];
      onChange(newValues);
    } else {
      onChange(optionValue);
      handleClose();
      triggerRef.current?.focus();
    }
  };

  const handleClear = (e: React.MouseEvent) => {
    e.stopPropagation();
    onChange(isMulti ? [] : "");
  };

  // Close on outside click or scroll/resize
  useEffect(() => {
    if (!isOpen) return;

    const handleClickOutside = (e: MouseEvent) => {
      const target = e.target as Node;
      if (
        containerRef.current?.contains(target) ||
        listboxRef.current?.contains(target)
      ) {
        return;
      }
      handleClose();
    };

    const handleScrollOrResize = () => {
      updatePosition();
    };

    document.addEventListener("mousedown", handleClickOutside);
    window.addEventListener("scroll", handleScrollOrResize, true);
    window.addEventListener("resize", handleScrollOrResize);

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      window.removeEventListener("scroll", handleScrollOrResize, true);
      window.removeEventListener("resize", handleScrollOrResize);
    };
  }, [isOpen, updatePosition]);

  // Focus search input when popover opens
  useEffect(() => {
    if (isOpen && searchable && searchInputRef.current) {
      searchInputRef.current.focus();
    }
  }, [isOpen, searchable]);

  // Keyboard navigation handler
  const handleKeyDown = (e: KeyboardEvent) => {
    if (disabled) return;

    if (!isOpen) {
      if (["ArrowDown", "ArrowUp", "Enter", " "].includes(e.key)) {
        e.preventDefault();
        handleOpen();
      }
      return;
    }

    switch (e.key) {
      case "Escape":
        e.preventDefault();
        handleClose();
        triggerRef.current?.focus();
        break;

      case "ArrowDown":
        e.preventDefault();
        setFocusedIndex((prev) => {
          const next = prev + 1;
          return next < filteredOptions.length ? next : 0;
        });
        break;

      case "ArrowUp":
        e.preventDefault();
        setFocusedIndex((prev) => {
          const next = prev - 1;
          return next >= 0 ? next : filteredOptions.length - 1;
        });
        break;

      case "Home":
        e.preventDefault();
        setFocusedIndex(0);
        break;

      case "End":
        e.preventDefault();
        setFocusedIndex(filteredOptions.length - 1);
        break;

      case "Enter":
      case " ":
        if (searchable && document.activeElement === searchInputRef.current && e.key === " ") {
          return;
        }
        e.preventDefault();
        if (focusedIndex >= 0 && focusedIndex < filteredOptions.length) {
          const opt = filteredOptions[focusedIndex];
          if (!opt.disabled) {
            handleSelect(opt.value);
          }
        }
        break;

      case "Tab":
        handleClose();
        break;
    }
  };

  // Scroll focused option into view
  useEffect(() => {
    if (isOpen && listboxRef.current && focusedIndex >= 0) {
      const itemEl = listboxRef.current.children[focusedIndex] as HTMLElement;
      if (itemEl) {
        itemEl.scrollIntoView({ block: "nearest" });
      }
    }
  }, [focusedIndex, isOpen]);

  // Render the Popover Listbox
  const popoverContent = (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          id={listboxId}
          role="listbox"
          tabIndex={-1}
          aria-multiselectable={isMulti}
          aria-activedescendant={
            focusedIndex >= 0 ? `${selectId}-option-${focusedIndex}` : undefined
          }
          initial={{
            opacity: 0,
            y: placement === "bottom" ? -8 : 8,
            scale: 0.96,
          }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{
            opacity: 0,
            y: placement === "bottom" ? -8 : 8,
            scale: 0.96,
          }}
          transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
          style={
            usePortal
              ? {
                  position: "fixed",
                  top: placement === "bottom" ? coords.top : undefined,
                  bottom: placement === "top" ? window.innerHeight - coords.top : undefined,
                  left: coords.left,
                  width: coords.width,
                  zIndex: 9999,
                }
              : undefined
          }
          className={`${
            usePortal
              ? ""
              : `absolute left-0 right-0 z-50 ${
                  placement === "bottom" ? "top-full mt-2" : "bottom-full mb-2"
                }`
          } rounded-2xl border border-white/[0.12] bg-[#0c0e17]/95 backdrop-blur-2xl p-2 shadow-2xl shadow-black/90 pointer-events-auto`}
        >
          {/* Search Filter Input */}
          {searchable && (
            <div className="relative mb-2 px-1 pt-1">
              <Search className="w-4 h-4 absolute left-3.5 top-3 text-gray-400 pointer-events-none" />
              <input
                ref={searchInputRef}
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder={searchPlaceholder}
                className="w-full bg-white/[0.05] border border-white/10 rounded-xl pl-9 pr-8 py-1.5 text-xs text-white placeholder-gray-400 focus:outline-none focus:border-purple-500/60 focus:ring-1 focus:ring-purple-500/60 transition-colors"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery("")}
                  className="absolute right-3.5 top-3 text-gray-400 hover:text-white transition-colors"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          )}

          {/* Options Scrollable Container */}
          <div
            ref={listboxRef}
            className="max-h-60 overflow-y-auto space-y-1 pr-0.5 custom-scrollbar"
          >
            {filteredOptions.length === 0 ? (
              <div className="py-6 px-4 text-center text-xs text-gray-400 font-medium">
                No matching options found
              </div>
            ) : (
              filteredOptions.map((opt, idx) => {
                // If it's a section header (e.g. 📘 Physics)
                if (opt.isHeader) {
                  const headerSubject = opt.subject || (opt.label.includes("Physics") ? "Physics" : opt.label.includes("Chemistry") ? "Chemistry" : "Maths");
                  const headerColorClass =
                    headerSubject === "Physics"
                      ? "text-[#67E8F9] bg-[rgba(6,182,212,0.12)] border-[rgba(6,182,212,0.25)]"
                      : headerSubject === "Chemistry"
                      ? "text-[#6EE7B7] bg-[rgba(16,185,129,0.12)] border-[rgba(16,185,129,0.25)]"
                      : "text-[#FCD34D] bg-[rgba(245,158,11,0.12)] border-[rgba(245,158,11,0.25)]";

                  return (
                    <div
                      key={`header-${idx}-${opt.label}`}
                      className={`sticky top-0 z-10 px-3 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider border my-1 pointer-events-none flex items-center justify-between ${headerColorClass}`}
                    >
                      <span>{opt.label}</span>
                    </div>
                  );
                }

                const isSelected = selectedValues.includes(opt.value);
                const isFocused = idx === focusedIndex;

                const subjectKey = opt.subject || (
                  opt.value === "Physics" || opt.label === "Physics" ? "Physics" :
                  opt.value === "Chemistry" || opt.label === "Chemistry" ? "Chemistry" :
                  opt.value === "Maths" || opt.value === "Mathematics" || opt.label === "Maths" || opt.label === "Mathematics" ? "Maths" :
                  ""
                );

                const subjectOptionStyle =
                  subjectKey === "Physics"
                    ? isSelected
                      ? "bg-[rgba(6,182,212,0.16)] text-[#67E8F9] border border-[rgba(6,182,212,0.35)]"
                      : isFocused
                      ? "bg-[rgba(6,182,212,0.12)] text-[#67E8F9]"
                      : "text-gray-300 hover:text-[#67E8F9] hover:bg-[rgba(6,182,212,0.12)]"
                    : subjectKey === "Chemistry"
                    ? isSelected
                      ? "bg-[rgba(16,185,129,0.16)] text-[#6EE7B7] border border-[rgba(16,185,129,0.35)]"
                      : isFocused
                      ? "bg-[rgba(16,185,129,0.12)] text-[#6EE7B7]"
                      : "text-gray-300 hover:text-[#6EE7B7] hover:bg-[rgba(16,185,129,0.12)]"
                    : subjectKey === "Maths" || subjectKey === "Mathematics"
                    ? isSelected
                      ? "bg-[rgba(245,158,11,0.16)] text-[#FCD34D] border border-[rgba(245,158,11,0.35)]"
                      : isFocused
                      ? "bg-[rgba(245,158,11,0.12)] text-[#FCD34D]"
                      : "text-gray-300 hover:text-[#FCD34D] hover:bg-[rgba(245,158,11,0.12)]"
                    : "";

                return (
                  <motion.div
                    key={`${opt.value}-${idx}`}
                    id={`${selectId}-option-${idx}`}
                    role="option"
                    aria-selected={isSelected}
                    onClick={() => !opt.disabled && handleSelect(opt.value)}
                    onMouseEnter={() => setFocusedIndex(idx)}
                    whileHover={{ x: opt.disabled ? 0 : 2 }}
                    transition={{ duration: 0.15 }}
                    className={`flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium cursor-pointer transition-all ${
                      opt.disabled
                        ? "opacity-40 cursor-not-allowed text-gray-500"
                        : subjectOptionStyle
                        ? subjectOptionStyle
                        : isSelected
                        ? "bg-purple-500/20 text-purple-200 border border-purple-500/30 shadow-sm"
                        : isFocused
                        ? "bg-white/[0.08] text-white"
                        : "text-gray-300 hover:text-white hover:bg-white/[0.05]"
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      {opt.icon && <span className="shrink-0 text-gray-300">{opt.icon}</span>}
                      <div className="min-w-0">
                        <p className="truncate font-semibold">{opt.label}</p>
                        {opt.description && (
                          <p className="text-[11px] opacity-75 font-normal truncate mt-0.5">
                            {opt.description}
                          </p>
                        )}
                      </div>
                      {opt.badge && <span className="shrink-0">{opt.badge}</span>}
                    </div>

                    {isSelected && (
                      <motion.span
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        transition={{ type: "spring", stiffness: 500, damping: 30 }}
                        className={`shrink-0 ml-2 ${
                          subjectKey === "Physics"
                            ? "text-[#67E8F9]"
                            : subjectKey === "Chemistry"
                            ? "text-[#6EE7B7]"
                            : subjectKey === "Maths" || subjectKey === "Mathematics"
                            ? "text-[#FCD34D]"
                            : "text-purple-400"
                        }`}
                      >
                        <Check className="w-4 h-4" />
                      </motion.span>
                    )}
                  </motion.div>
                );
              })
            )}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );

  return (
    <div className={`relative w-full ${className}`} ref={containerRef}>
      {label && (
        <label className="block text-xs font-semibold uppercase tracking-wider text-gray-300 mb-1.5">
          {label}
        </label>
      )}

      {/* Trigger Button */}
      <motion.button
        ref={triggerRef}
        type="button"
        whileTap={{ scale: disabled ? 1 : 0.985 }}
        onClick={() => (isOpen ? handleClose() : handleOpen())}
        onKeyDown={handleKeyDown}
        disabled={disabled}
        aria-haspopup="listbox"
        aria-expanded={isOpen}
        aria-controls={listboxId}
        aria-label={label || placeholder}
        className={`flex items-center justify-between w-full border font-medium transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-purple-500/50 disabled:opacity-50 disabled:cursor-not-allowed ${variantTriggerStyles[variant]} ${sizeStyles[size]} ${
          isOpen ? "ring-2 ring-purple-500/50 border-purple-500/50" : ""
        } ${error ? "border-red-500/50 ring-2 ring-red-500/20" : ""}`}
      >
        <div className="flex items-center gap-2 min-w-0 truncate flex-1">
          {icon && <span className="text-gray-400 shrink-0">{icon}</span>}

          {isMulti && selectedOptions.length > 0 ? (
            <div className="flex flex-wrap items-center gap-1.5 truncate">
              {selectedOptions.map((opt) => (
                <span
                  key={opt.value}
                  className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-purple-500/20 border border-purple-500/30 text-purple-200 text-xs font-semibold"
                >
                  {opt.label}
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleSelect(opt.value);
                    }}
                    className="hover:text-white"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </span>
              ))}
            </div>
          ) : singleSelectedOption ? (
            <div className="flex items-center gap-2 truncate">
              {singleSelectedOption.icon && (
                <span className="shrink-0 text-gray-300">{singleSelectedOption.icon}</span>
              )}
              <span className="truncate text-white font-medium">
                {singleSelectedOption.label}
              </span>
              {singleSelectedOption.badge && (
                <span className="shrink-0">{singleSelectedOption.badge}</span>
              )}
            </div>
          ) : (
            <span className="text-gray-400 font-normal truncate">{placeholder}</span>
          )}
        </div>

        <div className="flex items-center gap-1 shrink-0 ml-2">
          {isClearable && selectedValues.length > 0 && (
            <span
              role="button"
              onClick={handleClear}
              className="text-gray-400 hover:text-white p-0.5 transition-colors cursor-pointer"
              title="Clear selection"
            >
              <X className="w-3.5 h-3.5" />
            </span>
          )}

          <motion.span
            animate={{ rotate: isOpen ? 180 : 0 }}
            transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
            className="text-gray-400"
          >
            <ChevronDown className="w-4 h-4" />
          </motion.span>
        </div>
      </motion.button>

      {error && <p className="text-xs text-red-400 mt-1 font-medium">{error}</p>}

      {/* Render popover into document body via portal if usePortal is true */}
      {usePortal && isMounted
        ? createPortal(popoverContent, document.body)
        : popoverContent}
    </div>
  );
}

export default Select;
