import type { ReactNode, ComponentPropsWithoutRef } from "react";
import { motion, type HTMLMotionProps } from "framer-motion";

interface ProgressBarProps {
  value: number; // 0-100
  max?: number;
  label?: string;
  showPercentage?: boolean;
  variant?: "primary" | "success" | "warning" | "danger" | "physics" | "chemistry" | "maths" | "botany" | "zoology" | "biology";
  className?: string;
}

const variantColors = {
  primary: "bg-gradient-to-r from-purple-500 to-indigo-500",
  success: "bg-gradient-to-r from-emerald-500 to-teal-500",
  warning: "bg-gradient-to-r from-amber-500 to-orange-500",
  danger: "bg-gradient-to-r from-red-500 to-rose-600",
  physics: "bg-gradient-to-r from-cyan-500 to-teal-400",
  chemistry: "bg-gradient-to-r from-emerald-500 to-teal-400",
  maths: "bg-gradient-to-r from-amber-500 to-yellow-500",
  botany: "bg-gradient-to-r from-emerald-500 to-teal-400",
  zoology: "bg-gradient-to-r from-purple-500 to-indigo-400",
  biology: "bg-gradient-to-r from-teal-500 to-cyan-400",
};

export function ProgressBar({
  value,
  max = 100,
  label,
  showPercentage = true,
  variant = "primary",
  className,
}: ProgressBarProps) {
  const percentage = Math.min(Math.max((value / max) * 100, 0), 100);

  return (
    <div className={className}>
      {(label || showPercentage) && (
        <div className="flex items-center justify-between mb-2">
          {label && <span className="text-xs font-semibold tracking-wide text-gray-300 uppercase">{label}</span>}
          {showPercentage && (
            <span className="text-xs font-mono font-bold text-gray-400 tabular-nums">
              {percentage.toFixed(0)}%
            </span>
          )}
        </div>
      )}
      <div className="w-full h-2.5 rounded-full bg-slate-900/90 border border-white/[0.08] overflow-hidden p-0.5 shadow-inner">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${percentage}%` }}
          transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
          className={`h-full rounded-full ${variantColors[variant] || variantColors.primary}`}
        />
      </div>
    </div>
  );
}

interface SectionHeaderProps {
  title: string;
  subtitle?: string;
  action?: ReactNode;
  className?: string;
}

export function SectionHeader({
  title,
  subtitle,
  action,
  className,
}: SectionHeaderProps) {
  return (
    <div className={`flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 ${className || ""}`}>
      <div>
        <h2 className="text-2xl font-bold tracking-tight text-white mb-1">{title}</h2>
        {subtitle && (
          <p className="text-sm text-gray-400 font-normal leading-relaxed">{subtitle}</p>
        )}
      </div>
      {action && <div className="shrink-0">{action}</div>}
    </div>
  );
}

interface ButtonProps
  extends Omit<HTMLMotionProps<"button">, "children"> {
  variant?: "primary" | "secondary" | "danger" | "ghost" | "physics" | "chemistry" | "maths" | "botany" | "zoology" | "biology";
  size?: "sm" | "md" | "lg";
  loading?: boolean;
  children: ReactNode;
}

const variantButtonStyles = {
  primary: "bg-gradient-to-r from-purple-600 via-indigo-600 to-purple-600 hover:from-purple-500 hover:to-indigo-500 text-white border-[1.5px] border-white shadow-[0_0_20px_rgba(147,51,234,0.35)] font-bold",
  secondary: "bg-[#0f1118]/80 hover:bg-[#161a26] border border-white/10 text-white font-medium backdrop-blur-md shadow-sm",
  danger: "bg-red-950/50 hover:bg-red-900/70 border border-red-800/40 text-red-300 hover:text-red-100 shadow-sm",
  ghost: "bg-transparent hover:bg-white/[0.08] border border-transparent text-gray-300 hover:text-white",
  physics: "bg-[#15222b] hover:bg-[#192b37] text-white border border-[#253e50] shadow-sm",
  chemistry: "bg-[#132625] hover:bg-[#18312f] text-white border border-[#1d423e] shadow-sm",
  maths: "bg-[#231815] hover:bg-[#2e1f1b] text-white border border-[#4a2f26] shadow-sm",
  botany: "bg-[#0f241d] hover:bg-[#153428] text-white border border-[#1d423e] shadow-sm",
  zoology: "bg-[#221633] hover:bg-[#2e1f42] text-white border border-[#3e255b] shadow-sm",
  biology: "bg-[#0f2324] hover:bg-[#143133] text-white border border-[#1b4344] shadow-sm",
};

const sizeButtonStyles = {
  sm: "text-xs px-4 py-2 min-h-[36px] rounded-xl gap-2 font-bold",
  md: "text-xs sm:text-sm px-5 py-2.5 min-h-[42px] rounded-xl gap-2 font-bold",
  lg: "text-base px-6 py-3 min-h-[48px] rounded-xl gap-2.5 font-bold",
};

export function Button({
  variant = "primary",
  size = "md",
  loading = false,
  children,
  disabled,
  className,
  ...props
}: ButtonProps) {
  return (
    <motion.button
      whileHover={{ scale: disabled || loading ? 1 : 1.02, transition: { type: "spring", stiffness: 400, damping: 25 } }}
      whileTap={{ scale: disabled || loading ? 1 : 0.97 }}
      disabled={disabled || loading}
      className={`relative inline-flex items-center justify-center font-sans tracking-wide transition-colors cursor-pointer select-none disabled:opacity-50 disabled:pointer-events-none disabled:cursor-not-allowed ${variantButtonStyles[variant]} ${sizeButtonStyles[size]} ${className || ""}`}
      {...props}
    >
      {loading ? (
        <span className="flex items-center gap-2">
          <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
          Loading...
        </span>
      ) : (
        children
      )}
    </motion.button>
  );
}

interface BadgeProps {
  children: ReactNode;
  variant?: "purple" | "blue" | "cyan" | "green" | "amber" | "red" | "pink" | "gray" | "physics" | "chemistry" | "maths" | "botany" | "zoology" | "biology";
  className?: string;
}

const badgeVariants = {
  purple: "bg-purple-500/10 text-purple-300 border-purple-500/20",
  blue: "bg-blue-500/10 text-blue-300 border-blue-500/20",
  cyan: "bg-[rgba(6,182,212,0.12)] text-[#67E8F9] border-[rgba(6,182,212,0.28)]",
  green: "bg-[rgba(16,185,129,0.12)] text-[#6EE7B7] border-[rgba(16,185,129,0.28)]",
  amber: "bg-[rgba(245,158,11,0.12)] text-[#FCD34D] border-[rgba(245,158,11,0.28)]",
  physics: "bg-[rgba(6,182,212,0.12)] text-[#67E8F9] border-[rgba(6,182,212,0.28)]",
  chemistry: "bg-[rgba(16,185,129,0.12)] text-[#6EE7B7] border-[rgba(16,185,129,0.28)]",
  maths: "bg-[rgba(245,158,11,0.12)] text-[#FCD34D] border-[rgba(245,158,11,0.28)]",
  botany: "bg-[rgba(16,185,129,0.12)] text-[#34D399] border-[rgba(16,185,129,0.28)]",
  zoology: "bg-[rgba(139,92,246,0.12)] text-[#C4B5FD] border-[rgba(139,92,246,0.28)]",
  biology: "bg-[rgba(20,184,166,0.12)] text-[#5EEAD4] border-[rgba(20,184,166,0.28)]",
  red: "bg-red-500/10 text-red-300 border-red-500/20",
  pink: "bg-pink-500/10 text-pink-300 border-pink-500/20",
  gray: "bg-white/[0.06] text-gray-300 border-white/10",
};

export function Badge({ children, variant = "purple", className }: BadgeProps) {
  return (
    <span
      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold border tracking-wide ${badgeVariants[variant]} ${className || ""}`}
    >
      {children}
    </span>
  );
}

export { Select, type SelectOption, type SelectProps } from "./select";
export { Carousel, type CarouselSlide, type CarouselProps } from "./carousel";

const Controls = { ProgressBar, SectionHeader, Button, Badge };
export default Controls;


