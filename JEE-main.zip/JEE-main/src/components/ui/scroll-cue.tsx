"use client";

import { useState, useEffect, useCallback } from "react";
import { ChevronDown } from "lucide-react";
import { soundManager } from "@/lib/sound-manager";

interface ScrollCueProps {
  /** Target HTML ID to scroll to when clicked */
  targetId?: string;
  /** Primary subtle text label */
  label?: string;
  /** Optional container class overrides */
  className?: string;
  /** Scroll threshold in pixels after which the cue fades out */
  fadeThreshold?: number;
}

/**
 * ScrollCue Component
 * 
 * An elegant, modern, accessible scroll suggestion cue designed specifically
 * for the Focus Forge landing hero.
 * 
 * Features:
 * - Focus Forge Precision Reticle: Gliding focus dot inside a glassmorphic capsule.
 * - Auto-fade: Smoothly disappears once the user scrolls down; reappears at the top.
 * - Zero Layout Shift (CLS 0): Preserves container height so fading does not shift content.
 * - Smooth scroll & tactile audio feedback via soundManager.
 * - Keyboard accessible with clear focus ring and screen-reader semantics.
 * - Respects prefers-reduced-motion preferences.
 */
export function ScrollCue({
  targetId = "extension-showcase",
  label = "Scroll to discover",
  className = "",
  fadeThreshold = 65,
}: ScrollCueProps) {
  const [isVisible, setIsVisible] = useState(true);

  const handleScrollEvent = useCallback(() => {
    const currentScrollY = window.scrollY || document.documentElement.scrollTop;
    setIsVisible(currentScrollY < fadeThreshold);
  }, [fadeThreshold]);

  useEffect(() => {
    // Initial check in case page is refreshed while scrolled
    handleScrollEvent();

    let ticking = false;
    const onScroll = () => {
      if (!ticking) {
        window.requestAnimationFrame(() => {
          handleScrollEvent();
          ticking = false;
        });
        ticking = true;
      }
    };

    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      window.removeEventListener("scroll", onScroll);
    };
  }, [handleScrollEvent]);

  const scrollToSection = () => {
    try {
      soundManager.play("select");
    } catch {
      // Audio cue is non-critical
    }

    const targetElement = document.getElementById(targetId);
    if (targetElement) {
      targetElement.scrollIntoView({ behavior: "smooth", block: "start" });
    } else {
      // Fallback: smooth scroll by 80% of the viewport height
      window.scrollBy({ top: window.innerHeight * 0.8, behavior: "smooth" });
    }
  };

  return (
    <div
      className={`w-full flex justify-center items-center select-none ${className}`}
      aria-hidden={!isVisible}
    >
      <button
        type="button"
        onClick={scrollToSection}
        disabled={!isVisible}
        tabIndex={isVisible ? 0 : -1}
        aria-label={`${label} — explore Focus Forge features below`}
        className={`group relative flex flex-col items-center gap-2.5 px-4 py-2 rounded-2xl cursor-pointer
          border border-white/[0.06] hover:border-purple-500/35
          bg-white/[0.02] hover:bg-purple-500/5
          backdrop-blur-md
          shadow-[0_4px_24px_rgba(0,0,0,0.25)] hover:shadow-[0_0_24px_rgba(139,92,246,0.2)]
          focus:outline-none focus-visible:ring-2 focus-visible:ring-purple-500/60 focus-visible:ring-offset-2 focus-visible:ring-offset-[#08090d]
          transition-all duration-500 cubic-bezier(0.16,1,0.3,1)
          ${
            isVisible
              ? "opacity-100 translate-y-0 pointer-events-auto"
              : "opacity-0 translate-y-3 pointer-events-none"
          }`}
      >
        {/* Focus Forge Precision Capsule Track */}
        <div className="relative flex items-center justify-center">
          {/* Ambient Glow */}
          <div className="absolute inset-0 rounded-full bg-purple-500/10 blur-sm group-hover:bg-purple-500/25 transition-colors duration-300" />

          {/* Capsule body */}
          <div className="relative w-5 h-8 sm:w-[22px] sm:h-[34px] rounded-full border border-white/20 group-hover:border-purple-400/50 bg-white/[0.04] p-1 flex justify-center shadow-inner transition-colors duration-300">
            {/* Gliding focus dot / reticle */}
            <span
              className="w-1.5 h-2 rounded-full bg-gradient-to-b from-purple-300 via-indigo-200 to-cyan-300 shadow-[0_0_8px_rgba(168,85,247,0.85)] animate-scroll-glide motion-reduce:animate-none"
              aria-hidden="true"
            />
          </div>
        </div>

        {/* Text & Chevron Label */}
        <div className="flex items-center gap-1.5 text-gray-400 group-hover:text-purple-200 transition-colors duration-300">
          <span className="font-mono text-[10px] sm:text-[11px] font-medium tracking-widest uppercase">
            {label}
          </span>
          <ChevronDown
            className="w-3.5 h-3.5 text-purple-400/80 group-hover:text-purple-300 animate-scroll-bounce-subtle motion-reduce:animate-none transition-transform duration-300 group-hover:translate-y-0.5"
            aria-hidden="true"
          />
        </div>
      </button>
    </div>
  );
}
