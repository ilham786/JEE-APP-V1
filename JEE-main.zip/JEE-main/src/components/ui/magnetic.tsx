"use client";

import React, { useRef } from "react";
import { gsap, useGSAP } from "@/lib/gsap";

interface MagneticProps {
  children: React.ReactNode;
  strength?: number;
  className?: string;
}

/**
 * Magnetic
 * GSAP-powered magnetic hover wrapper.
 * Smoothly pulls towards the cursor within its bounds and springs back using gsap.quickTo.
 * Respects prefers-reduced-motion via gsap.matchMedia.
 */
export function Magnetic({ children, strength = 0.3, className = "" }: MagneticProps) {
  const containerRef = useRef<HTMLDivElement>(null);

  useGSAP(
    () => {
      const el = containerRef.current;
      if (!el) return;

      const mm = gsap.matchMedia();
      mm.add("(prefers-reduced-motion: no-preference)", () => {
        const xTo = gsap.quickTo(el, "x", { duration: 0.4, ease: "power3.out" });
        const yTo = gsap.quickTo(el, "y", { duration: 0.4, ease: "power3.out" });

        const onMouseMove = (e: MouseEvent) => {
          const rect = el.getBoundingClientRect();
          const x = (e.clientX - (rect.left + rect.width / 2)) * strength;
          const y = (e.clientY - (rect.top + rect.height / 2)) * strength;
          xTo(x);
          yTo(y);
        };

        const onMouseLeave = () => {
          xTo(0);
          yTo(0);
        };

        el.addEventListener("mousemove", onMouseMove);
        el.addEventListener("mouseleave", onMouseLeave);

        return () => {
          el.removeEventListener("mousemove", onMouseMove);
          el.removeEventListener("mouseleave", onMouseLeave);
        };
      });
    },
    { scope: containerRef }
  );

  return (
    <div ref={containerRef} className={`inline-block ${className}`}>
      {children}
    </div>
  );
}

export default Magnetic;
