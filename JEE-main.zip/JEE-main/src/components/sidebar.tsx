"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useStudyStore } from "@/store/use-study-store";
import { useMistakeStore } from "@/store/use-mistake-store";
import { useAuth } from "@/context/AuthContext";
import { useXpProgress } from "@/hooks/use-user-profile";
import { useExam } from "@/hooks/use-exam";
import { motion, AnimatePresence } from "framer-motion";
import {
  LayoutDashboard,
  Timer,
  BookOpen,
  History,
  GraduationCap,
  Globe,
  Bot,
  BarChart3,
  TrendingDown,
  ChevronLeft,
  ChevronRight,
  Flame,
  Zap,
  X,
  LogOut,
  User,
} from "lucide-react";
import { LogoutModal } from "@/components/ui/logout-modal";
import { soundManager } from "@/lib/sound-manager";

interface SidebarProps {
  onMobileClose?: () => void;
}

export function Sidebar({ onMobileClose }: SidebarProps) {
  const pathname = usePathname();
  const { monkModeEnabled } = useStudyStore();
  const { userProfile, uid, loading } = useAuth();
  const { config, isNeet } = useExam();
  const { level, xpIntoCurrentLevel, xpRequiredForNextLevel, progressPercent } = useXpProgress();
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [showLogoutModal, setShowLogoutModal] = useState(false);

  const menuItems = [
    { name: "Dashboard", href: "/dashboard", icon: LayoutDashboard, keyHint: "Alt+D" },
    { name: "User Profile", href: "/profile", icon: User },
    { name: "Study Session", href: "/study", icon: Timer, keyHint: "Alt+S" },
    { name: "Mistake Journal", href: "/mistakes", icon: BookOpen, keyHint: "Alt+J" },
    { name: "Revision Plan", href: "/revisions", icon: History, keyHint: "Alt+R" },
    { name: config.trackerTitle || (isNeet ? "NEET Tracker" : "JEE Tracker"), href: "/jee", icon: GraduationCap },
    { name: "Distraction Logs", href: "/tracker", icon: TrendingDown },
    { name: "Web Blocker", href: "/blocker", icon: Globe },
    { name: "AI Coach", href: "/coach", icon: Bot },
    { name: "Full Analytics", href: "/analytics", icon: BarChart3, keyHint: "Alt+M" },
  ];

  const filteredMenuItems = monkModeEnabled
    ? menuItems.filter((item) => ["Study Session", "Dashboard"].includes(item.name))
    : menuItems;

  const displayName = userProfile?.displayName || (loading ? "Loading..." : "Guest Aspirant");
  const username = userProfile?.username
    ? `@${userProfile.username}`
    : userProfile?.email
      ? `@${userProfile.email.split("@")[0]}`
      : "@aspirant";
  const initials = displayName
    .trim()
    .split(" ")
    .map((n) => n[0])
    .filter(Boolean)
    .join("")
    .substring(0, 2)
    .toUpperCase() || "GA";

  return (
    <motion.div
      animate={{ width: isCollapsed ? "68px" : "240px" }}
      transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
      className="relative flex flex-col h-screen border-r border-white/[0.08] bg-slate-950/80 backdrop-blur-xl shrink-0 z-30"
    >
      {/* Brand Header */}
      <div className="flex items-center justify-between h-16 px-4 border-b border-white/[0.08]">
        {!isCollapsed && (
          <motion.span
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-lg font-bold tracking-tight bg-gradient-to-r from-purple-400 via-indigo-300 to-blue-400 bg-clip-text text-transparent flex items-center gap-2"
          >
            <Zap className="w-5 h-5 text-purple-400 fill-purple-400/20" />
            FocusForge
          </motion.span>
        )}
        {isCollapsed && (
          <div className="mx-auto text-purple-400">
            <Zap className="w-6 h-6 fill-purple-400/20" />
          </div>
        )}

        {/* Desktop collapse/expand toggle */}
        <button
          onClick={() => {
            soundManager.play(isCollapsed ? "expand" : "collapse");
            setIsCollapsed(!isCollapsed);
          }}
          className="absolute -right-3 top-5 hidden md:flex items-center justify-center w-6 h-6 rounded-full border border-white/10 bg-slate-900 text-gray-400 hover:text-white transition-colors focus-visible:ring-2 focus-visible:ring-purple-500/50 cursor-pointer"
          aria-label={isCollapsed ? "Expand sidebar" : "Collapse sidebar"}
        >
          {isCollapsed ? <ChevronRight className="w-3.5 h-3.5" /> : <ChevronLeft className="w-3.5 h-3.5" />}
        </button>

        {/* Mobile close button */}
        {onMobileClose && (
          <button
            onClick={onMobileClose}
            className="md:hidden flex items-center justify-center w-8 h-8 rounded-lg text-gray-400 hover:text-white hover:bg-white/5 transition-colors cursor-pointer"
            aria-label="Close menu"
          >
            <X className="w-5 h-5" />
          </button>
        )}
      </div>

      {/* Profile & Level Bar */}
      <AnimatePresence>
        {!isCollapsed && !monkModeEnabled && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="p-4 border-b border-white/[0.08] bg-white/[0.02]"
          >
            {loading ? (
              <div className="space-y-3 animate-pulse">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-white/10 shrink-0" />
                  <div className="space-y-1.5 flex-1 min-w-0">
                    <div className="h-3.5 bg-white/10 rounded-md w-24" />
                    <div className="h-2.5 bg-white/10 rounded-md w-16" />
                  </div>
                </div>
                <div className="space-y-1.5 pt-1">
                  <div className="flex justify-between">
                    <div className="h-2 bg-white/10 rounded w-10" />
                    <div className="h-2 bg-white/10 rounded w-16" />
                  </div>
                  <div className="w-full h-1.5 bg-white/10 rounded-full" />
                </div>
              </div>
            ) : (
              <>
                <div className="flex items-center justify-between gap-2">
                  <Link href="/profile" className="flex items-center gap-3 min-w-0 group flex-1">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-purple-600 to-blue-500 flex items-center justify-center text-sm font-bold text-white shadow-md shadow-purple-950/40 border border-white/10 shrink-0 group-hover:scale-105 transition-transform">
                      {initials}
                    </div>
                    <div className="overflow-hidden min-w-0">
                      <p className="text-sm font-semibold text-white truncate group-hover:text-purple-300 transition-colors">{displayName}</p>
                      <div className="flex items-center gap-1.5 text-xs text-cyan-400 font-mono font-medium">
                        <span className="truncate">{username}</span>
                        <span className={`text-[9px] font-mono px-1.5 py-0.5 rounded border font-bold shrink-0 ${
                          isNeet ? "text-emerald-300 border-emerald-500/30 bg-emerald-500/10" : "text-purple-300 border-purple-500/30 bg-purple-500/10"
                        }`}>
                          {config.shortName}
                        </span>
                      </div>
                    </div>
                  </Link>

                  <button
                    type="button"
                    onClick={() => setShowLogoutModal(true)}
                    className="p-2 rounded-xl text-gray-400 hover:text-red-400 hover:bg-red-500/10 border border-transparent hover:border-red-500/20 transition-all shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-red-500/50"
                    title="Sign Out of FocusForge"
                    aria-label="Sign Out of FocusForge"
                  >
                    <LogOut className="w-4 h-4" />
                  </button>
                </div>

                {/* XP progress */}
                <div className="mt-3">
                  <div className="flex justify-between text-[10px] text-gray-400 mb-1 font-mono">
                    <span>LVL {level}</span>
                    <span>{xpIntoCurrentLevel}/{xpRequiredForNextLevel} XP</span>
                  </div>
                  <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden p-0.5">
                    <div
                      className="h-full bg-gradient-to-r from-purple-500 to-indigo-500 rounded-full transition-all duration-500"
                      style={{ width: `${progressPercent}%` }}
                    />
                  </div>
                </div>
              </>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Navigation Menu */}
      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto safe-area-bottom">
        {filteredMenuItems.map((item) => {
          const Icon = item.icon;
          const isActive = pathname === item.href;

          return (
            <Link
              key={item.name}
              href={item.href}
              onClick={() => {
                soundManager.playThrottled("select", 150);
                if (onMobileClose) onMobileClose();
              }}
              title={isCollapsed ? item.name : undefined}
            >
              <div
                className={`flex items-center justify-between px-3 py-2.5 rounded-xl text-sm font-medium transition-all relative group ${isActive
                    ? "text-white bg-white/[0.08] shadow-[inset_0_1px_1px_rgba(255,255,255,0.12)]"
                    : "text-gray-400 hover:text-white hover:bg-white/[0.04]"
                  }`}
              >
                {isActive && (
                  <motion.div
                    layoutId="active-indicator"
                    className="absolute left-0 w-1 h-5 rounded-r-full bg-purple-500 shadow-[0_0_10px_rgba(139,92,246,0.6)]"
                    transition={{ type: "spring", stiffness: 400, damping: 30 }}
                  />
                )}
                <div className="flex items-center gap-3 min-w-0">
                  <Icon className={`w-5 h-5 shrink-0 transition-colors ${isActive ? "text-purple-400" : "text-gray-400 group-hover:text-gray-200"}`} />
                  {!isCollapsed && <span className="truncate">{item.name}</span>}
                </div>

                {!isCollapsed && item.keyHint && (
                  <span className="text-[10px] font-mono text-gray-500 bg-white/[0.04] px-1.5 py-0.5 rounded border border-white/[0.06] group-hover:border-white/10 group-hover:text-gray-400 transition-colors">
                    {item.keyHint}
                  </span>
                )}
              </div>
            </Link>
          );
        })}
      </nav>

      {/* Monk Mode Indicator Badge */}
      {!isCollapsed && monkModeEnabled && (
        <div className="m-4 p-3 rounded-xl border border-purple-500/30 bg-purple-500/10 text-center text-xs text-purple-300 font-semibold flex items-center justify-center gap-2 pulse-glow-effect">
          <span className="w-2 h-2 rounded-full bg-purple-400 inline-block shadow-[0_0_8px_rgba(168,85,247,0.8)]" />
          MONK MODE ACTIVE
        </div>
      )}

      {/* Logout Confirmation Dialog */}
      <LogoutModal isOpen={showLogoutModal} onClose={() => setShowLogoutModal(false)} />
    </motion.div>
  );
}
