"use client";

import React, { useState } from "react";
import { ChapterData } from "@/data/jee-syllabus-data";
import { Button, Badge } from "@/components/ui/controls";
import {
  X,
  BookOpen,
  Bookmark,
  CheckCircle2,
  FileText,
  AlertTriangle,
  Lightbulb,
  HelpCircle,
  Calendar,
  RotateCcw,
  Sparkles,
  Play,
  Copy,
  Check
} from "lucide-react";

interface ChapterDetailModalProps {
  chapter: ChapterData | null;
  isOpen: boolean;
  onClose: () => void;
  completion: number;
  confidence: number;
  pyqsSolved: number;
  revisionCycles: number;
  onUpdateCompletion: (val: number) => void;
  onUpdateConfidence: (val: number) => void;
  onQuickPractice: () => void;
}

export const ChapterDetailModal: React.FC<ChapterDetailModalProps> = ({
  chapter,
  isOpen,
  onClose,
  completion,
  confidence,
  pyqsSolved,
  revisionCycles,
  onUpdateCompletion,
  onUpdateConfidence,
  onQuickPractice,
}) => {
  const [activeTab, setActiveTab] = useState<"syllabus" | "formulas" | "mistakes" | "pyqs" | "revision">("syllabus");
  const [copiedFormula, setCopiedFormula] = useState<string | null>(null);

  if (!isOpen || !chapter) return null;

  const handleCopyFormula = (expr: string) => {
    navigator.clipboard.writeText(expr);
    setCopiedFormula(expr);
    setTimeout(() => setCopiedFormula(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 sm:p-6 overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-slate-950 border border-white/15 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-6 border-b border-white/10 bg-slate-900/60 flex items-start justify-between gap-4">
          <div className="space-y-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                {chapter.subject} • {chapter.classLevel}
              </span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20">
                ★ {chapter.importanceBadge} Priority
              </span>
              <span className="text-[10px] text-gray-400 font-mono">
                Past 5-Yr Trend: <strong className="text-white">{chapter.trendWeightage}%</strong>
              </span>
            </div>

            <h2 className="text-xl font-black text-white tracking-tight">{chapter.name}</h2>
            <p className="text-xs text-gray-400">Sub-discipline: <strong className="text-gray-200">{chapter.subDiscipline}</strong></p>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-white/[0.05] hover:bg-white/10 text-gray-400 hover:text-white transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selection Navigation */}
        <div className="flex border-b border-white/10 bg-slate-900/40 text-xs overflow-x-auto">
          {[
            { id: "syllabus", label: "Official NTA Syllabus", icon: BookOpen },
            { id: "formulas", label: "Formulas & Notes", icon: FileText },
            { id: "mistakes", label: "Common Traps & Tricks", icon: AlertTriangle },
            { id: "pyqs", label: "PYQs & Question Trends", icon: Lightbulb },
            { id: "revision", label: "Spaced Revision System", icon: Calendar },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as "syllabus" | "formulas" | "mistakes" | "pyqs" | "revision")}
                className={`px-4 py-3 font-bold flex items-center gap-2 border-b-2 transition-all whitespace-nowrap cursor-pointer ${
                  isActive
                    ? "text-cyan-400 border-cyan-400 bg-cyan-500/10"
                    : "text-gray-400 border-transparent hover:text-white hover:bg-white/[0.03]"
                }`}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {/* TAB 1: Official NTA Syllabus */}
          {activeTab === "syllabus" && (
            <div className="space-y-6">
              <div>
                <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">
                  Official NTA Syllabus Curriculum Topics
                </h3>
                <div className="space-y-2">
                  {chapter.topics.map((t, idx) => (
                    <div key={idx} className="p-3 bg-slate-900/60 rounded-xl border border-white/[0.08] flex items-start gap-3">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <span className="text-xs font-medium text-gray-200">{t}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">
                  Key Subtopics & Tested Concepts
                </h3>
                <div className="flex flex-wrap gap-2">
                  {chapter.subtopics.map((sub, idx) => (
                    <span key={idx} className="px-3 py-1.5 rounded-lg bg-white/[0.04] border border-white/[0.08] text-xs font-mono text-gray-300">
                      • {sub}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: Formulas & Short Notes */}
          {activeTab === "formulas" && (
            <div className="space-y-6">
              <div>
                <h3 className="text-xs font-bold text-cyan-400 uppercase tracking-wider mb-3 flex items-center gap-2">
                  <FileText className="w-4 h-4" /> Formula Sheet & Equations
                </h3>
                <div className="space-y-3">
                  {chapter.formulas.map((f, idx) => (
                    <div key={idx} className="p-4 bg-slate-900/80 rounded-xl border border-white/10 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-extrabold text-white">{f.name}</span>
                        <button
                          onClick={() => handleCopyFormula(f.expression)}
                          className="text-[10px] font-mono text-gray-400 hover:text-white flex items-center gap-1 bg-white/[0.05] px-2 py-1 rounded cursor-pointer"
                        >
                          {copiedFormula === f.expression ? (
                            <>
                              <Check className="w-3 h-3 text-emerald-400" /> Copied
                            </>
                          ) : (
                            <>
                              <Copy className="w-3 h-3" /> Copy Formula
                            </>
                          )}
                        </button>
                      </div>
                      <p className="text-xs font-mono text-cyan-300 bg-black/60 p-3 rounded-lg border border-cyan-500/20 leading-relaxed overflow-x-auto">
                        {f.expression}
                      </p>
                      <p className="text-[11px] text-gray-400">{f.description}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-xs font-bold text-purple-400 uppercase tracking-wider mb-3">
                  Quick Memory Booster Notes
                </h3>
                <div className="space-y-2">
                  {chapter.shortNotes.map((note, idx) => (
                    <div key={idx} className="p-3 bg-purple-950/20 border border-purple-500/20 rounded-xl text-xs text-purple-200">
                      💡 {note}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: Common Traps & Tricks */}
          {activeTab === "mistakes" && (
            <div className="space-y-6">
              <div>
                <h3 className="text-xs font-bold text-rose-400 uppercase tracking-wider mb-3 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4" /> Common Calculation Errors & Traps
                </h3>
                <div className="space-y-3">
                  {chapter.commonMistakes.map((m, idx) => (
                    <div key={idx} className="p-4 bg-rose-950/20 border border-rose-500/30 rounded-xl space-y-1">
                      <span className="text-xs font-bold text-rose-300 block">⚠️ Trap #{idx + 1}</span>
                      <p className="text-xs text-gray-300">{m}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-xs font-bold text-amber-400 uppercase tracking-wider mb-3">
                  Frequently Tested High-Yield Concepts
                </h3>
                <div className="flex flex-wrap gap-2">
                  {chapter.freqConcepts.map((fc, idx) => (
                    <span key={idx} className="px-3 py-1.5 rounded-lg bg-amber-500/10 border border-amber-500/20 text-xs font-bold text-amber-300">
                      ⚡ {fc}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: PYQs & Question Trends */}
          {activeTab === "pyqs" && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="p-4 bg-slate-900/60 rounded-xl border border-white/10 text-center">
                  <span className="text-[10px] text-gray-400 uppercase font-semibold block">Total PYQs Available</span>
                  <span className="text-2xl font-black text-white font-mono">{chapter.pyqsTotal}</span>
                </div>
                <div className="p-4 bg-slate-900/60 rounded-xl border border-white/10 text-center">
                  <span className="text-[10px] text-gray-400 uppercase font-semibold block">2024 Session Questions</span>
                  <span className="text-2xl font-black text-cyan-400 font-mono">{chapter.pyqs2024Count}</span>
                </div>
                <div className="p-4 bg-slate-900/60 rounded-xl border border-white/10 text-center">
                  <span className="text-[10px] text-gray-400 uppercase font-semibold block">2025 Session Questions</span>
                  <span className="text-2xl font-black text-purple-400 font-mono">{chapter.pyqs2025Count}</span>
                </div>
              </div>

              <div className="p-5 bg-gradient-to-r from-cyan-950/40 to-slate-900 border border-cyan-500/30 rounded-2xl flex items-center justify-between gap-4">
                <div className="space-y-1">
                  <h4 className="text-sm font-bold text-white">Solve Past JEE Main PYQs</h4>
                  <p className="text-xs text-gray-300">Target solving 25+ questions to achieve 85%+ exam accuracy benchmark.</p>
                </div>
                <Button
                  onClick={onQuickPractice}
                  variant="primary"
                  size="md"
                  className="shrink-0"
                >
                  <Play className="w-4 h-4 mr-1.5" /> Launch PYQ Practice
                </Button>
              </div>
            </div>
          )}

          {/* TAB 5: Spaced Revision System */}
          {activeTab === "revision" && (
            <div className="space-y-6">
              <div className="p-5 bg-slate-900/80 border border-white/10 rounded-2xl space-y-4">
                <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
                  <RotateCcw className="w-4 h-4 text-cyan-400" /> Spaced Revision Cycle Schedule
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="p-3 bg-slate-950 border border-white/[0.08] rounded-xl space-y-1">
                    <span className="text-[10px] text-gray-400 uppercase">Revision 1 (+1 Day)</span>
                    <span className="text-xs font-bold text-emerald-400 block">Completed</span>
                  </div>
                  <div className="p-3 bg-slate-950 border border-white/[0.08] rounded-xl space-y-1">
                    <span className="text-[10px] text-gray-400 uppercase">Revision 2 (+3 Days)</span>
                    <span className="text-xs font-bold text-cyan-400 block">Completed</span>
                  </div>
                  <div className="p-3 bg-slate-950 border border-cyan-500/30 rounded-xl space-y-1 bg-cyan-500/5">
                    <span className="text-[10px] text-gray-400 uppercase">Revision 3 (+7 Days)</span>
                    <span className="text-xs font-bold text-amber-400 block">Due in 2 Days</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer controls */}
        <div className="p-4 border-t border-white/10 bg-slate-900/60 flex items-center justify-between gap-4">
          <div className="flex items-center gap-4 text-xs text-gray-400">
            <span>Completed: <strong className="text-white font-mono">{completion}%</strong></span>
            <span>Confidence: <strong className="text-purple-300 font-mono">{confidence}%</strong></span>
          </div>
          <Button onClick={onClose} variant="secondary" size="sm">
            Done
          </Button>
        </div>
      </div>
    </div>
  );
};
