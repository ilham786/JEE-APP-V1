"use client";

import React from "react";
import { ChapterData } from "@/data/jee-syllabus-data";
import { Button } from "@/components/ui/controls";
import {
  BarChart3,
  X,
  TrendingUp,
  Target,
  Award,
  Flame,
  Zap,
  CheckCircle2,
  AlertCircle
} from "lucide-react";

interface SubjectAnalyticsProps {
  subject: "Physics" | "Chemistry" | "Maths";
  chapters: ChapterData[];
  completionMap: Record<string, number>;
  confidenceMap: Record<string, number>;
  isOpen: boolean;
  onClose: () => void;
}

export const SubjectAnalyticsModal: React.FC<SubjectAnalyticsProps> = ({
  subject,
  chapters,
  completionMap,
  confidenceMap,
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  // Calculate Sub-discipline stats
  const subDisciplineMap: Record<string, { totalWeightage: number; completedWeightage: number; chapterCount: number }> = {};
  
  let totalSubjectWeightage = 0;
  let totalMasteredWeightage = 0;

  chapters.forEach((chap) => {
    const comp = completionMap[chap.id] || 0;
    totalSubjectWeightage += chap.trendWeightage;
    totalMasteredWeightage += (chap.trendWeightage * comp) / 100;

    if (!subDisciplineMap[chap.subDiscipline]) {
      subDisciplineMap[chap.subDiscipline] = { totalWeightage: 0, completedWeightage: 0, chapterCount: 0 };
    }
    subDisciplineMap[chap.subDiscipline].totalWeightage += chap.trendWeightage;
    subDisciplineMap[chap.subDiscipline].completedWeightage += (chap.trendWeightage * comp) / 100;
    subDisciplineMap[chap.subDiscipline].chapterCount += 1;
  });

  const estimatedMarksCovered = Math.round((totalMasteredWeightage / 100) * 100);
  const estimatedPercentileBoost = (totalMasteredWeightage * 0.95).toFixed(1);

  // Weak vs Strong chapters
  const sortedByCompletion = [...chapters].sort((a, b) => (completionMap[a.id] || 0) - (completionMap[b.id] || 0));
  const weakestChapters = sortedByCompletion.slice(0, 3);
  const strongestChapters = [...chapters].sort((a, b) => (completionMap[b.id] || 0) - (completionMap[a.id] || 0)).slice(0, 3);

  // Mock 7-day density heatmap
  const heatmapDays = [
    { day: "Mon", hours: 2.5, density: "high" },
    { day: "Tue", hours: 4.0, density: "max" },
    { day: "Wed", hours: 1.5, density: "med" },
    { day: "Thu", hours: 3.5, density: "high" },
    { day: "Fri", hours: 0.5, density: "low" },
    { day: "Sat", hours: 5.0, density: "max" },
    { day: "Sun", hours: 3.0, density: "high" },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 sm:p-6 overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-slate-950 border border-white/15 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-6 border-b border-white/10 bg-slate-900/60 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
              <BarChart3 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-black text-white">{subject} Preparation Analytics & Exam Trends</h2>
              <p className="text-xs text-gray-400">Sub-discipline coverage, estimated marks, and 7-day study density</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-white/[0.05] hover:bg-white/10 text-gray-400 hover:text-white transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {/* Marks & Percentile Estimator Banner */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-5 bg-gradient-to-br from-cyan-950/50 to-slate-900 border border-cyan-500/30 rounded-2xl space-y-1">
              <span className="text-[10px] font-bold text-cyan-400 uppercase tracking-wider block">Expected Marks Coverage</span>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-black text-white font-mono">{estimatedMarksCovered}</span>
                <span className="text-xs text-gray-400">/ 100 Marks</span>
              </div>
              <p className="text-[11px] text-gray-400 mt-1">Based on past 5-year trend weightage completed.</p>
            </div>

            <div className="p-5 bg-gradient-to-br from-purple-950/50 to-slate-900 border border-purple-500/30 rounded-2xl space-y-1">
              <span className="text-[10px] font-bold text-purple-400 uppercase tracking-wider block">Estimated Subject Percentile</span>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-black text-white font-mono">{estimatedPercentileBoost}%ile</span>
              </div>
              <p className="text-[11px] text-gray-400 mt-1">Simulated performance based on current accuracy.</p>
            </div>

            <div className="p-5 bg-gradient-to-br from-emerald-950/50 to-slate-900 border border-emerald-500/30 rounded-2xl space-y-1">
              <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider block">Total Weightage Mastered</span>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-black text-white font-mono">{totalMasteredWeightage.toFixed(1)}%</span>
                <span className="text-xs text-gray-400">/ {totalSubjectWeightage.toFixed(1)}%</span>
              </div>
              <p className="text-[11px] text-gray-400 mt-1">Weightage of high & critical chapters finished.</p>
            </div>
          </div>

          {/* Sub-discipline breakdown */}
          <div className="p-5 bg-slate-900/60 border border-white/10 rounded-2xl space-y-4">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Target className="w-4 h-4 text-cyan-400" /> Sub-Discipline Weightage Coverage
            </h3>

            <div className="space-y-3">
              {Object.entries(subDisciplineMap).map(([subName, data]) => {
                const percentDone = data.totalWeightage > 0 ? (data.completedWeightage / data.totalWeightage) * 100 : 0;
                return (
                  <div key={subName} className="space-y-1.5 p-3 bg-slate-950/80 rounded-xl border border-white/[0.06]">
                    <div className="flex justify-between text-xs">
                      <span className="font-bold text-white">{subName} ({data.chapterCount} Chapters)</span>
                      <span className="font-mono text-cyan-300 font-bold">{percentDone.toFixed(0)}% Done ({data.completedWeightage.toFixed(1)}% / {data.totalWeightage.toFixed(1)}% Trend)</span>
                    </div>
                    <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                      <div className="h-full bg-gradient-to-r from-cyan-400 to-emerald-400 rounded-full" style={{ width: `${percentDone}%` }} />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* 7-Day Study Heatmap */}
          <div className="p-5 bg-slate-900/60 border border-white/10 rounded-2xl space-y-4">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Flame className="w-4 h-4 text-amber-400" /> 7-Day Study Heatmap & Intensity Density
            </h3>

            <div className="grid grid-cols-7 gap-2">
              {heatmapDays.map((d) => (
                <div key={d.day} className="p-3 bg-slate-950 border border-white/[0.08] rounded-xl text-center space-y-1">
                  <span className="text-[10px] text-gray-400 font-mono block uppercase">{d.day}</span>
                  <div 
                    className={`w-full h-8 rounded-lg flex items-center justify-center font-mono font-bold text-xs ${
                      d.density === "max" ? "bg-cyan-500 text-black shadow-lg shadow-cyan-500/30" :
                      d.density === "high" ? "bg-cyan-600/60 text-white" :
                      d.density === "med" ? "bg-cyan-800/40 text-cyan-200" :
                      "bg-white/[0.05] text-gray-500"
                    }`}
                  >
                    {d.hours}h
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Weakest vs Strongest Chapters */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-5 bg-rose-950/20 border border-rose-500/30 rounded-2xl space-y-3">
              <h4 className="text-xs font-bold text-rose-400 uppercase tracking-wider flex items-center gap-2">
                <AlertCircle className="w-4 h-4" /> Top Priority Weak Chapters
              </h4>
              <div className="space-y-2">
                {weakestChapters.map((ch) => (
                  <div key={ch.id} className="p-2.5 bg-slate-950 rounded-lg border border-white/[0.06] flex items-center justify-between text-xs">
                    <span className="font-medium text-white truncate max-w-[180px]">{ch.name}</span>
                    <span className="font-mono text-rose-400 font-bold">{completionMap[ch.id] || 0}%</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="p-5 bg-emerald-950/20 border border-emerald-500/30 rounded-2xl space-y-3">
              <h4 className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4" /> Strongest Mastered Chapters
              </h4>
              <div className="space-y-2">
                {strongestChapters.map((ch) => (
                  <div key={ch.id} className="p-2.5 bg-slate-950 rounded-lg border border-white/[0.06] flex items-center justify-between text-xs">
                    <span className="font-medium text-white truncate max-w-[180px]">{ch.name}</span>
                    <span className="font-mono text-emerald-400 font-bold">{completionMap[ch.id] || 100}%</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-white/10 bg-slate-900/60 flex justify-end">
          <Button onClick={onClose} variant="secondary" size="sm">
            Close Analytics
          </Button>
        </div>
      </div>
    </div>
  );
};
