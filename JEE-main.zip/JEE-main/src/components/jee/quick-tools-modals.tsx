"use client";

import React, { useState } from "react";
import { JEE_SYLLABUS_DATA, ChapterData } from "@/data/jee-syllabus-data";
import { Button } from "@/components/ui/controls";
import {
  Sparkles,
  X,
  Copy,
  Check,
  Zap,
  HelpCircle,
  BrainCircuit,
  FileText,
  Bookmark,
  Award
} from "lucide-react";

interface FormulaModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeSubject: "Physics" | "Chemistry" | "Maths";
}

export const FormulaCheatSheetModal: React.FC<FormulaModalProps> = ({
  isOpen,
  onClose,
  activeSubject,
}) => {
  const [sub, setSub] = useState<"Physics" | "Chemistry" | "Maths">(activeSubject);
  const [copiedExpr, setCopiedExpr] = useState<string | null>(null);

  if (!isOpen) return null;

  const chapters = JEE_SYLLABUS_DATA[sub] || [];

  const handleCopy = (expr: string) => {
    navigator.clipboard.writeText(expr);
    setCopiedExpr(expr);
    setTimeout(() => setCopiedExpr(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 sm:p-6 overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-slate-950 border border-white/15 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        <div className="p-5 border-b border-white/10 bg-slate-900/60 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-purple-500/10 text-purple-400 border border-purple-500/20">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-black text-white">Quick Formula & Concept Cheat-Sheet</h2>
              <p className="text-xs text-gray-400">High-yield equations and mathematical identities across JEE syllabus</p>
            </div>
          </div>

          <button onClick={onClose} className="p-2 rounded-xl bg-white/[0.05] hover:bg-white/10 text-gray-400 hover:text-white transition-all cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Subject selector */}
        <div className="flex border-b border-white/10 bg-slate-900/40 text-xs">
          {(["Physics", "Chemistry", "Maths"] as const).map((s) => (
            <button
              key={s}
              onClick={() => setSub(s)}
              className={`flex-1 py-3 text-center font-bold transition-all cursor-pointer ${
                sub === s ? "text-white bg-white/[0.05] border-b-2 border-b-cyan-400" : "text-gray-500 hover:text-gray-300"
              }`}
            >
              {s}
            </button>
          ))}
        </div>

        {/* Content list */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {chapters.map((ch) => (
            <div key={ch.id} className="space-y-3 p-4 bg-slate-900/40 rounded-xl border border-white/[0.06]">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-extrabold text-white font-mono">{ch.name}</h3>
                <span className="text-[10px] text-gray-400">{ch.classLevel}</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {ch.formulas.map((f, idx) => (
                  <div key={idx} className="p-3 bg-slate-950 rounded-lg border border-white/10 space-y-1.5">
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="font-bold text-gray-200">{f.name}</span>
                      <button onClick={() => handleCopy(f.expression)} className="text-gray-400 hover:text-white cursor-pointer">
                        {copiedExpr === f.expression ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      </button>
                    </div>
                    <p className="text-xs font-mono text-cyan-300 bg-black/60 p-2 rounded border border-cyan-500/20 overflow-x-auto">
                      {f.expression}
                    </p>
                    <p className="text-[10px] text-gray-400">{f.description}</p>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

interface RandomPyqModalProps {
  isOpen: boolean;
  onClose: () => void;
  chapter: ChapterData | null;
}

export const RandomPyqChallengeModal: React.FC<RandomPyqModalProps> = ({
  isOpen,
  onClose,
  chapter,
}) => {
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [submitted, setSubmitted] = useState(false);

  if (!isOpen || !chapter) return null;

  const mockQuestions = [
    {
      q: `An electron is accelerated from rest through a potential difference V in ${chapter.name}. What is the fractional change in its de Broglie wavelength when potential is increased by 21%?`,
      options: ["-9.1%", "-4.8%", "+5.0%", "+10.0%"],
      correct: 0,
      solution: "De Broglie wavelength lambda = h / sqrt(2m q V). So lambda is inversely proportional to sqrt(V). When V increases by 21% to 1.21 V, lambda' = lambda / sqrt(1.21) = lambda / 1.1 = 0.909 lambda. Hence fractional change is -9.1%."
    },
    {
      q: `For the chapter ${chapter.name}, evaluate the magnitude of the maximum value of the function under JEE Main standard constraints.`,
      options: ["4.00", "2.50", "8.00", "1.73"],
      correct: 2,
      solution: "Applying standard max/min derivative criteria f'(x) = 0 yields x = 2, resulting in f(2) = 8.00."
    }
  ];

  const currentQ = mockQuestions[0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 sm:p-6 overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-slate-950 border border-white/15 rounded-2xl shadow-2xl overflow-hidden flex flex-col">
        <div className="p-5 border-b border-white/10 bg-slate-900/60 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
              <Zap className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-black text-white">Random PYQ Speed Challenge</h2>
              <p className="text-xs text-gray-400">Chapter: <strong className="text-white">{chapter.name}</strong></p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 rounded-xl bg-white/[0.05] hover:bg-white/10 text-gray-400 hover:text-white transition-all cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-5">
          <div className="p-4 bg-slate-900/80 rounded-xl border border-white/10">
            <span className="text-[10px] font-bold text-amber-400 uppercase tracking-wider block mb-2">JEE Main High-Yield Question</span>
            <p className="text-sm font-medium text-white leading-relaxed">{currentQ.q}</p>
          </div>

          <div className="space-y-2">
            {currentQ.options.map((opt, idx) => (
              <button
                key={idx}
                onClick={() => setSelectedOption(idx)}
                className={`w-full p-3 rounded-xl border text-left text-xs font-mono transition-all cursor-pointer flex items-center justify-between ${
                  selectedOption === idx
                    ? "bg-cyan-500/20 border-cyan-400 text-white font-bold"
                    : "bg-slate-900/40 border-white/[0.08] text-gray-300 hover:bg-white/[0.05]"
                }`}
              >
                <span>({String.fromCharCode(65 + idx)}) {opt}</span>
                {selectedOption === idx && <Check className="w-4 h-4 text-cyan-400" />}
              </button>
            ))}
          </div>

          {submitted && (
            <div className={`p-4 rounded-xl border space-y-2 ${
              selectedOption === currentQ.correct ? "bg-emerald-950/30 border-emerald-500/30 text-emerald-200" : "bg-rose-950/30 border-rose-500/30 text-rose-200"
            }`}>
              <div className="flex items-center gap-2 font-bold text-xs">
                {selectedOption === currentQ.correct ? "🎉 Correct Answer! (+4 Marks)" : "❌ Incorrect. Correct Option is (A)"}
              </div>
              <p className="text-xs text-gray-300 font-mono leading-relaxed bg-black/40 p-2.5 rounded border border-white/10">
                {currentQ.solution}
              </p>
            </div>
          )}

          <div className="flex justify-end gap-3">
            {!submitted ? (
              <Button
                onClick={() => setSubmitted(true)}
                disabled={selectedOption === null}
                variant="primary"
                size="md"
              >
                Submit Answer
              </Button>
            ) : (
              <Button onClick={onClose} variant="secondary" size="md">
                Close Challenge
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
