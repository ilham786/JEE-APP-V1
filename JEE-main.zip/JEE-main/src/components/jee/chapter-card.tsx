"use client";

import React from "react";
import { ChapterData } from "@/data/jee-syllabus-data";
import { Card } from "@/components/ui/card";
import { Badge, Button } from "@/components/ui/controls";
import {
  Star,
  Bookmark,
  Sparkles,
  Flame,
  CheckCircle2,
  Clock,
  RotateCcw,
  Play,
  FileText,
  ChevronRight,
  TrendingUp,
  BrainCircuit,
  Award
} from "lucide-react";

interface ChapterCardProps {
  chapter: ChapterData;
  completion: number;
  confidence: number;
  pyqsSolved: number;
  revisionCycles: number;
  lastRevisedDaysAgo?: number;
  nextRevisionDays?: number;
  isBookmarked: boolean;
  isFavourite: boolean;
  viewMode: "linear" | "notion" | "kanban";
  subjectColor: "cyan" | "emerald" | "purple";
  onToggleBookmark: () => void;
  onToggleFavourite: () => void;
  onUpdateCompletion: (val: number) => void;
  onUpdateConfidence: (val: number) => void;
  onOpenDetails: () => void;
  onQuickStart: () => void;
}

export const ChapterCard: React.FC<ChapterCardProps> = ({
  chapter,
  completion,
  confidence,
  pyqsSolved,
  revisionCycles,
  lastRevisedDaysAgo = 4,
  nextRevisionDays = 3,
  isBookmarked,
  isFavourite,
  viewMode,
  subjectColor,
  onToggleBookmark,
  onToggleFavourite,
  onUpdateCompletion,
  onUpdateConfidence,
  onOpenDetails,
  onQuickStart,
}) => {
  const getImportanceColor = (stars: number) => {
    switch (stars) {
      case 5:
        return "bg-rose-500/15 text-rose-400 border-rose-500/30";
      case 4:
        return "bg-amber-500/15 text-amber-400 border-amber-500/30";
      case 3:
        return "bg-cyan-500/15 text-cyan-400 border-cyan-500/30";
      case 2:
        return "bg-slate-500/15 text-slate-400 border-slate-500/30";
      default:
        return "bg-gray-500/10 text-gray-500 border-gray-500/20";
    }
  };

  const getDifficultyBadge = (diff: string) => {
    switch (diff) {
      case "Easy":
        return <Badge variant="green" className="text-[10px] px-2 py-0.5">Easy</Badge>;
      case "Medium":
        return <Badge variant="amber" className="text-[10px] px-2 py-0.5">Medium</Badge>;
      case "Hard":
      case "Very Hard":
        return <Badge variant="red" className="text-[10px] px-2 py-0.5">{diff}</Badge>;
      default:
        return null;
    }
  };

  const getStatusBadge = () => {
    if (completion >= 100 && confidence >= 85) {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
          <Award className="w-3 h-3 text-emerald-400" /> Mastered
        </span>
      );
    }
    if (completion >= 100) {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-blue-500/20 text-blue-300 border border-blue-500/30">
          <CheckCircle2 className="w-3 h-3 text-blue-400" /> Completed
        </span>
      );
    }
    if (nextRevisionDays <= 0 && revisionCycles > 0) {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 animate-pulse">
          <RotateCcw className="w-3 h-3 text-amber-400" /> Revision Due
        </span>
      );
    }
    if (completion > 0) {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/30">
          <Clock className="w-3 h-3 text-purple-400" /> In Progress
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-medium bg-white/[0.05] text-gray-400 border border-white/10">
        Not Started
      </span>
    );
  };

  // Render Notion Bento Card View
  if (viewMode === "notion") {
    return (
      <Card variant={subjectColor === "cyan" ? "physics" : subjectColor === "emerald" ? "chemistry" : "maths"} className="group relative overflow-hidden transition-all duration-300 hover:border-white/20 p-5 space-y-4">
        {/* Top bar */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-gray-400 font-mono">
              {chapter.classLevel} • {chapter.subDiscipline}
            </span>
            {getStatusBadge()}
          </div>
          <div className="flex items-center gap-1">
            <button
              onClick={onToggleFavourite}
              className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                isFavourite ? "text-amber-400 bg-amber-400/10" : "text-gray-500 hover:text-gray-300"
              }`}
              title="Toggle Favourite"
            >
              <Star className="w-3.5 h-3.5 fill-current" />
            </button>
            <button
              onClick={onToggleBookmark}
              className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                isBookmarked ? "text-cyan-400 bg-cyan-400/10" : "text-gray-500 hover:text-gray-300"
              }`}
              title="Bookmark Chapter"
            >
              <Bookmark className="w-3.5 h-3.5 fill-current" />
            </button>
          </div>
        </div>

        {/* Title */}
        <div>
          <h3 
            onClick={onOpenDetails}
            className="text-base font-extrabold text-white group-hover:text-cyan-300 transition-colors cursor-pointer flex items-center justify-between"
          >
            <span>{chapter.name}</span>
            <ChevronRight className="w-4 h-4 text-gray-500 group-hover:translate-x-1 transition-transform" />
          </h3>
          <p className="text-xs text-gray-400 mt-1 line-clamp-1">
            {chapter.topics.slice(0, 2).join(", ")}
          </p>
        </div>

        {/* Importance Stars & Trend Weightage */}
        <div className="grid grid-cols-2 gap-2 pt-2 border-t border-white/[0.06]">
          <div className="space-y-1">
            <span className="text-[10px] text-gray-400 uppercase font-semibold block">Past 5-Yr Trend</span>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold text-white">{chapter.trendWeightage}%</span>
              <div className="flex-1 h-1.5 bg-white/10 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-cyan-400 to-indigo-500 rounded-full"
                  style={{ width: `${Math.min(100, chapter.trendWeightage * 12)}%` }}
                />
              </div>
            </div>
          </div>

          <div className="space-y-1">
            <span className="text-[10px] text-gray-400 uppercase font-semibold block">Priority Badge</span>
            <div className="flex items-center gap-1">
              <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${getImportanceColor(chapter.importanceStars)}`}>
                {"★".repeat(chapter.importanceStars)} {chapter.importanceBadge}
              </span>
            </div>
          </div>
        </div>

        {/* Progress & Confidence sliders */}
        <div className="space-y-2.5 pt-1">
          <div className="space-y-1">
            <div className="flex justify-between text-xs text-gray-400 font-medium">
              <span>Completion ({completion}%)</span>
              <span>PYQs: <strong className="text-white font-mono">{pyqsSolved} / {chapter.pyqsTotal}</strong></span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              value={completion}
              onChange={(e) => onUpdateCompletion(parseInt(e.target.value))}
              className="w-full h-1.5 bg-white/10 rounded-full appearance-none cursor-pointer accent-cyan-400"
            />
          </div>

          <div className="flex items-center justify-between text-xs text-gray-400">
            <span className="flex items-center gap-1">
              <BrainCircuit className="w-3.5 h-3.5 text-purple-400" /> Confidence: <strong className="text-purple-300 font-mono">{confidence}%</strong>
            </span>
            <span className="text-[10px] text-gray-400">Cycles: <strong className="text-white font-mono">{revisionCycles}</strong></span>
          </div>
        </div>

        {/* Action footer */}
        <div className="flex items-center gap-2 pt-2 border-t border-white/[0.06]">
          <Button
            onClick={onOpenDetails}
            variant="secondary"
            size="sm"
            className="flex-1 text-xs py-1.5 justify-center"
          >
            <FileText className="w-3.5 h-3.5 mr-1" /> Notes & Formulas
          </Button>
          <Button
            onClick={onQuickStart}
            variant="primary"
            size="sm"
            className="text-xs py-1.5 px-3 justify-center shrink-0"
          >
            <Play className="w-3.5 h-3.5" />
          </Button>
        </div>
      </Card>
    );
  }

  // Render Linear List View
  if (viewMode === "linear") {
    return (
      <div className="group bg-slate-900/60 hover:bg-slate-900/90 border border-white/[0.08] hover:border-white/20 rounded-xl p-3.5 transition-all flex flex-col md:flex-row md:items-center justify-between gap-4">
        {/* Left main info */}
        <div className="flex items-start md:items-center gap-3 flex-1 min-w-0">
          <button
            onClick={onToggleFavourite}
            className={`p-1 mt-0.5 md:mt-0 transition-colors shrink-0 cursor-pointer ${
              isFavourite ? "text-amber-400" : "text-gray-600 hover:text-gray-400"
            }`}
          >
            <Star className="w-4 h-4 fill-current" />
          </button>

          <div className="min-w-0 flex-1 space-y-1">
            <div className="flex items-center gap-2 flex-wrap">
              <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${getImportanceColor(chapter.importanceStars)}`}>
                {"★".repeat(chapter.importanceStars)} {chapter.importanceBadge}
              </span>
              <span className="text-[10px] font-mono text-gray-400 uppercase">{chapter.classLevel}</span>
              {getDifficultyBadge(chapter.difficulty)}
              {getStatusBadge()}
            </div>
            
            <h3 
              onClick={onOpenDetails}
              className="text-sm font-extrabold text-white group-hover:text-cyan-300 transition-colors cursor-pointer truncate"
            >
              {chapter.name}
            </h3>
          </div>
        </div>

        {/* Middle Stats */}
        <div className="flex items-center gap-4 text-xs shrink-0 border-t md:border-t-0 border-white/[0.06] pt-2 md:pt-0">
          {/* Trend bar */}
          <div className="w-28 space-y-1">
            <div className="flex justify-between text-[10px] text-gray-400 font-mono">
              <span>5-Yr Trend</span>
              <span className="text-white font-bold">{chapter.trendWeightage}%</span>
            </div>
            <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
              <div 
                className="h-full bg-cyan-400 rounded-full" 
                style={{ width: `${Math.min(100, chapter.trendWeightage * 12)}%` }} 
              />
            </div>
          </div>

          {/* PYQ Solved */}
          <div className="text-right min-w-[70px]">
            <span className="text-[10px] text-gray-400 block">PYQs Solved</span>
            <span className="font-mono font-bold text-white">{pyqsSolved} / {chapter.pyqsTotal}</span>
          </div>

          {/* Progress */}
          <div className="w-24 space-y-1">
            <div className="flex justify-between text-[10px] text-gray-400">
              <span>Done</span>
              <span className="text-white font-bold font-mono">{completion}%</span>
            </div>
            <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
              <div 
                className="h-full bg-emerald-400 rounded-full" 
                style={{ width: `${completion}%` }} 
              />
            </div>
          </div>
        </div>

        {/* Right buttons */}
        <div className="flex items-center gap-2 shrink-0 justify-end">
          <Button
            onClick={onOpenDetails}
            variant="ghost"
            size="sm"
            className="text-xs text-gray-300 hover:text-white"
          >
            Explore
          </Button>
          <Button
            onClick={onQuickStart}
            variant="primary"
            size="sm"
            className="text-xs px-3"
          >
            <Play className="w-3 h-3" />
          </Button>
        </div>
      </div>
    );
  }

  // Render GitHub Projects Kanban Column Item View
  return (
    <div className="bg-slate-900/80 border border-white/[0.1] hover:border-white/25 rounded-lg p-3 space-y-3 shadow-lg transition-all group">
      <div className="flex items-center justify-between">
        <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold border ${getImportanceColor(chapter.importanceStars)}`}>
          {"★".repeat(chapter.importanceStars)}
        </span>
        <button
          onClick={onToggleBookmark}
          className={`text-xs ${isBookmarked ? "text-cyan-400" : "text-gray-600 hover:text-gray-400"}`}
        >
          <Bookmark className="w-3.5 h-3.5 fill-current" />
        </button>
      </div>

      <h4 
        onClick={onOpenDetails}
        className="text-xs font-bold text-white group-hover:text-cyan-300 cursor-pointer line-clamp-2"
      >
        {chapter.name}
      </h4>

      <div className="flex items-center justify-between text-[10px] text-gray-400 pt-1 border-t border-white/[0.06]">
        <span>Trend: <strong className="text-white font-mono">{chapter.trendWeightage}%</strong></span>
        <span>PYQs: <strong className="text-white font-mono">{pyqsSolved}/{chapter.pyqsTotal}</strong></span>
      </div>

      <div className="space-y-1">
        <div className="flex justify-between text-[10px] text-gray-400 font-mono">
          <span>Progress</span>
          <span>{completion}%</span>
        </div>
        <div className="h-1 bg-white/10 rounded-full overflow-hidden">
          <div className="h-full bg-cyan-400 rounded-full" style={{ width: `${completion}%` }} />
        </div>
      </div>
    </div>
  );
};
