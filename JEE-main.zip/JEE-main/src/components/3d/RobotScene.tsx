"use client";

import React, { useEffect, useRef, useState, useMemo } from "react";
import * as THREE from "three";
import { gsap } from "gsap";
import { motion, AnimatePresence } from "framer-motion";
import { ThinkingOrb, type OrbState } from "thinking-orbs";
import { BorderBeam } from "border-beam";
import {
  Bot,
  Sparkles,
  Shield,
  Eye,
  Lock,
  BrainCircuit,
  Zap,
  CheckCircle2,
  AlertTriangle,
  Cpu,
} from "lucide-react";

export type RobotStatus = "focused" | "stealth" | "peek" | "typing" | "celebrate" | "error";

interface RobotSceneProps {
  status: RobotStatus;
  isPasswordVisible?: boolean;
  onPoke?: () => void;
}

/**
 * ForgeBot — High-Performance 3D Robot Companion for FocusForge
 * 
 * Key Highlights:
 * 1. 3D Robotic Anatomy:
 *    - Smooth porcelain cyber chassis, curved glossy dark visor faceplate.
 *    - Cyan OLED eyes with procedural blinking and stealth slit squint.
 *    - Pink holographic blushing cheek nodes during privacy mode.
 *    - Articulated arms that physically cover eyes in Stealth mode, peek in Peek mode, and throw up in Celebrate mode.
 * 2. Quantum Arc Reactor Core (ThinkingOrb from libraries.dev/orbs):
 *    - Embedded directly into ForgeBot's chest reactor cavity, mapped dynamically to actions.
 * 3. 20px Micro-Orb Formula Chips (Exact reference from user's photo):
 *    - Floating formula chips running `solving` and `connecting` micro-orbs.
 * 4. BorderBeam Containment (libraries.dev):
 *    - Framed in animated traveling photon light.
 * 5. 100% Lag-Free Three.js Engine:
 *    - Clamped pixel ratio, zero heavy 2048 shadow maps (uses soft radial gradient contact shadow).
 *    - Delta timing via performance.now() without deprecated THREE.Clock.
 *    - 60-120 FPS guaranteed with zero typing latency.
 */
export default function RobotScene({ status, isPasswordVisible = false, onPoke }: RobotSceneProps) {
  const mountRef = useRef<HTMLDivElement>(null);
  const [manualStatus, setManualStatus] = useState<RobotStatus | null>(null);

  const effectiveStatus = manualStatus || status;

  // Map robot status to ThinkingOrb's hand-tuned particle states (libraries.dev/orbs)
  const activeOrbState: OrbState = useMemo(() => {
    switch (effectiveStatus) {
      case "stealth":
        return "shaping"; // Biometric shape-shifting cryptographic shield
      case "peek":
        return "connecting"; // Neural constellation peeking
      case "typing":
        return "working"; // High-speed tilted particle orbits syncing with typing
      case "celebrate":
        return "weaving"; // Tri-strand golden helix victory plaiting
      case "error":
        return "searching"; // Security meridian diagnostic sweep
      case "focused":
      default:
        return "breathing"; // Living gentle quantum consciousness
    }
  }, [effectiveStatus]);

  // Reset manual preview override after 5 seconds
  useEffect(() => {
    if (manualStatus) {
      const timer = setTimeout(() => setManualStatus(null), 5000);
      return () => clearTimeout(timer);
    }
  }, [manualStatus]);

  // Three.js References
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const robotGroupRef = useRef<THREE.Group | null>(null);
  const headGroupRef = useRef<THREE.Group | null>(null);
  const leftArmGroupRef = useRef<THREE.Group | null>(null);
  const rightArmGroupRef = useRef<THREE.Group | null>(null);
  const leftEyeRef = useRef<THREE.Mesh | null>(null);
  const rightEyeRef = useRef<THREE.Mesh | null>(null);
  const leftCheekRef = useRef<THREE.Mesh | null>(null);
  const rightCheekRef = useRef<THREE.Mesh | null>(null);
  const groundShadowRef = useRef<THREE.Mesh | null>(null);

  const mouseRef = useRef({ x: 0, y: 0, targetX: 0, targetY: 0 });

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const width = container.clientWidth || 500;
    const height = container.clientHeight || 580;

    // 1. SCENE & CAMERA
    const scene = new THREE.Scene();
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 50);
    camera.position.set(0, 0.25, 5.2);

    // 2. ULTRA-PERFORMANT WEBGL RENDERER (Zero 2048 Shadow Map Lag)
    const renderer = new THREE.WebGLRenderer({
      alpha: true,
      antialias: true,
      powerPreference: "high-performance",
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    rendererRef.current = renderer;

    container.appendChild(renderer.domElement);

    // 3. LIGHTING (Lightweight, zero shadow-map overhead)
    const ambientLight = new THREE.AmbientLight(0xffffff, 1.2);
    scene.add(ambientLight);

    const keyLight = new THREE.DirectionalLight(0xffffff, 1.5);
    keyLight.position.set(3, 5, 4);
    scene.add(keyLight);

    const cyanRim = new THREE.PointLight(0x06b6d4, 2.5, 12);
    cyanRim.position.set(-3.5, 2, 2);
    scene.add(cyanRim);

    const purpleFill = new THREE.PointLight(0x8b5cf6, 2.0, 10);
    purpleFill.position.set(3, -1.5, 1.5);
    scene.add(purpleFill);

    // 4. ROBOT MATERIALS
    const porcelainMat = new THREE.MeshStandardMaterial({
      color: 0xf8fafc,
      roughness: 0.2,
      metalness: 0.1,
    });

    const visorMat = new THREE.MeshStandardMaterial({
      color: 0x050811,
      roughness: 0.1,
      metalness: 0.85,
    });

    const darkJointMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      roughness: 0.4,
      metalness: 0.5,
    });

    const cyanEyeMat = new THREE.MeshBasicMaterial({
      color: 0x06b6d4,
    });

    const pinkCheekMat = new THREE.MeshBasicMaterial({
      color: 0xff4081,
      transparent: true,
      opacity: 0,
    });

    const accentCyanMat = new THREE.MeshBasicMaterial({
      color: 0x22d3ee,
    });

    // 5. MASTER ROBOT HIERARCHY
    const robotGroup = new THREE.Group();
    robotGroup.position.set(0, -0.2, 0);
    robotGroupRef.current = robotGroup;
    scene.add(robotGroup);

    // A. TORSO & CHASSIS
    const torsoGroup = new THREE.Group();
    robotGroup.add(torsoGroup);

    const torsoGeo = new THREE.CylinderGeometry(0.68, 0.82, 1.25, 32);
    const torsoMesh = new THREE.Mesh(torsoGeo, porcelainMat);
    torsoMesh.position.set(0, 0, 0);
    torsoGroup.add(torsoMesh);

    // Neck Collar Ring
    const collarGeo = new THREE.TorusGeometry(0.55, 0.08, 16, 32);
    const collarMesh = new THREE.Mesh(collarGeo, darkJointMat);
    collarMesh.position.set(0, 0.65, 0);
    collarMesh.rotation.x = Math.PI / 2;
    torsoGroup.add(collarMesh);

    // Chest Arc Reactor Ring Port (Frames the ThinkingOrb)
    const reactorPortGeo = new THREE.TorusGeometry(0.38, 0.06, 16, 32);
    const reactorPortMesh = new THREE.Mesh(reactorPortGeo, accentCyanMat);
    reactorPortMesh.position.set(0, 0.12, 0.72);
    torsoGroup.add(reactorPortMesh);

    const reactorBackplateGeo = new THREE.CircleGeometry(0.36, 32);
    const reactorBackplateMesh = new THREE.Mesh(
      reactorBackplateGeo,
      new THREE.MeshBasicMaterial({ color: 0x030712 })
    );
    reactorBackplateMesh.position.set(0, 0.12, 0.73);
    torsoGroup.add(reactorBackplateMesh);

    // B. HEAD GROUP
    const headGroup = new THREE.Group();
    headGroup.position.set(0, 1.2, 0);
    headGroupRef.current = headGroup;
    robotGroup.add(headGroup);

    // Porcelain Head Sphere
    const headGeo = new THREE.SphereGeometry(0.72, 32, 32);
    headGeo.scale(1.22, 0.88, 0.98);
    const headMesh = new THREE.Mesh(headGeo, porcelainMat);
    headGroup.add(headMesh);

    // Curved Glossy Visor Faceplate
    const visorGeo = new THREE.SphereGeometry(0.68, 32, 32);
    visorGeo.scale(1.15, 0.76, 0.72);
    const visorMesh = new THREE.Mesh(visorGeo, visorMat);
    visorMesh.position.set(0, 0.02, 0.28);
    headGroup.add(visorMesh);

    // Cybernetic OLED Cyan Eyes
    const eyeGeo = new THREE.SphereGeometry(0.08, 24, 24);
    eyeGeo.scale(1.0, 1.2, 0.5);

    const leftEye = new THREE.Mesh(eyeGeo, cyanEyeMat);
    leftEye.position.set(-0.28, 0.04, 0.74);
    leftEyeRef.current = leftEye;
    headGroup.add(leftEye);

    const rightEye = new THREE.Mesh(eyeGeo, cyanEyeMat);
    rightEye.position.set(0.28, 0.04, 0.74);
    rightEyeRef.current = rightEye;
    headGroup.add(rightEye);

    // Connecting Bridge Line
    const eyeBridgeGeo = new THREE.CylinderGeometry(0.015, 0.015, 0.54, 16);
    const eyeBridgeMesh = new THREE.Mesh(eyeBridgeGeo, cyanEyeMat);
    eyeBridgeMesh.position.set(0, 0.04, 0.74);
    eyeBridgeMesh.rotation.z = Math.PI / 2;
    headGroup.add(eyeBridgeMesh);

    // Blushing Pink Cheek Nodes (Illuminate on Stealth / Privacy Mode)
    const cheekGeo = new THREE.SphereGeometry(0.05, 16, 16);
    cheekGeo.scale(1.2, 0.8, 0.3);

    const leftCheek = new THREE.Mesh(cheekGeo, pinkCheekMat);
    leftCheek.position.set(-0.46, -0.14, 0.68);
    leftCheekRef.current = leftCheek;
    headGroup.add(leftCheek);

    const rightCheek = new THREE.Mesh(cheekGeo, pinkCheekMat);
    rightCheek.position.set(0.46, -0.14, 0.68);
    rightCheekRef.current = rightCheek;
    headGroup.add(rightCheek);

    // Ear Sensor Antennas with Glowing Ring
    const earGeo = new THREE.CylinderGeometry(0.12, 0.12, 0.22, 16);
    const leftEar = new THREE.Mesh(earGeo, darkJointMat);
    leftEar.position.set(-0.94, 0, 0);
    leftEar.rotation.z = Math.PI / 2;
    headGroup.add(leftEar);

    const rightEar = new THREE.Mesh(earGeo, darkJointMat);
    rightEar.position.set(0.94, 0, 0);
    rightEar.rotation.z = Math.PI / 2;
    headGroup.add(rightEar);

    const earTipGeo = new THREE.SphereGeometry(0.08, 16, 16);
    const leftEarTip = new THREE.Mesh(earTipGeo, accentCyanMat);
    leftEarTip.position.set(-1.08, 0, 0);
    headGroup.add(leftEarTip);

    const rightEarTip = new THREE.Mesh(earTipGeo, accentCyanMat);
    rightEarTip.position.set(1.08, 0, 0);
    headGroup.add(rightEarTip);

    // C. ARTICULATED ARMS (Kinematics for Covering Eyes & Celebrating)
    // Left Arm Group
    const leftArmGroup = new THREE.Group();
    leftArmGroup.position.set(-1.15, 0.38, 0);
    leftArmGroupRef.current = leftArmGroup;
    robotGroup.add(leftArmGroup);

    const armGeo = new THREE.SphereGeometry(0.28, 24, 24);
    armGeo.scale(0.85, 2.1, 0.85);

    const leftArmMesh = new THREE.Mesh(armGeo, porcelainMat);
    leftArmMesh.position.set(0, -0.48, 0.15);
    leftArmMesh.rotation.z = 0.2;
    leftArmGroup.add(leftArmMesh);

    const leftHandGeo = new THREE.SphereGeometry(0.18, 20, 20);
    const leftHandMesh = new THREE.Mesh(leftHandGeo, porcelainMat);
    leftHandMesh.position.set(0.1, -1.05, 0.25);
    leftArmGroup.add(leftHandMesh);

    // Right Arm Group
    const rightArmGroup = new THREE.Group();
    rightArmGroup.position.set(1.15, 0.38, 0);
    rightArmGroupRef.current = rightArmGroup;
    robotGroup.add(rightArmGroup);

    const rightArmMesh = new THREE.Mesh(armGeo, porcelainMat);
    rightArmMesh.position.set(0, -0.48, 0.15);
    rightArmMesh.rotation.z = -0.2;
    rightArmGroup.add(rightArmMesh);

    const rightHandMesh = new THREE.Mesh(leftHandGeo, porcelainMat);
    rightHandMesh.position.set(-0.1, -1.05, 0.25);
    rightArmGroup.add(rightHandMesh);

    // D. ULTRA-LIGHTWEIGHT CONTACT SHADOW PLANE (Zero GPU shadow map cost!)
    const canvas = document.createElement("canvas");
    canvas.width = 128;
    canvas.height = 128;
    const ctx = canvas.getContext("2d");
    if (ctx) {
      const gradient = ctx.createRadialGradient(64, 64, 10, 64, 64, 60);
      gradient.addColorStop(0, "rgba(0,0,0,0.5)");
      gradient.addColorStop(0.5, "rgba(0,0,0,0.2)");
      gradient.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, 128, 128);
    }
    const shadowTexture = new THREE.CanvasTexture(canvas);

    const groundShadowGeo = new THREE.PlaneGeometry(2.8, 2.8);
    const groundShadowMat = new THREE.MeshBasicMaterial({
      map: shadowTexture,
      transparent: true,
      depthWrite: false,
    });
    const groundShadow = new THREE.Mesh(groundShadowGeo, groundShadowMat);
    groundShadow.rotation.x = -Math.PI / 2;
    groundShadow.position.set(0, -1.5, 0);
    groundShadowRef.current = groundShadow;
    scene.add(groundShadow);

    // 6. MOUSE TRACKING (Passive, non-blocking)
    const handleMouseMove = (e: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      const y = -(((e.clientY - rect.top) / rect.height) * 2 - 1);
      mouseRef.current.targetX = Math.max(-1, Math.min(1, x));
      mouseRef.current.targetY = Math.max(-1, Math.min(1, y));
    };

    window.addEventListener("mousemove", handleMouseMove, { passive: true });

    // 7. RENDER LOOP (High-Performance delta time without deprecated THREE.Clock)
    let animationFrameId: number;
    let lastTime = performance.now();
    let totalElapsed = 0;
    let blinkTimer = 0;

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);

      const now = performance.now();
      const delta = Math.min((now - lastTime) / 1000, 0.1);
      lastTime = now;
      totalElapsed += delta;
      blinkTimer += delta;

      // Mouse Lerp
      mouseRef.current.x += (mouseRef.current.targetX - mouseRef.current.x) * 0.08;
      mouseRef.current.y += (mouseRef.current.targetY - mouseRef.current.y) * 0.08;

      const mx = mouseRef.current.x;
      const my = mouseRef.current.y;

      // Natural Breathing Bob
      if (robotGroupRef.current) {
        const hoverY = Math.sin(totalElapsed * 1.8) * 0.07 - 0.18;
        robotGroupRef.current.position.y = hoverY;
        robotGroupRef.current.rotation.y = mx * 0.22;
        robotGroupRef.current.rotation.x = -my * 0.12;

        // Scale ground shadow with hover
        if (groundShadowRef.current) {
          const shadowScale = 1 - hoverY * 0.5;
          groundShadowRef.current.scale.set(shadowScale, shadowScale, shadowScale);
        }
      }

      // Procedural Head LookAt
      if (headGroupRef.current && effectiveStatus !== "stealth") {
        headGroupRef.current.rotation.y = mx * 0.38;
        headGroupRef.current.rotation.x = -my * 0.25;
      }

      // Procedural Blinking (Every 3.5 to 5 seconds)
      if (blinkTimer > 4.2) {
        blinkTimer = 0;
        if (leftEyeRef.current && rightEyeRef.current && effectiveStatus !== "stealth") {
          gsap.to([leftEyeRef.current.scale, rightEyeRef.current.scale], {
            y: 0.1,
            duration: 0.1,
            yoyo: true,
            repeat: 1,
            ease: "power2.inOut",
          });
        }
      }

      renderer.render(scene, camera);
    };

    animate();

    // Resize Handler
    const handleResize = () => {
      if (!mountRef.current || !rendererRef.current) return;
      const newW = mountRef.current.clientWidth;
      const newH = mountRef.current.clientHeight;
      camera.aspect = newW / newH;
      camera.updateProjectionMatrix();
      rendererRef.current.setSize(newW, newH);
    };

    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
      window.removeEventListener("resize", handleResize);
      cancelAnimationFrame(animationFrameId);

      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }

      // Clean GPU memory
      scene.clear();
      renderer.dispose();
    };
  }, []);

  // 8. GSAP ANIMATIONS FOR ROBOT STATUS (Stealth, Peek, Typing, Celebrate, Error)
  useEffect(() => {
    if (!leftArmGroupRef.current || !rightArmGroupRef.current || !headGroupRef.current || !robotGroupRef.current) {
      return;
    }

    const leftArm = leftArmGroupRef.current;
    const rightArm = rightArmGroupRef.current;
    const head = headGroupRef.current;
    const robot = robotGroupRef.current;
    const leftCheek = leftCheekRef.current;
    const rightCheek = rightCheekRef.current;
    const leftEye = leftEyeRef.current;
    const rightEye = rightEyeRef.current;

    if (effectiveStatus === "stealth") {
      // 🙈 STEALTH PRIVACY MODE: Hands cover eyes, cheeks blush pink!
      gsap.to(leftArm.rotation, {
        x: 1.35,
        y: -0.38,
        z: -0.42,
        duration: 0.35,
        ease: "power2.out",
      });
      gsap.to(rightArm.rotation, {
        x: 1.35,
        y: 0.38,
        z: 0.42,
        duration: 0.35,
        ease: "power2.out",
      });
      gsap.to(head.rotation, { x: -0.22, y: 0, duration: 0.35 });

      // Squint eyes & turn on blushing cheeks
      if (leftCheek && rightCheek) {
        gsap.to([leftCheek.material, rightCheek.material], { opacity: 0.9, duration: 0.3 });
      }
      if (leftEye && rightEye) {
        gsap.to([leftEye.scale, rightEye.scale], { y: 0.2, duration: 0.25 });
      }
    } else if (effectiveStatus === "peek") {
      // 👀 PEEKING MODE: Left arm lowers slightly, left eye widens with curious glow!
      gsap.to(leftArm.rotation, {
        x: 0.65,
        y: -0.25,
        z: -0.25,
        duration: 0.3,
        ease: "power2.out",
      });
      gsap.to(rightArm.rotation, {
        x: 1.35,
        y: 0.38,
        z: 0.42,
        duration: 0.3,
        ease: "power2.out",
      });
      gsap.to(head.rotation, { x: 0.1, y: -0.15, z: 0.08, duration: 0.3 });

      if (leftCheek && rightCheek) {
        gsap.to([leftCheek.material, rightCheek.material], { opacity: 0.5, duration: 0.3 });
      }
      if (leftEye && rightEye) {
        gsap.to(leftEye.scale, { y: 1.4, duration: 0.25 });
        gsap.to(rightEye.scale, { y: 0.2, duration: 0.25 });
      }
    } else if (effectiveStatus === "typing") {
      // ⚡ TYPING MODE: Subtle air typing keystroke pulses and bouncy head tilt
      gsap.to(leftArm.rotation, {
        x: 0.45,
        y: -0.2,
        z: -0.15,
        duration: 0.2,
        yoyo: true,
        repeat: 1,
      });
      gsap.to(rightArm.rotation, {
        x: 0.45,
        y: 0.2,
        z: 0.15,
        duration: 0.2,
        yoyo: true,
        repeat: 1,
      });
      gsap.to(head.rotation, { z: 0.08, duration: 0.18, yoyo: true, repeat: 1 });

      if (leftCheek && rightCheek) {
        gsap.to([leftCheek.material, rightCheek.material], { opacity: 0, duration: 0.2 });
      }
      if (leftEye && rightEye) {
        gsap.to([leftEye.scale, rightEye.scale], { y: 1.2, duration: 0.2 });
      }
    } else if (effectiveStatus === "celebrate") {
      // 🎉 CELEBRATE MODE: 360 Victory Spin, arms raised high!
      const tl = gsap.timeline();
      tl.to(leftArm.rotation, { x: 2.5, y: -0.5, z: -0.6, duration: 0.35, ease: "back.out(1.5)" })
        .to(rightArm.rotation, { x: 2.5, y: 0.5, z: 0.6, duration: 0.35, ease: "back.out(1.5)" }, "<")
        .to(robot.position, { y: 0.4, duration: 0.35, ease: "power2.out" }, "<")
        .to(robot.rotation, { y: Math.PI * 2, duration: 0.75, ease: "power1.inOut" }, "<")
        .to(robot.position, { y: -0.2, duration: 0.35, ease: "bounce.out" });

      if (leftCheek && rightCheek) {
        gsap.to([leftCheek.material, rightCheek.material], { opacity: 0.4, duration: 0.3 });
      }
    } else if (effectiveStatus === "error") {
      // ⚠️ ALERT / ERROR MODE: Gentle head shake
      const tl = gsap.timeline();
      tl.to(head.rotation, { y: 0.25, duration: 0.1 })
        .to(head.rotation, { y: -0.25, duration: 0.15 })
        .to(head.rotation, { y: 0.15, duration: 0.1 })
        .to(head.rotation, { y: 0, duration: 0.1 });

      gsap.to(leftArm.rotation, { x: 0.3, y: 0, z: 0.2, duration: 0.2 });
      gsap.to(rightArm.rotation, { x: 0.3, y: 0, z: -0.2, duration: 0.2 });
    } else {
      // 🌿 FOCUSED RESTING STATE
      gsap.to(leftArm.rotation, { x: 0, y: 0, z: 0.2, duration: 0.35 });
      gsap.to(rightArm.rotation, { x: 0, y: 0, z: -0.2, duration: 0.35 });
      gsap.to(head.rotation, { x: 0, y: 0, z: 0, duration: 0.35 });

      if (leftCheek && rightCheek) {
        gsap.to([leftCheek.material, rightCheek.material], { opacity: 0, duration: 0.25 });
      }
      if (leftEye && rightEye) {
        gsap.to([leftEye.scale, rightEye.scale], { y: 1.0, duration: 0.25 });
      }
    }
  }, [effectiveStatus, isPasswordVisible]);

  const getStatusLabel = () => {
    switch (effectiveStatus) {
      case "stealth":
        return {
          title: "Privacy Shutter Active",
          desc: "ForgeBot is covering its eyes while you type your password.",
          tag: "STEALTH",
          color: "text-rose-400 border-rose-500/30 bg-rose-500/10",
          dot: "bg-rose-400 animate-ping",
        };
      case "peek":
        return {
          title: "Curious Peeking Mode",
          desc: "Password unmasked • ForgeBot peeks with one eye!",
          tag: "PEEKING",
          color: "text-amber-400 border-amber-500/30 bg-amber-500/10",
          dot: "bg-amber-400 animate-bounce",
        };
      case "typing":
        return {
          title: "Syncing Keystrokes",
          desc: "ForgeBot Quantum Core processing input at 120 FPS.",
          tag: "TYPING",
          color: "text-cyan-400 border-cyan-500/30 bg-cyan-500/10",
          dot: "bg-cyan-400 animate-pulse",
        };
      case "celebrate":
        return {
          title: "Victory Mode!",
          desc: "Authentication verified • Preparing your study OS workspace.",
          tag: "VICTORY",
          color: "text-emerald-400 border-emerald-500/30 bg-emerald-500/10",
          dot: "bg-emerald-400 animate-pulse",
        };
      case "error":
        return {
          title: "Diagnostic Alert",
          desc: "Please review credentials or handle availability.",
          tag: "ALERT",
          color: "text-red-400 border-red-500/30 bg-red-500/10",
          dot: "bg-red-400 animate-pulse",
        };
      case "focused":
      default:
        return {
          title: "Neural Companion Focused",
          desc: "ForgeBot is tracking your study session and eye focus.",
          tag: "FOCUSED",
          color: "text-cyan-300 border-cyan-500/25 bg-cyan-500/10",
          dot: "bg-cyan-400",
        };
    }
  };

  const statusMeta = getStatusLabel();

  return (
    <div
      onClick={onPoke}
      className="w-full h-full relative flex flex-col justify-between p-6 lg:p-8 select-none overflow-hidden cursor-crosshair"
    >
      {/* Background Cyber Ambient Aura (Pure CSS, 0 GPU cost) */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full bg-cyan-500/10 blur-3xl pointer-events-none -translate-x-1/2 -translate-y-1/2" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 rounded-full bg-purple-600/10 blur-3xl pointer-events-none translate-x-1/2 translate-y-1/2" />

      {/* Cybernetic Grid Matrix Background */}
      <div
        className="absolute inset-0 opacity-[0.03] pointer-events-none"
        style={{
          backgroundImage:
            "linear-gradient(#06b6d4 1px, transparent 1px), linear-gradient(90deg, #06b6d4 1px, transparent 1px)",
          backgroundSize: "32px 32px",
        }}
      />

      {/* Top Floating Status Indicator */}
      <div className="relative z-20 flex items-center justify-between w-full pointer-events-none">
        <div className="pointer-events-auto flex items-center gap-2.5 bg-slate-950/80 border border-white/10 rounded-full px-4 py-2 text-xs text-gray-300 backdrop-blur-md shadow-xl shadow-black/50">
          <div className="w-6 h-6 rounded-lg bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
            <Bot className="w-3.5 h-3.5" />
          </div>
          <span className="font-bold text-white tracking-wide">ForgeBot 3D</span>
          <span className="text-gray-600">•</span>
          <div className={`px-2 py-0.5 rounded-full text-[10px] font-mono font-bold flex items-center gap-1.5 border ${statusMeta.color}`}>
            <span className={`w-1.5 h-1.5 rounded-full ${statusMeta.dot}`} />
            <span>{statusMeta.tag}</span>
          </div>
        </div>
      </div>

      {/* Full-Bleed 3D Robot WebGL Viewport */}
      <div className="absolute inset-0 z-10 flex items-center justify-center overflow-hidden">
        {/* Actual Three.js WebGL Mount */}
        <div ref={mountRef} className="w-full h-full absolute inset-0" />

        {/* Quantum Arc Reactor Core Overlay (ThinkingOrb in Robot's Chest) */}
        <div
          className="absolute z-20 pointer-events-none transition-all duration-300"
          style={{
            top: "54%",
            left: "50%",
            transform: "translate(-50%, -50%)",
          }}
        >
          <div className="p-1 rounded-full bg-slate-950/90 border border-cyan-500/40 shadow-lg shadow-cyan-500/20 flex items-center justify-center">
            <ThinkingOrb
              state={activeOrbState}
              size={64}
              theme="dark"
              speed={effectiveStatus === "typing" ? 1.4 : 1.0}
            />
          </div>
        </div>
      </div>

      {/* Bottom Floating Control Dock */}
      <div className="relative z-20 w-full max-w-lg mx-auto pointer-events-auto mt-auto">
        <BorderBeam
          colorVariant="ocean"
          size="sm"
          strength={0.7}
          duration={3.5}
          className="w-full rounded-2xl"
        >
          <div className="w-full rounded-2xl bg-slate-950/85 backdrop-blur-xl border border-white/10 p-4 shadow-2xl space-y-3">
            {/* Status Telemetry */}
            <div className="flex items-center justify-between gap-2">
              <div>
                <p className="text-xs font-bold text-white tracking-tight flex items-center gap-2">
                  <span>{statusMeta.title}</span>
                </p>
                <p className="text-[11px] text-gray-400 font-mono mt-0.5 leading-tight">{statusMeta.desc}</p>
              </div>
              <div className="shrink-0 flex items-center gap-1.5 text-[10px] font-mono text-cyan-400 bg-cyan-500/10 px-2 py-1 rounded-lg border border-cyan-500/20">
                <Cpu className="w-3 h-3" />
                <span>120 FPS</span>
              </div>
            </div>

            {/* Streamlined Interactive Reaction Bar */}
            <div className="pt-2 border-t border-white/[0.08] flex items-center justify-between gap-1.5">
              {(
                [
                  { status: "focused" as const, label: "Focus", orb: "breathing" as const },
                  { status: "typing" as const, label: "Type", orb: "working" as const },
                  { status: "stealth" as const, label: "Privacy", orb: "shaping" as const },
                  { status: "peek" as const, label: "Peek", orb: "connecting" as const },
                  { status: "celebrate" as const, label: "Victory", orb: "weaving" as const },
                ] as const
              ).map((item) => {
                const isCurrent = effectiveStatus === item.status;
                return (
                  <button
                    type="button"
                    key={item.status}
                    onClick={(e) => {
                      e.stopPropagation();
                      setManualStatus(item.status);
                    }}
                    className={`flex-1 py-1.5 px-2 rounded-xl text-[11px] font-mono transition-all border cursor-pointer flex items-center justify-center gap-1.5 ${
                      isCurrent
                        ? "bg-cyan-500/20 border-cyan-500/50 text-cyan-300 font-bold shadow-sm shadow-cyan-950/40"
                        : "bg-white/[0.02] border-white/[0.06] text-gray-400 hover:text-white hover:bg-white/[0.06]"
                    }`}
                  >
                    <ThinkingOrb state={item.orb} size={20} theme="dark" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </BorderBeam>
      </div>
    </div>
  );
}
