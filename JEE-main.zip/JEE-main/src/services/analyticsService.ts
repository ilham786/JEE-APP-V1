import { CompletedSessionRecord } from "@/store/use-study-store";
import { MistakeEntry, ChapterProgress } from "@/store/use-mistake-store";
import { VisitLogDoc } from "@/services/blockerService";
import { supabase } from "@/lib/supabase/client";

export type TrendTimeframe = "7d" | "30d" | "90d" | "1y";

export interface PeakVulnerabilityWindow {
  slot: string;
  label: string;
  minutes: number;
  percentage: number;
  incidentCount: number;
  recommendation: string;
}

export interface DomainDistractionStat {
  name: string;
  value: number;
  minutes: number;
  percentage: number;
  incidentCount: number;
  color: string;
}

export interface DistractionComparisonPoint {
  day: string;
  date: string;
  Productive: number;
  Wasted: number;
}

export interface DistractionAnalysisResult {
  totalWastedMinutes: number;
  totalWastedSeconds: number;
  totalBreakMinutes: number;
  totalBreakSeconds: number;
  totalProductiveMinutes: number;
  totalTrackedMinutes: number;
  focusEfficiency: number;
  focusLeakIndex: number;
  severityLevel: "Optimal Focus" | "Moderate Risk" | "Critical Leakage";
  severityColor: string;
  severityBadgeBg: string;
  equivalentQuestionsLost: number;
  inSessionWastedMinutes: number;
  inSessionIncidentCount: number;
  inSessionContaminationRate: number;
  casualWastedMinutes: number;
  peakVulnerability: PeakVulnerabilityWindow;
  compareChartData: DistractionComparisonPoint[];
  domainBreakdown: DomainDistractionStat[];
  filteredLogs: VisitLogDoc[];
}

export interface AnalyticsTrendPoint {
  date: string; // Display label (e.g. "Mon", "Jul 31", "Jan")
  fullDate?: string; // YYYY-MM-DD for tooltip context
  Hours: number;
  Efficiency: number; // Avg Focus Score for that period
  sessionsCount: number;
}

export interface ErrorClassificationPoint {
  name: string;
  value: number;
  color: string;
}

export interface SubjectComparisonPoint {
  name: string;
  "Completion %": number;
  "PYQs Solved": number;
}

export interface SubjectBreakdownPoint {
  name: string;
  value: number; // Percentage 0-100
  hours: number;
  color: string;
}

export interface UserAnalyticsDoc {
  xp?: number;
  level?: number;
  currentStreak?: number;
  totalStudyHours?: number;
  avgFocusScore?: number;
  [key: string]: unknown;
}

export interface AnalyticsOverviewMetrics {
  consistencyScore: number;
  strongestSubject: string;
  weakestSubject: string;
  projectedCompletionDays: number;
  trendData: AnalyticsTrendPoint[];
  errorData: ErrorClassificationPoint[];
  compareChartData: SubjectComparisonPoint[];
  subjectBreakdown: SubjectBreakdownPoint[];
  totalStudyHours: number;
  avgFocusScore: number;
  hasData: boolean;
}

/**
 * Format date in local timezone as YYYY-MM-DD
 */
export function getLocalDateKey(dateInput: string | Date): string {
  const d = new Date(dateInput);
  if (isNaN(d.getTime())) return new Date().toISOString().split("T")[0];
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

export const analyticsService = {
  /**
   * Calculate Study Sessions Trend data dynamically for 7D, 30D, 90D, or 1Y timeframes
   */
  calculateStudyTrend(
    sessionHistory: CompletedSessionRecord[] = [],
    timeframe: TrendTimeframe = "7d"
  ): AnalyticsTrendPoint[] {
    const validSessions = (sessionHistory || []).filter(
      (s) => s && (s as CompletedSessionRecord & { completed?: boolean }).completed !== false && Number(s.totalDurationMinutes || 0) > 0
    );

    const now = new Date();

    if (timeframe === "7d") {
      const daysOfWeek = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
      const results: AnalyticsTrendPoint[] = [];

      for (let i = 6; i >= 0; i--) {
        const d = new Date(now);
        d.setDate(now.getDate() - i);
        const dateKey = getLocalDateKey(d);
        const dayLabel = daysOfWeek[d.getDay()];

        const daySessions = validSessions.filter((s) => {
          const sKey = s.date || (s.startTime ? getLocalDateKey(s.startTime) : "");
          return sKey === dateKey;
        });

        const totalMins = daySessions.reduce((acc, s) => acc + (s.totalDurationMinutes || 0), 0);
        const hrs = parseFloat((totalMins / 60).toFixed(1));
        const avgFocus =
          daySessions.length > 0
            ? Math.round(
                daySessions.reduce((acc, s) => acc + (s.focusScore ?? 0), 0) / daySessions.length
              )
            : 0;

        results.push({
          date: dayLabel,
          fullDate: dateKey,
          Hours: hrs,
          Efficiency: avgFocus,
          sessionsCount: daySessions.length,
        });
      }
      return results;
    }

    if (timeframe === "30d") {
      const results: AnalyticsTrendPoint[] = [];

      for (let i = 29; i >= 0; i--) {
        const d = new Date(now);
        d.setDate(now.getDate() - i);
        const dateKey = getLocalDateKey(d);
        const label = d.toLocaleDateString("en-US", { month: "short", day: "numeric" });

        const daySessions = validSessions.filter((s) => {
          const sKey = s.date || (s.startTime ? getLocalDateKey(s.startTime) : "");
          return sKey === dateKey;
        });

        const totalMins = daySessions.reduce((acc, s) => acc + (s.totalDurationMinutes || 0), 0);
        const hrs = parseFloat((totalMins / 60).toFixed(1));
        const avgFocus =
          daySessions.length > 0
            ? Math.round(
                daySessions.reduce((acc, s) => acc + (s.focusScore ?? 0), 0) / daySessions.length
              )
            : 0;

        results.push({
          date: label,
          fullDate: dateKey,
          Hours: hrs,
          Efficiency: avgFocus,
          sessionsCount: daySessions.length,
        });
      }
      return results;
    }

    if (timeframe === "90d") {
      const results: AnalyticsTrendPoint[] = [];
      // 90 days aggregated in 3-day buckets (30 points) for readable chart rendering
      for (let i = 87; i >= 0; i -= 3) {
        const dEnd = new Date(now);
        dEnd.setDate(now.getDate() - i);
        const label = dEnd.toLocaleDateString("en-US", { month: "short", day: "numeric" });

        let bucketMins = 0;
        let bucketFocusSum = 0;
        let bucketSessCount = 0;

        for (let b = 0; b < 3; b++) {
          const d = new Date(now);
          d.setDate(now.getDate() - (i + b));
          const dateKey = getLocalDateKey(d);

          const daySessions = validSessions.filter((s) => {
            const sKey = s.date || (s.startTime ? getLocalDateKey(s.startTime) : "");
            return sKey === dateKey;
          });

          bucketMins += daySessions.reduce((acc, s) => acc + (s.totalDurationMinutes || 0), 0);
          bucketFocusSum += daySessions.reduce((acc, s) => acc + (s.focusScore ?? 0), 0);
          bucketSessCount += daySessions.length;
        }

        const hrs = parseFloat((bucketMins / 60).toFixed(1));
        const avgFocus = bucketSessCount > 0 ? Math.round(bucketFocusSum / bucketSessCount) : 0;

        results.push({
          date: label,
          Hours: hrs,
          Efficiency: avgFocus,
          sessionsCount: bucketSessCount,
        });
      }
      return results;
    }

    // 1y (Year View - 12 Months)
    const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    const results: AnalyticsTrendPoint[] = [];

    for (let i = 11; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const year = d.getFullYear();
      const monthIndex = d.getMonth();
      const label = monthNames[monthIndex];

      const monthSessions = validSessions.filter((s) => {
        const sDate = new Date(s.startTime || s.date || "");
        return !isNaN(sDate.getTime()) && sDate.getFullYear() === year && sDate.getMonth() === monthIndex;
      });

      const totalMins = monthSessions.reduce((acc, s) => acc + (s.totalDurationMinutes || 0), 0);
      const hrs = parseFloat((totalMins / 60).toFixed(1));
      const avgFocus =
        monthSessions.length > 0
          ? Math.round(
              monthSessions.reduce((acc, s) => acc + (s.focusScore ?? 0), 0) / monthSessions.length
            )
          : 0;

      results.push({
        date: label,
        Hours: hrs,
        Efficiency: avgFocus,
        sessionsCount: monthSessions.length,
      });
    }

    return results;
  },

  /**
   * Calculate Subject Breakdown dynamically from completed study session minutes
   */
  calculateSubjectBreakdown(
    sessionHistory: CompletedSessionRecord[] = [],
    examType: "JEE" | "NEET" = "JEE"
  ): SubjectBreakdownPoint[] {
    const validSessions = (sessionHistory || []).filter(
      (s) => s && (s as CompletedSessionRecord & { completed?: boolean }).completed !== false && Number(s.totalDurationMinutes || 0) > 0
    );

    if (examType === "NEET") {
      let phyMins = 0;
      let chemMins = 0;
      let botanyMins = 0;
      let zoologyMins = 0;

      validSessions.forEach((s) => {
        const subj = s.subject ? s.subject.trim() : "";
        if (subj === "Physics") phyMins += s.totalDurationMinutes;
        else if (subj === "Chemistry") chemMins += s.totalDurationMinutes;
        else if (subj === "Botany") botanyMins += s.totalDurationMinutes;
        else if (subj === "Zoology") zoologyMins += s.totalDurationMinutes;
        else if (subj === "Biology") {
          botanyMins += Math.floor(s.totalDurationMinutes / 2);
          zoologyMins += Math.ceil(s.totalDurationMinutes / 2);
        }
      });

      const totalMins = phyMins + chemMins + botanyMins + zoologyMins;
      const phyHrs = parseFloat((phyMins / 60).toFixed(1));
      const chemHrs = parseFloat((chemMins / 60).toFixed(1));
      const botanyHrs = parseFloat((botanyMins / 60).toFixed(1));
      const zoologyHrs = parseFloat((zoologyMins / 60).toFixed(1));

      if (totalMins === 0) {
        return [
          { name: "Physics", value: 0, hours: 0, color: "#06b6d4" },
          { name: "Chemistry", value: 0, hours: 0, color: "#10b981" },
          { name: "Botany", value: 0, hours: 0, color: "#059669" },
          { name: "Zoology", value: 0, hours: 0, color: "#8b5cf6" },
        ];
      }

      return [
        { name: "Physics", value: Math.round((phyMins / totalMins) * 100), hours: phyHrs, color: "#06b6d4" },
        { name: "Chemistry", value: Math.round((chemMins / totalMins) * 100), hours: chemHrs, color: "#10b981" },
        { name: "Botany", value: Math.round((botanyMins / totalMins) * 100), hours: botanyHrs, color: "#059669" },
        { name: "Zoology", value: Math.round((zoologyMins / totalMins) * 100), hours: zoologyHrs, color: "#8b5cf6" },
      ];
    }

    let phyMins = 0;
    let chemMins = 0;
    let mathMins = 0;

    validSessions.forEach((s) => {
      const subj = s.subject ? s.subject.trim() : "";
      if (subj === "Physics") phyMins += s.totalDurationMinutes;
      else if (subj === "Chemistry") chemMins += s.totalDurationMinutes;
      else if (subj === "Maths" || subj === "Mathematics") mathMins += s.totalDurationMinutes;
    });

    const totalMins = phyMins + chemMins + mathMins;

    if (totalMins === 0) {
      return [
        { name: "Physics", value: 0, hours: 0, color: "#06b6d4" },
        { name: "Chemistry", value: 0, hours: 0, color: "#10b981" },
        { name: "Maths", value: 0, hours: 0, color: "#f59e0b" },
      ];
    }

    const phyHrs = parseFloat((phyMins / 60).toFixed(1));
    const chemHrs = parseFloat((chemMins / 60).toFixed(1));
    const mathHrs = parseFloat((mathMins / 60).toFixed(1));

    return [
      { name: "Physics", value: Math.round((phyMins / totalMins) * 100), hours: phyHrs, color: "#06b6d4" },
      { name: "Chemistry", value: Math.round((chemMins / totalMins) * 100), hours: chemHrs, color: "#10b981" },
      { name: "Maths", value: Math.round((mathMins / totalMins) * 100), hours: mathHrs, color: "#f59e0b" },
    ];
  },

  /**
   * Calculate comprehensive analytics metrics dynamically from actual session history & mistake entries
   */
  calculateAnalyticsMetrics(
    sessionHistory: CompletedSessionRecord[] = [],
    mistakes: MistakeEntry[] = [],
    syllabus: Record<string, ChapterProgress[] | undefined> = { Physics: [], Chemistry: [], Maths: [] },
    timeframe: TrendTimeframe = "7d",
    examType: "JEE" | "NEET" = "JEE"
  ): AnalyticsOverviewMetrics {
    const validSessions = (sessionHistory || []).filter(
      (s) => s && (s as CompletedSessionRecord & { completed?: boolean }).completed !== false && Number(s.totalDurationMinutes || 0) > 0
    );

    const hasData = validSessions.length > 0 || mistakes.length > 0;

    // 1. Daily Study Trend
    const trendData = this.calculateStudyTrend(validSessions, timeframe);

    // 2. Subject Breakdown
    const subjectBreakdown = this.calculateSubjectBreakdown(validSessions, examType);

    // 3. Overall Focus Score & Total Hours
    const totalMinutes = validSessions.reduce((acc, s) => acc + (s.totalDurationMinutes || 0), 0);
    const totalStudyHours = parseFloat((totalMinutes / 60).toFixed(1));

    const avgFocusScore =
      validSessions.length > 0
        ? Math.round(
            validSessions.reduce((acc, s) => acc + (s.focusScore ?? 0), 0) / validSessions.length
          )
        : 0;

    // 4. Error Classifications from Mistake Journal
    const calcCount = mistakes.filter((m) => m.errorType === "Calculation Error").length;
    const conceptCount = mistakes.filter((m) => m.errorType === "Conceptual Gap").length;
    const sillyCount = mistakes.filter((m) => m.errorType === "Silly Mistake").length;
    const timeCount = mistakes.filter((m) => m.errorType === "Time Pressure").length;

    const errorData: ErrorClassificationPoint[] = [
      { name: "Calculation Errors", value: calcCount, color: "#3b82f6" },
      { name: "Conceptual Gaps", value: conceptCount, color: "#10b981" },
      { name: "Silly Mistakes", value: sillyCount, color: "#f59e0b" },
      { name: "Time Pressure", value: timeCount, color: "#ef4444" },
    ];

    // 5. Subject Averages & Comparison Data
    const compareChartData: SubjectComparisonPoint[] = Object.entries(syllabus).map(
      ([subj, chapters]) => {
        const totalComp = (chapters || []).reduce((acc, c) => acc + (c.completion || 0), 0);
        const totalPyqs = (chapters || []).reduce((acc, c) => acc + (c.pyqsSolved || 0), 0);
        const count = (chapters || []).length;

        return {
          name: subj,
          "Completion %": count > 0 ? Math.round(totalComp / count) : 0,
          "PYQs Solved": totalPyqs,
        };
      }
    );

    // Subject sorting
    const sortedSubjs = [...compareChartData].sort((a, b) => b["Completion %"] - a["Completion %"]);
    const strongestSubject = sortedSubjs[0]?.["Completion %"] > 0 ? sortedSubjs[0].name : "N/A";
    const weakestSubject =
      sortedSubjs[sortedSubjs.length - 1]?.["Completion %"] > 0 || validSessions.length > 0
        ? sortedSubjs[sortedSubjs.length - 1].name
        : "N/A";

    // 6. Consistency Score (0-100)
    const last7DaysTrend = this.calculateStudyTrend(validSessions, "7d");
    const activeDaysCount = last7DaysTrend.filter((t) => t.Hours > 0).length;
    const consistencyScore = Math.min(100, Math.round((activeDaysCount / 7) * 100));

    // 7. Projected Completion Days based on study velocity
    const totalWeeklyHours = last7DaysTrend.reduce((acc, t) => acc + t.Hours, 0);
    const avgDailyVelocity = totalWeeklyHours / 7;
    const projectedCompletionDays =
      avgDailyVelocity > 0 ? Math.round(180 / avgDailyVelocity) : 0;

    return {
      consistencyScore,
      strongestSubject,
      weakestSubject,
      projectedCompletionDays,
      trendData,
      errorData,
      compareChartData,
      subjectBreakdown,
      totalStudyHours,
      avgFocusScore,
      hasData,
    };
  },

  /**
   * High-performance single-pass O(N+M) analytics engine for distraction incident logs,
   * wasted time tracking, focus leakage indexing, peak vulnerability analysis,
   * and JEE-specific cognitive impact calculation.
   */
  calculateDistractionAnalytics(
    logs: VisitLogDoc[] = [],
    sessions: CompletedSessionRecord[] = [],
    dateFilter: "Today" | "Week" | "All" = "Today",
    searchQuery = "",
    nowMs: number = Date.now()
  ): DistractionAnalysisResult {
    const todayStr = getLocalDateKey(new Date(nowMs));
    const weekAgoMs = nowMs - 7 * 86400000;
    const normalizedSearch = (searchQuery || "").trim().toLowerCase();

    // 1. Initialize 7-Day comparison bucket map
    const daysOfWeek = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    const sevenDaysMap = new Map<string, DistractionComparisonPoint>();
    for (let i = 6; i >= 0; i--) {
      const d = new Date(nowMs - i * 86400000);
      const dateKey = getLocalDateKey(d);
      sevenDaysMap.set(dateKey, {
        day: daysOfWeek[d.getDay()],
        date: dateKey,
        Productive: 0,
        Wasted: 0,
      });
    }

    // 2. Single-pass over study sessions: O(N)
    let totalProductiveMinutes = 0;
    for (const s of sessions) {
      if (!s || (s as CompletedSessionRecord & { completed?: boolean }).completed === false) continue;
      const sDate = s.date || (s.startTime ? getLocalDateKey(s.startTime) : "");
      const dur = Number(s.totalDurationMinutes || 0);
      if (dur <= 0) continue;

      const chartEntry = sevenDaysMap.get(sDate);
      if (chartEntry) {
        chartEntry.Productive += dur;
      }

      // Check date filter
      let matchesFilter = false;
      if (dateFilter === "Today") {
        matchesFilter = sDate === todayStr;
      } else if (dateFilter === "Week") {
        const sTime = new Date(s.startTime || sDate).getTime();
        matchesFilter = !isNaN(sTime) ? sTime >= weekAgoMs : sDate >= getLocalDateKey(new Date(weekAgoMs));
      } else {
        matchesFilter = true;
      }

      if (matchesFilter) {
        totalProductiveMinutes += dur;
      }
    }

    // 3. Single-pass over distraction logs: O(M)
    let totalWastedMinutes = 0;
    let totalWastedSeconds = 0;
    let totalBreakMinutes = 0;
    let totalBreakSeconds = 0;
    let inSessionWastedMinutes = 0;
    let inSessionIncidentCount = 0;
    let casualWastedMinutes = 0;

    const filteredLogs: VisitLogDoc[] = [];
    const domainMap = new Map<string, { name: string; minutes: number; count: number }>();

    const timeSlots = {
      late_night: {
        slot: "Late Night (22:00 - 04:00)",
        label: "Late Night",
        minutes: 0,
        count: 0,
        recommendation: "High risk of sleep deprivation and passive doomscrolling. Use Monk Mode or auto-shutdown after 22:30.",
      },
      early_morning: {
        slot: "Early Morning (04:00 - 10:00)",
        label: "Early Morning",
        minutes: 0,
        count: 0,
        recommendation: "Prime alertness window being disrupted. Start morning sessions with pen-and-paper formula practice before checking screens.",
      },
      mid_day: {
        slot: "Mid Day (10:00 - 16:00)",
        label: "Mid Day",
        minutes: 0,
        count: 0,
        recommendation: "Classroom & coaching gap vulnerability. Schedule dedicated lunch & break blocks so study time remains strict.",
      },
      evening_prime: {
        slot: "Evening Prime (16:00 - 22:00)",
        label: "Evening Prime",
        minutes: 0,
        count: 0,
        recommendation: "Peak fatigue window. Switch to high-engagement numerical practice or PYQs rather than passive reading to maintain focus.",
      },
    };

    for (const log of logs) {
      if (!log) continue;
      const lDate = log.timestamp ? getLocalDateKey(log.timestamp) : "";
      const isBlocked = Boolean(log.blocked);
      const rawSecs = Number(log.durationSeconds ?? (log.durationMinutes ? log.durationMinutes * 60 : 0));
      
      // Strict IIT-JEE Focus Rules:
      // 1. Blocked requests are intercepted at network level and do NOT count as wasted browsing time.
      // 2. Continuous visits must be at least 60 seconds to count towards wasted study time.
      const durSecs = isBlocked ? 0 : Math.max(0, rawSecs);
      const durMins = (!isBlocked && durSecs >= 60) ? Math.floor(durSecs / 60) : 0;
      const isPauseBreak = log.activityType === "pause_break" || log.sessionState === "paused";

      const chartEntry = sevenDaysMap.get(lDate);
      if (chartEntry && !isPauseBreak) {
        chartEntry.Wasted += durMins;
      }

      // Slot categorization based on actual hour (only counted if genuine wasted time occurred)
      if (durMins > 0 && !isPauseBreak) {
        const logDateObj = log.timestamp ? new Date(log.timestamp) : new Date();
        const hour = !isNaN(logDateObj.getTime()) ? logDateObj.getHours() : 12;
        if (hour >= 22 || hour < 4) {
          timeSlots.late_night.minutes += durMins;
          timeSlots.late_night.count += 1;
        } else if (hour >= 4 && hour < 10) {
          timeSlots.early_morning.minutes += durMins;
          timeSlots.early_morning.count += 1;
        } else if (hour >= 10 && hour < 16) {
          timeSlots.mid_day.minutes += durMins;
          timeSlots.mid_day.count += 1;
        } else {
          timeSlots.evening_prime.minutes += durMins;
          timeSlots.evening_prime.count += 1;
        }
      }

      // Check search query
      if (normalizedSearch) {
        const domainMatch = (log.domain || "").toLowerCase().includes(normalizedSearch);
        const urlMatch = (log.website || "").toLowerCase().includes(normalizedSearch);
        if (!domainMatch && !urlMatch) continue;
      }

      // Check date filter
      let matchesDate = false;
      if (dateFilter === "Today") {
        matchesDate = lDate === todayStr;
      } else if (dateFilter === "Week") {
        const lTime = new Date(log.timestamp).getTime();
        matchesDate = !isNaN(lTime) ? lTime >= weekAgoMs : lDate >= getLocalDateKey(new Date(weekAgoMs));
      } else {
        matchesDate = true;
      }

      if (!matchesDate) continue;

      filteredLogs.push(log);

      if (isPauseBreak) {
        totalBreakMinutes += durMins;
        totalBreakSeconds += durSecs;
      } else {
        totalWastedMinutes += durMins;
        totalWastedSeconds += durSecs;

        if (log.isDuringSession) {
          inSessionWastedMinutes += durMins;
          if (durMins > 0) {
            inSessionIncidentCount += 1;
          }
        } else {
          casualWastedMinutes += durMins;
        }
      }

      if (durMins > 0) {
        const domainKey = (log.domain || "unknown").toLowerCase();
        const existing = domainMap.get(domainKey);
        if (existing) {
          existing.minutes += durMins;
          existing.count += 1;
        } else {
          domainMap.set(domainKey, { name: log.domain || "Unknown", minutes: durMins, count: 1 });
        }
      }
    }

    // 4. Synthesize Peak Vulnerability Slot
    let topSlotKey: keyof typeof timeSlots = "late_night";
    let maxSlotMins = -1;
    const allSlotMins = Object.values(timeSlots).reduce((acc, s) => acc + s.minutes, 0);

    for (const [key, val] of Object.entries(timeSlots)) {
      if (val.minutes > maxSlotMins) {
        maxSlotMins = val.minutes;
        topSlotKey = key as keyof typeof timeSlots;
      }
    }

    const peakSlotData = timeSlots[topSlotKey];
    const peakVulnerability: PeakVulnerabilityWindow = {
      slot: peakSlotData.slot,
      label: peakSlotData.label,
      minutes: peakSlotData.minutes,
      percentage: allSlotMins > 0 ? Math.round((peakSlotData.minutes / allSlotMins) * 100) : 0,
      incidentCount: peakSlotData.count,
      recommendation:
        allSlotMins > 0
          ? peakSlotData.recommendation
          : "Flawless focus! No distraction incidents logged yet for this period.",
    };

    // 5. Synthesize Domain Breakdown
    const DOMAIN_COLORS = ["#ef4444", "#ec4899", "#f97316", "#8b5cf6", "#06b6d4", "#6b7280"];
    const sortedDomains = Array.from(domainMap.values()).sort((a, b) => b.minutes - a.minutes);
    const topDomains = sortedDomains.slice(0, 5);
    const domainBreakdown: DomainDistractionStat[] =
      topDomains.length > 0
        ? topDomains.map((item, idx) => {
            const pct = totalWastedMinutes > 0 ? Math.round((item.minutes / totalWastedMinutes) * 100) : 0;
            return {
              name: item.name,
              value: pct,
              percentage: pct,
              minutes: item.minutes,
              incidentCount: item.count,
              color: DOMAIN_COLORS[idx % DOMAIN_COLORS.length],
            };
          })
        : [{ name: "No Distractions", value: 100, minutes: 0, percentage: 100, incidentCount: 0, color: "#10b981" }];

    // 6. Efficiency, Leak Index, and JEE Question Lost Calculation
    const totalTrackedMinutes = totalProductiveMinutes + totalWastedMinutes;
    const focusEfficiency =
      totalTrackedMinutes > 0
        ? Math.round((totalProductiveMinutes / totalTrackedMinutes) * 100)
        : totalProductiveMinutes > 0
        ? 100
        : 0;

    const focusLeakIndex =
      totalTrackedMinutes > 0 ? Math.round((totalWastedMinutes / totalTrackedMinutes) * 100) : 0;

    // Severity rating
    let severityLevel: "Optimal Focus" | "Moderate Risk" | "Critical Leakage" = "Optimal Focus";
    let severityColor = "text-emerald-400";
    let severityBadgeBg = "bg-emerald-500/10 border-emerald-500/20 text-emerald-400";

    if (focusLeakIndex > 28 || totalWastedMinutes >= 90) {
      severityLevel = "Critical Leakage";
      severityColor = "text-rose-400";
      severityBadgeBg = "bg-rose-500/10 border-rose-500/30 text-rose-400";
    } else if (focusLeakIndex > 12 || totalWastedMinutes >= 35) {
      severityLevel = "Moderate Risk";
      severityColor = "text-amber-400";
      severityBadgeBg = "bg-amber-500/10 border-amber-500/30 text-amber-400";
    }

    // In IIT-JEE, ~3.5 minutes per standard numerical/MCQ question
    const equivalentQuestionsLost = Math.round(totalWastedMinutes / 3.5);
    const inSessionContaminationRate =
      totalWastedMinutes > 0 ? Math.round((inSessionWastedMinutes / totalWastedMinutes) * 100) : 0;

    const compareChartData = Array.from(sevenDaysMap.values());

    return {
      totalWastedMinutes,
      totalWastedSeconds,
      totalBreakMinutes,
      totalBreakSeconds,
      totalProductiveMinutes,
      totalTrackedMinutes,
      focusEfficiency,
      focusLeakIndex,
      severityLevel,
      severityColor,
      severityBadgeBg,
      equivalentQuestionsLost,
      inSessionWastedMinutes,
      inSessionIncidentCount,
      inSessionContaminationRate,
      casualWastedMinutes,
      peakVulnerability,
      compareChartData,
      domainBreakdown,
      filteredLogs,
    };
  },

  /**
   * Fetch analytics document from Supabase
   */
  async getAnalytics(userId: string): Promise<UserAnalyticsDoc | null> {
    if (!userId || userId.startsWith("guest_") || userId === "guest") return null;
    try {
      const { data, error } = await supabase
        .from("profiles")
        .select("xp, level, streak, statistics")
        .eq("id", userId)
        .maybeSingle();

      if (error || !data) return null;

      const stats = (data.statistics as Record<string, unknown>) || {};

      // Compute genuine average focus score from actual study sessions
      const { data: sessionData } = await supabase
        .from("study_sessions")
        .select("focus_score")
        .eq("user_id", userId);

      let avgFocus = 0;
      if (sessionData && sessionData.length > 0) {
        const sum = sessionData.reduce((acc, s) => acc + Number(s.focus_score || 0), 0);
        avgFocus = Math.round(sum / sessionData.length);
      }

      return {
        xp: Number(data.xp || 0),
        level: Number(data.level || 1),
        currentStreak: Number(data.streak || 0),
        totalStudyHours: parseFloat(((Number(stats.totalFocusMinutes || 0)) / 60).toFixed(1)),
        avgFocusScore: avgFocus,
      };
    } catch (err) {
      console.error("Error fetching analytics from Supabase:", err);
      return null;
    }
  },

  /**
   * Save analytics metrics to Supabase
   */
  async updateAnalytics(userId: string, data: UserAnalyticsDoc): Promise<void> {
    if (!userId || userId.startsWith("guest_") || userId === "guest") return;
    try {
      const payload: Record<string, unknown> = {
        updated_at: new Date().toISOString(),
      };
      if (data.xp !== undefined) payload.xp = data.xp;
      if (data.level !== undefined) payload.level = data.level;
      if (data.currentStreak !== undefined) payload.streak = data.currentStreak;

      await supabase.from("profiles").update(payload).eq("id", userId);
    } catch (err) {
      console.error("Error updating analytics in Supabase:", err);
    }
  },
};

