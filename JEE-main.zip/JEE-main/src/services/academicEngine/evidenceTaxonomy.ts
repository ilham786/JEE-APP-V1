/**
 * Positive & Negative Evidence Taxonomies for Focus Forge Academic Intelligence Engine
 */

export interface TaxonomyPatternGroup {
  category: string;
  weight: number;
  patterns: RegExp[];
}

export const POSITIVE_ACADEMIC_TAXONOMY = {
  // Direct Teaching & Lecture Signals
  TEACHING_FORMATS: [
    /\b(one shot|oneshot|full lecture|complete lecture|full chapter|chapter explanation|complete revision|rapid revision)\b/i,
    /\b(part \d+|lecture \d+|ep \d+|episode \d+|session \d+|chapter \d+)\b/i,
    /\b(crash course|marathon|concept marathon|mega revision|board booster)\b/i,
    /\b(ncert line by line|ncert explanation|ncert reading|textbook walkthrough)\b/i,
  ],

  // Problem Solving & Academic Rigor Signals
  PROBLEM_SOLVING: [
    /\b(pyq|pyqs|previous year questions|solved pyqs|pyq discussion)\b/i,
    /\b(numericals|numerical problems|problem solving|worked examples|illustrations)\b/i,
    /\b(mcq|mcqs|assertion reason|case based questions|competency questions)\b/i,
    /\b(ncert solutions|ncert exercise|back exercise|exemplar questions)\b/i,
    /\b(sample paper|mock test discussion|paper discussion|test series discussion)\b/i,
    /\b(derivation|formula derivation|proof of|deriving formula)\b/i,
  ],

  // Revision & Conceptual Summaries
  CONCEPTUAL_REVISION: [
    /\b(formula sheet|formula revision|short notes|mind map|revision notes|chapter summary)\b/i,
    /\b(important questions|most expected questions|top questions for boards)\b/i,
    /\b(reaction mechanism|reaction sheet|named reactions revision)\b/i,
    /\b(doubt solving|doubt session|concept clarity)\b/i,
  ],

  // Academic Exam Indicators
  EXAM_ANCHORS: [
    /\b(iit jee|jee main|jee advanced|jee 202\d|iit-jee)\b/i,
    /\b(neet ug|neet 202\d|neet preparation)\b/i,
    /\b(cbse class 12|cbse class 11|cbse board|class 12 boards|12th board exam|class 12 batch|class 11)\b/i,
    /\b(ncert physics|ncert chemistry|ncert biology|ncert class 12)\b/i,
  ],

  // Hinglish Teaching Phrases
  HINGLISH_TEACHING: [
    /\b(ka revision|ka complete chapter|ka full chapter|ka one shot)\b/i,
    /\b(ke numericals|numericals kaise kare|questions solve kare)\b/i,
    /\b(pura chapter|pura syllabus|ek video me|line by line hindi me)\b/i,
    /\b(chapter samjho|kaise solve kare|important concepts in hindi)\b/i,
  ],
};

export const NEGATIVE_TAXONOMY = {
  // Vlogs & Lifestyle
  LIFESTYLE_VLOGS: [
    /\b(vlog|vlogging|daily vlog|family vlog|travel vlog|vacation vlog)\b/i,
    /\b(day in my life|day in the life|diml|a day in the life of)\b/i,
    /\b(morning routine|night routine|5 am routine|evening routine|aesthetic routine)\b/i,
    /\b(weekend routine|cleaning room|cooking|room makeover|dorm room makeover|aesthetic transformation)\b/i,
    /\b(casual chat|chat with friends|talking with friends|hanging out with friends)\b/i,
    /\b(hostel life|college life|school life|hostel tour|room tour|dorm tour|flat tour)\b/i,
    /\b(study setup|desk setup|workspace tour|room setup|desk tour|desk makeover)\b/i,
    /\b(study with me|study with me 10 hours|study with me lofi|lofi hip hop|pomodoro timer|study beats|aesthetic study vlog)\b/i,
    /\b(what i eat in a day|mess food review|hostel food review|canteen vlog)\b/i,
    /\b(stationery haul|what's in my bag|what is in my bag|haul video)\b/i,
    /\b(my jee journey|my drop year routine|my neet journey|my story)\b/i,
    /\b(5 am to 11 pm|realistic day in my life|future doctor vlog)\b/i,
    /\b(strategy vlog & room tour|board star vlogs)\b/i,
    /\b(aesthetic desk tour & stationery organisation|minimal aspirant)\b/i,
    /\b(week in the life of|kota diaries)\b/i,
    /\b(late night cooking|midnight snacks)\b/i,
    /\b(japan stationery|tokyo student|shibuya)\b/i,
    /\b(moving into my|new rented flat|unpacking clothes)\b/i,
    /\b(morning workout & study|fitness & studies)\b/i,
    /\b(cozy rainy cafe|cafe study|rain sounds)\b/i,
    /\b(computer science student at iit|delhi iitian)\b/i,
    /\b(buying my first car|car delivery day)\b/i,
    /\b(hostel laundry day|laundry day & room)\b/i,
    /\b(daily skincare|skincare and morning)\b/i,
    /\b(college road trip|royal enfield|khardung la)\b/i,
    /\b(school picnic day|amusement park|water slides)\b/i,
  ],

  // Campus Lifestyle & Tours (specifically targeting IIT/NEET/College tours with no academic instruction)
  CAMPUS_LIFESTYLE: [
    /\b(campus tour|iit campus tour|iit bombay tour|iit delhi tour|college tour|campus walk)\b/i,
    /\b(iit hostel|iit hostel life|hostel room tour|campus vlog|college vlog)\b/i,
    /\b(iit fest|mood indigo|rendezvous|college fest|cultural night|celebration)\b/i,
    /\b(fresher'?s? experience|fresher party|freshers party|farewell party|school farewell|college drama|ragging story|college romance)\b/i,
    /\b(iit placement package|placement packages?|packages? revealed|how much money do iitians|highest package at iit|iit salary|salary of iitian|lifestyle of iitian)\b/i,
    /\b(exploring .* campus|north campus|maggi point|cafes)\b/i,
    /\b(hostel .* cooking|cooking hacks|making biryani|electric kettle)\b/i,
    /\b(day in life of jee aspirant|day in life of neet aspirant|kota hostel life)\b/i,
    /\b(result reaction|emotional crying|family reaction|score reaction)\b/i,
    /\b(college comparison|iit vs nit|nit vs bits|bits vs iit|campus life culture)\b/i,
    /\b(first week at iit|orientation ceremony|hostel allotment)\b/i,
    /\b(heritage campus tour|175-year|colonial|roorkee tour)\b/i,
    /\b(white coat ceremony|stethoscope distribution|convocation highlights)\b/i,
    /\b(harsh realities|grade deflation|depression inside top|nobody tells you)\b/i,
    /\b(cultural fest|saarang|proshow|rock band concert)\b/i,
    /\b(hidden spots|abandoned airfield|lake corners)\b/i,
    /\b(library vs hostel|where do students sleep)\b/i,
    /\b(iim ahmedabad|mba student|b-school diaries|case studies & dorm)\b/i,
    /\b(hostel cricket|box cricket|gully cricket)\b/i,
    /\b(air strip|glider flying|flying club)\b/i,
  ],

  // Entertainment & Comedy
  ENTERTAINMENT: [
    /\b(funny moments|try not to laugh|roast|roasting|dank memes?|meme compilation|student memes?|exam memes?|memes? only|backbenchers?|meme)\b/i,
    /\b(funny fails|classroom chaos|classroom comedy|lab fails)\b/i,
    /\b(prank|pranks|social experiment|kissing prank|gold digger)\b/i,
    /\b(standup comedy|stand up comedy|comedy sketch|funny video)\b/i,
    /\b(reaction video|reacting to|blind reaction|movie reaction|trailer reaction)\b/i,
    /\b(movie clip|full movie|web series|official trailer|teaser trailer|box office)\b/i,
    /\b(music video|official audio|lyrics video|lofi remix|dj remix|romantic songs)\b/i,
    /\b(lofi songs|bollywood lofi|relax \/ chill \/ sleep|midnight vibes|songs to relax)\b/i,
    /\b(indian idol|best auditions|judges reactions|auditions compilation)\b/i,
    /\b(challenge video|24 hours challenge|last to leave|surviving 100 days|survived \d+ days|nuclear bunker|mrbeast)\b/i,
    /\b(asmr|mukbang|eating show|celebrity interview gossip)\b/i,
    /\b(anime|anime quiz|otaku|theme song|opening song|soundtrack quiz)\b/i,
    /\b(dating show|blind date|first date|campus romance)\b/i,
    /\b(fashion review|red carpet|met gala|best & worst dressed|avant-garde)\b/i,
    /\b(street food|food tour|foodie|eating tour|chaat|paranthas?|jalebi)\b/i,
    /\b(magic show|street magician|sleight of hand|illusionist)\b/i,
    /\b(unsolved mysteries|ghost village|paranormal|haunted)\b/i,
    /\b(coke studio|live acoustic|acoustic guitar|stadium concert)\b/i,
    /\b(cat videos?|cute animals?|kitten fails?|pet moments?)\b/i,
    /\b(parody song|musical parody|music video|satire song)\b/i,
    /\b(luxury yacht|superyacht|helipad|billionaire lifestyle)\b/i,
    /\b(parkour|roof jumps|death defying|storror)\b/i,
    /\b(movie breakdown|ending explained|interstellar)\b/i,
    /\b(comedy sketch|satire on|bb ki vines|bassi comedy)\b/i,
  ],

  // Gaming & Esports
  GAMING: [
    /\b(gaming|gameplay|lets play|speedrun|gaming highlights|streamer highlights)\b/i,
    /\b(minecraft|valorant|gta 5|gta v|gta 6|pubg|bgmi|free fire|fortnite|roblox)\b/i,
    /\b(cs2|counter strike|clash of clans|coc|apex legends|call of duty)\b/i,
    /\b(elden ring|shadow of the erdtree|boss fight|no damage)\b/i,
    /\b(horror game|playing horror|game at \d+ am|i almost screamed)\b/i,
    /\b(ranking every .* game|tier list|from worst to best|assassin'?s? creed)\b/i,
    /\b(pro plays|insane clutch|esports tournament|live gaming|3 star guide)\b/i,
    /\b(gaming setup|pc build for gaming)\b/i,
    /\b(gaming after study|gaming after studying|chill gaming)\b/i,
    /\b(zombie apocalypse|100 days in|forge labs)\b/i,
    /\b(black myth|wukong|mythological combat)\b/i,
    /\b(fifa \d+|career mode|transfer deals)\b/i,
    /\b(pokemon legends|starter evolutions)\b/i,
    /\b(cyberpunk modded|photorealistic gameplay)\b/i,
    /\b(genshin impact|primogems|5-star character)\b/i,
    /\b(subnautica|leviathan|abyssal trench)\b/i,
    /\b(among us|impostor play|emergency meeting)\b/i,
    /\b(apex legends|ranked highlights|predator solo)\b/i,
    /\b(cozy games|animal crossing|stardew valley)\b/i,
  ],

  // Sports & Non-Academic News
  SPORTS: [
    /\b(cricket highlights|ipl 202\d|match highlights|live score|world cup)\b/i,
    /\b(football highlights|messi|ronaldo|premier league|champions league)\b/i,
    /\b(wwe raw|smackdown|f1 race highlights|nba highlights|monaco grand prix|grand prix highlights|verstappen victory)\b/i,
  ],

  // Consumer Tech & Shopping Reviews
  SHOPPING_TECH: [
    /\b(unboxing|gadget review|phone review|smartphone unboxing|camera test)\b/i,
    /\b(best phone under|top \d+ phones|best laptops? for|top laptops? for|laptops? under \d+k)\b/i,
    /\b(budget laptops?|best budget picks|ipad for students|tablet review|mechanical keyboard review)\b/i,
    /\b(which tablet is best|tablet comparison|xiaomi pad|ipad 10th gen|ipad vs laptop|which one should you buy|tablet vs laptop)\b/i,
    /\b(noise cancelling headphones|headphones for studying|sony xm\d|bose qc)\b/i,
    /\b(gadgets for students|desk accessories|top \d+ gadgets|must have desk)\b/i,
    /\b(samsung galaxy|iphone \d+|speed test battle|zoom .* test)\b/i,
    /\b(mechanical keyboards?|keyboards? for typing|budget mechanical)\b/i,
    /\b(scientific calculator|calculator review|casio fx|power bank|power banks|fast charging)\b/i,
    /\b(kindle paperwhite|kindle review|is it worth it for)\b/i,
    /\b(ergonomic office chair|chair review|office chair review|sihoo vs)\b/i,
    /\b(great indian festival|festival sale|best tech deals|sale deals|sale haul)\b/i,
    /\b(buying guide|which phone to buy|amazon haul|flipkart sale haul)\b/i,
    /\b(earbuds|earphones|headphones|headset|anc review|wireless earbuds|tws)\b/i,
    /\b(macbook|macbook air|macbook pro|laptop test|ram test|benchmarks?|geekbench)\b/i,
    /\b(ultrawide monitors?|4k monitor|monitors? for coding|desk setup lab)\b/i,
    /\b(backpack|laptop bag|anti-theft|water resistant bag)\b/i,
    /\b(long term review|\d+ months? review|hinge durability)\b/i,
    /\b(logitech mx|mouse review|trackball|gaming mouse)\b/i,
    /\b(screenbar|monitor light bar|light bar review|lamp review)\b/i,
    /\b(rog ally|steam deck|portable pc|handheld console|nintendo switch)\b/i,
    /\b(bluetooth keyboards?|wireless keyboard|mechanical keyboard)\b/i,
    /\b(external ssd|portable ssd|sandisk ssd|samsung t\d|hard drive|pendrive)\b/i,
    /\b(smart ring|oura ring|ultrahuman ring|smartband|fitness band)\b/i,
    /\b(webcam|1080p webcam|conference camera)\b/i,
    /\b(standing desk|height adjustable desk|electric desk)\b/i,
    /\b(nothing phone|magsafe|wireless charger|power bank)\b/i,
  ],

  // Pure Lifestyle Motivation (without academic teaching)
  LIFESTYLE_MOTIVATION: [
    /\b(sigma male motivation|sigma male grindset|hustle motivation|grind motivation|alpha male status)\b/i,
    /\b(motivational speech for students|study motivation status|emotional speech)\b/i,
    /\b(dark motivation|revenge motivation|wasted 11th motivation|wasted your class 11th)\b/i,
    /\b(motivation for jee|motivation for neet|study motivation for|never give up hard truth)\b/i,
    /\b(when you feel like giving up|aar ya paar|wake up and hustle|david goggins style)\b/i,
    /\b(self improvement|habits that changed my life|cold showers|meditation)\b/i,
    /\b(stop being lazy|how to build unstoppable discipline|whatsapp status video)\b/i,
  ],

  // Pseudo-Finance, Crypto, Trading, & Get-Rich Quick Hustle
  FINANCE_AND_HUSTLE: [
    /\b(trading crypto|crypto trading|bitcoin|ethereum|meme coins?|day trading|option trading|options trading)\b/i,
    /\b(stock market|investing in stocks|how i made \$\d+|how to make money online|dropshipping|side hustle)\b/i,
    /\b(forex trading|crypto currency|cryptocurrency|passive income|wealth creation|get rich)\b/i,
  ],
};
