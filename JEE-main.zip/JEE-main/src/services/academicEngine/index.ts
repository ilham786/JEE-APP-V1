/**
 * FocusForge Academic Intelligence Engine
 * 
 * Version: 2026.1
 * Authoritative Multi-Pass Semantic Classifier
 */

import {
  AcademicClassificationInput,
  AcademicClassificationOutput,
  ClassificationTraceEvent,
  StructuredResponse,
} from "./types";
import {
  TAXONOMY_VERSION,
  CLASSIFIER_VERSION,
  matchKnowledgeGraph,
} from "@/lib/academic-knowledge-graph";
import {
  POSITIVE_ACADEMIC_TAXONOMY,
  NEGATIVE_TAXONOMY,
} from "./evidenceTaxonomy";
import { EvidenceConflictResolver } from "./conflictResolver";

export { TAXONOMY_VERSION, CLASSIFIER_VERSION } from "@/lib/academic-knowledge-graph";
export * from "./types";
export * from "./evidenceTaxonomy";
export * from "./conflictResolver";
export * from "./profileHash";

// Pre-seeded verified educational channels
export const VERIFIED_ACADEMIC_CHANNELS = [
  "physics wallah",
  "alakh pandey",
  "mohit tyagi",
  "unacademy jee",
  "vedantu jee",
  "mathongo",
  "neha agrawal mathematically inclined",
  "pankaj sir chemistry",
  "canvas classes",
  "apni kaksha",
  "aman dhattarwal",
  "garima goel biology",
  "biology at ease",
  "dear sir",
  "simran sahni",
  "magnet brains",
  "khan academy",
  "khan academy india",
  "unacademy neet",
  "vedantu neet",
  "allen career institute",
  "motion jee",
  "esraptutorials",
];

/**
 * Classifies a YouTube video using the Focus Forge Academic Intelligence Engine.
 */
export function classifyAcademicVideo(
  input: AcademicClassificationInput
): AcademicClassificationOutput {
  const {
    videoId,
    title = "",
    description = "",
    channelName = "",
    tags = [],
    durationSeconds = 0,
    activeSessionSubject = "",
    activeSessionChapter = "",
    guardMode = "balanced",
  } = input;

  const normalizedTitle = title.toLowerCase().trim();
  const normalizedDesc = (description || "").toLowerCase().trim();
  const normalizedChannel = (channelName || "").toLowerCase().trim();
  const normalizedTags = (tags || []).map((t) => t.toLowerCase()).join(" ");

  const combinedText = `${normalizedTitle} ${normalizedDesc} ${normalizedChannel} ${normalizedTags}`;

  // 1. Shorts Check: STRICT invariant during active study sessions
  const isShort =
    Boolean(input.isShorts) ||
    (durationSeconds > 0 && durationSeconds <= 60) ||
    normalizedTitle.includes("#shorts") ||
    normalizedTitle.includes("#short") ||
    input.category === "shorts";

  // 2. Channel Trust Verification
  const isTrustedChannel = VERIFIED_ACADEMIC_CHANNELS.some(
    (ch) => normalizedChannel.includes(ch) || ch.includes(normalizedChannel)
  );

  // 3. Knowledge Graph Entity Resolution
  const rawMatches = matchKnowledgeGraph(combinedText);

  // Apply contextual boost if matches active session subject & chapter
  const taxonomyMatches = rawMatches.map((match) => {
    let boost = 0;
    if (activeSessionSubject && match.subject.toLowerCase() === activeSessionSubject.toLowerCase()) {
      boost += 0.05;
    }
    if (
      activeSessionChapter &&
      (match.chapter.toLowerCase().includes(activeSessionChapter.toLowerCase()) ||
        activeSessionChapter.toLowerCase().includes(match.chapter.toLowerCase()))
    ) {
      boost += 0.08;
    }
    return {
      ...match,
      matchConfidence: Math.min(1.0, match.matchConfidence + boost),
    };
  });

  // 4. Positive Signals Extraction
  const matchedFormats: string[] = [];
  for (const pat of POSITIVE_ACADEMIC_TAXONOMY.TEACHING_FORMATS) {
    const m = combinedText.match(pat);
    if (m) matchedFormats.push(m[0]);
  }

  const matchedProblemSolving: string[] = [];
  for (const pat of POSITIVE_ACADEMIC_TAXONOMY.PROBLEM_SOLVING) {
    const m = combinedText.match(pat);
    if (m) matchedProblemSolving.push(m[0]);
  }

  const matchedRevision: string[] = [];
  for (const pat of POSITIVE_ACADEMIC_TAXONOMY.CONCEPTUAL_REVISION) {
    const m = combinedText.match(pat);
    if (m) matchedRevision.push(m[0]);
  }

  const matchedExamAnchors: string[] = [];
  for (const pat of POSITIVE_ACADEMIC_TAXONOMY.EXAM_ANCHORS) {
    const m = combinedText.match(pat);
    if (m) matchedExamAnchors.push(m[0]);
  }

  const matchedHinglish: string[] = [];
  for (const pat of POSITIVE_ACADEMIC_TAXONOMY.HINGLISH_TEACHING) {
    const m = combinedText.match(pat);
    if (m) matchedHinglish.push(m[0]);
  }

  // 5. Negative Signals Extraction
  const matchedVlogs: string[] = [];
  for (const pat of NEGATIVE_TAXONOMY.LIFESTYLE_VLOGS) {
    const m = combinedText.match(pat);
    if (m) matchedVlogs.push(m[0]);
  }

  const matchedCampusLifestyle: string[] = [];
  for (const pat of NEGATIVE_TAXONOMY.CAMPUS_LIFESTYLE) {
    const m = combinedText.match(pat);
    if (m) matchedCampusLifestyle.push(m[0]);
  }

  const matchedEntertainment: string[] = [];
  for (const pat of NEGATIVE_TAXONOMY.ENTERTAINMENT) {
    const m = combinedText.match(pat);
    if (m) matchedEntertainment.push(m[0]);
  }

  const matchedGaming: string[] = [];
  for (const pat of NEGATIVE_TAXONOMY.GAMING) {
    const m = combinedText.match(pat);
    if (m) matchedGaming.push(m[0]);
  }

  const matchedSports: string[] = [];
  for (const pat of NEGATIVE_TAXONOMY.SPORTS) {
    const m = combinedText.match(pat);
    if (m) matchedSports.push(m[0]);
  }

  const matchedShoppingTech: string[] = [];
  for (const pat of NEGATIVE_TAXONOMY.SHOPPING_TECH) {
    const m = combinedText.match(pat);
    if (m) matchedShoppingTech.push(m[0]);
  }

  const matchedMotivation: string[] = [];
  for (const pat of NEGATIVE_TAXONOMY.LIFESTYLE_MOTIVATION) {
    const m = combinedText.match(pat);
    if (m) matchedMotivation.push(m[0]);
  }

  const matchedFinanceHustle: string[] = [];
  for (const pat of NEGATIVE_TAXONOMY.FINANCE_AND_HUSTLE) {
    const m = combinedText.match(pat);
    if (m) matchedFinanceHustle.push(m[0]);
  }

  // 6. Contradiction Resolution via EvidenceConflictResolver
  const resolution = EvidenceConflictResolver.resolve({
    title,
    combinedText,
    taxonomyMatches,
    positiveSignals: {
      formats: matchedFormats,
      problemSolving: matchedProblemSolving,
      revision: matchedRevision,
      examAnchors: matchedExamAnchors,
      hinglish: matchedHinglish,
    },
    negativeSignals: {
      vlogs: matchedVlogs,
      campusLifestyle: matchedCampusLifestyle,
      entertainment: matchedEntertainment,
      gaming: matchedGaming,
      sports: matchedSports,
      shoppingTech: matchedShoppingTech,
      motivation: matchedMotivation,
      financeAndHustle: matchedFinanceHustle,
    },
    isShort,
    isTrustedChannel,
    durationSeconds,
    guardMode,
  });

  const bestMatch = taxonomyMatches[0] || null;
  const matchedKeywords = Array.from(
    new Set([
      ...(bestMatch ? [bestMatch.matchedEntity] : []),
      ...matchedFormats,
      ...matchedProblemSolving,
      ...matchedRevision,
      ...matchedExamAnchors,
    ])
  );

  const now = Date.now();
  const trace: ClassificationTraceEvent[] = [
    { videoId, stage: "DETECTED", timestamp: now - 15 },
    { videoId, stage: "METADATA_LOADED", timestamp: now - 10, details: { titleLength: title.length, hasChannel: Boolean(channelName) } },
    { videoId, stage: "LOCAL_CLASSIFIED", timestamp: now - 5, details: { matchedCount: taxonomyMatches.length, topEntity: bestMatch?.matchedEntity } },
    { videoId, stage: "FINAL_DECISION", timestamp: now, details: { decision: resolution.decision, confidenceBand: resolution.confidenceBand } },
  ];

  return {
    videoId,
    decision: resolution.decision,
    confidence: resolution.confidence,
    confidenceBand: resolution.confidenceBand,
    subject: bestMatch?.subject || "",
    chapter: bestMatch?.chapter || "",
    topic: bestMatch?.topic || "",
    subtopic: bestMatch?.subtopic || "",
    intent: resolution.intent,
    examRelevance: bestMatch?.examRelevance || [],
    boardRelevance: ["CBSE"],
    academicLevel: bestMatch?.academicLevel || "Class 11 / Class 12",
    reasonCodes: resolution.reasonCodes,
    humanReason: resolution.humanReason,
    matchedKeywords,
    isTrustedChannel,
    isShort,
    cachedAt: now,
    taxonomyVersion: TAXONOMY_VERSION,
    classifierVersion: CLASSIFIER_VERSION,
    trace,
  };
}

/**
 * Produces strict JSON StructuredResponse adhering to Section 29 of the specification.
 */
export function toStructuredResponse(output: AcademicClassificationOutput): StructuredResponse {
  return {
    decision: output.decision,
    subject: output.subject || "",
    chapter: output.chapter || "",
    topic: output.topic || "",
    subtopic: output.subtopic || "",
    intent: output.intent,
    academicLevel: output.academicLevel,
    examRelevance: output.examRelevance,
    boardRelevance: output.boardRelevance,
    confidenceBand: output.confidenceBand,
    reasonCodes: output.reasonCodes,
  };
}

export * from "./profileHash";

/**
 * Authoritative Unified FocusForgeYouTubeGuard Subsystem Export
 */
export const FocusForgeYouTubeGuard = {
  TAXONOMY_VERSION,
  CLASSIFIER_VERSION,
  classifyVideo: classifyAcademicVideo,
  toStructuredResponse,
};
