import { AcademicSubject, TargetExam } from "@/lib/academic-knowledge-graph";

export type AcademicDecision = "STUDY" | "NON_STUDY" | "REVIEW";

export type ConfidenceBand = "VERY_HIGH" | "HIGH" | "MEDIUM" | "LOW";

export type AcademicIntent =
  // Allowed Study Intents
  | "TEACH"
  | "EXPLAIN"
  | "SOLVE"
  | "REVISE"
  | "PRACTICE"
  | "EXAM_PREP"
  | "TEXTBOOK_HELP"
  | "QUESTION_DISCUSSION"
  | "DOUBT_SOLVING"
  // Non-Study Intents
  | "VLOG"
  | "LIFESTYLE"
  | "ENTERTAINMENT"
  | "ENTERTAIN" // backward compat
  | "GAMING"
  | "MOTIVATION"
  | "MOTIVATE" // backward compat
  | "SHOPPING"
  | "REACTION"
  | "SPORTS"
  | "TRAVEL"
  | "NEWS"
  | "CELEBRITY"
  | "UNKNOWN";

export type ReasonCode =
  // Academic
  | "TOPIC_MATCH"
  | "CHAPTER_MATCH"
  | "SUBJECT_MATCH"
  | "EXAM_MATCH"
  | "BOARD_MATCH"
  | "CLASS_MATCH"
  | "NCERT_MATCH"
  | "ACADEMIC_INTENT"
  | "LECTURE"
  | "LECTURE_FORMAT"
  | "PROBLEM_SOLVING"
  | "REVISION"
  | "REVISION_FORMAT"
  | "QUESTION_SOLVING"
  | "TRUSTED_CHANNEL"
  | "CURRENT_SESSION_MATCH"
  // Negative
  | "VLOG"
  | "LIFESTYLE"
  | "GAMING"
  | "ENTERTAINMENT"
  | "MOTIVATION"
  | "SHOPPING"
  | "SHOPPING_TECH"
  | "REACTION"
  | "TRAVEL"
  | "SPORTS"
  | "UNRELATED_TOPIC"
  | "NON_ACADEMIC_INTENT"
  | "CONFLICTING_EVIDENCE"
  | "INSUFFICIENT_EVIDENCE"
  | "AMBIGUOUS_CONTEXT"
  | "CAMPUS_LIFESTYLE"
  | "SHORTS_PROHIBITED";

export interface AcademicClassificationInput {
  videoId: string;
  title: string;
  description?: string;
  channelName?: string;
  channelId?: string;
  category?: string;
  tags?: string[];
  durationSeconds?: number;
  hasCaptions?: boolean;
  topicDetails?: string[];
  userExam?: string;
  userBoard?: string;
  userClass?: string;
  userSubjects?: string[];
  activeSessionSubject?: string;
  activeSessionChapter?: string;
  guardMode?: "strict" | "balanced" | "custom";
  currentStudyTopic?: string;
  currentTopicMode?: boolean;
  isShorts?: boolean;
}

export interface StructuredResponse {
  decision: AcademicDecision;
  subject: string;
  chapter: string;
  topic: string;
  subtopic: string;
  intent: AcademicIntent;
  academicLevel: string;
  examRelevance: TargetExam[];
  boardRelevance: string[];
  confidenceBand: ConfidenceBand;
  reasonCodes: ReasonCode[];
}

export type ClassificationTraceStage =
  | "DETECTED"
  | "METADATA_LOADED"
  | "LOCAL_CLASSIFIED"
  | "BACKEND_CLASSIFIED"
  | "FINAL_DECISION";

export interface ClassificationTraceEvent {
  videoId: string;
  stage: ClassificationTraceStage;
  timestamp: number;
  details?: Record<string, unknown>;
}

export interface AcademicClassificationOutput {
  videoId: string;
  decision: AcademicDecision;
  confidence: number; // 0 to 1
  confidenceBand: ConfidenceBand;
  subject?: AcademicSubject | "";
  chapter?: string;
  topic?: string;
  subtopic?: string;
  intent: AcademicIntent;
  examRelevance: TargetExam[];
  boardRelevance: string[];
  academicLevel: string;
  reasonCodes: ReasonCode[];
  humanReason: string;
  matchedKeywords: string[];
  isTrustedChannel: boolean;
  isShort: boolean;
  cachedAt?: number;
  taxonomyVersion: string;
  classifierVersion: string;
  trace?: ClassificationTraceEvent[];
}
