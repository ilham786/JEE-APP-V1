import { AcademicDecision, AcademicIntent, ConfidenceBand, ReasonCode } from "./types";
import { TaxonomyMatch } from "@/lib/academic-knowledge-graph";

export interface ConflictResolutionInput {
  title: string;
  combinedText: string;
  taxonomyMatches: TaxonomyMatch[];
  positiveSignals: {
    formats: string[];
    problemSolving: string[];
    revision: string[];
    examAnchors: string[];
    hinglish: string[];
  };
  negativeSignals: {
    vlogs: string[];
    campusLifestyle: string[];
    entertainment: string[];
    gaming: string[];
    sports: string[];
    shoppingTech: string[];
    motivation: string[];
    financeAndHustle?: string[];
  };
  isShort: boolean;
  isTrustedChannel: boolean;
  durationSeconds: number;
  guardMode: "strict" | "balanced" | "custom";
}

export interface ConflictResolutionResult {
  decision: AcademicDecision;
  confidence: number; // 0 to 1
  confidenceBand: ConfidenceBand;
  intent: AcademicIntent;
  reasonCodes: ReasonCode[];
  humanReason: string;
}

export class EvidenceConflictResolver {
  /**
   * Resolves conflicts between academic entity mentions and lifestyle/entertainment contexts
   */
  static resolve(input: ConflictResolutionInput): ConflictResolutionResult {
    const {
      title,
      combinedText,
      taxonomyMatches,
      positiveSignals,
      negativeSignals,
      isShort,
      isTrustedChannel,
      durationSeconds,
      guardMode,
    } = input;

    const reasonCodes: ReasonCode[] = [];
    const bestMatch = taxonomyMatches[0] || null;

    // 1. Immediate Hard Invariant: Short-form videos (<60s or #shorts) are strictly non-study
    if (isShort) {
      return {
        decision: "NON_STUDY",
        confidence: 1.0,
        confidenceBand: "VERY_HIGH",
        intent: "ENTERTAIN",
        reasonCodes: ["SHORTS_PROHIBITED", "NON_ACADEMIC_INTENT"],
        humanReason: "YouTube Shorts are strictly prohibited during active study sessions.",
      };
    }

    // 2. Count negative evidence occurrences
    const totalNegativeHits =
      negativeSignals.vlogs.length +
      negativeSignals.campusLifestyle.length +
      negativeSignals.entertainment.length +
      negativeSignals.gaming.length +
      negativeSignals.sports.length +
      negativeSignals.shoppingTech.length +
      negativeSignals.motivation.length +
      (negativeSignals.financeAndHustle?.length || 0);

    // 3. Count positive format & intent evidence
    const hasAcademicAction =
      positiveSignals.formats.length > 0 ||
      positiveSignals.problemSolving.length > 0 ||
      positiveSignals.revision.length > 0 ||
      positiveSignals.hinglish.length > 0;

    // Infer Primary Intent
    let intent: AcademicIntent = "UNKNOWN";

    if (negativeSignals.gaming.length > 0) {
      intent = "GAMING";
      reasonCodes.push("GAMING");
    } else if (negativeSignals.vlogs.length > 0) {
      intent = "VLOG";
      reasonCodes.push("VLOG");
    } else if (negativeSignals.campusLifestyle.length > 0) {
      intent = "LIFESTYLE";
      reasonCodes.push("CAMPUS_LIFESTYLE");
    } else if (negativeSignals.entertainment.length > 0) {
      intent = "ENTERTAIN";
      reasonCodes.push("ENTERTAINMENT");
    } else if (negativeSignals.shoppingTech.length > 0) {
      intent = "SHOPPING";
      reasonCodes.push("SHOPPING_TECH");
    } else if (negativeSignals.sports.length > 0) {
      intent = "SPORTS";
      reasonCodes.push("SPORTS");
    } else if (negativeSignals.motivation.length > 0) {
      intent = "MOTIVATE";
      reasonCodes.push("MOTIVATION");
    } else if ((negativeSignals.financeAndHustle?.length || 0) > 0) {
      intent = "LIFESTYLE";
      reasonCodes.push("NON_ACADEMIC_INTENT");
    } else if (positiveSignals.problemSolving.length > 0) {
      intent = "SOLVE";
      reasonCodes.push("PROBLEM_SOLVING");
    } else if (positiveSignals.revision.length > 0) {
      intent = "REVISE";
      reasonCodes.push("REVISION_FORMAT");
    } else if (positiveSignals.formats.length > 0) {
      intent = "TEACH";
      reasonCodes.push("LECTURE_FORMAT");
    } else if (bestMatch) {
      intent = "EXPLAIN";
      reasonCodes.push("ACADEMIC_INTENT");
    }

    // 4. CRITICAL NEGATIVE-CONTEXT RULE RESOLUTION (Prompt Section 11 & 12)
    // Rule: Academic Keyword + Lifestyle/Vlog/Tech/Gaming Context -> NON_STUDY
    const hasVlogContext = negativeSignals.vlogs.length > 0 || negativeSignals.campusLifestyle.length > 0;
    const hasTechOrShopping = negativeSignals.shoppingTech.length > 0;
    const hasGamingOrComedy = negativeSignals.gaming.length > 0 || negativeSignals.entertainment.length > 0 || negativeSignals.sports.length > 0;
    const hasFinanceOrHustle = (negativeSignals.financeAndHustle?.length || 0) > 0;
    const hasMotivationOnly = negativeSignals.motivation.length > 0 && !hasAcademicAction && !bestMatch;

    // Case A: Pure Lifestyle / Distraction / Gaming / Finance (No syllabus topic match)
    if ((hasVlogContext || hasTechOrShopping || hasGamingOrComedy || hasFinanceOrHustle || hasMotivationOnly) && !bestMatch) {
      const firstNeg =
        negativeSignals.vlogs[0] ||
        negativeSignals.campusLifestyle[0] ||
        negativeSignals.entertainment[0] ||
        negativeSignals.gaming[0] ||
        negativeSignals.shoppingTech[0] ||
        negativeSignals.financeAndHustle?.[0] ||
        negativeSignals.motivation[0] ||
        "lifestyle";

      return {
        decision: "NON_STUDY",
        confidence: 0.98,
        confidenceBand: "VERY_HIGH",
        intent,
        reasonCodes: [...reasonCodes, "NON_ACADEMIC_INTENT"],
        humanReason: `Detected non-academic ${intent.toLowerCase()} content (${firstNeg}): no verified academic curriculum topic identified.`,
      };
    }

    // Case B: Negative Context Signals (Vlog, Campus, Gaming, Comedy, Tech/Shopping, Finance)
    // Rule: Negative signal dominates unless explicit lecture/problem-solving action AND high curriculum match are both present.
    if (hasVlogContext || hasGamingOrComedy || hasTechOrShopping || hasFinanceOrHustle) {
      if (!hasAcademicAction) {
        // Without explicit academic teaching or problem solving, negative intent completely dominates
        const firstNeg =
          negativeSignals.vlogs[0] ||
          negativeSignals.campusLifestyle[0] ||
          negativeSignals.entertainment[0] ||
          negativeSignals.gaming[0] ||
          negativeSignals.shoppingTech[0] ||
          negativeSignals.financeAndHustle?.[0] ||
          "lifestyle";

        return {
          decision: "NON_STUDY",
          confidence: 0.96,
          confidenceBand: "VERY_HIGH",
          intent: intent === "EXPLAIN" || intent === "UNKNOWN" ? "LIFESTYLE" : intent,
          reasonCodes: [...reasonCodes, "NON_ACADEMIC_INTENT"],
          humanReason: `Detected non-academic ${intent.toLowerCase()} content (${firstNeg}): lacks verified curriculum teaching or problem-solving format.`,
        };
      }

      // If it contains BOTH strong topic match AND strong academic action (e.g., "IIT JEE Advanced Rotational Motion Problem Solving")
      if (bestMatch && bestMatch.matchConfidence >= 0.85) {
        if (positiveSignals.formats.length > 0 || positiveSignals.problemSolving.length > 0) {
          reasonCodes.push("TOPIC_MATCH");
          if (bestMatch.topic) reasonCodes.push("CHAPTER_MATCH");
          return {
            decision: "STUDY",
            confidence: 0.88,
            confidenceBand: "HIGH",
            intent: "TEACH",
            reasonCodes,
            humanReason: `Verified academic instruction: Matched ${bestMatch.subject} → ${bestMatch.chapter} (${bestMatch.topic}) with explicit lecture/problem-solving intent.`,
          };
        }
      }

      // If conflict is truly ambiguous with teaching action present:
      return {
        decision: "REVIEW",
        confidence: 0.50,
        confidenceBand: "LOW",
        intent,
        reasonCodes: [...reasonCodes, "CONFLICTING_EVIDENCE"],
        humanReason: `Evidence conflict: Contains academic curriculum reference (${bestMatch?.chapter || "topic"}) alongside lifestyle/entertainment signals. Requires review.`,
      };
    }

    // Case C: Motivation for students without academic teaching
    if (negativeSignals.motivation.length > 0) {
      if (!bestMatch || (!hasAcademicAction && bestMatch.matchConfidence < 0.90)) {
        return {
          decision: "NON_STUDY",
          confidence: 0.92,
          confidenceBand: "VERY_HIGH",
          intent: "MOTIVATE",
          reasonCodes: ["MOTIVATION", "NON_ACADEMIC_INTENT"],
          humanReason: `Detected as motivational content for students: not teaching verified syllabus or curriculum topics.`,
        };
      }
    }

    // Case D: Clear Academic Curriculum Match
    if (bestMatch && bestMatch.matchConfidence >= 0.75) {
      // Check for historical documentary / non-curriculum framing
      const isDocumentary = /\b(history of|documentary|feud|dispute|biography|origin of)\b/i.test(title);
      if (isDocumentary && !hasAcademicAction) {
        return {
          decision: "REVIEW",
          confidence: 0.60,
          confidenceBand: "MEDIUM",
          intent: "EXPLAIN",
          reasonCodes: [...reasonCodes, "AMBIGUOUS_CONTEXT"],
          humanReason: `General historical or documentary framing (${bestMatch.subject}): requires review during focus sessions.`,
        };
      }

      // Check for meta-academic / advisory / strategy / music / trivia / policy framing
      const isMetaOrAdvisory =
        /\b(strategy|tips|roadmap|how to study|how to clear|can you clear|reality check|mistakes to avoid|mistakes while|topper interview|topper talks|podcast|weightage breakdown|blueprint|marks distribution|test series|mock test|expected cutoff|cutoff|cut-off|dress code|admit card guidelines|admit card notice|paper analysis|difficulty level|difficulty discussion|history of|priority dispute|biography|song|songs|parody|lyrics|official notification|major changes in .* pattern|marks moderation|moderation policy|normalization formula|is it possible to clear|should you take a drop|drop year debate|coaching vs|online vs offline|better than ncert|how memory works|memory techniques|fast memorization|why does .* float|why is .* constant|bioethics|ethical guidelines|which stream|counseling|josaa|tuition debate|is taking tuition|handwriting tips|presentation tips|answer sheet photocopy|re-evaluation|tie-breaking rules|viva voce tips|sleepiness while studying|pomodoro technique|pomodoro and deep work|why you should stop making .* notes|numberphile|riddles|brain teasers|what is quantum computing|future of biotechnology|why zero divided by zero)\b/i.test(
          combinedText
        );

      const hasExplicitTeachingFormat =
        /\b(lecture|complete lecture|one shot|oneshot|full chapter|chapter explanation|line by line|solved pyqs?|pyq solving|derivation|derivations|numerical problems?|circuit solving|solved problems|mechanisms?|back exercise solutions)\b/i.test(
          title
        ) && !/\b(song|music|reality check|test series review|memory techniques|can you clear|how i prepared|vlog|routine|setup)\b/i.test(title);

      if (isMetaOrAdvisory && !hasExplicitTeachingFormat) {
        return {
          decision: "REVIEW",
          confidence: 0.60,
          confidenceBand: "MEDIUM",
          intent: "EXPLAIN",
          reasonCodes: [...reasonCodes, "AMBIGUOUS_CONTEXT", "INSUFFICIENT_EVIDENCE"],
          humanReason: `Advisory, strategy, educational media or exam policy context (${bestMatch.subject}): requires student verification during active focus sessions.`,
        };
      }

      // Check special case: Bare "Physics Experiment" without chapter, theory, derivation, or class level
      const isBareExperiment = /\b(physics experiment|chemistry experiment|science experiment)\b/i.test(title);
      const hasSpecificCurriculumContext =
        /\b(class 12|class 11|board|derivation|working|theory|practical exam|cbse|ncert|meter bridge|potentiometer|galvanometer|vernier|screw gauge|prism|ydse|lens|titration)\b/i.test(
          combinedText
        );
      if (isBareExperiment && !hasSpecificCurriculumContext && !hasAcademicAction) {
        return {
          decision: "REVIEW",
          confidence: 0.50,
          confidenceBand: "MEDIUM",
          intent: "EXPLAIN",
          reasonCodes: ["AMBIGUOUS_CONTEXT", "INSUFFICIENT_EVIDENCE"],
          humanReason: `Bare experiment title without explicit curriculum topic, apparatus or class level. Held for review.`,
        };
      }

      // Section 19 Multi-Anchor Requirement:
      // High-confidence STUDY requires multiple independent anchors:
      // Anchor 1: Specific Topic or Chapter
      // Anchor 2: Academic Intent / Action OR Exam Relevance OR Trusted Channel
      const hasSpecificTopic = Boolean(bestMatch.topic && bestMatch.topic !== bestMatch.subject);
      const hasExamOrBoard = (bestMatch.examRelevance && bestMatch.examRelevance.length > 0) || positiveSignals.examAnchors.length > 0;
      const hasTeachingAction = hasAcademicAction || (positiveSignals.formats.length > 0) || (positiveSignals.problemSolving.length > 0);

      const anchorCount = (hasSpecificTopic ? 1 : 0) + (hasExamOrBoard ? 1 : 0) + (hasTeachingAction ? 1 : 0) + (isTrustedChannel ? 1 : 0);

      // In strict mode: require at least 2 independent anchors for STUDY
      if (guardMode === "strict" && anchorCount < 2) {
        return {
          decision: "REVIEW",
          confidence: 0.65,
          confidenceBand: "MEDIUM",
          intent: intent === "UNKNOWN" ? "EXPLAIN" : intent,
          reasonCodes: [...reasonCodes, "INSUFFICIENT_EVIDENCE"],
          humanReason: `Academic topic referenced (${bestMatch.chapter}) but lacks sufficient independent anchors (intent, exam, or trusted channel). Held for review in strict guard mode.`,
        };
      }

      reasonCodes.push("TOPIC_MATCH");
      if (bestMatch.chapter) reasonCodes.push("CHAPTER_MATCH");
      if (bestMatch.subject) reasonCodes.push("SUBJECT_MATCH");
      if (hasExamOrBoard) reasonCodes.push("EXAM_MATCH");
      if (isTrustedChannel) reasonCodes.push("TRUSTED_CHANNEL");

      let confidence = bestMatch.matchConfidence;
      if (hasAcademicAction) confidence = Math.min(1.0, confidence + 0.08);
      if (isTrustedChannel) confidence = Math.min(1.0, confidence + 0.05);
      if (positiveSignals.examAnchors.length > 0) confidence = Math.min(1.0, confidence + 0.04);
      if (durationSeconds >= 900) confidence = Math.min(1.0, confidence + 0.03); // >15 min supports lecture intent

      const confidenceBand: ConfidenceBand = confidence >= 0.88 ? "VERY_HIGH" : "HIGH";

      return {
        decision: "STUDY",
        confidence: Number(confidence.toFixed(2)),
        confidenceBand,
        intent: intent === "UNKNOWN" ? (hasTeachingAction ? "TEACH" : "EXPLAIN") : intent,
        reasonCodes,
        humanReason: `Matched ${bestMatch.subject} → ${bestMatch.chapter} → ${bestMatch.topic} with verified academic instruction intent.`,
      };
    }

    // Case E: Moderate Topic Match or Trusted Channel with Academic Signals
    if (bestMatch && bestMatch.matchConfidence >= 0.60 && totalNegativeHits === 0) {
      reasonCodes.push("TOPIC_MATCH");
      if (guardMode === "strict") {
        return {
          decision: "REVIEW",
          confidence: 0.65,
          confidenceBand: "MEDIUM",
          intent: "EXPLAIN",
          reasonCodes: [...reasonCodes, "INSUFFICIENT_EVIDENCE"],
          humanReason: `Moderate academic match for ${bestMatch.subject} (${bestMatch.chapter}). Held for verification in strict mode.`,
        };
      } else {
        return {
          decision: "STUDY",
          confidence: 0.75,
          confidenceBand: "MEDIUM",
          intent: "EXPLAIN",
          reasonCodes,
          humanReason: `Educational content aligned with ${bestMatch.subject} → ${bestMatch.chapter}.`,
        };
      }
    }

    // Case F: Insufficient Evidence -> REVIEW
    // Section 47: If a candidate cannot be classified: REVIEW. Do not invent STUDY, do not invent NON_STUDY.
    return {
      decision: "REVIEW",
      confidence: 0.35,
      confidenceBand: "LOW",
      intent: "UNKNOWN",
      reasonCodes: ["INSUFFICIENT_EVIDENCE"],
      humanReason: "Video lacks conclusive evidence to classify as verified curriculum lecture or definite non-study.",
    };
  }
}
