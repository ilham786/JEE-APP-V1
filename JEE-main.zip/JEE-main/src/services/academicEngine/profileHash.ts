/**
 * FocusForge Academic Profile Hashing Engine
 * Ensures user academic contexts remain isolated in caching layers.
 */

export interface AcademicProfileData {
  exam?: string;
  board?: string;
  classLevel?: string;
  subjects?: string[];
  guardMode?: "strict" | "balanced" | "custom";
  currentTopicMode?: boolean;
  currentStudyTopic?: string;
}

export function computeAcademicProfileHash(profile: AcademicProfileData): string {
  const exam = (profile.exam || "JEE").toLowerCase().trim();
  const board = (profile.board || "CBSE").toLowerCase().trim();
  const classLevel = (profile.classLevel || "Class 12").toLowerCase().trim();
  const subjects = (profile.subjects || ["Physics", "Chemistry", "Mathematics"])
    .map((s) => s.toLowerCase().trim())
    .sort()
    .join(",");
  const mode = (profile.guardMode || "balanced").toLowerCase().trim();
  const topicMode = Boolean(profile.currentTopicMode);
  const currentTopic = topicMode ? (profile.currentStudyTopic || "").toLowerCase().trim() : "";

  const raw = `${exam}|${board}|${classLevel}|${subjects}|${mode}|${topicMode}|${currentTopic}`;

  // Deterministic FNV-1a 32-bit hash converted to hex
  let hash = 0x811c9dc5;
  for (let i = 0; i < raw.length; i++) {
    hash ^= raw.charCodeAt(i);
    hash += (hash << 1) + (hash << 4) + (hash << 7) + (hash << 8) + (hash << 24);
  }
  return (hash >>> 0).toString(16).padStart(8, "0");
}

export function buildClassificationCacheKey(
  videoId: string,
  profileHash: string,
  taxonomyVersion: string,
  classifierVersion: string
): string {
  return `${videoId}:${profileHash}:${taxonomyVersion}:${classifierVersion}`;
}
