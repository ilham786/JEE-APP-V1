import { createClient } from "@supabase/supabase-js";

const SUPABASE_URL = "https://yhcowzmcvlsmcffbqryb.supabase.co";
const SUPABASE_ANON_KEY = "sb_publishable_F20ljth7U20W5cxupHPQiw_btbZuvGk";

const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

async function inspect() {
  console.log("=== Checking study_sessions ===");
  const { data: sessions, error: sessErr } = await supabase
    .from("study_sessions")
    .select("*")
    .order("created_at", { ascending: false })
    .limit(5);

  if (sessErr) {
    console.error("study_sessions error:", sessErr);
  } else {
    console.log("Latest study_sessions count:", sessions.length);
    console.log("Latest study_sessions:", JSON.stringify(sessions, null, 2));
  }

  console.log("\n=== Checking active/paused study_sessions ===");
  const { data: activeSessions, error: actErr } = await supabase
    .from("study_sessions")
    .select("*")
    .in("status", ["active", "paused"])
    .order("created_at", { ascending: false })
    .limit(5);

  if (actErr) {
    console.error("active sessions error:", actErr);
  } else {
    console.log("Active/paused count:", activeSessions.length);
    console.log("Active/paused sessions:", JSON.stringify(activeSessions, null, 2));
  }

  console.log("\n=== Checking extension_state ===");
  const { data: extState, error: extErr } = await supabase
    .from("extension_state")
    .select("*")
    .limit(5);

  if (extErr) {
    console.error("extension_state error:", extErr);
  } else {
    console.log("extension_state count:", extState.length);
    console.log("extension_state:", JSON.stringify(extState, null, 2));
  }
}

inspect().catch(console.error);
