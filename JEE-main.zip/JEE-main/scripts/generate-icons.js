const fs = require("fs");
const path = require("path");

// Valid base64 encoded PNG purple bolt icon placeholder
const pngBase64 = "iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAAOxAAADsQBlSsOGwAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAAAJFSURBVHic7da9TxRRFMDxX4CQEBMRTYyJhYmJjV+JjYmVnQ0WFhZ2drb+ARZWdjba2FnZ2drY2NhYYmJiTGw0sTEhhEgIm+NuvM3Lzs6+3Tf7fnNzcmfPvZl7uTPnvdmdxGQyGZPEaUAHGAGOB66vAzeAb8CHpLEbT3sCvwDmAfcC52uB+/3AbOD648Sxn4w8CdwAjoQuLwG/An9Sxs6JowA3AQfC/xX/L3C2pG+P8eN/LwX+t9g5c+LogzbgDWA/cD5wcgD4FLjeBzwG7gNngZcDx2sL5+tK4HylM+Zz4BDwDHgIXAQ+AheB48D1wPlK1/nC6w3n+8/hfcXznw7ny89xee4v9p9z+19X+q0l+tY4vC/27y/y572+16/G/f1v2L+h900f8Bp4AtwFTgA3AvfbwK2+/Tf58w/6ztsC32/y56fK+vYW/3w/7F8p6dth/Pk+/nwv/H8e/18v5dtr8vg68Bh4BtwArgZ+t4BbwMO+/a1+f60V/t70z1eU8+0o8fnZ4PN5fO5aOd+u4ueVn5/n1t+g59Vl/H4e37+Nn+e5b/xZ/flp/v1821/C++bU/2B2+POx8L6iXW2F9xXteVv9L27e69fC+4r/b2rXyX1/vW98s/88+47s8eeWvw3t8edp/T+8zT/fn7+k/34s/fn+0OvvNf981uuvlPTtqHxf7J4n9u4vcP3vEfv+Yt+xVNK3c/nzhfLnf/Pn+8L/S/n9X/rzv2Xv+4d/vtrv/3j5+XGz/2yZt03/H8e+g/f5+XzLd2x2/R8q69tz/vj98vPlt//u8e/g05K+5Z0f4Qv+B11zL+3Xp1dZAAAAAElEQVQ4y2NgGAWjYBSMglEwCkbBSAMAEGAAAeb6/zYAAAAASUVORK5CYII=";

const iconBuffer = Buffer.from(pngBase64, "base64");

const dirs = [
  path.join(__dirname, "../public/extension"),
  path.join(__dirname, "../public/extension/icons"),
  path.join(__dirname, "../extension"),
  path.join(__dirname, "../extension/icons"),
];

dirs.forEach((dir) => {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }

  fs.writeFileSync(path.join(dir, "icon16.png"), iconBuffer);
  fs.writeFileSync(path.join(dir, "icon48.png"), iconBuffer);
  fs.writeFileSync(path.join(dir, "icon128.png"), iconBuffer);
});

console.log("Successfully generated extension icon PNG assets.");
