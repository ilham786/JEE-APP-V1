import { createClient } from "@supabase/supabase-js";
import { JEE_SYLLABUS_DATA } from "../src/data/jee-syllabus-data";

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || "https://yhcowzmcvlsmcffbqryb.supabase.co";
const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY || "sb_secret_r6Ynh9WdfZLvQnfdeuAjtg_M7Yob0Ut";

const supabaseAdmin = createClient(supabaseUrl, serviceRoleKey, {
  auth: { autoRefreshToken: false, persistSession: false },
});

async function seedAllProgress() {
  console.log("🚀 Starting Supabase Full Progress Seeder...");

  // 1. Create or Find Primary User in auth.users
  const userEmail = "ilham@focusforge.app";
  const userPassword = "Password@123";
  let userId: string;

  const { data: existingUsers, error: listErr } = await supabaseAdmin.auth.admin.listUsers();
  if (listErr) {
    console.error("Error listing users:", listErr);
  }

  const existingUser = existingUsers?.users?.find((u) => u.email === userEmail);

  if (existingUser) {
    userId = existingUser.id;
    console.log(`✅ Found existing user: ${userEmail} (${userId})`);
  } else {
    const { data: newUser, error: createErr } = await supabaseAdmin.auth.admin.createUser({
      email: userEmail,
      password: userPassword,
      email_confirm: true,
      user_metadata: {
        full_name: "ILHAM FAROOQUE",
        username: "ilham_jee",
        target_exam: "IIT-JEE 2026",
      },
    });

    if (createErr || !newUser.user) {
      console.error("Failed to create user in auth.users:", createErr);
      return;
    }
    userId = newUser.user.id;
    console.log(`✅ Created new user in Supabase Auth: ${userEmail} (${userId})`);
  }

  const now = new Date().toISOString();

  // 2. Seed User Profile
  console.log("📦 Seeding User Profile...");
  await supabaseAdmin.from("profiles").upsert({
    id: userId,
    username: "@ilham_jee",
    display_name: "ILHAM FAROOQUE",
    email: userEmail,
    photo_url: `https://api.dicebear.com/7.x/bottts/svg?seed=${userId}`,
    target_exam: "IIT-JEE 2026",
    target_year: "2026",
    target_rank: "AIR < 500",
    class_level: "Class 12 / Dropper",
    daily_goal: "6 Hours Daily",
    onboarding_completed: true,
    theme: "dark",
    bio: "IIT-JEE Main & Advanced aspirant working towards AIR 1.",
    timezone: "Asia/Kolkata",
    country: "India",
    preferences: { defaultSubject: "Physics", autoBlock: true, monkModeDefault: false },
    streak: 12,
    xp: 3450,
    level: 4,
    extension_connected: true,
    browser_name: "Chrome Desktop",
    device_name: "IIT-JEE Workstation",
    notification_settings: { email: true, browser: true, sound: true },
    privacy_settings: { publicProfile: true, showStreak: true },
    statistics: { totalFocusMinutes: 1420, completedSessions: 18, mistakesLogged: 12, formulasBookmarked: 35 },
    joined_at: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
    last_login_at: now,
    updated_at: now,
  });

  await supabaseAdmin.from("usernames").upsert({
    username: "ilham_jee",
    user_id: userId,
    claimed_at: now,
  });

  // 3. Seed Study Sessions (Last 14 sessions across subjects)
  console.log("📦 Seeding Study Sessions & Daily Stats...");
  const subjects = ["Physics", "Chemistry", "Maths"];
  const chapters = {
    Physics: ["Electrostatics", "Rotational Motion", "Current Electricity", "Optics", "Thermodynamics"],
    Chemistry: ["Chemical Bonding", "Coordination Compounds", "Organic Halogens", "Electrochemistry", "Equilibrium"],
    Maths: ["Integral Calculus", "Matrices and Determinants", "Trigonometry", "Probability", "Vector Algebra"],
  };

  const sampleSessions = [];
  const dailyTotals: Record<string, { minutes: number; count: number; subjects: string[] }> = {};

  for (let i = 13; i >= 0; i--) {
    const sessionDate = new Date();
    sessionDate.setDate(sessionDate.getDate() - i);
    const dateKey = sessionDate.toISOString().split("T")[0];

    const subj = subjects[i % 3] as "Physics" | "Chemistry" | "Maths";
    const chapList = chapters[subj];
    const chap = chapList[i % chapList.length];
    const duration = 45 + (i % 4) * 15; // 45 to 90 mins
    const focusScore = 85 + (i % 15);
    const xpEarned = duration * 3 + (focusScore > 90 ? 50 : 0);

    const sessionId = `sess_${Date.now() - i * 86400000}_${i}`;
    const startTime = new Date(sessionDate.setHours(10 + (i % 8), 0, 0, 0)).toISOString();
    const endTime = new Date(sessionDate.getTime() + duration * 60000).toISOString();

    sampleSessions.push({
      id: sessionId,
      user_id: userId,
      subject: subj,
      chapter: chap,
      subchapter: "Core PYQs & Theory",
      task_type: i % 2 === 0 ? "PYQ" : "Practice",
      mode: duration >= 90 ? "DeepWork" : "Pomodoro",
      start_time: startTime,
      end_time: endTime,
      total_duration_minutes: duration,
      date: dateKey,
      notes: `Solved ${Math.round(duration / 3)} JEE Advanced questions with high accuracy.`,
      productivity_rating: 4 + (i % 2),
      difficulty: i % 3 === 0 ? "JEE Advanced" : "Hard",
      mood: "Focused",
      focus_score: focusScore,
      was_goal_completed: true,
      completed: true,
      xp_earned: xpEarned,
      created_at: startTime,
      updated_at: endTime,
    });

    if (!dailyTotals[dateKey]) {
      dailyTotals[dateKey] = { minutes: 0, count: 0, subjects: [] };
    }
    dailyTotals[dateKey].minutes += duration;
    dailyTotals[dateKey].count += 1;
    if (!dailyTotals[dateKey].subjects.includes(subj)) {
      dailyTotals[dateKey].subjects.push(subj);
    }
  }

  await supabaseAdmin.from("study_sessions").upsert(sampleSessions);

  // 4. Seed Daily Stats & Consistency Grid
  console.log("📦 Seeding Consistency Grid & Daily Stats...");
  const consistencyRows = [];
  const dailyStatsRows = [];

  for (const [dateKey, d] of Object.entries(dailyTotals)) {
    const hours = parseFloat((d.minutes / 60).toFixed(1));
    const intensity = hours >= 4 ? 4 : hours >= 2 ? 3 : hours >= 1 ? 2 : 1;

    dailyStatsRows.push({
      id: `${userId}_${dateKey}`,
      user_id: userId,
      date: dateKey,
      total_minutes: d.minutes,
      sessions_count: d.count,
      last_updated: now,
    });

    consistencyRows.push({
      id: `${userId}_${dateKey}`,
      user_id: userId,
      date: dateKey,
      study_hours: hours,
      completed_sessions: d.count,
      subjects: d.subjects,
      intensity_level: intensity,
      focus_score: 92,
      created_at: now,
      updated_at: now,
    });
  }

  await supabaseAdmin.from("daily_stats").upsert(dailyStatsRows);
  await supabaseAdmin.from("consistency_grid").upsert(consistencyRows);

  // 5. Seed Mistake Journal & Revision Plans
  console.log("📦 Seeding Mistake Journal & Spaced Revision Schedules...");
  const sampleMistakes = [
    {
      id: `m-rot-1`,
      user_id: userId,
      subject: "Physics",
      chapter: "Rotational Motion",
      subchapter: "Moment of Inertia",
      question_reference: "JEE Adv 2023 Paper 1 Q.14",
      error_category: "Conceptual",
      description: "Forgot to apply parallel axis theorem about the center of mass before shifting to new axis.",
      correct_solution: "I_new = I_cm + M*d^2. Always locate the true COM axis first.",
      my_wrong_attempt: "Directly added M*d^2 to I_edge without passing through COM.",
      tags: ["Rotational Mechanics", "Parallel Axis", "High Priority"],
      difficulty: "Hard",
      reviewed_count: 2,
      next_review_date: new Date(Date.now() + 2 * 86400000).toISOString().split("T")[0],
      completed: false,
    },
    {
      id: `m-calc-2`,
      user_id: userId,
      subject: "Maths",
      chapter: "Integral Calculus",
      subchapter: "Definite Integrals",
      question_reference: "JEE Main 2024 Shift 2 Q.21",
      error_category: "Calculation",
      description: "Sign error in integration by parts for e^x * sin(x) during substitution.",
      correct_solution: "Use King's property f(a+b-x) first to eliminate numerator symmetry.",
      my_wrong_attempt: "Expanded into 4 integrals, resulting in sign confusion at boundary.",
      tags: ["Definite Integrals", "King Property", "Sign Error"],
      difficulty: "Medium",
      reviewed_count: 3,
      next_review_date: new Date(Date.now() + 5 * 86400000).toISOString().split("T")[0],
      completed: true,
    },
    {
      id: `m-chem-3`,
      user_id: userId,
      subject: "Chemistry",
      chapter: "Coordination Compounds",
      subchapter: "Crystal Field Theory",
      question_reference: "JEE Adv 2022 Paper 2 Q.8",
      error_category: "Conceptual",
      description: "Misidentified strong field vs weak field ligand splitting for d6 octahedral complex.",
      correct_solution: "CN- and CO cause low spin t2g6 eg0 pairing with magnetic moment = 0 BM.",
      my_wrong_attempt: "Assumed high spin due to presence of H2O in outer sphere.",
      tags: ["CFT", "Ligand Field", "Magnetic Moment"],
      difficulty: "Hard",
      reviewed_count: 1,
      next_review_date: new Date(Date.now() + 1 * 86400000).toISOString().split("T")[0],
      completed: false,
    },
    {
      id: `m-elec-4`,
      user_id: userId,
      subject: "Physics",
      chapter: "Electrostatics",
      subchapter: "Gauss Law & Conductors",
      question_reference: "JEE Main 2025 Jan Session",
      error_category: "Conceptual",
      description: "Induced charges on concentric spherical conducting shells when inner shell is grounded.",
      correct_solution: "Set potential of inner grounded shell V = 0, solve for Q_inner = -Q * (R1/R2).",
      my_wrong_attempt: "Set electric field = 0 on inner shell instead of potential = 0.",
      tags: ["Conductors", "Earthing", "Potential"],
      difficulty: "Hard",
      reviewed_count: 2,
      next_review_date: new Date(Date.now() + 3 * 86400000).toISOString().split("T")[0],
      completed: false,
    },
  ];

  await supabaseAdmin.from("mistake_journal").upsert(sampleMistakes);

  const sampleRevisions = sampleMistakes.map((m, idx) => ({
    id: `rev_${m.id}`,
    user_id: userId,
    subject: m.subject,
    chapter: m.chapter,
    subchapter: m.subchapter,
    scheduled_date: m.next_review_date,
    interval_days: (idx + 1) * 3,
    stage: idx + 1,
    status: m.completed ? "completed" : "pending",
    notes: m.description,
    created_at: now,
    updated_at: now,
  }));

  await supabaseAdmin.from("revision_plans").upsert(sampleRevisions);

  // 6. Seed JEE Progress for all Syllabus Chapters
  console.log("📦 Seeding All JEE Syllabus Chapters Progress...");
  const jeeProgressRows: Record<string, unknown>[] = [];

  Object.entries(JEE_SYLLABUS_DATA).forEach(([subject, chaptersList]) => {
    chaptersList.forEach((chap, idx) => {
      // Give initial realistic progress for top chapters
      const isTopChapter = idx < 6;
      const compPct = isTopChapter ? Math.min(100, 45 + (idx * 11)) : 0;
      const pyqsSolved = isTopChapter ? Math.round((compPct / 100) * chap.pyqsTotal) : 0;

      jeeProgressRows.push({
        id: `${userId}_${chap.id}`,
        user_id: userId,
        subject: subject === "Maths" ? "Mathematics" : subject,
        chapter_id: chap.id,
        chapter_name: chap.name,
        completed: compPct >= 100,
        progress_percent: compPct,
        solved_pyq_count: pyqsSolved,
        total_pyq_count: chap.pyqsTotal || 50,
        bookmarked: idx % 4 === 0,
        notes: `Weightage: ${chap.trendWeightage}% • Priority: ${chap.weightageTier}`,
        subchapters: chap.subtopics || [],
        updated_at: now,
      });
    });
  });

  if (jeeProgressRows.length > 0) {
    await supabaseAdmin.from("jee_progress").upsert(jeeProgressRows);
    console.log(`✅ Seeded ${jeeProgressRows.length} JEE chapters into Supabase jee_progress!`);
  }

  // 7. Seed Formula Bank
  console.log("📦 Seeding Essential Formula Sheets...");
  const formulaRows: Record<string, unknown>[] = [];

  Object.entries(JEE_SYLLABUS_DATA).forEach(([subject, chaptersList]) => {
    chaptersList.forEach((chap) => {
      if (chap.formulas && Array.isArray(chap.formulas)) {
        chap.formulas.forEach((f, fIdx) => {
          formulaRows.push({
            id: `f_${chap.id}_${fIdx}`,
            user_id: userId,
            subject,
            chapter: chap.name,
            formula_name: f.name,
            formula_expression: f.expression,
            variables_defined: f.description,
            is_bookmarked: fIdx === 0,
            created_at: now,
            updated_at: now,
          });
        });
      }
    });
  });

  if (formulaRows.length > 0) {
    // Upsert first 60 core formulas
    await supabaseAdmin.from("formula_sheets").upsert(formulaRows.slice(0, 60));
    console.log(`✅ Seeded ${Math.min(60, formulaRows.length)} formulas into Supabase formula_sheets!`);
  }

  // 8. Seed Blocked Websites
  console.log("📦 Seeding Blocked Sites...");
  const defaultBlocked = ["youtube.com", "instagram.com", "reddit.com", "facebook.com", "twitter.com", "discord.com"];
  const blockedRows = defaultBlocked.map((domain) => ({
    id: `${userId}_${domain}`,
    user_id: userId,
    domain,
    category: "Social Media / Video",
    is_active: true,
    created_at: now,
  }));

  await supabaseAdmin.from("blocked_sites").upsert(blockedRows);

  console.log("====================================================================");
  console.log("🎉 ALL USER PROGRESS HAS BEEN SUCCESSFULLY SAVED TO SUPABASE!");
  console.log(`📧 User Email:    ${userEmail}`);
  console.log(`🔑 User Password: ${userPassword}`);
  console.log(`👤 User Name:     ILHAM FAROOQUE (@ilham_jee)`);
  console.log(`🏆 XP:            3,450 XP (Level 4)`);
  console.log(`🔥 Streak:        12-Day Streak`);
  console.log(`📚 Chapters:      ${jeeProgressRows.length} JEE Syllabus Chapters Seeded`);
  console.log(`📝 Mistakes:      ${sampleMistakes.length} Logged Mistakes Seeded`);
  console.log(`⏱️ Sessions:      ${sampleSessions.length} Focus Sessions Seeded`);
  console.log("====================================================================");
}

seedAllProgress().catch((err) => {
  console.error("Seeder error:", err);
  process.exit(1);
});
