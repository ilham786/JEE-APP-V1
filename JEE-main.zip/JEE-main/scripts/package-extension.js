const fs = require("fs");
const path = require("path");
const { execSync } = require("child_process");

function packageExtension() {
  console.log("=========================================");
  console.log("⚡ FocusForge Chrome Extension Build & Validation");
  console.log("=========================================");

  const extDir = path.resolve(__dirname, "../public/extension");

  // 1. Audit Required Files
  const requiredFiles = [
    "manifest.json",
    "background.js",
    "content.js",
    "youtube-study-controller.js",
    "supabase.js",
    "popup/popup.html",
    "popup/popup.js",
    "block-page/index.html",
    "pause-guard.html",
    "pause-guard.js",
    "youtube-verify.html",
    "youtube-verify.js",
    "icon16.png",
    "icon48.png",
    "icon128.png",
  ];

  console.log("🔍 Auditing required extension files...");
  for (const relPath of requiredFiles) {
    const fullPath = path.join(extDir, relPath);
    if (!fs.existsSync(fullPath)) {
      throw new Error(`[BUILD FAILURE] Missing required extension file: ${relPath} at ${fullPath}`);
    }
    console.log(`  ✓ Verified: ${relPath}`);
  }

  // 2. Validate Manifest JSON & MV3 schema
  console.log("📄 Validating manifest.json schema...");
  const manifestRaw = fs.readFileSync(path.join(extDir, "manifest.json"), "utf8");
  let manifest;
  try {
    manifest = JSON.parse(manifestRaw);
  } catch (err) {
    throw new Error(`[BUILD FAILURE] manifest.json contains invalid JSON syntax: ${err.message}`);
  }

  if (manifest.manifest_version !== 3) {
    throw new Error(`[BUILD FAILURE] manifest_version must be 3, found: ${manifest.manifest_version}`);
  }
  if (!manifest.name || !manifest.version) {
    throw new Error("[BUILD FAILURE] manifest.json missing required 'name' or 'version' fields.");
  }
  console.log(`  ✓ Manifest V3 Validated — Name: "${manifest.name}", Version: ${manifest.version}`);

  const outputZipPath = path.resolve(__dirname, `../public/FocusForge-Extension-v${manifest.version}.zip`);
  const fallbackZipPath = path.resolve(__dirname, "../public/FocusForge-Extension.zip");

  // 3. Clean previous zip archives if any
  const legacyZips = [
    path.resolve(__dirname, "../public/FocusForge-Extension-v1.0.4.zip"),
    path.resolve(__dirname, "../public/FocusForge-Extension-v1.0.5.zip"),
    path.resolve(__dirname, "../public/FocusForge-Extension-v1.0.6.zip"),
    path.resolve(__dirname, "../public/FocusForge-Extension-v1.0.7.zip"),
    path.resolve(__dirname, "../public/FocusForge-Extension-v1.0.8.zip"),
    path.resolve(__dirname, "../public/FocusForge-Extension-v1.0.9.zip"),
    path.resolve(__dirname, "../public/FocusForge-Extension-v1.1.0.zip"),
  ];
  for (const zipFile of legacyZips) {
    if (fs.existsSync(zipFile)) fs.unlinkSync(zipFile);
  }
  if (fs.existsSync(outputZipPath)) fs.unlinkSync(outputZipPath);
  if (fs.existsSync(fallbackZipPath)) fs.unlinkSync(fallbackZipPath);

  // 4. Generate Binary PKZip Archive with normalized forward-slash paths
  console.log("📦 Compressing extension files into binary PKZip archive...");
  let packaged = false;

  // Primary: Python zipfile (ensures forward-slash relative paths across all operating systems)
  const tempPy = path.join(__dirname, "_package_temp.py");
  try {
    const pyCode = [
      "import zipfile, os",
      `ext_dir = r"${extDir}"`,
      `output_zip = r"${outputZipPath}"`,
      "with zipfile.ZipFile(output_zip, 'w', zipfile.ZIP_DEFLATED) as zf:",
      "    for root, dirs, files in os.walk(ext_dir):",
      "        for file in files:",
      "            full_path = os.path.join(root, file)",
      "            rel_path = os.path.relpath(full_path, ext_dir).replace('\\\\', '/')",
      "            zf.write(full_path, rel_path)",
    ].join("\n");

    fs.writeFileSync(tempPy, pyCode, "utf8");
    execSync(`python "${tempPy}"`, { stdio: "inherit" });
    packaged = true;
    console.log("  ✓ Created archive via Python zip engine (forward-slash normalized).");
  } catch (pyErr) {
    console.warn("  ℹ Python zip engine unavailable, attempting platform fallback:", pyErr.message);
  } finally {
    if (fs.existsSync(tempPy)) fs.unlinkSync(tempPy);
  }

  // Fallback: platform-native tools
  if (!packaged) {
    if (process.platform === "win32") {
      const psCmd = `powershell -NoProfile -Command "Compress-Archive -Path '${extDir}\\*' -DestinationPath '${outputZipPath}' -Force"`;
      execSync(psCmd, { stdio: "inherit" });
    } else {
      const zipCmd = `cd "${extDir}" && zip -r "${outputZipPath}" .`;
      execSync(zipCmd, { stdio: "inherit" });
    }
  }

  // Copy to unversioned fallback path
  fs.copyFileSync(outputZipPath, fallbackZipPath);

  // 5. Validate Generated ZIP Archive Integrity
  console.log("⚙️ Validating generated PKZip archive integrity...");
  const zipStats = fs.statSync(outputZipPath);
  const sizeKB = (zipStats.size / 1024).toFixed(2);

  if (zipStats.size === 0) {
    throw new Error("[BUILD FAILURE] Generated ZIP archive is 0 KB.");
  }

  // Check Magic Bytes: PKZip header must be 0x50 0x4B 0x03 0x04 ("PK\x03\x04")
  const buffer = fs.readFileSync(outputZipPath);
  const isPkZip = buffer[0] === 0x50 && buffer[1] === 0x4b && buffer[2] === 0x03 && buffer[3] === 0x04;

  if (!isPkZip) {
    throw new Error("[BUILD FAILURE] Generated file does not contain valid PKZip binary headers.");
  }

  console.log(`  ✓ ZIP Archive Integrity Confirmed! Size: ${sizeKB} KB`);
  console.log(`  ✓ Magic Bytes Verified: 0x50 0x4B 0x03 0x04 (PKZip format)`);
  console.log("=========================================");
  console.log(`✅ Extension Package Created Successfully: ${outputZipPath}`);
  console.log(`✅ Fallback Extension Package Updated: ${fallbackZipPath}`);
  console.log("=========================================");
}

try {
  packageExtension();
} catch (err) {
  console.error("❌ Extension Packaging Failed:", err.message);
  process.exit(1);
}
