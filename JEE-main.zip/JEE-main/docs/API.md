# FocusForge — API & Data Access Service Reference

This document provides complete documentation for the HTTP REST API endpoints and client-side Cloud Firestore Data Access Service layer (`src/services/`) in **FocusForge**.

---

## 📋 Table of Contents

1. [Overview](#-overview)
2. [Next.js API Routes](#-nextjs-api-routes)
3. [Express Auth & Static Host Server APIs (`server.js`)](#-express-auth--static-host-server-apis-serverjs)
4. [Cloud Firestore Data Access Services (`src/services/`)](#-cloud-firestore-data-access-services-srcservices)
   - [Auth & User Management (`authService.ts`, `userService.ts`)](#1-auth--user-management)
   - [Study Sessions & Timers (`studySessionService.ts`)](#2-study-sessions--timers)
   - [Mistake Journal & Spaced Repetition (`mistakeJournalService.ts`, `revisionService.ts`)](#3-mistake-journal--spaced-repetition)
   - [Distraction Shield & Extension Sync (`blockerService.ts`, `extensionService.ts`)](#4-distraction-shield--extension-sync)
   - [JEE Syllabus & Progress Tracking (`jeeService.ts`)](#5-jee-syllabus--progress-tracking)
   - [Analytics & Consistency Heatmap (`analyticsService.ts`, `consistencyGridService.ts`)](#6-analytics--consistency-heatmap)
   - [Notes & Formulas (`notesService.ts`, `formulaService.ts`)](#7-notes--formulas)
5. [Error Handling & Status Codes](#-error-handling--status-codes)

---

## 🚀 Overview

FocusForge employs a hybrid API architecture:
1. **Next.js Serverless API Routes**: Handles dynamic asset packaging and file downloads (`src/app/api/`).
2. **Standalone Express Auth Server**: Serves mock authentication endpoints and standalone static HTML hosting (`server.js`).
3. **Firestore Client Data Access Services**: 27 modular TypeScript service facades in `src/services/` that encapsulate all real-time Cloud Firestore reads, writes, transactions, and event listeners.

---

## 🌐 Next.js API Routes

### 1. Download Companion Chrome Extension
Serves the generated `.zip` archive of the FocusForge Companion Chrome Extension.

* **Endpoint**: `GET /api/download-extension`
* **File Source**: `public/FocusForge-Extension-v1.2.0.zip`
* **Response Headers**:
  * `Content-Type: application/zip`
  * `Content-Disposition: attachment; filename="FocusForge-Extension-v1.2.0.zip"`
* **Response Status Codes**:
  * `200 OK`: File stream download.
  * `404 Not Found`: Extension build zip archive missing. Suggests running `npm run package:extension`.
  * `500 Internal Server Error`: Read error.

---

## 🖥 Express Auth & Static Host Server APIs (`server.js`)

Executed when running `npm run server` (runs on `PORT 3001` by default).

### 1. Health Check Endpoint
* **Endpoint**: `GET /api/health`
* **Response Body**:
```json
{
  "status": "ok",
  "service": "FocusForge Login Auth Service",
  "timestamp": "2026-07-31T14:11:37.000Z",
  "uptime": 124.5
}
```

### 2. User Authentication Endpoint
* **Endpoint**: `POST /api/login`
* **Request Body**:
```json
{
  "email": "student@iitjee.edu",
  "password": "SecretPassword123",
  "rememberMe": true
}
```
* **Response Body (200 OK)**:
```json
{
  "success": true,
  "message": "Authentication successful. Redirecting to FocusForge Workspace...",
  "user": {
    "email": "student@iitjee.edu",
    "name": "student",
    "role": "IIT-JEE Aspirant",
    "targetYear": "2026"
  },
  "token": "ff_token_1785507097000_a8z9b",
  "redirectUrl": "/dashboard"
}
```

### 3. Guest Authentication Endpoint
* **Endpoint**: `POST /api/guest`
* **Response Body (200 OK)**:
```json
{
  "success": true,
  "message": "Guest session created. Welcome to FocusForge Workspace!",
  "user": {
    "name": "Guest Aspirant",
    "role": "IIT-JEE Aspirant (Guest)",
    "isGuest": true
  },
  "token": "ff_guest_1785507097000",
  "redirectUrl": "/dashboard"
}
```

---

## 🗄️ Cloud Firestore Data Access Services (`src/services/`)

All direct database reads, writes, and real-time listeners are encapsulated in strongly-typed TypeScript services:

### 1. Auth & User Management

#### `userService.ts`
* `getUserProfile(userId: string): Promise<UserProfile | null>`: Fetches user document from `users/{userId}`.
* `updateUserProfile(userId: string, data: Partial<UserProfile>): Promise<void>`: Updates profile fields.
* `addXP(userId: string, xpAmount: number): Promise<void>`: Increments user XP and handles level progression.
* `updateStreak(userId: string): Promise<number>`: Calculates and increments daily study streak.

#### `authService.ts`
* `loginWithEmail(email: string, pass: string)`: Authenticates user via Firebase Auth.
* `registerWithEmail(email: string, pass: string, name: string)`: Registers new user and initializes `users/{userId}`.
* `logout()`: Clears active Auth session.

---

### 2. Study Sessions & Timers

#### `studySessionService.ts`
* `saveStudySession(session: StudySessionData): Promise<string>`: Logs completed focus timer session to `studySessions` collection, updates subject analytics, and awards XP.
* `getActiveFocusSession(userId: string): Promise<ActiveFocusSession | null>`: Fetches active timer state.
* `updateActiveFocusSession(userId: string, session: Partial<ActiveFocusSession>): Promise<void>`: Real-time update of elapsed seconds and Monk Mode status.

---

### 3. Mistake Journal & Spaced Repetition

#### `mistakeJournalService.ts`
* `createMistake(userId: string, mistake: Omit<MistakeItem, "id">): Promise<string>`: Adds mistake entry, tags weak topics, and sets initial SuperMemo-2 interval date.
* `getUserMistakes(userId: string): Promise<MistakeItem[]>`: Fetches mistakes for current user.
* `updateMistake(mistakeId: string, updates: Partial<MistakeItem>): Promise<void>`: Updates mistake details.
* `deleteMistake(mistakeId: string): Promise<void>`: Removes mistake entry.

#### `revisionService.ts`
* `getDueRevisions(userId: string): Promise<MistakeItem[]>`: Queries mistakes where `nextReviewDate <= today`.
* `executeRevision(mistakeId: string, qualityRating: number): Promise<void>`: Advances SuperMemo-2 spaced repetition cycle, updates interval (`1 -> 3 -> 7 -> 15 -> 30 days`), and reschedules next review date.

---

### 4. Distraction Shield & Extension Sync

#### `blockerService.ts`
* `getBlockedSites(userId: string): Promise<BlockedSitesDoc | null>`: Retrieves `blockedSites/{userId}` document.
* `updateBlocklist(userId: string, domains: string[]): Promise<void>`: Updates blacklisted domain list.
* `toggleExamLock(userId: string, active: boolean): Promise<void>`: Enables/disables unbypassable Exam Mode Lockout.

#### `extensionService.ts`
* `getExtensionState(userId: string): Promise<ExtensionStateDoc | null>`: Fetches status of Companion Chrome Extension.
* `updateExtensionState(userId: string, updates: Partial<ExtensionStateDoc>): Promise<void>`: Updates extension heartbeats and active state.
* `subscribeExtensionState(userId: string, callback: Function): Unsubscribe`: Attaches real-time `onSnapshot` listener to `extensionState/{userId}`.

---

### 5. JEE Syllabus & Progress Tracking

#### `jeeService.ts`
* `getJEETracker(userId: string): Promise<JEETrackerDoc | null>`: Retrieves overall completion percentage, solved PYQ counts, and completed chapter IDs from `jeeTracker/{userId}`.
* `markChapterComplete(userId: string, chapterId: string): Promise<void>`: Recalculates subject and overall completion stats.
* `updatePYQStats(userId: string, subject: string, count: number): Promise<void>`: Increments solved Past Year Question totals.

---

### 6. Analytics & Consistency Heatmap

#### `analyticsService.ts`
* `calculateStudyTrend(sessionHistory, timeframe)`: Calculates daily/monthly aggregated study hours over 7D, 30D, 90D, or 1Y timeframes using local timezone dates.
* `calculateSubjectBreakdown(sessionHistory)`: Computes exact Physics %, Chemistry %, and Maths % study time allocation.
* `calculateAnalyticsMetrics(sessionHistory, mistakes, syllabus, timeframe)`: Returns dynamic metrics including consistency score, strongest/weakest subject, projected completion days, and error classification breakdown.

#### `consistencyGridService.ts`
* `getHeatmapLevel(hours: number)`: Determines cube color intensity (0=0h, 1=0-1h, 2=1-2h, 3=2-4h, 4=4-6h, 5=6h+).
* `generateGridRecords(sessionHistory, rangeDays, dailyTargetHours)`: Parses completed session history into contiguous daily contribution records.
* `calculateStreaks(records)`: Calculates Daily Streak, Longest Streak, Weekly Sessions, Monthly Sessions, and Missed Days.
* `generateMonthlyInsights(records, monthlyTarget)`: Generates intelligent insights including total hours, sessions count, top subject, best day, and average focus.

---

### 7. Notes & Formulas

#### `notesService.ts`
* `getNotes(userId: string): Promise<NoteItem[]>`: Fetches user notes from `notes` collection.
* `saveNote(userId: string, note: Partial<NoteItem>): Promise<string>`: Creates or updates Markdown note.

#### `formulaService.ts`
* `getBookmarkedFormulas(userId: string): Promise<FormulaBookmark[]>`: Fetches formula bookmarks.
* `toggleFormulaBookmark(userId: string, formula: FormulaBookmark): Promise<void>`: Bookmarks or unbookmarks formula reference.

---

## ⚠️ Error Handling & Status Codes

All service functions wrap Firestore operations in `try-catch` blocks and throw standardized error objects:

| Error Code | Meaning | Recovery Strategy |
| :--- | :--- | :--- |
| `auth/user-not-found` | User ID missing or unauthenticated | Prompt user to log in or create guest session |
| `permission-denied` | Firestore security rule violation | Verify user ownership of target document ID |
| `unavailable` | Client is offline | Writes are saved to IndexedDB and synced upon reconnect |
| `failed-precondition` | Missing Firestore composite index | Create required index link generated in browser console |
