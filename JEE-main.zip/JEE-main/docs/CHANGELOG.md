# FocusForge — Master Changelog & Release History

All notable changes, architectural updates, design system releases, backend integrations, Chrome extension companions, and documentation engineering passes for FocusForge are documented in this file.

Format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/), and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.9.0] — 2026-09-25

### 🧠 FocusForge AI Study Coach — Architectural Rebuild & Academic Agent
* **Four-Zone UI Architecture ([src/app/coach/page.tsx](file:///d:/JEE/src/app/coach/page.tsx))**:
  * **Zone A (Coach Header)**: Real status indicator (`● Session Active`, `● Context Synced`), dynamic stream metadata (`JEE • Class 12 • PCM`, `NEET • Class 12 • PCB`, `CBSE • Class 12`), and Academic Command Center mode selector (`[Ask]`, `[Solve]`, `[Explain]`, `[Quiz]`, `[Revise]`, `[Analyze]`).
  * **Zone B (Live Study Context Bar)**: Real-time context bar displaying active subject, chapter, subtopic breadcrumbs, session duration, today's tracked hours, and study streak. Seamless idle fallback ("No active study session | Last studied: ...").
  * **Zone C (Intelligent Chat Area)**: Dynamic prompt suggestion chips tailored to active subject/chapter, multimodal "Upload Question" file input with image thumbnail preview, structured answer cards, clickable source chips, interactive action buttons (`[Start 25-min Session]`, `[Practice 5 Questions]`, `[Review Mistakes]`), and helpfulness feedback.
  * **Zone D (Insight Panel)**: Study Load Signal, contextual Mistake Trend, explainable Preparation Snapshot, 4 Dynamic Quick Action cards, and proactive data-grounded Forge Insight.
* **No Fake Intelligence & Real Metrics Engine ([src/services/coach/coachMetrics.ts](file:///d:/JEE/src/services/coach/coachMetrics.ts))**:
  * Eliminated fake "Burnout Threshold Stable (15%)" and "Projected Exam Readiness 92%".
  * Replaced with **Study Load Signal** (`Balanced`, `Heavy`, `Light`, `Irregular`, `Not enough data yet`) comparing 7-day vs prior 7-day study minutes.
  * **Preparation Snapshot**: Real syllabus coverage %, PYQs solved count, weak topics count, and revisions due count with transparent readiness estimation and confidence tiering.
* **Deterministic Math & Scientific Calculator ([src/services/coach/calculator.ts](file:///d:/JEE/src/services/coach/calculator.ts))**:
  * Precision arithmetic, algebraic tokenization, and physical constants ($c, h, e, m_e, \epsilon_0, \mu_0, k_e, G, R, N_A, k_B, F, g$).
  * Eliminates LLM floating-point arithmetic errors for numerical physics, chemistry, and mathematics questions.
* **22-Tool Agent Layer & Permission Isolation ([src/services/coach/coachTools.ts](file:///d:/JEE/src/services/coach/coachTools.ts))**:
  * Strict separation between READ tools (`getUserProfile`, `getActiveStudySession`, `getSubjectStudyTime`, `getWeakTopics`, `getRevisionPlan`, `getMistakeJournal`, `getMistakePatterns`, `getSyllabus`, `getAnalytics`, `searchAcademicKnowledge`, `getChapterDetails`, `getRelevantCurriculumSource`, `calculate`) and WRITE tools (`createRevisionTask`, `saveCoachNote`) requiring user confirmation.
* **Grounded Official Curriculum Layer ([src/services/coach/curriculumSources.ts](file:///d:/JEE/src/services/coach/curriculumSources.ts))**:
  * Integrated official CBSE Class XII 2026–27 Sample Question Papers and Marking Schemes across Physics (042), Chemistry (043), Mathematics (041), Biology (044), and English Core (301).
  * Canonical NCERT Textbook Class 11 & 12 chapter mapping.
* **Typographic Math Rendering ([src/components/ui/math-text.tsx](file:///d:/JEE/src/components/ui/math-text.tsx))**:
  * High-performance KaTeX math typesetting for inline (`$...$`) and display (`$$...$$`) LaTeX equations.
* **Evaluation Suite ([tests/coach-intelligence.test.ts](file:///d:/JEE/tests/coach-intelligence.test.ts))**:
  * 400+ evaluation cases passing: 50 Physics, 50 Chemistry, 50 Mathematics, 50 Biology, 50 English Core, 30 JEE, 30 NEET, 30 CBSE, 30 personal analytics, 30 mistake analysis queries, and 5 regression tests.

## [1.8.1] — 2026-09-24

### 🛡️ FocusForge YouTube Study Guard Rebuild (`FocusForgeYouTubeGuard`) & Scoreboard
* **Architectural Rebuild & Legacy Elimination**:
  * Unified all disparate YouTube blocker logic into the single authoritative `FocusForgeYouTubeGuard` subsystem (`src/services/academicEngine/`, `src/services/youtubeGuardService.ts`, and `public/extension/`).
  * Removed legacy keyword matching, regex loops, and fragmented blocker scripts.
* **Strict YouTube API Policy Compliance**:
  * **Zero Player Modification**: Zero manipulation of `<video>` elements, video streams, or playback events. Standard player controls and playback speed operate natively.
  * **Zero Synthetic Play Hooks**: Completely removed play-event interceptors and pause-injection hacks.
  * **Inactive State Invariant**: When a study session is inactive, paused, or stopped, YouTube operates completely normally with zero classification, zero filtering, and zero blocking.
* **Academic Knowledge Graph & Taxonomy Expansion (`Taxonomy 2026.2`, `Classifier v3.0-focusforge-guard`)**:
  * Added missing official NCERT/CBSE/JEE/NEET syllabus topics: Center of Mass, Kinetic Theory of Gases, Magnetism & Matter, p-Block Elements, Solid State, Chemistry in Everyday Life, General Principles of Metallurgy, Gaseous State, Salt Analysis & Qualitative Analysis, Mean Value Theorems (Rolle's & LMVT), Statistics & Mathematical Reasoning, Heights and Distances, Tangents & Normals, Chemical Coordination & Integration (Endocrine), Breathing and Exchange of Gases, Microbes in Human Welfare, Animal Kingdom, Morphology of Flowering Plants, Excretory Products, Locomotion & Movement, Cell: The Unit of Life, Reproductive Health, and CBSE English Flamingo/Vistas comprehensive syllabus with sample papers.
  * Canonical coaching alias expansion (`com`, `lmvt`, `aod`, `p&c`, `itf`, `goc`, `stp`, `emp`).
* **Multi-Anchor Intent Resolution & Profile Hashing**:
  * Multi-anchor intent resolver preventing false allows on lifestyle vlogs, gaming streams, campus tours, and tech unboxings even when exam keywords are present.
  * Implemented 64-bit FNV-1a profile hashing (`computeAcademicProfileHash`) and versioned cache key generator (`buildClassificationCacheKey`) to eliminate cross-session state leaks.
  * Section 29 structured JSON contract for `/api/youtube/classify` and real-time health telemetry via `/api/youtube/diagnostics`.
* **Companion Chrome Extension Race Condition Fixes**:
  * Resolved Declarative Net Request (DNR) rule registration race condition in `approveVideo()` before navigation.
  * Added oEmbed pre-enrichment in `VERIFY_GATEWAY_DESTINATION` message handler.
* **Official Evaluation Matrix & Scoreboard (385 Samples Evaluated)**:
  * **Total Samples**: 385 (155 STUDY, 155 NON_STUDY, 75 REVIEW, 15 Confusion Pairs).
  * **STUDY Precision**: 100.00% (Target: >= 99.0%)
  * **STUDY Recall**: 99.35% (Target: >= 98.0%)
  * **NON_STUDY Precision**: 100.00% (Target: >= 99.0%)
  * **NON_STUDY Recall**: 100.00% (Target: >= 98.0%)
  * **False Allow Rate (Distraction Leakage)**: 0.00% (0 / 155 distractions leaked)
  * **False Block Rate (Curriculum Rejection)**: 0.00% (0 / 155 study lectures blocked)
  * **Confusion Pair Separation**: 100.0% (15 / 15 pairs correctly disambiguated)
  * **Strict Mode Fidelity**: 100.0% (Zero ambiguous cases falsely allowed into study)
  * Packaged into extension distribution bundle [public/FocusForge-Extension-v1.2.0.zip](file:///d:/JEE/public/FocusForge-Extension-v1.2.0.zip) (133.57 KB).

## [1.8.0] — 2026-09-24

### 🧠 Focus Forge Academic Intelligence Engine (`v2.0-academic-intelligence`)
* **Core Intelligence Rebuild — Academic Knowledge Graph & Semantic Classifier**:
  * Eliminated legacy keyword matching and fragile blacklist heuristics in favor of a typed, hierarchical **Academic Knowledge Graph** and multi-evidence semantic intent classifier ([src/lib/academic-knowledge-graph.ts](file:///d:/JEE/src/lib/academic-knowledge-graph.ts) & [src/services/academicEngine/](file:///d:/JEE/src/services/academicEngine/)).
  * **Taxonomy Version `2026.1` Across 5 Core Disciplines**:
    * **Physics**: Mechanics (Kinematics, NLM, WEP, Rotational Dynamics, Gravitation, SHM, Waves), Electrodynamics (Electrostatics, Current, Magnetism, EMI, AC, EM Waves), Optics & Modern Physics (Wave Optics, Ray Optics, Dual Nature, Atoms, Nuclei, Semiconductors), Thermal & Fluids (Fluids, Thermodynamics, KTG, Thermal Properties).
    * **Chemistry**: Physical (Mole Concept, Thermodynamics, Equilibrium, Kinetics, Electrochemistry, Solutions), Inorganic (Periodic Table, Chemical Bonding, Coordination Compounds, p/d/f-block), Organic (GOC, Hydrocarbons, Haloalkanes, Alcohols/Phenols, Aldehydes/Ketones, Amines, Biomolecules, Named Reactions).
    * **Mathematics**: Algebra (Complex Numbers, Quadratic Equations, Matrices & Determinants, P&C, Binomial, Sequences), Calculus (Limits/Continuity, Differentiation, AOD, Indefinite/Definite Integrals, Differential Equations, Area Under Curve), Coordinate Geometry (Straight Lines, Circles, Conics), Vectors & 3D Geometry, Trigonometry.
    * **Biology (NEET)**: Genetics & Evolution (Mendelian Genetics, Molecular Basis of Inheritance), Cell Biology & Cell Division, Human Physiology (Digestion, Respiration, Circulation, Neural/Endocrine), Plant Physiology (Photosynthesis, Respiration), Biotechnology (Principles & Processes), Ecology & Human Reproduction.
    * **English Core (CBSE Class 12)**: Flamingo Prose (The Last Lesson, Lost Spring, Deep Water, The Rattrap, Indigo, Poets and Pancakes, The Interview, Going Places), Flamingo Poetry (My Mother at Sixty-Six, Keeping Quiet, A Thing of Beauty, A Roadside Stand, Aunt Jennifer's Tigers), Vistas (The Third Level, The Tiger King, Journey to the End of the Earth, The Enemy, On the Face of It, Memories of Childhood), and Formal Writing Skills (Notice, Formal & Informal Invitations, Letter to Editor, Job Application, Report & Article Writing).
* **Token-Bounded Matcher & Substring Collision Elimination**:
  * Engineered `matchesEntityBounded(normText, entityNorm)` employing regex `(^|\s)entity(\s|$)` to eliminate catastrophic partial-token false positives (e.g. `shm` inside `freshman`, `mot` inside `emotional` or `motivation`, `wep` inside `sweeping`).
* **Negative Context Dominance & Distraction Deflection**:
  * Solved the lifestyle vlog bypass: When college vloggers include academic exam terms in their video titles (e.g., *"My JEE Preparation Vlog: 14 Hours at Kota Hostel"* or *"IIT Bombay Campus Tour & Mess Food"*), negative context dominance automatically triggers unless explicit pedagogical instruction or problem-solving actions are present.
  * Comprehensive negative taxonomy covering `LIFESTYLE_VLOGS`, `CAMPUS_LIFESTYLE`, `ENTERTAINMENT` (memes, funny fails, comedy), `GAMING`, `SPORTS`, `SHOPPING_TECH` (laptop/desk setups), `LIFESTYLE_MOTIVATION`, and `FINANCE_AND_HUSTLE`.
* **Three-Way Decision Contract (`STUDY`, `NON_STUDY`, `REVIEW`)**:
  * **`STUDY`**: Verified syllabus topic + explicit pedagogical instruction or problem solving (`confidence >= 0.70`).
  * **`NON_STUDY`**: Definite entertainment, vlog, gaming, distraction, or negative context dominance.
  * **`REVIEW`**: Ambiguous, documentary, or borderline educational context; held at the Layer B Gateway for student verification. In strict guard mode (`guardMode === "strict"`), fails closed to `NON_STUDY`.
* **Browser Extension Companion Upgrade**:
  * Background service worker ([public/extension/background.js](file:///d:/JEE/public/extension/background.js)) upgraded with full bounded token matcher, fallback classifier, and `isStudyAllowedDecision(decision)` contract.
  * In-page controller ([public/extension/youtube-study-controller.js](file:///d:/JEE/public/extension/youtube-study-controller.js)) upgraded with bounded fast classifier and three-way action routing.
  * Gateway verification portal ([public/extension/youtube-verify.html](file:///d:/JEE/public/extension/youtube-verify.html) & [youtube-verify.js](file:///d:/JEE/public/extension/youtube-verify.js)) enhanced with interactive `state-review` section, diagnostic metadata badges (Subject, Chapter, Topic, Reason Codes), and student confirmation action ("Confirm as Study Material & Open").
* **Web Dashboard Status Synchronization**:
  * Added live FocusForge Academic Intelligence Engine card to [src/app/blocker/page.tsx](file:///d:/JEE/src/app/blocker/page.tsx) with real-time taxonomy version display, 5-subject syllabus hierarchy stats, and `0.00%` false allow rate indicators.
* **Automated Test Validation Scoreboard**:
  * Added comprehensive test suite ([tests/academic-intelligence-engine.test.ts](file:///d:/JEE/tests/academic-intelligence-engine.test.ts)) with **260 / 260 tests passing (100%)**:
    * **Phase 1 (105 Study Lectures)**: 105 / 105 (100.0% academic recall, 0 false blocks across Physics, Chemistry, Math, Biology, and English Core).
    * **Phase 2 (105 Distractions/Vlogs/Tech)**: 105 / 105 (0.00% false allow rate, 0 distractions leaked).
    * **Phase 3 (50 Borderline Cases)**: Disambiguated between documentary, career advice, and strict mode fail-closed behavior.
    * **Phase 4 (12 High-Risk Confusion Pairs)**: 12 / 12 pairs successfully separated (e.g. *Rotational Motion Lecture* vs *Rotational Motion in Beyblade Battles*).
  * Packaged into extension distribution bundle [public/FocusForge-Extension-v1.2.0.zip](file:///d:/JEE/public/FocusForge-Extension-v1.2.0.zip) (133.36 KB).

## [1.7.9] — 2026-09-23

### 🛡️ Focus Forge YouTube Content Gateway — Two-Layer Defense in Depth
* **Architectural Rebuild — YouTube Content Gateway**:
  * Eliminated all legacy, ad-hoc, and DOM-only YouTube blocking loopholes in favor of a synchronized **Two-Layer Content Gateway**:
    * **Layer A (In-Page Pre-Navigation Click Firewall)** ([public/extension/youtube-study-controller.js](file:///d:/JEE/public/extension/youtube-study-controller.js)):
      * Document-level capture-phase interception (`click`, `auxclick`, `keydown`) running at `document_start`.
      * Decides destination legitimacy **before** the browser enters that video for clickable recommendations and links.
      * Absolute Current Video Immunity: Active study lecture continues playing with 0 interruptions while recommendations are pre-verified or distractions are deflected.
      * Controlled Transition Replay: Programmatic replay on approved videos primes the background Priority 100 allow rule before native navigation occurs.
    * **Layer B (Network-Level Declarative Net Request Video Gateway)** ([public/extension/background.js](file:///d:/JEE/public/extension/background.js)):
      * Solves the Direct Address Bar URL bypass (`youtube.com/watch?v=...`) and missed clicks at the network request layer.
      * **Priority 100 (`YT_PRIORITY_EXACT_ALLOW = 100`)**: Exact allow rule for each approved video ID with a valid Focus Pass (`||youtube.com/watch?*v=VIDEO_ID*`).
      * **Priority 50 (`YT_PRIORITY_SHORTS = 50`)**: Shorts restriction redirecting to distraction block screen.
      * **Priority 10 (`YT_PRIORITY_GATEWAY_REDIRECT = 10`)**: Unverified `/watch` navigations match regex and redirect to [public/extension/youtube-verify.html](file:///d:/JEE/public/extension/youtube-verify.html).
      * **Zero Domain/Subresource Blocking**: YouTube Home (`/`), Search (`/results`), Channels (`/@...`), and playlists remain 100% accessible at all times; subresources, scripts, media, and stylesheets are never blocked.
  * **Web-Accessible Verification Redirect Page** ([public/extension/youtube-verify.html](file:///d:/JEE/public/extension/youtube-verify.html) & [public/extension/youtube-verify.js](file:///d:/JEE/public/extension/youtube-verify.js)):
    * Web-accessible extension resource registered in [public/extension/manifest.json](file:///d:/JEE/public/extension/manifest.json).
    * Evaluates target video against active study session:
      * If session inactive: seamlessly navigates back to target URL.
      * If classified ALLOW: grants Focus Pass, installs Priority 100 DNR rule, and auto-navigates to original YouTube URL (Priority 100 allow rule overrides Priority 10 redirect rule, loading video normally without looping).
      * If classified BLOCK: stays on verification page with "Stay in the Zone" block screen and navigation options—distracting video NEVER touches the YouTube player.
  * **Session-Scoped Focus Pass Token Architecture**:
    * Implemented `FocusPassManager` in background service worker, issuing structured authorization tokens:
      `{ videoId, userId, sessionId, decision, subject, chapter, topic, confidence, reason, issuedAt, expiresAt }`.
    * Cleared automatically on session stop, pause, completion, or expiration.
  * **Service Worker Restart Resilience (`chrome.storage.session`)**:
    * Reconstructs guard runtime state, verified session ID, lease timestamp, approved video set, and active Focus Passes from session storage on worker startup or wake.
  * **Popup & Web Dashboard Synchronization**:
    * Updated [public/extension/popup/popup.html](file:///d:/JEE/public/extension/popup/popup.html) & [popup.js](file:///d:/JEE/public/extension/popup/popup.js) with live YouTube Content Gateway drawer displaying Layer A & Layer B status, active Focus Passes, approved videos, and classifier health.
    * Updated [src/app/blocker/page.tsx](file:///d:/JEE/src/app/blocker/page.tsx) with Content Gateway operational indicators.
  * **Comprehensive Automated Test Verification**:
    * Created [tests/youtube-content-gateway.test.ts](file:///d:/JEE/tests/youtube-content-gateway.test.ts) testing rule priority hierarchy (100 > 50 > 10), route scoping, direct URL Layer B simulation, Focus Pass lifecycle, session storage persistence, and syllabus vs. lifestyle filtering.
    * Updated [tests/youtube-guard-dnr.test.ts](file:///d:/JEE/tests/youtube-guard-dnr.test.ts) to validate the new Gateway DNR rules.
    * Added to `npm test` script in [package.json](file:///d:/JEE/package.json); 100% pass across all 12 test suites.
  * **Packaged Extension**: Freshly generated and verified [public/FocusForge-Extension-v1.2.0.zip](file:///d:/JEE/public/FocusForge-Extension-v1.2.0.zip) and `public/FocusForge-Extension.zip` (131.33 KB).

## [1.7.8] — 2026-09-23

### 🛡️ YouTube Study Guard Navigation Firewall Rebuild & Zero-Interruption Invariant
* **Central Navigation Firewall Architecture**:
  * **Complete Content Script Rebuild** ([public/extension/youtube-study-controller.js](file:///d:/JEE/public/extension/youtube-study-controller.js)):
    * Re-architected around the core **Navigation Firewall** paradigm: determines whether the destination video is allowed **before** navigation occurs for any YouTube video link click.
    * Integrated the 7 authoritative subsystems:
      1. **Explicit State Machine**: `OFF`, `STARTING`, `ARMED`, `VERIFYING_DESTINATION`, `ALLOWING`, `BLOCKING`, `ERROR`.
      2. **Single Session Gate (`isStudyGuardActive()`)**: Active **only** when authenticated, session status is `focus` / `active`, session ID matches verified session, and lease is valid. When false, YouTube behaves 100% normally.
      3. **Robust Destination Video Extraction**: Normalizes `/watch?v=...`, `/shorts/...`, `/embed/...`, and `youtu.be/...` with strict validation.
      4. **Capture-Phase Click Interceptor**: Document-level capture listeners (`click`, `auxclick`, `keydown` Enter) intercept destination links before YouTube's Polymer SPA router can initiate navigation.
      5. **Priority Verification Queue (`VerificationQueueManager`)**: Strict scheduling priority: `CRITICAL` (clicked destination) > `HIGH` (hovered card) > `MEDIUM` (visible recommendations via `IntersectionObserver`) > `LOW` (search / offscreen items).
      6. **Absolute Current Video Immunity**: Setting `isCurrentVideoImmune = true` guarantees that the currently playing, verified study lecture is never paused, dimmed, or interrupted while background scanning or distraction block occurs.
      7. **Controlled Transition Bypass (`approvedNavigationToken`)**: Prevents infinite recursion when triggering approved navigations programmatically.
      8. **Race Condition Prevention (`navigationToken`)**: Ensures the latest user click always wins and stale asynchronous responses are cleanly discarded.
  * **No Blanket /watch Network Block**: YouTube remains fully usable; DNR rules only target `/shorts/` and known blocked distraction IDs—never all `/watch` paths.
  * **Extension Popup Firewall Diagnostics Drawer** ([public/extension/popup/popup.html](file:///d:/JEE/public/extension/popup/popup.html) & [public/extension/popup/popup.js](file:///d:/JEE/public/extension/popup/popup.js)):
    * Real-time diagnostic panel displaying Firewall State (`ARMED` / `OFF`), Destination Gate status, Active Session verification, Approved Count, Guard Mode, and Classifier connectivity.
  * **Comprehensive Navigation Firewall Test Suite**:
    * Created [tests/youtube-navigation-firewall.test.ts](file:///d:/JEE/tests/youtube-navigation-firewall.test.ts) covering session gating, robust ID extraction, pre-navigation click interception, current video immunity, priority queue execution, approved navigation replay, and campus lifestyle classification.
    * Added to `npm test` script in [package.json](file:///d:/JEE/package.json); 100% pass across all 11 test suites.
  * **Fresh Extension Packages**: Rebuilt and validated [public/FocusForge-Extension-v1.2.0.zip](file:///d:/JEE/public/FocusForge-Extension-v1.2.0.zip) and `public/FocusForge-Extension.zip`.

## [1.7.7] — 2026-09-23

### 🛡️ YouTube Study Guard Transition Redesign & Zero-Interruption Invariant
* **Pre-Navigation Click Interception Architecture**:
  * **Level 1 Pre-Navigation Gate** ([public/extension/youtube-study-controller.js](file:///d:/JEE/public/extension/youtube-study-controller.js)):
    * Implemented capture-phase click interception (`document.addEventListener("click", ..., true)`, `auxclick`, and `keydown`) registered at `document_start` before YouTube's SPA event handlers attach.
    * Video link clicks (`/watch?v=...`, `youtu.be`) check `localDecisionCache` synchronously:
      * **Verified Study Lecture**: Allowed immediately without pause, overlay, or delay; YouTube navigates and plays instantaneously.
      * **Distraction / Unverified Video**: Prevented before navigation (`e.preventDefault()`, `e.stopPropagation()`); the currently playing study lecture remains undisturbed, and a floating FocusForge "Stay in the Zone" card notifies the student why the video was blocked.
      * **Unknown / Uncached**: Click intercepted while the current study lecture continues playing. Dispatches priority `CHECK_OR_CLASSIFY_CLICK` with a unique `navigationToken`. When verified `ALLOW`, smoothly triggers transition with programmatic bypass; if `BLOCK`, remains on lecture and notifies student.
  * **Predictive Recommendation Pre-Verification Engine**:
    * Visible recommendation cards observed via `IntersectionObserver` across `#related` and secondary results containers.
    * Batched prefetch requests (`PREFETCH_YOUTUBE_RECOMMENDATIONS`) sent to background worker in batches of 10–25 candidates.
    * Hover priority escalation (`pointerover`) pre-verifies cards before the user completes a click, achieving near-instant cache hits.
  * **Current Lecture Non-Interference Invariant**:
    * The approved study lecture that the student is actively watching is **never paused, overlaid, dimmed, or interrupted** during recommendation pre-verification.
  * **Multi-Signal Academic vs. Lifestyle Classification**:
    * Enhanced [src/services/youtubeGuardService.ts](file:///d:/JEE/src/services/youtubeGuardService.ts) and [src/app/api/youtube/classify/route.ts](file:///d:/JEE/src/app/api/youtube/classify/route.ts) with `batchClassifyVideos(inputs, userId)`.
    * Rejects student lifestyle vlogs (hostel tours, Kota aspirant routines, campus fests, desk setups, gadget/laptop reviews, non-academic motivational speeches) while protecting comprehensive IIT-JEE/NEET/CBSE academic syllabus lectures.
  * **Absolute Session Guard Invariant**:
    * YouTube Study Guard is strictly active **ONLY** during an active study session (`status === "focus"` / `"ACTIVE"` with valid lease). If idle, paused, on break, or logged out, YouTube behaves 100% normally without any click interception or observers.
* **Automated Verification**:
  * Added [tests/youtube-guard-transition.test.ts](file:///d:/JEE/tests/youtube-guard-transition.test.ts) covering batch pre-verification, syllabus vs. distraction filtering, click state machine simulation, non-interference invariants, and navigation token race prevention.
  * Packaged and verified extension binaries ([public/FocusForge-Extension-v1.2.0.zip](file:///d:/JEE/public/FocusForge-Extension-v1.2.0.zip) and `public/FocusForge-Extension.zip`).
  * 100% test pass rate across all 10 test suites in `npm test`.

## [1.7.6] — 2026-09-23

### 🔄 Master Chrome Companion Extension Sync Repair & Canonical Download Unification
* **Chrome Extension Real-Time Synchronization Repair**:
  * **Database Schema Alignment**: Added missing columns (`active_session_id`, `active_goal`, `start_time`, `planned_duration_minutes`) to `public.extension_state` on remote Supabase and ensured full replica identity and publication replication.
  * **Resilient Service Upserts**: Wrapped `extension_state` writes defensively in [src/services/studySessionService.ts](file:///d:/JEE/src/services/studySessionService.ts) so auxiliary table failures never abort `broadcastControlEvent` broadcasts.
  * **Background Service Worker Hardening** ([public/extension/background.js](file:///d:/JEE/public/extension/background.js)):
    * Added durable `supabaseClient.auth.onAuthStateChange` listener to persist refreshed JWT access tokens across service worker restarts.
    * Fixed `GET_EXTENSION_STATUS` to unconditionally trigger `reconcileWithCloud` whenever authenticated (or recover auth session from local storage), eliminating the bug where opening the extension popup skipped cloud reconciliation and left the UI stuck at "00:00" and "No Active Session".
    * Inverted countdown math in `computeTimeLeft()` to prioritize high-precision snapshot elapsed derivation (`timeLeftSeconds - elapsedSinceSync`), preserving exact countdown time matching the website even across multiple pause/resume cycles.
    * Ensured authoritative Supabase active/paused sessions immediately purge any stale entries from `terminalSessionIds`.
    * Implemented Fail-Closed / Second Line of Truth policy: transient query errors or unauthenticated responses never wipe active sessions when `extension_state` confirms an active focus session.
  * **Popup UI State Clarification** ([public/extension/popup/popup.js](file:///d:/JEE/public/extension/popup/popup.js)):
    * Clarified sync badge to display "Focus Active" during focus, "Paused" during breaks, and "Live Connected" when idle.
    * Accurate countdown calculation matching the web application timer.
* **Canonical Extension Download Architecture**:
  * **Single Source of Truth**: Created [src/lib/extension-download.ts](file:///d:/JEE/src/lib/extension-download.ts) exporting canonical metadata (`EXTENSION_VERSION`, `EXTENSION_FILENAME`, `downloadExtension()`).
  * **Unified Downloads**: Replaced direct hardcoded download links on Homepage ([src/app/page.tsx](file:///d:/JEE/src/app/page.tsx)) and Web Blocker ([src/app/blocker/page.tsx](file:///d:/JEE/src/app/blocker/page.tsx)) with `downloadExtension()`.
  * **Resilient API Route** ([src/app/api/download-extension/route.ts](file:///d:/JEE/src/app/api/download-extension/route.ts)): Dynamic binary PKZip verification with direct binary headers and automatic Vercel CDN 302 fallback.
  * **Forward-Slash Normalized Packaging**: Updated [scripts/package-extension.js](file:///d:/JEE/scripts/package-extension.js) with Python zipfile engine, ensuring all ZIP entries have standard `/` paths (`popup/popup.html`, `block-page/index.html`) across all operating systems.
  * Both `public/FocusForge-Extension-v1.2.0.zip` and `public/FocusForge-Extension.zip` generated with identical SHA-256 hashes (`1EEE7A58...`).

## [1.7.5] — 2026-09-22

### ⏱️ Persistent Study Session Continuity & Authoritative Timer Invariant
* **Elimination of Timer Auto-Resets, Freezes & Session Dropping**:
  * Enforced the **Core Product Rule**: Once a user presses **START STUDY SESSION**, the session is persistent and **MUST NEVER AUTO-RESET OR STOP**.
  * Survives tab switching, opening new tabs/windows, background tab throttling, route navigation, page reloads, React StrictMode remounts, Supabase auth refreshes, and routine cloud hydrations.
* **Authoritative Timestamp-Derived Duration Mathematics**:
  * Replaced interval-tick-dependent math with deterministic timestamp offsets:
    * $\text{elapsedSeconds} = \text{accumulatedElapsedSeconds} + (\text{status} === \text{"focus"} \ \&\& \ \text{startedAt} ? \lfloor(\text{Date.now}() - \text{startedAt}) / 1000\rfloor : 0)$
    * $\text{remainingSeconds} = \max(0, (\text{durationMinutes} \times 60) - \text{elapsedSeconds})$
  * Eliminates all clock drift, tab suspension inaccuracy, and background throttling artifacts.
* **Non-Destructive Reconciliation Engine & Strict NO-OP**:
  * Fixed `reconcileStudySession(cloudSession)` in **[src/store/use-study-store.ts](file:///d:/JEE/src/store/use-study-store.ts)**:
    * Identical incoming state is a strict NO-OP — prevents state churn, timer resets, and blocker re-initializations.
    * Replaced session-wiping fallback with sacred local session preservation: routine background hydrations that return `null` or experience transient network timeouts never reset an active or paused session.
    * Active sessions can only transition via explicit user actions (PAUSE, RESUME, COMPLETE, ABANDON), authenticated companion terminal broadcasts (`STUDY_SESSION_COMPLETED`, `STUDY_SESSION_ABANDONED`), or natural duration expiration.
* **Elimination of Destructive Hydration Clears**:
  * Removed `useStudyStore.getState().resetStudyStore()` from `hydrateUserData()` in **[src/services/syncService.ts](file:///d:/JEE/src/services/syncService.ts)**. `resetStudyStore()` is now strictly reserved for explicit user sign-out (`handleUserLogout()`).
  * Updated `userScopedStorageState` so that guest sessions and authenticated users are partitioned and persisted across tab switches and reloads.
  * Added `visibilitychange` and window `focus` event listener in **[src/components/workspace-layout.tsx](file:///d:/JEE/src/components/workspace-layout.tsx)** for instantaneous timer display catch-up upon returning to the tab without modifying session lifecycle.
* **Database Schema & Continuity Migration**:
  * Created [supabase/migrations/20260922150000_study_session_continuity.sql](file:///d:/JEE/supabase/migrations/20260922150000_study_session_continuity.sql) adding `paused_at`, `resumed_at`, and `accumulated_seconds` with index `idx_study_sessions_user_status_time`.
  * Synchronized [supabase/schema.sql](file:///d:/JEE/supabase/schema.sql).
  * Validated via `scripts/validate-supabase.js` (Status: SUCCESS, all 7 migrations validated).
* **Automated Test Suite**:
  * Added [tests/study-session-continuity.test.ts](file:///d:/JEE/tests/study-session-continuity.test.ts) covering 8 comprehensive test cases (timestamp calculation, tab switch simulation, non-destructive `hydrateUserData`, strict NO-OP, pause/resume continuity, auto-complete, cloud restoration, and multi-account isolation).
  * Integrated into `npm test` (all 9 test suites pass 100%).

## [1.7.4] — 2026-09-22

### 🛡️ 15 Default Blocked Domains on New Account Creation
* **Exact 15 Distraction Domains Auto-Selected for New Accounts**:
  * Configured the exact 15 domains shown in Study Protection & Content Guard (`/blocker`):
    1. `instagram.com`
    2. `facebook.com`
    3. `snapchat.com`
    4. `primevideo.com`
    5. `disneyplus.com`
    6. `netflix.com`
    7. `twitch.tv`
    8. `dailymotion.com`
    9. `discord.com`
    10. `9gag.com`
    11. `imgur.com`
    12. `steamcommunity.com`
    13. `reddit.com`
    14. `pinterest.com`
    15. `x.com`
* **Full-Stack Persistence & Synchronization**:
  * **[src/services/blockerService.ts](file:///d:/JEE/src/services/blockerService.ts)**:
    * Exported `DEFAULT_BLOCKED_DOMAINS` array containing all 15 domains in exact screenshot order.
    * Added `seedDefaultBlockedSites(userId: string)` to persist all 15 domains into `public.blocked_sites` and `public.extension_state`.
    * Updated `getBlockedSites(userId)` fallback to return all 15 domains for guest or unconfigured accounts, and auto-persist for authenticated accounts.
  * **[src/store/use-study-store.ts](file:///d:/JEE/src/store/use-study-store.ts)**:
    * Upgraded `DEFAULT_BLOCKED_WEBSITES` from legacy 5 domains to the exact 15 domains.
    * Initialized `blockedWebsites` with `[...DEFAULT_BLOCKED_WEBSITES]`.
    * Ensured `resetStudyStore()` and `restoreStudyStore()` fall back to `DEFAULT_BLOCKED_WEBSITES`.
  * **[src/services/syncService.ts](file:///d:/JEE/src/services/syncService.ts)**:
    * In `hydrateUserData()`, updated fallback so newly created accounts without existing records receive `[...DEFAULT_BLOCKED_WEBSITES]`.
  * **[src/context/AuthContext.tsx](file:///d:/JEE/src/context/AuthContext.tsx)**:
    * In `signup()`, called `blockerService.seedDefaultBlockedSites(activeUser.id)` immediately upon profile bootstrap, ensuring the 15 domains are in the database before the user lands on the dashboard.
  * **Database Trigger & Migration**:
    * Created [supabase/migrations/20260922_default_blocked_domains.sql](file:///d:/JEE/supabase/migrations/20260922_default_blocked_domains.sql).
    * Executed updated `public.handle_new_user()` trigger on Supabase (`yhcowzmcvlsmcffbqryb`) to automatically insert 15 rows into `public.blocked_sites` and initialize `public.extension_state` on `auth.users` row creation.
* **Automated Verification**:
  * Added Test 7 to [tests/instant-signup-auth.test.ts](file:///d:/JEE/tests/instant-signup-auth.test.ts) verifying count, sequence, store defaults, reset preservation, and service resolution.
  * All 8 automated test suites passing 100%; TypeScript (`npm run typecheck`) and Next.js build (`npm run build`) passing with zero errors.

## [1.7.3] — 2026-09-22

### 🚀 Instant Signup & Zero Email-Confirmation Barrier Architecture
* **Supabase Project Configuration & Auto-Confirmation**:
  * Pushed updated project auth configuration to remote Supabase project (`yhcowzmcvlsmcffbqryb`) with `enable_confirmations = false`.
  * Created `public.auto_confirm_new_user()` trigger on `auth.users` (`BEFORE INSERT`) ensuring every new account has `email_confirmed_at = NOW()`, establishing guaranteed instant verification.
  * Auto-confirmed all existing unconfirmed users in `auth.users` (including `sarfarazirl@gmail.com`) so they can log in with password immediately.
  * Enhanced `public.handle_new_user()` database trigger to extract `exam_type`, `target_exam_year`, `syllabus_version`, `country`, and `daily_goal` from `raw_user_meta_data`, bootstrapping profiles immediately at the database level.
  * Created migration file [supabase/migrations/20260922_auto_confirm_and_signup_profile.sql](file:///d:/JEE/supabase/migrations/20260922_auto_confirm_and_signup_profile.sql).
* **One Email = One Account Uniqueness Guarantee**:
  * Maintained strict email uniqueness: duplicate signups are cleanly intercepted and presented with: `"An account with this email already exists. Please log in instead."`
  * No duplicate accounts, profiles, or orphaned records are created.
* **Instant Authentication Flow**:
  * **[src/context/AuthContext.tsx](file:///d:/JEE/src/context/AuthContext.tsx)**: Simplified `signup` to return `Promise<void>`, removed all `requiresEmailConfirmation` barriers, immediately utilizes the session returned by `signUp()`, falls back to immediate `signInWithPassword()` if session is absent, and hydrates user state and extensions seamlessly.
  * **[src/services/userService.ts](file:///d:/JEE/src/services/userService.ts)**: Refactored `createUserProfile` to idempotently update existing profile records with explicit user-entered signup fields (`displayName`, `country`, `examType`, `targetExam`, `targetYear`, `studyGoal`, `username`) rather than discarding them.
  * **[src/app/login/page.tsx](file:///d:/JEE/src/app/login/page.tsx)**: Completely removed the "Check your inbox to confirm your account" interstitial, transitioning directly upon signup into celebratory confetti, sound, and immediate navigation to `/dashboard`.
* **Flow Preservation**:
  * Strictly preserved password reset / forgot password recovery emails (`src/app/forgot-password/page.tsx`, `src/app/reset-password/page.tsx`, and `src/app/auth/confirm/route.ts`).
  * Preserved Google OAuth authentication.
* **Automated Verification**:
  * Created [tests/instant-signup-auth.test.ts](file:///d:/JEE/tests/instant-signup-auth.test.ts) covering instant sessions, duplicate email rejection, profile persistence, and multi-exam tracks.
  * Verified live signup and immediate login on remote Supabase project. All 8 automated test suites passing 100%.

## [1.7.2] — 2026-09-22

### ⚡ Next.js Hydration Mismatch Elimination & Supabase Persistence Hardening
* **Zero-Suppression Hydration Architecture**:
  * Root-cause eliminated React hydration mismatches ("A tree hydrated but some attributes of the server rendered HTML didn't match the client properties") without resorting to blanket `suppressHydrationWarning`.
  * **[src/components/consistency-grid.tsx](file:///d:/JEE/src/components/consistency-grid.tsx)**: Replaced midnight Date parsing with noon UTC (`T12:00:00Z`) and explicit `timeZone: "UTC"`, eliminating timezone boundary date shifts.
  * **[src/app/study/page.tsx](file:///d:/JEE/src/app/study/page.tsx)**: Updated `getSessionTimeDetails` to provide deterministic SSR output (`"--:--"`, deterministic relative age, and default work block) during server render and initial hydration pass (`!isMounted`), then seamlessly hydrating with local browser time. Initialized `currentTime` state to `0` and guarded cooling block indicators with `isMounted`.
  * **[src/app/tracker/page.tsx](file:///d:/JEE/src/app/tracker/page.tsx)**: Guarded domain summary timestamps and child log date/time formatting with `mounted ? dateObj.toLocaleTimeString(...) : "—"` and `mounted ? dateObj.toLocaleDateString(...) : (isValidDate ? dateStr : "Today")`.
  * **[src/app/mistakes/page.tsx](file:///d:/JEE/src/app/mistakes/page.tsx)**: Guarded created and next revision dates with `isMounted ? new Date(...).toLocaleDateString() : ISO_date_fallback`.
  * **[src/app/profile/page.tsx](file:///d:/JEE/src/app/profile/page.tsx)**: Guarded joined date formatting with `isMounted`.
  * **[src/app/blocker/page.tsx](file:///d:/JEE/src/app/blocker/page.tsx)**: Guarded `lastSync` heartbeat formatting with `isMounted`.
  * **[src/app/revisions/page.tsx](file:///d:/JEE/src/app/revisions/page.tsx)**: Added noon UTC parsing and `timeZone: "UTC"` to `formatDate`.
* **Verified Non-Swallowing Supabase Cloud Persistence**:
  * **Database Migration Applied**: Executed multi-exam migration directly on remote Supabase project (`yhcowzmcvlsmcffbqryb`), adding `exam_type` column to `profiles`, `study_sessions`, `mistake_journal`, `jee_progress`, `revision_plans`, and `custom_revision_plans`, creating `exam_weightage` table, and establishing composite indexes (`user_id, exam_type, created_at`).
  * **[src/services/studySessionService.ts](file:///d:/JEE/src/services/studySessionService.ts)**:
    * `saveCompletedSession` now uses `.select().single()` and throws `sessionErr` instead of swallowing.
    * `saveStudySession`, `createActiveSession`, `updateActiveSessionStatus`, `completeActiveSession`, `abandonActiveSession`, and `cancelActiveSession` now inspect Postgrest error objects and throw typed exceptions.
    * Single-session UUID invariant preserved across `START -> PAUSE -> RESUME -> COMPLETE/ABANDON`.
  * **[src/services/mistakeJournalService.ts](file:///d:/JEE/src/services/mistakeJournalService.ts)**:
    * `saveMistake` now returns confirmed `MistakeJournalDoc` via `.select().single()` and throws on any Postgrest error.
    * `updateMistakeStatus`, `updateMistakeFields`, and `deleteMistake` now check `{ error }` and throw.
  * **[src/store/use-study-store.ts](file:///d:/JEE/src/store/use-study-store.ts)**:
    * Made `startSession` an `async` action returning `Promise<void>`, awaiting `studySessionService.createActiveSession` before local state progression.
    * Added `isStarting` button state in [src/app/study/page.tsx](file:///d:/JEE/src/app/study/page.tsx) with alert dialog on cloud connection failure.
    * Updated session history header to `"Cloud-Synced Database History"`.
  * **[src/store/use-mistake-store.ts](file:///d:/JEE/src/store/use-mistake-store.ts)**:
    * Made `addMistake` an `async` action returning `Promise<MistakeEntry>`, awaiting `mistakeJournalService.saveMistake`.
    * Upgraded ID generator to standard `crypto.randomUUID()`.
    * In [src/app/mistakes/page.tsx](file:///d:/JEE/src/app/mistakes/page.tsx): added `isSaving` and `saveError` error banner; retains user form inputs intact if database mutation fails.
* **Automated Verification**:
  * Created [tests/hydration-persistence-verification.test.ts](file:///d:/JEE/tests/hydration-persistence-verification.test.ts) verifying SSR determinism, guest guards, and async store contracts.
  * All 7 test suites passing 100% with zero type errors.

## [1.7.1] — 2026-09-22

### 🛡️ Master Full-Stack Stabilization & Cross-Account Data Isolation Engine
* **Single Canonical Auth Architecture ([src/lib/supabase/client.ts](file:///d:/JEE/src/lib/supabase/client.ts), [src/context/AuthContext.tsx](file:///d:/JEE/src/context/AuthContext.tsx))**:
  * Removed arbitrary `cachedActiveUid` and raw localStorage token sniffing loop from Supabase browser client.
  * Added `getAuthenticatedUserId()` and `clearActiveUserId()` ensuring strictly authenticated UUIDs are supplied to database services.
  * Introduced `activeAuthUidRef` race-condition token in `AuthContext` to prevent out-of-order async resolution when switching accounts (`User A -> Logout -> User B`).
  * Enforced email confirmation handling in `signup` and idempotent profile bootstrap on `login`.
* **Zero-Leakage Zustand Store Partitioning ([src/store/use-study-store.ts](file:///d:/JEE/src/store/use-study-store.ts), [src/store/use-mistake-store.ts](file:///d:/JEE/src/store/use-mistake-store.ts))**:
  * Implemented dynamic `userScopedStorageState` with Zustand's `createJSONStorage`. Unauthenticated users receive `null` and each authenticated user is strictly isolated under `focusforge_study_storage_${uid}` and `focusforge_mistakes_storage_${uid}`.
  * In `restoreStudyStore`: eliminated fallback to `get().xp`, `get().level`, and `get().currentStreak`. Replaced with genuine zero defaults.
  * Removed dangerous automatic cloud writes of empty blocked website lists that previously cross-contaminated user profiles.
  * In `resetStudyStore` and `resetMistakeStore`: completely purged active user storage keys on logout.
* **Unified Single-Owner Realtime Synchronization ([src/services/syncService.ts](file:///d:/JEE/src/services/syncService.ts))**:
  * Enforced clean-room store resets prior to hydrating cloud data.
  * Added `currentSyncedUserId` concurrency check to reject stale in-flight payloads from a previous session.
  * Removed duplicate uncoordinated `restoreStudyStore(uid)` and `restoreMistakeStore(uid)` calls from [src/components/sidebar.tsx](file:///d:/JEE/src/components/sidebar.tsx).
* **Multi-Exam Backend Synchronization & Genuine Defaults**:
  * Hardened [src/services/studySessionService.ts](file:///d:/JEE/src/services/studySessionService.ts), [src/services/jeeService.ts](file:///d:/JEE/src/services/jeeService.ts), and [src/services/mistakeJournalService.ts](file:///d:/JEE/src/services/mistakeJournalService.ts) to persist and query `exam_type` (`"JEE" | "NEET"`).
  * In [src/services/dashboardService.ts](file:///d:/JEE/src/services/dashboardService.ts): removed fake hardcoded `100 XP`, `1 streak day`, and `85% weekly completion`, ensuring clean zero baselines for new users.
  * Removed deprecated dead services: `authService.ts`, `mistakeService.ts`, and `focusService.ts`.
* **Workspace Auth Gateway & Diagnostics**:
  * Added full-screen loading portal and unauthenticated router redirect in [src/components/workspace-layout.tsx](file:///d:/JEE/src/components/workspace-layout.tsx).
  * Created diagnostic health route at `/api/health` ([src/app/api/health/route.ts](file:///d:/JEE/src/app/api/health/route.ts)) verifying database connectivity and table schemas.
  * Added comprehensive automated multi-account verification test suite ([tests/data-isolation-multi-exam.test.ts](file:///d:/JEE/tests/data-isolation-multi-exam.test.ts)) passing 100%.

## [1.7.0] — 2026-09-22

### 🧬 Master Multi-Exam Architecture: Dynamic IIT-JEE & NEET-UG Support Engine
* **Universal Multi-Track Architecture**:
  * Seamlessly powers both **IIT-JEE** (Physics, Chemistry, Mathematics) and **NEET-UG** (Physics, Chemistry, Botany, Zoology) preparation tracks.
  * Zero superficial theme switching: track selection dynamically drives signup, profile target year (`[2027, 2028, 2029, 2030]`), dashboard, navigation, syllabus, trackers, study session categorization, mistake journals, revision plans, and analytics.
  * **Complete Data Preservation**: Switching between tracks preserves all logged study sessions, XP, streaks, and mistake entries.
* **Central Exam Configuration Engine ([src/lib/exam-config.ts](file:///d:/JEE/src/lib/exam-config.ts))**:
  * Unified `EXAM_CONFIG` registry with strongly-typed `ExamConfig` for both tracks.
  * Dynamic `getUpcomingExamYears(4)` resolving strictly to `[2027, 2028, 2029, 2030]`.
  * `detectExamTypeFromTarget(targetExam)` auto-inference engine.
* **Reactive Exam Hook ([src/hooks/use-exam.ts](file:///d:/JEE/src/hooks/use-exam.ts))**:
  * Single source of truth reactive hook exposing `examType`, `config`, `isNeet`, `isJee`, `subjects`, `subjectConfigs`, `targetYear`, and `switchExamTrack(newTrack, year)`.
* **Authoritative NEET-UG Curriculum & NCERT Engine ([src/data/curriculum/](file:///d:/JEE/src/data/curriculum/))**:
  * Full NMC/NTA 2026-compliant syllabus: 30 Physics, 20 Chemistry, 17 Botany, and 15 Zoology chapters (82 total).
  * Biology split into first-class Botany and Zoology subjects giving Biology 50% score (360/720 marks).
  * 2019–2025 PYQ historical trend data, weightage badges, and NCERT facts/diagrams integration.
* **First-Class Subject Themes ([src/theme/subjectColors.ts](file:///d:/JEE/src/theme/subjectColors.ts), [src/lib/subjectTheme.ts](file:///d:/JEE/src/lib/subjectTheme.ts))**:
  * Dedicated design tokens and glow variables for Botany (`#10B981`), Zoology (`#8B5CF6`), and Biology (`#14B8A6`).
  * Reusable UI primitives ([src/components/ui/controls.tsx](file:///d:/JEE/src/components/ui/controls.tsx), [src/components/ui/select.tsx](file:///d:/JEE/src/components/ui/select.tsx)) enriched with Botany, Zoology, and Biology variants.
* **Multi-Exam UI & Flow Upgrades**:
  * **Onboarding & Signup ([src/app/login/page.tsx](file:///d:/JEE/src/app/login/page.tsx))**: Step 02 preparation track cards (`[⚡ JEE]` / `[🩺 NEET]`) and dynamic exam years.
  * **First-Time Track Selection Modal ([src/components/modals/exam-track-selection-modal.tsx](file:///d:/JEE/src/components/modals/exam-track-selection-modal.tsx))**: Automatically detects unconfigured profiles and provides 1-click track selection with data preservation guarantee.
  * **Profile Management ([src/app/profile/page.tsx](file:///d:/JEE/src/app/profile/page.tsx))**: Interactive Preparation Track Switcher Card with full confirmation modal and dynamic subject preview.
  * **Dynamic Hub & Tracker ([src/app/jee/page.tsx](file:///d:/JEE/src/app/jee/page.tsx))**: Dynamically switches between JEE Hub and NEET Hub with Botany & Zoology tabs, Biology 360° overview, and NCERT Fact Vault.
  * **Study Sessions & Mistake Journal ([src/app/study/page.tsx](file:///d:/JEE/src/app/study/page.tsx), [src/app/mistakes/page.tsx](file:///d:/JEE/src/app/mistakes/page.tsx))**: Subject dropdowns, NEET task types (NCERT line-by-line reading, diagram practice), and NEET-specific error classifications (Assertion-Reason, NCERT Fact Recall).
  * **AI Study Coach & Analytics ([src/app/coach/page.tsx](file:///d:/JEE/src/app/coach/page.tsx), [src/app/analytics/page.tsx](file:///d:/JEE/src/app/analytics/page.tsx))**: Multi-exam diagnostics, personalized weak-topic breakdowns across all 4 subjects, and target exam forecasts.
* **Database & Schema Updates ([supabase/migrations/20260922_multi_exam_support.sql](file:///d:/JEE/supabase/migrations/20260922_multi_exam_support.sql), [supabase/schema.sql](file:///d:/JEE/supabase/schema.sql))**:
  * Added `exam_type` (`"JEE" | "NEET"`) to `profiles`, `study_sessions`, `mistake_entries`, `revision_plans`, and `syllabus_progress` with automated backward-compatibility backfilling.

## [1.6.2] — 2026-09-22

### 🎬 YouTube Study Guard — Complete Architectural Redesign: In-Page Player Controller & Zero Network-Level Watch Blocks
* **Root Architectural Correction**:
  * **Never Block YouTube Itself**: `youtube.com`, YouTube search (`/results`), channels, and `/watch` navigations are 100% accessible at the network level.
  * **Eliminated Network-Level `/watch` DNR Blocking**: Removed `YT_RULE_WATCH_GENERAL` (`regexFilter: ^https?://(www\.)?youtube\.com/watch\?.*`) and `onHistoryStateUpdated` redirects on `/watch`. Unclassified videos are never blocked at the HTTP layer before metadata can be evaluated.
  * **Core Invariant**: `UNKNOWN VIDEO != NETWORK BLOCK`. `UNKNOWN VIDEO = LOAD PAGE + PAUSE PLAYER + CLASSIFY`.
* **Authoritative In-Page Video Controller ([public/extension/youtube-study-controller.js](file:///d:/JEE/public/extension/youtube-study-controller.js))**:
  * **5-State Machine**: `NO_GUARD | VERIFYING | ALLOWED | BLOCKED | ERROR`. Single source of truth for in-page YouTube video control.
  * **Anti-Flash Playback Lock**: Captures `'play'` and `'playing'` events on `document` during the capture phase at `document_start`. If state is `VERIFYING` or `BLOCKED`, calls `e.target.pause()`, `e.preventDefault()`, and `e.stopImmediatePropagation()`, stopping playback before frames or audio render.
  * **Verification Overlay**: Injects glassmorphic modal (`#focusforge-yt-verifying-overlay`) with pulsing badge and spinner: `"FOCUS FORGE: Verifying study content..."`.
  * **Multi-Signal Academic vs Student-Adjacent Classifier**:
    * Distinguishes genuine academic instruction (*Rotational Motion JEE Advanced*, *Class 12 Physics Current Electricity*, *Organic Chemistry Full Revision*, *The Last Lesson Explanation*) from student lifestyle/distraction (*My JEE Prep Vlog*, *Day in My Life as NEET Aspirant*, *Hostel Life at IIT*, *IIT Campus Tour*, *Top Laptops for Students*, *Funny School Compilation*, *Student Memes*).
    * Obvious academic topic -> instant `ALLOW`.
    * Obvious lifestyle/vlog/entertainment -> instant `BLOCK`.
    * Uncertain -> queries background service worker (`CLASSIFY_YOUTUBE_VIDEO`).
  * **Decision Enforcement**:
    * `ALLOWED`: Clears overlays, unlocks playback, calls `video.play()`, and starts 30-second study watch ticker.
    * `BLOCKED`: Keeps player locked and displays Focus Forge block screen (`#focusforge-yt-block-overlay`) with `[Back to YouTube Study]` button. User can freely use the top search bar to discover study lectures.
    * `ERROR`: Keeps player paused and displays retry UI.
  * **Full SPA Navigation Tracking**: Listens for `yt-navigate-finish`, `yt-page-data-updated`, `popstate`, `FF_YOUTUBE_NAVIGATED`, and URL polling. Resets state to `VERIFYING` on any video ID change without inheriting prior approvals.
  * **Clean Dormant State**: When study session is inactive, paused, completed, or expired, resets to `NO_GUARD`, unbinds locks, removes all overlays, and restores 100% normal YouTube playback.
* **Service Worker & DNR Optimization ([public/extension/background.js](file:///d:/JEE/public/extension/background.js))**:
  * DNR session rules restricted strictly to `YT_RULE_SHORTS` (Priority 1500) and approved video allow rules (Priority 2000). Zero watch-level redirect rules.
  * Structured development diagnostics logging: `[FF][YT] session=ACTIVE videoId=... state=VERIFYING ... decision=ALLOW/BLOCK playback=UNLOCKED/LOCKED`.
* **Testing & Integrity Verification**:
  * DNR test suite ([tests/youtube-guard-dnr.test.ts](file:///d:/JEE/tests/youtube-guard-dnr.test.ts)): Verified absence of general watch block in DNR, subresource protection, and Priority 2000 > 1500 hierarchy.
  * Syllabus & distraction test suite ([tests/youtube-study-guard.test.ts](file:///d:/JEE/tests/youtube-study-guard.test.ts)): 16 academic subjects verified, 19/19 distractions successfully deflected.
  * Production package regenerated: [public/FocusForge-Extension-v1.2.0.zip](file:///d:/JEE/public/FocusForge-Extension-v1.2.0.zip) (117.36 KB).

## [1.6.1] — 2026-09-22

### 🛡️ YouTube Study Guard — Declarative Net Request (DNR) Session Rules Hard-Enforcement Engine
* **Browser-Level Request & Navigation Enforcement Layer ([public/extension/background.js](file:///d:/JEE/public/extension/background.js))**:
  * Replaced cosmetic DOM-only hiding with hard network/navigation blocking via Chrome Manifest V3 `chrome.declarativeNetRequest.updateSessionRules()`.
  * **Master Rule Gating Invariant**: Guard is enabled ONLY when: `authenticated && (sessionStatus === "focus" || "active") && activeSessionId && verifiedSessionId === activeSessionId && leaseUntil > Date.now()`.
  * **Fail-Open Invariant**: When no verified study session is active, or during pause/complete/abandon/logout states, YouTube is completely unrestricted with ZERO lingering rules.
* **Three-Tier Priority Hierarchy & Scoping**:
  * **Priority 2000 (Exact Approved Lecture Allow)**: Deterministic IDs `96000..99500` with `condition.urlFilter: "||youtube.com/watch?*v={videoId}*"`. Allows verified educational lectures to stream without interruption.
  * **Priority 1500 (Prohibited Surface Navigation Redirect)**: Dedicated IDs `95001..95010` intercepting `/`, `/shorts/*`, `/feed/*`, `/results*`, `/explore*`, `/trending*`, `/@*`, `/channel/*`, `/c/*`, `/user/*` (`main_frame` navigations only) to `block-page/index.html`.
  * **Priority 1000 (Default Watch Navigation Protection)**: Rule `95020` catching `^https?://(www\\.)?youtube\\.com/watch\\?.*` (`main_frame` requests only) redirecting unapproved videos to the block page with target URL.
  * **Subresource Protection**: Explicitly restricts rules to `resourceTypes: ["main_frame"]`. Scripts, stylesheets, fonts, playback APIs, and video stream chunks from `googlevideo.com` and `youtube.com` remain 100% unblocked.
* **RE2 Memory Limit Compliance & Rule Isolation**:
  * Replaced nested regex groups with RE2-safe pattern (`^https?://(www\\.)?youtube\\.com/watch\\?.*`) avoiding the 2KB RE2 compiled bytecode limit in Chrome DNR.
  * Isolated dedicated rule namespace `[95000, 99900]`. Updated `BlockerManager.getExistingRuleIds()` to prevent general domain blocking from clearing YouTube Guard session rules.
  * Zero-flicker configuration hashing (`mode:sessionId:approvedIds`) ensures idempotent synchronization without rule flapping.
* **Block Page Auto-Verification & Auto-Recovery ([public/extension/block-page/index.html](file:///d:/JEE/public/extension/block-page/index.html))**:
  * Automatically extracts `v=` parameter from blocked URLs and performs background verification via `VERIFY_AND_UNLOCK_VIDEO`.
  * Instantly forwards to verified lectures upon approval, or provides "Report / Request Review" and "Return to Study" buttons.
  * Listens for session termination to auto-redirect the user back to their destination URL once study mode ends.
* **Comprehensive Test Coverage & Live Browser Verification**:
  * Unit/DNR test suite ([tests/youtube-guard-dnr.test.ts](file:///d:/JEE/tests/youtube-guard-dnr.test.ts)): Tests namespace determinism, priority hierarchy, subresource protection, 5-point master gate, and BlockerManager isolation.
  * Live Chromium headless test runner ([tests/puppeteer-extension-verification.mjs](file:///d:/JEE/tests/puppeteer-extension-verification.mjs)): Validates initial 0 rules, session start 11 rules, approved video priority 2000 installation, pause cleanup, resume re-engagement, and terminal session teardown. All 6 browser integration tests pass 100%.
* **Chrome Extension Companion v1.2.0 Milestone Release ([manifest.json](file:///d:/JEE/public/extension/manifest.json), [background.js](file:///d:/JEE/public/extension/background.js), [content.js](file:///d:/JEE/public/extension/content.js))**:
  * Bumped extension version to `v1.2.0` across manifest, service worker (`const EXTENSION_VERSION = "1.2.0"`), content script handshake, and popup header tag.
  * Generated and verified production PKZip binary distribution [public/FocusForge-Extension-v1.2.0.zip](file:///d:/JEE/public/FocusForge-Extension-v1.2.0.zip) (~110 KB) and updated fallback `public/FocusForge-Extension.zip`.
  * Updated Next.js static download route `/api/download-extension` to serve `FocusForge-Extension-v1.2.0.zip` with verified binary headers.
  * Synchronized website home page (`src/app/page.tsx`): updated version badges (`v1.2.0 Verified PKZip`, `v1.2.0 Stable`), installation guide modal, and interactive Release Notes modal.
  * Updated `presenceService.ts` and `extensionService.ts` fallback versions to `1.2.0`.

## [1.6.0] — 2026-09-22

### 🎬 YouTube Study Content Guard — Commercial-Grade Focus Video Filtering & Verification Engine
* **Master Rule Gating & Fail-Open Non-Interference**:
  * Enforces `youtubeGuardEnabled = authenticated && session.status === "ACTIVE" (focus) && verifiedSessionId === currentSessionId && leaseIsValid`.
  * If no study session is active, or during breaks, paused states, completion, or unauthenticated use, YouTube is completely unrestricted and untouched.
  * Stale locks eliminated via 2-minute rolling lease timestamps with presence heartbeat refresh.
* **Academic Taxonomy & Multi-Signal Semantic Classifier ([src/services/youtubeGuardService.ts](file:///d:/JEE/src/services/youtubeGuardService.ts))**:
  * Full curricular coverage across JEE Main, JEE Advanced, NEET, and CBSE Class 12:
    * **Physics**: Units, Kinematics, Dynamics, Work-Power-Energy, Rotational Motion, Gravitation, Solids, Fluids, Thermodynamics, KTG, Oscillations, Waves, Electrostatics, Current Electricity, Magnetism, EMI, AC, Optics, Dual Nature, Atoms, Nuclei, Semiconductors.
    * **Chemistry**: Mole Concept, Atomic Structure, Periodic Table, Bonding, Thermodynamics, Equilibrium, Redox, Solutions, Electrochemistry, Kinetics, D/F-Block, Coordination, Haloalkanes, Alcohols, Aldehydes/Ketones/Acids, Amines, Biomolecules.
    * **Mathematics**: Sets/Relations/Functions, Trigonometry, Quadratic Equations, Sequences/Series, PNC, Binomial, Straight Lines, Circles, Conics, Limits/Continuity, Derivatives, AOD, Integrals, Differential Equations, Matrices/Determinants, Probability, Vectors/3D.
    * **Biology**: Cell Biology, Principles of Inheritance, Molecular Basis of Inheritance, Human Physiology, Plant Physiology, Human Reproduction, Sexual Reproduction in Flowering Plants, Ecology, Biotechnology (Principles & Applications).
    * **English Core (CBSE 12)**: Flamingo Prose (The Last Lesson, Lost Spring, Deep Water, Rattrap, Indigo, etc.), Flamingo Poetry (My Mother at Sixty-Six, Keeping Quiet, Thing of Beauty, etc.), Vistas (Tiger King, Journey to the End of the Earth, Enemy, etc.), Writing Skills (Notice Writing, Formal Letters, Report Writing).
  * Seeded trusted channels: Mohit Tyagi, Physics Wallah, Unacademy JEE/NEET, Vedantu, Khan Academy India, Eduniti, MathonGo, LearnoHub, NCERT Official, Apni Kaksha, Biology at Ease, Garima Goel, Neha Agrawal, Pankaj Sir, Simran Sahni, Magnet Brains, English Academy, Dear Sir.
  * Negative distraction penalty system: Deflects gaming, Minecraft speedruns, aesthetic 5 AM routines, student tech reviews, meme compilations, pop culture challenges, and ambient chill music.
  * YouTube Shorts strictly prohibited during active study sessions regardless of title keywords.
* **Supabase Cloud Schema & Realtime Publications ([supabase/migrations/20260922_youtube_study_guard.sql](file:///d:/JEE/supabase/migrations/20260922_youtube_study_guard.sql))**:
  * 6 PostgreSQL tables: `youtube_topics`, `youtube_trusted_channels`, `youtube_allowed_videos`, `youtube_classification_cache`, `youtube_guard_settings`, `youtube_access_logs`.
  * Multi-layer RLS policies and Realtime publication replication.
* **Next.js Backend API Surface (`/api/youtube/*`)**:
  * Classification endpoint (`/api/youtube/classify`)
  * Guard settings & academic scope (`/api/youtube/settings`)
  * Trusted channels manager (`/api/youtube/channels`)
  * User allowed video whitelist (`/api/youtube/allowed-videos`)
  * Taxonomy catalog query (`/api/youtube/topics`)
  * Distraction-free study lecture search (`/api/youtube/search`)
  * Verified watch time & telemetry logs (`/api/youtube/logs`)
* **Companion Chrome Extension Guard Engine ([public/extension/background.js](file:///d:/JEE/public/extension/background.js), [public/extension/content.js](file:///d:/JEE/public/extension/content.js))**:
  * Targeted Declarative Net Request rules redirect `/shorts/*` and `/feed/*` (in strict mode) while keeping watch pages inspectable.
  * SPA navigation observer hooks `yt-navigate-finish`, `yt-page-data-updated`, and history state transitions.
  * Non-intrusive FocusForge block overlay for intercepted distraction content with review options.
  * Active study watch-time metering only while tab is visible and video actively playing.
  * Popup status badge (`🟢 ON` during focus, `🟡 OFF` on pause, `⚪ OFF` when idle).
* **Blocker & Analytics Web Interfaces ([src/app/blocker/page.tsx](file:///d:/JEE/src/app/blocker/page.tsx), [src/app/analytics/page.tsx](file:///d:/JEE/src/app/analytics/page.tsx))**:
  * Blocker page upgraded with 3-tab layout: `YouTube Study Guard`, `Distraction Shields`, `Companion Extension`.
  * Realtime Master Rule status card, mode selectors (Strict, Balanced, Custom), academic scope checklist, trusted channel manager, approved video manager, taxonomy explorer, and distraction-free lecture player.
  * Analytics page enhanced with YouTube Verified Study Analytics panel displaying verified watch-time, subject breakdowns, distraction interception tallies, and audit event logs.
* **Automated Test Suite & Verification ([tests/youtube-study-guard.test.ts](file:///d:/JEE/tests/youtube-study-guard.test.ts))**:
  * 6 test suites covering Master Rule constraints, 16 curriculum subjects/topics across JEE/NEET/CBSE, 9 distraction penalty cases, Shorts blocking, memory cache performance (< 1ms hits), and manual whitelist overrides. All passing.

## [1.5.5] — 2026-09-22

### 🌐 Production Domain Linking & Companion Extension Alignment (`jee-made-easy-by-ilham.vercel.app`)
* **Dynamic Web Host Detection & Bridge Handshake ([public/extension/content.js](file:///d:/JEE/public/extension/content.js))**:
  * Rewrote `checkIsFocusForgeHost` to recognize the production domain `jee-made-easy-by-ilham.vercel.app`, any host containing `jee-made-easy` or `focusforge`, and fallback DOM meta detection (`<meta name="focusforge-app">` / `<meta name="application-name" content="FocusForge">`).
  * Dispatches `FOCUSFORGE_REGISTER_WEBAPP_ORIGIN` with `window.location.origin` so the service worker, popup, and block screens dynamically adapt to the live hosting origin.
  * Added resilient multi-stage handshake execution (`document_start`, `DOMContentLoaded`, `load`, and intervals at 500ms, 1500ms, 3000ms) to ensure Next.js React client hydration attaches without missing auth tokens.
  * Automatically sets `data-focusforge-extension="1.1.0"` on `document.documentElement` and emits `FOCUSFORGE_EXTENSION_PONG` for instant client-side detection.
* **Service Worker Domain Whitelist & Immediate Presence ([public/extension/background.js](file:///d:/JEE/public/extension/background.js))**:
  * Whitelisted `jee-made-easy-by-ilham.vercel.app` and `vercel.app` in Declarative Net Request system allow rules (Priority 20000).
  * Excluded `jee-made-easy-by-ilham.vercel.app` and `jee-made-easy` from `cleanDomains`, `isDistractingDomain`, and `recordBlockedAttempt`, ensuring the study app is never treated as a distraction.
  * Broadened `notifyFocusForgeTabs` to forward events to `jee-made-easy-by-ilham.vercel.app` tabs.
  * Triggered `sendPresenceHeartbeat()` immediately upon `FOCUSFORGE_SET_AUTH_SESSION` and `FOCUSFORGE_SYNC` instead of delaying up to 60 seconds on alarms.
* **Dynamic Navigation & Origin Routing ([public/extension/popup/popup.js](file:///d:/JEE/public/extension/popup/popup.js), [public/extension/pause-guard.js](file:///d:/JEE/public/extension/pause-guard.js), [public/extension/block-page/index.html](file:///d:/JEE/public/extension/block-page/index.html))**:
  * Replaced hardcoded `http://localhost:3000` URLs across the popup, pause guard, and block pages with dynamic origin routing via `focusforge_webapp_origin` (defaulting to `https://jee-made-easy-by-ilham.vercel.app`).
  * Updated popup version tag to `v1.1.0`.
* **In-Tab Extension Presence Recognition ([src/app/blocker/page.tsx](file:///d:/JEE/src/app/blocker/page.tsx), [src/app/layout.tsx](file:///d:/JEE/src/app/layout.tsx))**:
  * Added `<meta name="application-name" content="FocusForge" />` and `<meta name="focusforge-app" content="true" />` to layout head.
  * Added handshake listeners and `data-focusforge-extension` checks in `/blocker` to provide instant UI feedback of extension connectivity.
* **Automated Tests & Re-packaged Archive ([tests/extension-sync-distraction.test.ts](file:///d:/JEE/tests/extension-sync-distraction.test.ts), [scripts/package-extension.js](file:///d:/JEE/scripts/package-extension.js))**:
  * Added test assertions verifying `jee-made-easy-by-ilham.vercel.app` is protected from distraction tracking and correctly matched.
  * Re-generated and verified `public/FocusForge-Extension-v1.1.0.zip` (95.91 KB) and `public/FocusForge-Extension.zip`.

## [1.5.4] — 2026-09-21

### ⏱️ Universal Distraction Tracking & Blocked Attempt Telemetry Plane
* **Universal Distraction Tracking on Every External Visit ([public/extension/background.js](file:///d:/JEE/public/extension/background.js))**:
  * Rewrote `isDistractingDomain`: every external website visited by the user is actively monitored as a distraction/browsing activity, while strictly excluding internal hosts (`localhost`, `127.0.0.1`, `focusforge`, `supabase`) and approved IIT-JEE study platforms (`DEFAULT_WHITELISTED_STUDY_SITES`).
  * Expanded `DEFAULT_WHITELISTED_STUDY_SITES` to include key learning portals: `khanacademy.org`, `physicswallah.live`, `unacademy.com`, `nta.ac.in`, `jeemain.nta.ac.in`, `allen.ac.in`, `vedantu.com`, `byjus.com`, `doubtnut.com`, `embibe.com`, `esaral.com`, `mathongo.com`, `marks.app`, `exams.nta.ac.in`, and study search engines.
  * Lowered the visit duration threshold from 60s to $\ge 1\text{s}$ in `finalizeActiveDistraction`, ensuring all visits across websites are recorded into `distraction_logs` without being silently discarded.
* **Blocked Attempt Interception & Telemetry ([public/extension/background.js](file:///d:/JEE/public/extension/background.js), [public/extension/block-page/index.html](file:///d:/JEE/public/extension/block-page/index.html))**:
  * Added `recordBlockedAttempt(domain, url)` with 3-second event deduplication to record intercepted visits to blocked sites as `blocked: true`, `duration_seconds: 0`.
  * Added `RECORD_BLOCKED_ATTEMPT` message handler in `background.js` and hooked `chrome.tabs.onUpdated` block page detector.
  * `block-page/index.html` dispatches `RECORD_BLOCKED_ATTEMPT` upon page load.
* **Real-time Distraction Log Bridge ([src/app/tracker/page.tsx](file:///d:/JEE/src/app/tracker/page.tsx))**:
  * Extended `handleMessage` to listen for `FOCUSFORGE_DISTRACTION_LOGGED` postMessages from the companion extension.
  * Prepends newly finalized visits and blocked attempts directly into the JEE Tracker's live `logs` state and synchronizes with `blockerService.logVisit`.
* **Automated Test Suite Expansion ([tests/extension-sync-distraction.test.ts](file:///d:/JEE/tests/extension-sync-distraction.test.ts))**:
  * Added Test 26: Universal Distraction Tracking On Every External Site Visit.
  * Added Test 27: Whitelist Study Resource & Internal Site Exclusions.
  * Added Test 28: Low Duration Threshold ($\ge 1\text{s}$) & Blocked Attempt Telemetry.
  * 28/28 tests passing.
* **Extension ZIP Re-packaging ([scripts/package-extension.js](file:///d:/JEE/scripts/package-extension.js))**:
  * Rebuilt and verified `public/FocusForge-Extension-v1.1.0.zip` and fallback `public/FocusForge-Extension.zip`.

## [1.5.3] — 2026-09-21

### 🛡️ Continuous Session Architecture, Zero-Flicker Blocker Engine & Stable Telemetry Plane
* **Strict Control Plane vs Telemetry Plane Separation ([public/extension/background.js](file:///d:/JEE/public/extension/background.js))**:
  * Decoupled routine cloud data synchronization from the local session runtime. Cloud sync is strictly telemetry & data synchronization; it NEVER resets active session state, restarts timers, recreates visits, or touches the blocker control plane.
  * In `reconcileWithCloud`: added `isSameSession` idempotency check (`isFocusActive && activeSessionId === activeSession.id && sessionStatus === targetStatus`). If true, logs continuity preservation and performs a **NO-OP for the Session Control Plane**, preserving active session bounds, start timestamps, and active distraction tracking.
* **Zero-Flicker DNR Blocker Engine with Config Hash ([public/extension/background.js](file:///d:/JEE/public/extension/background.js))**:
  * Introduced `currentInstalledBlockerHash = null` and `computeBlockerConfigHash(mode, domains)`.
  * In `enforceActiveRules` and `enforcePauseGuardRules`: if incoming configuration hash matches `currentInstalledBlockerHash` and rules are active, immediately returns as a **NO-OP**.
  * Eliminates DNR rule recreation flicker, drops in rule coverage, and redundant tab reloading loops that previously allowed requests to slip through and disrupted active tracking.
  * Blocker hash is cleanly invalidated when switching modes (`focus` vs `paused`), when clearing rules, or when temporary allow exceptions change.
* **Continuous Distraction Tracking & Single Stable `visitId` ([public/extension/background.js](file:///d:/JEE/public/extension/background.js))**:
  * Enforced single continuous tracking instance: distraction visits on the same tab and domain keep accumulating with the original immutable `visitId` (UUID) and `startTimeMs`.
  * Routine cloud sync and presence heartbeats never fragment an active distraction visit or spawn duplicate visit records.
  * Only genuine tab switches or navigation away finalize a visit; short visits under 60 seconds are filtered, and qualifying visits (>= 60s) are recorded as a single continuous block.
* **Fail-Closed Blocker Invariant ([public/extension/background.js](file:///d:/JEE/public/extension/background.js))**:
  * In `reconcileWithCloud`: if Supabase queries encounter network errors, timeouts, or transient dropouts (`sessErr`), the extension logs a warning and preserves the active blocker rules intact.
  * Blocker disengagement occurs ONLY upon verified terminal events (`COMPLETED`, `ABANDONED`, `CANCELLED`) or explicit cloud deactivation.
* **Telemetry Outbox Buffer & Resilient Wake Continuity ([public/extension/background.js](file:///d:/JEE/public/extension/background.js))**:
  * Added `telemetryOutbox`, `enqueueTelemetry()`, and `flushTelemetryOutbox()`.
  * Finalized distraction logs that fail cloud upsert due to network dropouts are buffered in `telemetryOutbox` and persisted in `chrome.storage.local`.
  * `flushTelemetryOutbox()` runs on periodic alarms (`focusforge_heartbeat`) and startup wake to reliably sync queued telemetry once connectivity returns.
  * On service worker hydration, restores `activeTracking` (`visitId`, `startTimeMs`) and `telemetryOutbox`.
* **Continuous Countdown Synchronization ([public/extension/popup/popup.js](file:///d:/JEE/public/extension/popup/popup.js), [public/extension/background.js](file:///d:/JEE/public/extension/background.js))**:
  * In `computeAccurateRemaining` and `computeTimeLeft`: prioritized pure immutable timestamp derivation (`startTime && plannedDurationMinutes`) over `syncTimestamp`.
  * Ensures countdown timer monotonically decrements with zero clock drift and never jumps back to zero upon routine synchronization.
* **Automated Test Suite Expansion ([tests/extension-sync-distraction.test.ts](file:///d:/JEE/tests/extension-sync-distraction.test.ts))**:
  * Added Test 21: Idempotent Cloud Sync & Zero-Flicker Blocker Engine (10 identical syncs = 0 rule reinstalls, 0 tab reloads).
  * Added Test 22: Continuous Distraction Tracking Across Routine Syncs (5-minute visit maintains single stable `visitId` across 5 sync cycles).
  * Added Test 23: Fail-Closed Blocker Invariant Under Network Outages (network timeout preserves active blocker).
  * Added Test 24: Telemetry Outbox Buffer & Service Worker Wake Continuity (offline buffering, deduplication, and flush upon reconnection).
  * 24/24 test suites passing.
* **Chrome Extension v1.1.0 Milestone Release & Website Alignment ([manifest.json](file:///d:/JEE/public/extension/manifest.json), [page.tsx](file:///d:/JEE/src/app/page.tsx), [route.ts](file:///d:/JEE/src/app/api/download-extension/route.ts))**:
  * Bumped extension version to `1.1.0` in `public/extension/manifest.json` and `background.js` (`const EXTENSION_VERSION = "1.1.0"`).
  * Generated and verified production PKZip binary archive `FocusForge-Extension-v1.1.0.zip` (95.88 KB) and updated `FocusForge-Extension.zip`.
  * Purged all stale zip artifacts (`v1.0.4.zip`, `v1.0.5.zip`, `v1.0.6.zip`, `v1.0.7.zip`, `v1.0.8.zip`, `v1.0.9.zip`).
  * Updated `GET /api/download-extension` to serve `FocusForge-Extension-v1.1.0.zip` with verified binary headers.
  * Synchronized website home page (`src/app/page.tsx`): updated version badge (`v1.1.0 Verified PKZip`), version stat (`v1.1.0 Stable`), file size (`~96.0 KB`), date (`September 2026`), guide modal installation instructions, and rich interactive Release Notes modal.
  * Updated Blocker Settings (`src/app/blocker/page.tsx`), `extensionService.ts`, and `presenceService.ts` fallback versions to `v1.1.0`.

## [1.5.2] — 2026-09-21

### 💎 Unified Study Session Architecture & Authoritative Cloud Reconcile Engine
* **Single Authoritative Writer & Decoupling ([src/store/use-study-store.ts](file:///d:/JEE/src/store/use-study-store.ts), [src/services/studySessionService.ts](file:///d:/JEE/src/services/studySessionService.ts))**:
  * Decoupled `focusService` from `useStudyStore`: removed all 7 conflicting `focusService.updateFocusState()` calls that were racing with `studySessionService` writes to `extension_state`.
  * Fixed Pause Flag Collision: in `studySessionService.updateActiveSessionStatus`, set `is_focus_active: true` during pause with `session_status: "paused"`. Previously, `is_focus_active: status === "active"` set it to `false`, tricking `reconcileWithCloud` into falsely terminating paused sessions.
  * Preserved frozen `time_left_seconds` in `extension_state` and broadcast events during pause.
* **StudySessionManager & Zero-Rule Guarantee ([public/extension/background.js](file:///d:/JEE/public/extension/background.js))**:
  * Implemented canonical `StudySessionManager` with states: `NO_SESSION`, `ACTIVE`, `PAUSED`, `COMPLETED`, `ABANDONED`, `CANCELLED`.
  * Enforced Zero-Rule Guarantee: whenever state is not `ACTIVE` or `PAUSED`, all DNR session and dynamic rules and temporary allow exceptions are unconditionally purged (`activeRuleCount = 0`).
  * Added direct DNR rule inspection on periodic heartbeat alarm (`focusforge_heartbeat`): if inactive and any DNR rules exist, immediately purges them.
  * Added wake-from-sleep session expiration check on SW startup: if stored session duration has already elapsed by clock time and not paused, immediately marks inactive before network requests.
* **Tab Auto-Recovery Across Guard & Block Pages ([public/extension/background.js](file:///d:/JEE/public/extension/background.js), [public/extension/block-page/index.html](file:///d:/JEE/public/extension/block-page/index.html))**:
  * In `cleanupTerminalSession`, enhanced open tab destination resolution to inspect both `targetUrl` and `url` search parameters: `const targetUrl = u.searchParams.get("targetUrl") || u.searchParams.get("url")`. Ensures tabs on `pause-guard.html` and `block-page/index.html` are cleanly restored back to their destination.
* **Instant Reactivity & Telemetry Drawer in Companion Popup ([public/extension/popup/popup.js](file:///d:/JEE/public/extension/popup/popup.js))**:
  * Added `chrome.storage.onChanged` listener in `popup.js` for instant 0ms state reflection without waiting for poll intervals.
  * In `GET_EXTENSION_STATUS`, added bounded 400ms reconciliation race so popup opens with fresh verified cloud data while maintaining instantaneous paint.
  * Removed duplicate obsolete root files `public/extension/popup.js` and `popup.html`.
* **Automated Test Suite Expansion ([tests/extension-sync-distraction.test.ts](file:///d:/JEE/tests/extension-sync-distraction.test.ts))**:
  * Added Test 17: Pause -> Resume rule transitions and temporary exception pruning.
  * Added Test 18: Pause -> Complete terminal zero-rule guarantee.
  * Added Test 19: Offline/sleep wake idempotent session expiry check.
  * Added Test 20: Auto-recovery destination resolution with `targetUrl` parameter across block and guard pages.
  * 20/20 test suites passing.

## [1.5.1] — 2026-09-21

### 🛡️ End-to-End Study Session Completion Sync, DNR Rule Purge & Tab Auto-Recovery
* **Atomic Database Session Completion & Defensive Sweeps ([src/services/studySessionService.ts](file:///d:/JEE/src/services/studySessionService.ts), [src/store/use-study-store.ts](file:///d:/JEE/src/store/use-study-store.ts))**:
  * Implemented `completeActiveSession` in `studySessionService.ts`: explicitly executes `UPDATE public.study_sessions SET status = 'completed', completed = true, end_time = nowIso, actual_duration_minutes = ..., updated_at = nowIso WHERE id = sessionId AND user_id = userId`.
  * Added defensive active session sweep: `UPDATE public.study_sessions SET status = 'completed', completed = true WHERE user_id = userId AND status IN ('active', 'paused')`.
  * Upserts `extension_state`: `is_focus_active: false`, `session_status: "idle"`, `active_session_id: null`, `time_left_seconds: 0`.
  * Cached broadcast channels awaiting `SUBSCRIBED` status to eliminate dropped `STUDY_SESSION_COMPLETED` events.
  * In `useStudyStore.completeSession`, captured `activeId = activeSession?.id` and passed explicit `sessionId`, `userId`, and `sessionStatus: "idle"` to the web-to-extension bridge.
* **Unconditional Terminal Cleanup & DNR Rule Purge ([public/extension/background.js](file:///d:/JEE/public/extension/background.js))**:
  * Fixed trap in `cleanupTerminalSession` that previously ignored terminal events if `incomingSessionId !== currentSessionId`. Added verification against `userId` and unconditional registration into `terminalSessionIds`.
  * Enforced invariant: on terminal session completion, `activeRuleCount = 0`, `isFocusActive = false`, `sessionStatus = "idle"`, `timeLeftSeconds = 0`, and all DNR session/dynamic rules and temporary allow rules are purged.
  * Added open tab recovery: immediately queries all open tabs and restores tabs sitting on `block-page/index.html` or `pause-guard.html` back to their destination URL (`https://instagram.com/`, etc.).
* **Authoritative Cloud Reconciliation on Popup Open & Startup ([public/extension/background.js](file:///d:/JEE/public/extension/background.js), [public/extension/popup/popup.js](file:///d:/JEE/public/extension/popup/popup.js))**:
  * In `GET_EXTENSION_STATUS`, background service worker proactively initiates `reconcileWithCloud(authenticatedUserId)` to verify cloud status without serving stale MV3 cached states.
  * In `reconcileWithCloud`, queried `extension_state` and `study_sessions` in parallel; deactivates and cleans up immediately if `extension_state.is_focus_active === false` or if no active/paused sessions exist.
  * In `computeTimeLeft`, strictly returns 0 for `completed`, `abandoned`, `cancelled`, and `idle` states.
  * In `popup.js`, strictly renders `NO_ACTIVE_SESSION` (`00:00`, `SHIELD READY`, `0 (Idle)`) when session is terminal or idle, hiding live distraction tickers.
* **Block Page Invariant Auto-Recovery ([public/extension/block-page/index.html](file:///d:/JEE/public/extension/block-page/index.html))**:
  * Added auto-redirect inside `updateSessionCard()`: if the study session is no longer active, the block page automatically redirects to the destination domain/url without user interaction.
  * Added `chrome.storage.onChanged` listener to instantly trigger redirect upon state change.
* **Automated Test Expansion ([tests/extension-sync-distraction.test.ts](file:///d:/JEE/tests/extension-sync-distraction.test.ts))**:
  * Added Test 15 verifying session completion invariant (0 DNR rules, auto-recovery URL resolution).
  * Added Test 16 verifying authoritative cloud reconciliation override (`extension_state.is_focus_active: false`).
  * 16/16 test suites passing.

## [1.5.0] — 2026-09-21

### ⚡ Architectural Study Session ↔ Extension Synchronization & Blocker Reconciliation
* **Supabase Single Authoritative Source of Truth ([public/extension/background.js](file:///d:/JEE/public/extension/background.js), [src/services/studySessionService.ts](file:///d:/JEE/src/services/studySessionService.ts))**:
  * Fixed critical ghost session bug in `reconcileWithCloud`: replaced brittle `.eq("completed", false)` query with strict `.in("status", ["active", "paused"])`. Prevents cancelled or abandoned sessions (which previously had `completed: false`) from being resurrected as active focus zones on service worker wake or browser restart.
  * Added `extStateChannel` on `extension_state` table to listen for `is_focus_active: false` in real time and trigger instantaneous terminal cleanup.
* **One-Way Irreversible Terminal State Machine ([public/extension/background.js](file:///d:/JEE/public/extension/background.js), [src/store/use-study-store.ts](file:///d:/JEE/src/store/use-study-store.ts))**:
  * Defined canonical Study Session lifecycle: `IDLE`, `ACTIVE`, `PAUSED`, `COMPLETED`, `ABANDONED`, `CANCELLED`.
  * Added `terminalSessionIds` set and `cleanupTerminalSession` helper in `background.js`: once a session enters `completed`, `abandoned`, or `cancelled`, it can never be reactivated by out-of-order Realtime events or cached local storage.
  * Added dedicated `abandonActiveSession` in `studySessionService.ts` recording `status: "abandoned"`, `completed: true`, `end_time`, `actual_duration_minutes`, and broadcasting `STUDY_SESSION_ABANDONED`.
  * Added `abandonSession()` in `useStudyStore` and wired up Study page Abandon button and Emergency Abort modal.
* **Guaranteed Blocker Invariant & DNR Reconciliation ([public/extension/background.js](file:///d:/JEE/public/extension/background.js))**:
  * Enforced safety rule: `blockerEnabled = authenticated && session.status === "active" && blockingEnabled === true`.
  * If no active session exists in Supabase, all DNR session and dynamic rules are unconditionally purged (`activeRuleCount = 0`). Temporary pause exceptions and allow rules are completely cleared.
* **Authoritative Timestamp-Derived Synchronized Timers ([src/store/use-study-store.ts](file:///d:/JEE/src/store/use-study-store.ts), [public/extension/background.js](file:///d:/JEE/public/extension/background.js), [public/extension/popup/popup.js](file:///d:/JEE/public/extension/popup/popup.js))**:
  * Website timer, service worker timer, and extension popup timer derive elapsed and remaining time authoritatively from timestamps (`start_time`, `planned_duration_minutes`, `paused_at`, `resumed_at`), eliminating clock drift and runaway counters.
  * On terminal states (`completed`, `abandoned`, `cancelled`, `idle`), remaining time is strictly 0 and the popup immediately displays `"No Active Session"` with `"SHIELD READY"`.
* **Bridge Timing & Race Condition Elimination ([src/store/use-study-store.ts](file:///d:/JEE/src/store/use-study-store.ts))**:
  * Fixed `notifyBridge` so that `completeSession`, `abandonSession`, and `cancelSession` dispatch `sessionStatus: "idle"` and `isFocusActive: false` synchronously without transmitting stale active metadata.
* **Automated Test Suite Expansion ([tests/extension-sync-distraction.test.ts](file:///d:/JEE/tests/extension-sync-distraction.test.ts))**:
  * Added Tests 11 through 14 verifying:
    * Test 11: Irreversible terminal states (anti-resurrection invariant).
    * Test 12: Supabase active session query invariant (ignoring cancelled/abandoned records).
    * Test 13: Timestamp-derived timer calculation and zero clock drift across sessions.
    * Test 14: Defensive blocker safety rule across all session statuses.
  * 14/14 automated test suites passing.

## [1.4.3] — 2026-09-21

### 🛡️ Clean Navigation Dispatch & Status Handshake Architecture (v1.0.9)
* **Decoupled Handshake & Tab Navigation ([public/extension/background.js](file:///d:/JEE/public/extension/background.js))**:
  * In `RESOLVE_PAUSE_GUARD`, `ALLOW_TEMPORARY_URL`, and `ALLOW_TEMPORARY_DOMAIN`, the Service Worker now dispatches `sendResponse(res)` *before* initiating `chrome.tabs.update()`.
  * Prevents the message port from prematurely terminating while the tab navigates, eliminating any `lastError` or false-failure states in the Pause Guard UI.
* **Refined Realtime Loading Sequence ([public/extension/pause-guard.js](file:///d:/JEE/public/extension/pause-guard.js))**:
  * Adhered strictly to Master Spec Section 16 & 17: button click displays `"Allowing this page..."` / `"Allowing this site..."`, followed immediately on verified rule confirmation by `"Loading Instagram..."` (or Discord, YouTube, Reddit).
  * Removed the aggressive 120ms `window.location.replace()` race condition. Navigation is owned 100% by the Service Worker via `chrome.tabs.update()`.
* **Tab ID Dual-Channel Resolution ([public/extension/pause-guard.js](file:///d:/JEE/public/extension/pause-guard.js))**:
  * Resolves `currentTabId` via `chrome.tabs.getCurrent()` inside `pause-guard.js` and transmits it in the payload, guaranteeing bulletproof tab resolution even if `sender.tab.id` is delayed.
* **Extension Packaging & Version Bump ([public/extension/manifest.json](file:///d:/JEE/public/extension/manifest.json), [public/extension/background.js](file:///d:/JEE/public/extension/background.js))**:
  * Bumped extension version to `1.0.9`.
  * Generated fresh binary PKZip archive `FocusForge-Extension-v1.0.9.zip` (99.36 KB) and updated `FocusForge-Extension.zip`.

## [1.4.2] — 2026-09-21

### 🚀 Permanent Elimination of In-Page DOM Block Overlay (`#focusforge-block-overlay`) & Version 1.0.8
* **Complete Code Removal of `#focusforge-block-overlay` ([public/extension/content.js](file:///d:/JEE/public/extension/content.js))**:
  * Permanently deleted `renderFocusOverlay()`, `evaluateInPageShield()`, and all in-page DOM injection routines that previously created the "Focus Zone Active" modal overlay on top of web pages.
  * Replaced with an active cleanup mechanism (`purgeBlockOverlay()`) that immediately strips any lingering or cached `#focusforge-block-overlay` element from the DOM at script execution, `DOMContentLoaded`, and `window.load`.
  * Preserved the clean Web-to-Extension communication bridge for Supabase auth, session sync, and live distraction tracking on FocusForge web hosts (`localhost:3000`).
* **Open Tab Management via Native Chrome Navigation ([public/extension/background.js](file:///d:/JEE/public/extension/background.js))**:
  * When Active Focus begins (`enforceActiveRules`), already open tabs on blocked domains are cleanly redirected via `chrome.tabs.update()` to `block-page/index.html`.
  * When a session pauses (`enforcePauseGuardRules`), already open tabs on blocked domains (without active exceptions) are redirected via `chrome.tabs.update()` to `pause-guard.html`.
  * When a user clicks **Continue to This Page** or **Continue on This Site**, the tab-scoped DNR allow rule (Priority 10000) permits the target website (`discord.com`, `instagram.com`, etc.) to load 100% cleanly without any in-page DOM overlay or modal interference.
* **Extension Packaging & Version Bump ([public/extension/manifest.json](file:///d:/JEE/public/extension/manifest.json), [scripts/package-extension.js](file:///d:/JEE/scripts/package-extension.js))**:
  * Bumped manifest and background worker version to `1.0.8`.
  * Re-built and validated PKZip archive `FocusForge-Extension-v1.0.8.zip` (99.11 KB) and updated `FocusForge-Extension.zip`.

## [1.4.1] — 2026-09-21

### 🛠️ Urgent Fix: Pause Guard Continue Navigation Loop & Tab-Scoped DNR Exception Engine
* **Elimination of Infinite Redirect Loop ([public/extension/background.js](file:///d:/JEE/public/extension/background.js), [public/extension/pause-guard.js](file:///d:/JEE/public/extension/pause-guard.js), [public/extension/pause-guard.html](file:///d:/JEE/public/extension/pause-guard.html))**:
  * **Root Cause**: Previously, `pause-guard.js` triggered navigation via `window.location.replace()` before the service worker confirmed the DNR rule, and literal `urlFilter` failed to match HTTP 301/302 redirects or subresources on social sites (such as Instagram's redirect from `/` to `/accounts/login/` or query param variants). As a result, the Priority 100 Pause Guard redirect rule matched the redirected request and looped back to the guard page.
  * **Service Worker As Single Source of Truth**: The extension service worker now exclusively governs exception rule installation and tab navigation. `pause-guard.js` sends `RESOLVE_PAUSE_GUARD`, disables buttons, displays loading feedback (`Allowing this page...` / `Loading Instagram...`), and leaves navigation to the service worker.
  * **Rule Priority Calibration**: Escalated developer-defined priority: `SYSTEM_ALLOW_PRIORITY = 20000`, `TEMPORARY_ALLOW_PRIORITY = 10000`, `BLOCK_RULE_PRIORITY = 100`. The temporary allow exception strictly dominates the block/redirect rule.
  * **Tab-Scoped Session Rules (`tabIds: [tabId]`)**: Scoped temporary allow rules to the requesting tab only (`tabIds: [numericTabId]`), ensuring other browser tabs remain protected.
  * **Explicit Rule Verification Before Navigation**: Implemented `BlockerManager.verifyTemporaryRule(tabId, ruleId)` querying `chrome.declarativeNetRequest.getSessionRules()` to ensure the rule is active and matched before calling `chrome.tabs.update(tabId, { url: validUrl })`.
  * **Robust Regex Matching**: Replaced brittle literal strings with path-aware regexes supporting query parameters, anchors, trailing slashes, and subresources (`main_frame`, `stylesheet`, `script`, `image`, `xmlhttprequest`, etc.).
  * **Zero Stale Rules & Strict Expiration**:
    * Session Resume (`handleSessionResumed`): Immediately purges all temporary exceptions, engages normal blocker rules, and redirects open tabs on blocked domains back to the block page.
    * Session Complete / Cancel (`handleSessionCompleted`, `handleSessionCancelled`): Flushes all temporary exceptions and blocker rules.
    * Tab Close (`chrome.tabs.onRemoved`): Automatically cleans up exceptions scoped to the closed tab.
    * Navigation Away (`chrome.tabs.onUpdated`): Cleans up single-page exceptions when navigating to a different domain.
    * Startup Reconciliation (`reconcileWithCloud`): Prunes exceptions for closed tabs and purges all exceptions if the session is no longer paused.
  * **Secondary In-Page Shield Isolation in Content Script ([public/extension/content.js](file:///d:/JEE/public/extension/content.js))**:
    * **Root Cause Discovered via DOM Inspection (`#focusforge-block-overlay`)**: While the DNR engine successfully allowed the network navigation to `instagram.com`, `content.js` previously evaluated `isFocusActive === true` without verifying `sessionStatus !== "focus"` or checking active temporary exceptions. Consequently, upon page load, `content.js` injected `<div id="focusforge-block-overlay">` over the loaded social site with "Focus Zone Active".
    * **Strict Focus-Only Gating**: `evaluateInPageShield()` now strictly requires `state.sessionStatus === "focus"`. If the session is `paused`, `idle`, or if the requesting tab/domain has an active temporary exception, `removeFocusOverlay()` is immediately invoked and overlay rendering is completely suppressed.
    * **Dual Storage & Service Worker Confirmation**: Content script checks local persistent storage for temporary exceptions and queries the background service worker via `CHECK_TAB_BLOCK_STATUS` before ever considering rendering an in-page block.
    * **Real-Time Storage & Message Cleanup**: Listens to `chrome.storage.onChanged` and `REMOVE_BLOCK_OVERLAY` runtime messages to instantly remove any lingering overlay elements from the DOM the moment a session pauses or an exception is granted.
  * **Automated Tests & Extension Package Update ([tests/extension-sync-distraction.test.ts](file:///d:/JEE/tests/extension-sync-distraction.test.ts))**:
    * Updated test suite asserting `TEMPORARY_ALLOW_PRIORITY = 10000` and tab-scoped `tabIds: [tabId]`. 10/10 test suites passing.
    * Re-packaged `FocusForge-Extension-v1.0.7.zip` (100.54 KB) and updated `FocusForge-Extension.zip`.

## [1.4.0] — 2026-09-21

### 🛡️ Master Re-Architecture: Pause Guard, Dual-Priority DNR Rules, Real-Time Distraction & Break Tracking
* **Pause Guard Engine & Interception Architecture ([public/extension/pause-guard.html](file:///d:/JEE/public/extension/pause-guard.html), [public/extension/pause-guard.js](file:///d:/JEE/public/extension/pause-guard.js), [public/extension/background.js](file:///d:/JEE/public/extension/background.js))**:
  * Distracting and social sites are no longer silently permitted during paused study sessions.
  * In `SESSION_PAUSED` state, navigation is redirected to a dark glassmorphic **Pause Guard** interceptor (`pause-guard.html`) displaying the target domain, original URL, session context, and clear actionable choices.
  * Three user pathways: *Back to Dashboard* (navigates to FocusForge), *Continue to This Page* (allows specific URL only), and *Continue on This Site* (allows domain for remainder of pause).
* **Dual-Priority Declarative Net Request Rules Hierarchy ([public/extension/background.js](file:///d:/JEE/public/extension/background.js))**:
  * Implemented strict 3-tier DNR priority structure:
    * `SYSTEM_ALLOW_PRIORITY = 2000`: Localhost, Supabase, and core learning whitelist.
    * `TEMPORARY_ALLOW_PRIORITY = 1000`: Scoped session exceptions granted via Pause Guard.
    * `BLOCK_RULE_PRIORITY = 100`: Active Focus redirects (`block-page/index.html`) and Paused Session redirects (`pause-guard.html`).
  * Temporary exceptions override pause guard rules cleanly without altering or deleting entries from the persistent `blocked_sites` table in Supabase.
* **Separation of Study Waste Time vs Pause Break Time ([src/services/analyticsService.ts](file:///d:/JEE/src/services/analyticsService.ts), [src/services/blockerService.ts](file:///d:/JEE/src/services/blockerService.ts))**:
  * Database schema extended with `session_state`, `activity_type`, `ended_at`, and `visit_id` on `distraction_logs`.
  * Browsing during paused breaks is categorized as `activity_type = 'pause_break'` and tracked in `totalBreakMinutes` / `totalBreakSeconds`.
  * `totalWastedMinutes` and `totalWastedSeconds` strictly aggregate non-break distraction visits during active focus sessions. Blocked attempts contribute 0 seconds.
* **Real-Time Live Ticker Bridge (Zero DB Write Storms) ([public/extension/background.js](file:///d:/JEE/public/extension/background.js), [public/extension/content.js](file:///d:/JEE/public/extension/content.js), [src/app/tracker/page.tsx](file:///d:/JEE/src/app/tracker/page.tsx))**:
  * Background service worker maintains a running second-by-second visit ticker in `chrome.storage.local` (`focusforge_live_tracking`).
  * `content.js` relays updates to the web app via `window.postMessage` (`FOCUSFORGE_LIVE_TRACKING`).
  * Live status banner rendered in the extension popup and on the `/tracker` page with animated pulse indicators and live elapsed timers.
  * Visits are persisted to Supabase REST only after completion (tab switch, window blur, URL change) and only if duration is $\ge 60$ seconds.
* **Purge of Simulated Distraction Debt ([src/store/use-study-store.ts](file:///d:/JEE/src/store/use-study-store.ts), [src/services/syncService.ts](file:///d:/JEE/src/services/syncService.ts), [src/app/study/page.tsx](file:///d:/JEE/src/app/study/page.tsx), [src/app/tracker/page.tsx](file:///d:/JEE/src/app/tracker/page.tsx))**:
  * Fully purged `simulatedDistractions` array, `logSimulatedDistraction`, and fake manual triggers (`+2m YouTube`, etc.) across the codebase.
  * `recordDistractionTime` delegates directly to `blockerService.recordDistractionTime` with 0 duration on blocked attempts and genuine measured seconds on unblocked visits.
* **Immediate Re-Lock on Session Resume & Boundary Clamping ([public/extension/background.js](file:///d:/JEE/public/extension/background.js))**:
  * Transitioning from paused to active focus (`SESSION_ACTIVE`) instantly flushes all temporary allow rules, clamps any in-flight pause break logs, and re-engages Priority 100 block rules.
  * Session completion or cancellation wipes all blocker and guard rules, returning normal browsing behavior.
* **Automated Test Coverage & Extension Packaging v1.0.7 ([tests/extension-sync-distraction.test.ts](file:///d:/JEE/tests/extension-sync-distraction.test.ts), [scripts/package-extension.js](file:///d:/JEE/scripts/package-extension.js))**:
  * Added Tests 7-10 verifying DNR priority hierarchy, Pause Guard redirect generation, activity type separation, scoped temporary allow rules, and state transition cleanup (10/10 test suites passing, 0 TypeScript errors).
  * Packaged `FocusForge-Extension-v1.0.7.zip` (95.95 KB) with full integrity checks.

## [1.3.9] — 2026-09-21

### 🛡️ Master Re-Architecture: Declarative Session Blocker, Dual Realtime Pipeline & Distraction Registry
* **Declarative Net Request Session Rules Engine ([public/extension/background.js](file:///d:/JEE/public/extension/background.js))**:
  * Fully migrated URL blocking to Manifest V3 Session Rules (`chrome.declarativeNetRequest.updateSessionRules`), ensuring rules persist strictly in browser memory and clear reliably on session termination.
  * Rules strictly bind to `SESSION_ACTIVE` state and automatically clear on `SESSION_PAUSED`, session completion, session cancellation, or user logout.
  * Added sweeping cleanup for lingering dynamic rules (`updateDynamicRules`) to eliminate ghost blocks.
* **Dual-Layer Realtime Event Pipeline ([src/services/studySessionService.ts](file:///d:/JEE/src/services/studySessionService.ts), [src/services/blockerService.ts](file:///d:/JEE/src/services/blockerService.ts), [public/extension/background.js](file:///d:/JEE/public/extension/background.js))**:
  * Implemented sub-50ms instant control channel via Supabase Broadcast (`focusforge_control_${userId}`) emitting `STUDY_SESSION_STARTED`, `STUDY_SESSION_PAUSED`, `STUDY_SESSION_RESUMED`, `STUDY_SESSION_COMPLETED`, `STUDY_SESSION_CANCELLED`, and `BLOCK_LIST_CHANGED`.
  * Combined broadcast events with Supabase Postgres Changes listeners on `study_sessions` and `blocked_sites`, backed by `reconcileWithCloud` periodic safety net.
* **Distraction Tracking & Session Boundary Clamping ([public/extension/background.js](file:///d:/JEE/public/extension/background.js), [src/services/blockerService.ts](file:///d:/JEE/src/services/blockerService.ts))**:
  * Enforced strict $\ge 60$s threshold for distraction waste time. Visits under 60 seconds are discarded; blocked navigation attempts strictly generate 0 waste time.
  * Fixed duration calculation in `blockerService.ts` to prevent unblocked visits or blocked attempts from defaulting to 1 minute.
  * Handled session boundary clamping: in-flight distraction logs are cleanly finalized when a study session completes or is cancelled.
  * Added active tab switching and window blur/focus listeners to record accurately with idempotent `visitId` upserts.
* **Multi-User Isolation & Teardown Handshake ([public/extension/background.js](file:///d:/JEE/public/extension/background.js), [public/extension/content.js](file:///d:/JEE/public/extension/content.js))**:
  * Implemented `FOCUSFORGE_LOGOUT` handler: immediately unbinds Supabase Realtime channels, clears DNR session and dynamic rules, wipes local state from `chrome.storage.local`, and resets state machine to `AUTHENTICATION_REQUIRED`.
* **Tracker Page Domain Aggregation & Incident Drawers ([src/app/tracker/page.tsx](file:///d:/JEE/src/app/tracker/page.tsx))**:
  * Added `viewMode` toggle (`Grouped by Domain` vs `All Logs`).
  * Implemented domain-level rollups displaying total wasted time (`Xm Ys`), visit counts, blocked attempts, and active session breach counts.
  * Added expandable child incident drawers and one-click domain-level log deletion.
* **Popup Telemetry & Diagnostics Drawer ([public/extension/popup/](file:///d:/JEE/public/extension/popup/))**:
  * Added expandable live diagnostics drawer displaying extension status, user UUID, realtime channel status, active DNR session rules count, active session ID, and installation UUID.
* **Automated Test Coverage ([tests/extension-sync-distraction.test.ts](file:///d:/JEE/tests/extension-sync-distraction.test.ts))**:
  * Added unit tests for domain aggregation calculations and broadcast control payload validation. All 6 test suites passing.

## [1.3.8] — 2026-09-21

### ⚡ Master Real-Time Integration: Website ↔ Chrome Extension ↔ Supabase ↔ Blocker
* **Supabase Realtime & PostgreSQL Database Hardening ([supabase/schema.sql](file:///d:/JEE/supabase/schema.sql))**:
  * Provisioned `public.extension_presence` table with strict Row Level Security (RLS) policies (`auth.uid() = user_id`) and index on `(user_id, last_seen_at DESC)`.
  * Configured `REPLICA IDENTITY FULL` on `study_sessions`, `blocked_sites`, `distraction_logs`, `extension_state`, and `extension_presence` to ensure column-filtered Realtime payloads emit reliably on UPDATE/DELETE events.
  * Added `extension_presence`, `blocked_sites`, and `distraction_logs` to the `supabase_realtime` publication on the production Supabase database (`yhcowzmcvlsmcffbqryb`).
* **Web-to-Extension Auth Session Bridge ([src/context/AuthContext.tsx](file:///d:/JEE/src/context/AuthContext.tsx), [public/extension/content.js](file:///d:/JEE/public/extension/content.js))**:
  * Configured `AuthContext` to broadcast `FOCUSFORGE_AUTH_SESSION` (containing `access_token`, `refresh_token`, `expires_at`, and `user`) whenever Supabase auth state initializes or transitions.
  * Handshake protocol: content script sends `FOCUSFORGE_REQUEST_AUTH_SESSION` on page load, receiving credentials immediately without requiring user re-authentication.
  * Extension content script forwards session to `background.js` via `chrome.runtime.sendMessage`, allowing `supabaseClient.auth.setSession(...)` to authenticate the service worker.
* **Chrome Extension Service Worker Rebuild ([public/extension/background.js](file:///d:/JEE/public/extension/background.js))**:
  * Eliminated unauthenticated `anon` queries that previously returned empty results due to RLS.
  * Generated and persisted stable UUID `installation_id` in `chrome.storage.local`.
  * Emits periodic presence heartbeat every minute to `extension_presence` with device metadata.
  * Subscribes to `study_sessions` and `blocked_sites` via authenticated Supabase Realtime channels with automatic reconnect and fallback reconciliation.
  * Implemented deterministic DNR Dynamic Rule IDs generated via mathematical domain hashing (`1..2000000000`), redirecting blocked traffic to `block-page/index.html`.
  * Implemented central active tab distraction tracking for continuous browsing >= 60 seconds (discarding visits < 60 seconds and zero-second blocked interceptions).
* **Block Page & Distraction Decoupling ([public/extension/block-page/index.html](file:///d:/JEE/public/extension/block-page/index.html), [src/services/analyticsService.ts](file:///d:/JEE/src/services/analyticsService.ts))**:
  * Removed legacy `LOG_DISTRACTION` call from `block-page/index.html` that previously inflated waste time by 60 seconds on every blocked navigation attempt.
  * Updated `analyticsService.calculateDistractionAnalytics`: blocked requests contribute 0 wasted minutes and 0 wasted seconds. Continuous browsing < 60 seconds is discarded from waste time aggregation.
* **Presence Liveness & Real UI States ([src/services/presenceService.ts](file:///d:/JEE/src/services/presenceService.ts), [src/services/extensionService.ts](file:///d:/JEE/src/services/extensionService.ts), [src/app/blocker/page.tsx](file:///d:/JEE/src/app/blocker/page.tsx))**:
  * Built `presenceService` with real-time Supabase subscription and 2-minute timeout threshold (`isDeviceOnline`).
  * Removed all hardcoded mock `connected: true` states and fake device generators in `/blocker`.
* **Extension Popup UI & Packaging v1.0.6 ([public/extension/popup/](file:///d:/JEE/public/extension/popup/), [scripts/package-extension.js](file:///d:/JEE/scripts/package-extension.js))**:
  * Updated extension to `v1.0.6` with live active tab inspector, authentic status pills (`Active Focus`, `Paused`, `Live Connected`, `Syncing`, `Disconnected`, `Not Linked`), and unauthenticated warning banner.
  * Automated extension packaging with binary PKZip integrity checks (`public/FocusForge-Extension-v1.0.6.zip` and `public/FocusForge-Extension.zip`).
* **Automated Testing ([tests/extension-sync-distraction.test.ts](file:///d:/JEE/tests/extension-sync-distraction.test.ts))**:
  * Added unit test suite covering distraction threshold filtering, blocked attempt separation, domain matching/anti-spoofing, deterministic DNR rule ID generation, and presence liveness timeouts. All tests passing.

## [1.3.7] — 2026-09-20

### 🎧 Master Sound Architecture, Category Bus, Sensory Onboarding & Full UX Upgrade
* **Multi-Category Audio Routing Engine ([src/lib/sound-manager.ts](file:///d:/JEE/src/lib/sound-manager.ts))**:
  * Added 6 isolated sound categories: `ui`, `study`, `navigation`, `notification`, `extension`, `system`.
  * Implemented proportional category volume scaling (`effectiveVolume = masterVolume * categoryVolume * cueVolume`).
  * Added category enable/mute toggles (`setCategoryEnabled`, `isCategoryEnabled`) with instant loop and playback suppression.
  * Added intelligent sound priority hierarchy (`LOW`, `MEDIUM`, `HIGH`, `CRITICAL`) with automatic cooldown suppression of routine micro-clicks when high-priority milestone/error cues play.
  * Added multi-theme sound pack switching support (`glass`, `minimal`, `soft`, `zen`).
  * Added cue preview method (`previewCue`) for instant auditory verification in settings, bypassing active mutes.
  * Added one-click reset to factory audio defaults (`resetToDefaults`).
* **Calm Sound Onboarding Banner ([src/components/ui/sound-onboarding-toast.tsx](file:///d:/JEE/src/components/ui/sound-onboarding-toast.tsx))**:
  * Built non-blocking, accessible first-time sound choice banner mounted in `WorkspaceLayout`.
  * Explicit user gesture unlock primes Web Audio context (`await soundManager.unlock()`) without triggering browser autoplay blocks.
  * Persistent user onboarding state (`focusforge:sfx-onboarded`).
* **Comprehensive Sound Settings Experience ([src/components/settings/sound-settings-panel.tsx](file:///d:/JEE/src/components/settings/sound-settings-panel.tsx), [src/app/profile/page.tsx](file:///d:/JEE/src/app/profile/page.tsx))**:
  * Integrated dedicated "Audio & Sensory Experience" tab inside `/profile` with direct deep-link (`#sound-settings`).
  * Master sound toggle and proportional master volume slider.
  * Acoustic Theme Language selector (`Glass`, `Minimal`, `Soft`, `Zen`).
  * 4-card category routing matrix with independent switches and volume sliders.
  * 8-cue interactive audition suite (`Study Start`, `Focus Milestone`, `Session Complete`, `Mistake Journal Log`, `Distraction Shield`, `AI Coach Reply`, `Rank Milestone Up`, `UI Micro-Tap`).
  * Accessibility guarantee notice and one-click "Reset Defaults" action.
* **Header Audio Quick Link ([src/components/header.tsx](file:///d:/JEE/src/components/header.tsx))**:
  * Enhanced header audio dropdown with active sound pack indicator and direct shortcut to full sound settings.
* **Full Website UX & Micro-Interaction Polish Across All 12 Routes**:
  * Audited and connected acoustic feedback and micro-interactions across `/`, `/dashboard`, `/study`, `/mistakes`, `/revisions`, `/jee`, `/tracker`, `/blocker`, `/coach`, `/analytics`, `/profile`, `/login`.
  * Preserved real data calculations from Supabase and client Zustand stores with zero mock numbers or fake statistics.
* **Automated Testing**:
  * Expanded `tests/sound-manager.test.ts` to test category routing, category volume scaling, priority throttling, preview cues, and defaults reset. All 11 test suites passing.

## [1.3.6] — 2026-09-20

### 🔊 UI Sound Effects Architecture (`uisfx` • `glass` pack)
* **Sound Pack Decision (`glass`)**:
  * Evaluated all 12 sound packs from the canonical `uisfx` catalog. Selected the **`glass`** pack ("bright, crystalline, and premium") for its 1:1 tactile synergy with FocusForge's dark liquid-glass aesthetic (`@samasante/liquid-glass`), crystalline study timers, and ambient rainfall/binaural focus audio.
* **Centralized Sound Engine ([src/lib/sound-manager.ts](file:///d:/JEE/src/lib/sound-manager.ts))**:
  * Instantiated a client-only, SSR-safe singleton using `createUISFX({ pack: 'glass', volume: 0.7, enabled: savedSoundPreference })`.
  * Configured user gesture capture (`pointerdown`, `keydown`) to unlock the Web Audio context cleanly without autoplay blocks.
  * Added safety suppression for background and asynchronous cues before the first genuine gesture.
  * Implemented idempotent loop management (`startLoop`, `stopLoop`, `stopAllLoops`) with retained `PlayingSFX` handles, guaranteeing termination on exit paths, timeouts, unmounts, or mute.
  * Added throttled cue playback (`playThrottled`) and unthrottled low-volume key feedback (`playTyping`).
  * Built complete localStorage preference persistence for enabled state, volume, and pack name.
* **Accessible Sound Preference Controls ([src/components/header.tsx](file:///d:/JEE/src/components/header.tsx))**:
  * Integrated dedicated "UI Sound Effects (uisfx • glass pack)" controls directly inside the top header audio panel.
  * Accessible toggle switch (`role="switch"`, `aria-checked`, `aria-label`) with instant `ON` / `MUTED` badges.
  * Immediate mute calling `soundManager.stopAll()` and clearing all active loops.
  * Smooth volume range slider with throttled `volume-change` audio feedback.
* **Semantic Product Event Sound Mapping Across Workflows**:
  * **AI Study Coach ([src/app/coach/page.tsx](file:///d:/JEE/src/app/coach/page.tsx))**: Wired `send` on inquiry submission, active `processing` loop during diagnostic inference with guaranteed cleanup in `finally` and on unmount, `receive` on response delivery, and unthrottled `typing` feedback during prompt input.
  * **Study Session & Timers ([src/store/use-study-store.ts](file:///d:/JEE/src/store/use-study-store.ts), [src/app/study/page.tsx](file:///d:/JEE/src/app/study/page.tsx))**: Wired `start` on focus session initiation, `pause` on pause, `play` on resume, `stop` on session cancel, `warning` at 30 seconds remaining, `checkpoint` pings for last 5 seconds, `complete` triumphant chime on session finish, `reward` on celebratory completion, `select` on subject change, and `choose` on chapter pick.
  * **Mistake Journal ([src/app/mistakes/page.tsx](file:///d:/JEE/src/app/mistakes/page.tsx))**: Wired `success` on log creation/edit, `warning` on form validation error, `check` on marking understood, `checkpoint` on needs-more-practice, `stash` on archiving, `unstash` on restoration, `delete` on committed log deletion, `open`/`close` on drawer and review modals, and `select` on tab switching.
  * **Web Blocker ([src/app/blocker/page.tsx](file:///d:/JEE/src/app/blocker/page.tsx))**: Wired `lock` when adding blocked domain, `unlock` on domain removal, `check` on allowed list additions, `delete` on allowed list deletions, `connect` on companion sync, `disconnect` on device disconnection, `toggle-on`/`toggle-off` on whitelist switch, and `lock`/`unlock` on exam mode toggle.
  * **Logout Confirmation ([src/components/ui/logout-modal.tsx](file:///d:/JEE/src/components/ui/logout-modal.tsx))**: Wired `open` on dialog display, `cancel` on cancellation, and `disconnect` + `soundManager.stopAll()` on confirmed sign-out.
  * **Navigation & Shortcuts ([src/components/sidebar.tsx](file:///d:/JEE/src/components/sidebar.tsx), [src/hooks/use-keyboard-shortcuts.ts](file:///d:/JEE/src/hooks/use-keyboard-shortcuts.ts))**: Wired `expand`/`collapse` on sidebar toggles, and `select` on navigation clicks and `Alt+` shortcuts.
* **Automated Test Suite ([tests/sound-manager.test.ts](file:///d:/JEE/tests/sound-manager.test.ts))**:
  * Added automated tests verifying SSR safety, default `glass` pack, volume clamping, user gesture unlock suppression, loop idempotency, loop cleanup on mute, and throttled execution. Integrated `npm test` script.

## [1.3.5] — 2026-09-19

### 🎨 Desktop & Mobile UI Minimal Polish, Spacing & Gapping Architecture
* **Streamlined Desktop 3D Companion Stage ([src/components/3d/RobotScene.tsx](file:///d:/JEE/src/components/3d/RobotScene.tsx))**:
  * **Eliminated Container-in-Container Clutter**: Removed nested card frames, redundant secondary headers ("Baymax Forge" vs "FORGEBOT COMPANION v3.0 3D"), and floating formula chips that obscured the robot.
  * **Full-Bleed 3D Stage**: Allowed the 3D robot to breathe in open cybernetic space with soft ambient lighting and cyber grid background.
  * **Unified Top-Left Floating Pill**: Sleek floating glass badge (`ForgeBot 3D • ● FOCUSED`) with dynamic state-driven colors and animated indicator dots.
  * **Bottom Floating Action Dock**: Compact glassmorphic dock framed with `BorderBeam` containing live telemetry (`120 FPS Active`), dynamic status description, and 5 streamlined reaction pills (`Focus`, `Type`, `Privacy`, `Peek`, `Victory`) with 20px `ThinkingOrb` indicators.
* **Mobile Fluid Spacing & Zero Horizontal Overflow ([src/app/login/page.tsx](file:///d:/JEE/src/app/login/page.tsx))**:
  * **Zero-Overflow Mobile Viewport Guarantee**: Constrained form container with `w-full max-w-md mx-auto px-4 sm:px-8 min-w-0`, preventing horizontal spillage and clipping across all mobile devices (tested down to 360px–390px).
  * **Mobile Reactive Companion Touch**: Added an elegant header pill featuring a live 20px `ThinkingOrb` and `ForgeBot` tag, reacting in real time to student typing, password privacy shutter, and victory states.
  * **Structured Form Sections (Sign Up Mode)**: Categorized dense inputs into two distinct, beautifully spaced logical groups (`01. ACCOUNT CREDENTIALS` and `02. JEE PREPARATION TARGET`) with single-row exam year pill selectors (2027–2030).
  * **Ergonomic Action Hierarchy**: Relocated "Explore as Demo Aspirant" (with `BorderBeam` and `ThinkingOrb`) into a sleek quick-connect bar next to Google Login, allowing the primary email/password fields to remain front and center without unnecessary vertical scrolling.

## [1.3.4] — 2026-09-19

### 📱 Responsive Layout, Magnetic Physics & Form Ergonomics Polish
* **Mobile-First Responsive Layout & Fluid Viewport Scaling ([src/app/login/page.tsx](file:///d:/JEE/src/app/login/page.tsx))**:
  * **Adaptive Robot & Form Shell**: Upgraded auth view grid with responsive max-width (`max-w-md lg:max-w-5xl xl:max-w-6xl`), adaptive gap scaling, and proportional vertical spacing (`py-6 sm:py-10 px-4 sm:px-6`).
  * **Compact Companion Mode for Mobile**: Dynamically scales the 3D ForgeBot container height (`h-[220px] sm:h-[280px] lg:h-[380px]`) and centers on small viewports with glass framing, ensuring high performance and zero overlap.
  * **Touch Target Optimization**: Full 44px+ touch targets on all interactive fields, pills, and selects.
  * **Ergonomic Country & Target Exam Fields**: Refactored country and daily study goal inputs into responsive grid (`grid-cols-1 sm:grid-cols-2`) preventing horizontal layout clipping on narrow mobile screens.
  * **Magnetic Action Physics**: Integrated smooth spring physics (`Magnetic` component) on the primary authentication button with custom micro-animations.
  * **Enhanced Safe Area Support**: Added bottom padding safe zones on mobile views (`pb-6 sm:pb-2`).

## [1.3.3] — 2026-09-18

### 🤖 High-Performance 3D Robot Companion ("ForgeBot") & Full Defect Resolution Pass
* **Articulated 3D Robot ("ForgeBot") ([src/components/3d/RobotScene.tsx](file:///d:/JEE/src/components/3d/RobotScene.tsx))**:
  * **Charming Porcelain Cybernetic Chassis**: Beautiful rounded head, curved dark gloss visor faceplate, ear sensors, and cybernetic limbs.
  * **Procedural Blinking Cyan OLED Eyes**: Natural eye blinking with ambient lookAt mouse tracking.
  * **Articulated Kinematics & Privacy Reactions**:
    * **Stealth Privacy Mode (`stealth`)**: Physically raises both mechanical hands to cover its eyes and blushes pink cheeks (`opacity: 0.9`) when the password input is focused.
    * **Peeking Mode (`peek`)**: Drops left arm and peeks through fingers with curious glowing eye when password text is toggled visible.
    * **Typing Mode (`typing`)**: Bobs in sync with keystrokes with subtle air-typing arm gestures.
    * **Victory Celebration (`celebrate`)**: High jump, 360° spin, and raised arms upon successful authentication.
    * **Alert Mode (`error`)**: Gentle head shake upon invalid credentials or alerts.
  * **Integrated Quantum Arc Reactor Core (ThinkingOrb from `libraries.dev/orbs`)**:
    * Seamlessly embeds the live 64px `ThinkingOrb` directly in ForgeBot's chest cavity, morphing dynamically (`breathing`, `working`, `shaping`, `connecting`, `weaving`, `searching`).
  * **Dual 20px Satellite Formula Micro-Chips (User Reference Match)**:
    * Floating chips featuring $\nabla \times \mathbf{E} = -\frac{\partial \mathbf{B}}{\partial t}$ in `solving` mode and `AIR < 500 Goal` in `connecting` mode.
  * **`BorderBeam` Framing (from `libraries.dev`)**:
    * Encased in `<BorderBeam colorVariant="ocean" size="md" strength={0.85} duration={3.5}>`.
  * **Zero-Lag Three.js Performance Architecture**:
    * Replaced 2048x2048 shadow maps with lightweight radial contact shadow plane, eliminating all GPU lag.
    * Replaced deprecated `THREE.Clock` with delta timing via `performance.now()`.
    * Clamped pixel ratio `Math.min(window.devicePixelRatio, 1.5)` running at steady 60–120 FPS.
* **Defect Resolutions & Stability Hardening ([src/context/AuthContext.tsx](file:///d:/JEE/src/context/AuthContext.tsx), [src/app/login/page.tsx](file:///d:/JEE/src/app/login/page.tsx))**:
  * **React Infinite Render Loop Fix**: Wrapped `checkUsernameAvailability` in `useCallback` in `AuthContext` and guarded `setUsernameStatus` / `setUsernameSuggestions` state setters against empty state re-allocations, completely resolving `Maximum update depth exceeded`.
  * **Badge Collision & Overlap Elimination**: Removed redundant telemetry pills from `page.tsx` that previously collided with `RobotScene.tsx` at `bottom-6`, fixing the illegible text overlap and "Lag" artifact.
  * **Tab Switching Accessibility**: Assigned explicit accessibility IDs (`btn-tab-signin`, `btn-tab-create-account`) ensuring reliable tab toggling between "Sign In" and "Create Account".

## [1.3.2] — 2026-09-18

### ⚡ Ultra-Lightweight "Aura Forge Cognitive Core" & Zero-Lag Typing Architecture
* **Aura Forge Cognitive Core Entity ([src/components/3d/RobotScene.tsx](file:///d:/JEE/src/components/3d/RobotScene.tsx))**:
  * **Authentic `ThinkingOrb` Engine (libraries.dev/orbs)**: Replaced high-poly Three.js puppet (which consumed substantial GPU and caused typing lag) with an ultra-lightweight, 60–120 FPS 2D Canvas entity.
  * **Dynamic Action State Mapping**:
    * `breathing` (Resting): Gentle living ambient consciousness for the student's study companion.
    * `working` (Typing): High-speed particles orbiting on tilted planes, perfectly synchronized with keystrokes.
    * `shaping` (Privacy Shutter): Morphing cryptographic biometric shield when password input is focused.
    * `connecting` (Peeking): Neural constellation peeking when password visibility is unmasked.
    * `weaving` (Celebration): Tri-strand golden helix plaiting celebrating successful login.
    * `searching` (Security Diagnostics): Meridian scanning sweep upon invalid credentials or alerts.
  * **20px Satellite Micro-Orbs (Exact Reference Match)**: Integrated dual micro-orb processors directly matching user photo (`Formula Solver` running `solving` with `∇ × E = -∂B/∂t` and `Neural Vault` running `connecting` with `AIR < 500 Goal`).
  * **Libraries.dev `BorderBeam` Chamber**: Wrapped the quantum containment chamber in `<BorderBeam colorVariant="ocean" size="md" strength={0.9} duration={3.2}>` with ambient CSS-only glow fields.
  * **Cognitive Matrix State Explorer**: Integrated interactive 8-mode selector pills with 20px live micro-orbs allowing students to preview all 8 cognitive states in real time.
  * **Zero-Overhead 3D Mouse Perspective**: Implemented CSS 3D perspective (`perspective(1000px) rotateX(...) rotateY(...)`) for organic mouse tracking with zero WebGL draw calls.
* **Typing Latency Optimization & State Throttling ([src/app/login/page.tsx](file:///d:/JEE/src/app/login/page.tsx))**:
  * **Main-Thread Throttling**: Implemented `isTypingRef` latching in `notifyTyping()`. Typing 10+ characters only updates state *once* on initial keypress and resets 700ms after typing ceases, eliminating main-thread churn and typing lag completely.
  * **Demo Aspirant BorderBeam Button**: Wrapped guest onboarding in `<BorderBeam colorVariant="ocean" size="sm">` with embedded 20px `<ThinkingOrb state="solving" />`.

## [1.3.1] — 2026-09-18

### 🤖 3D Robot Companion ("Baymax Forge") & Next-Gen Interactive Auth Experience
* **Articulated 3D Kinematics & Cybernetic OLED Expressions ([src/components/3d/RobotScene.tsx](file:///d:/JEE/src/components/3d/RobotScene.tsx))**:
  * **Articulated Arm Chain**: Built multi-jointed arms (Shoulder ➔ Forearm ➔ Mitten Hand) enabling realistic eye-covering and gesturing without clipping.
  * **Procedural Eye Expressions & Blinking**: Cyan OLED eyes with randomized procedural blinking (3–6s) and multi-state reactions (`focused`, `stealth`, `peek`, `typing`, `celebrate`, `error`).
  * **Privacy Shutter Active (`stealth`)**: Robot covers its eyes and blushes with pink holographic cheeks when students focus on the password field.
  * **Peeking Mode (`peek`)**: Parts left arm and peeks curiously with one eye when password visibility is toggled.
  * **Quantum Arc Reactor Core**: Pulsating chest core with dynamic light emission that beats in rhythm with student interactions and keystrokes.
  * **Decoupled Floating Holographic JEE Datapad**: Hovering datapad with an authentic blueprint grid rendering actual IIT-JEE Maxwell, Schrödinger, Thermodynamics, and Calculus formulas.
  * **Holographic Orbital Rings**: Dual counter-rotating orbital rings with an active 3D orbiting cyan energy node.
* **Frictionless Auth Suite ([src/app/login/page.tsx](file:///d:/JEE/src/app/login/page.tsx))**:
  * **Sliding Tab Switcher**: Framer Motion `layoutId="auth-tab-indicator"` fluidly morphs between Sign In and Create Account.
  * **1-Click Demo Aspirant Access**: Prominent, zero-setup guest onboarding allowing immediate entry to the workspace.
  * **Real-Time Password Strength Checklist**: Interactive badge evaluation across 4 criteria (`8+ Chars`, `Uppercase`, `Number`, `Symbol`).
  * **Real-Time Username Availability**: Live debounced verification with smart alternative suggestions when taken.
  * **Tactile Magnetic Submit Button**: Primary action button wrapped in `<Magnetic strength={0.2}>`.
  * **Responsive Mobile 3D Viewport**: Integrated compact 3D companion viewport on mobile devices.

## [1.3.0] — 2026-09-18

### 🛡️ Enterprise Logout Architecture, Active Session Safety & Multi-Tab Broadcast Sync
* **Dual-Tier Server & Client Session Revocation**:
  * **Server Route Handler ([src/app/api/auth/logout/route.ts](file:///d:/JEE/src/app/api/auth/logout/route.ts))**: POST endpoint that signs out via `@supabase/ssr` server client, actively revoking HTTP session cookies on the response.
  * **Client Hardening ([src/context/AuthContext.tsx](file:///d:/JEE/src/context/AuthContext.tsx))**: Signs out via `supabase.auth.signOut({ scope: "local" })`, purges all local and session storage tokens (`focusforge_active_uid`, `focusforge_guest_uid`, and Supabase cached JWTs), resets Zustand stores, and navigates to `/login?logged_out=true`.
* **Zero-Latency Cross-Tab Sync via `BroadcastChannel`**:
  * Established `BroadcastChannel("focusforge_auth_channel")` so signing out in any browser tab instantly notifies all other active tabs.
  * Other tabs immediately purge in-memory stores and navigate cleanly to `/login?reason=multi_tab_logout` without converting into a zombie guest session or flashing protected data.
* **Signature `<LogoutModal>` Interaction Primitive ([src/components/ui/logout-modal.tsx](file:///d:/JEE/src/components/ui/logout-modal.tsx))**:
  * **Viewport-Wide Portal (`createPortal`)**: Mounted modal to `document.body` with `useIsClient` guard, preventing CSS transform/filter containment by the parent sidebar and centering the modal across the entire display viewport.
  * **Minimal Centered Card**: Constrained card width to a sleek `410px` with ambient glow and backdrop blur across the full screen.
  * **Zero Overlap Flex Header**: Restructured header into a flex row separating the alert icon and the top-right close `X` button with generous spacing, eliminating any overlap.
  * **Active Focus Hazard Guard**: Detects if an active study session or mock test is in progress (`status === 'focus'`) and presents an explicit warning before any timer is discarded.
  * **Identity Verification**: Displays user avatar, name, `@handle`, and "Cloud Synced" status badge so aspirants know exactly which account is being closed.
  * **Tactile Micro-Interactions**: Spring physics, keyboard `Escape` dismissal, and `<Magnetic>` destructive button.
  * **Revocation Status**: Transitions into a live "Securing offline vault..." state with `<ThinkingOrb state="working" size={20}>`.
* **Ergonomics & Placement Upgrades**:
  * **[Sidebar](file:///d:/JEE/src/components/sidebar.tsx)**: Replaced the accidental-click 16px icon with a dedicated modal trigger button with distinct hover aura and tooltip.
  * **[Profile Page](file:///d:/JEE/src/app/profile/page.tsx)**: Added a dedicated "Account Session & Security" card allowing users to sign out directly from their profile.
  * **[Login Notification](file:///d:/JEE/src/app/login/page.tsx)**: Displays a reassuring emerald confirmation toast upon returning from logout.

## [1.2.9] — 2026-09-18

### 🎬 Universal GSAP Plugin Suite Registration & Fluid Magnetic Motion Architecture
* **Centralized SSR-Safe GSAP Configuration Engine ([src/lib/gsap.ts](file:///d:/JEE/src/lib/gsap.ts))**:
  * Registered all 25 core & advanced GSAP plugins (`useGSAP`, `ScrollTrigger`, `CustomEase`, `CustomBounce`, `CustomWiggle`, `Flip`, `Draggable`, `Observer`, `TextPlugin`, `ScrambleTextPlugin`, `DrawSVGPlugin`, `InertiaPlugin`, `MorphSVGPlugin`, `MotionPathPlugin`, `Physics2DPlugin`, `PhysicsPropsPlugin`, `PixiPlugin`, `ScrollSmoother`, `ScrollToPlugin`, `SplitText`, `RoughEase`, `ExpoScaleEase`, `SlowMo`, `EaselPlugin`, `GSDevTools`).
  * Enforced SSR hydration safety (`typeof window !== "undefined"`) preventing server render crashes or layout shifts.
* **GSAP Magnetic Interaction Primitive ([src/components/ui/magnetic.tsx](file:///d:/JEE/src/components/ui/magnetic.tsx))**:
  * Created hardware-accelerated magnetic cursor-tracking component using `gsap.quickTo` on X and Y axes with cubic-bezier spring return (`power3.out`).
  * Integrated `gsap.matchMedia` for `(prefers-reduced-motion: no-preference)`, automatically disabling physics for users who prefer reduced motion.
* **Landing Page Motion Choreography ([src/app/page.tsx](file:///d:/JEE/src/app/page.tsx))**:
  * Orchestrated hero entrance with `useGSAP` and `CustomEase` ("focusEase") for badge, headline, subhead, and CTAs.
  * Applied `<Magnetic>` to primary action buttons (`Launch Workspace` and `Download Extension`).
  * Configured `ScrollTrigger` batch reveals for the Companion Extension card and Interactive Feature Tour.
* **Study Session Tactility ([src/app/study/page.tsx](file:///d:/JEE/src/app/study/page.tsx))**:
  * Integrated `<Magnetic>` feedback on the primary "Complete Zone" study action button.

## [1.2.7] — 2026-09-17

### 🛡️ One Email = One Account & Session Persistence Hardening
* **Authoritative Email Uniqueness Enforcement**:
  * **Database Unique Index**: Created case-insensitive PostgreSQL unique index `profiles_email_lower_idx` on `public.profiles (LOWER(TRIM(email)))` ensuring zero duplicate profile rows can ever be written.
  * **Supabase GoTrue Duplicate Detection**: Added detection for Supabase's obfuscated signup response (`data.user.identities.length === 0`), preventing silent overwrite of existing account profile rows when signing up with an already-registered email address.
  * **Consistent Email Normalization**: Applied `.trim().toLowerCase()` consistently across signup, login, and password reset flows in both the UI and Auth layers.
  * **Interactive Duplicate Account UX**: Signup form captures duplicate attempts and displays the clear guidance `"An account with this email already exists. Please log in instead."` alongside an immediate "Log In Now" action button that switches to the login tab and pre-fills the email.
* **Persistent Session Management & Returning Users**:
  * Seamless returning user session hydration via Supabase Auth without forcing re-authentication.
  * Automatic missing profile recovery: if an existing Auth user is missing a `profiles` row, exactly one recovery profile is created without duplicating Auth accounts.
* **Zero Flash of Wrong User / Startup Skeletons**:
  * Implemented animated pulse skeleton states in **Sidebar**, **Header**, and **Dashboard** while the session and user profile are hydrating (`loading === true`), eliminating glitches of default/fallback statistics or guest usernames.
* **Complete Multi-Tab Logout & Store Isolation**:
  * Implemented and consolidated `resetStudyStore()` and `resetMistakeStore()` to purge all local Zustand state and remove `focusforge-study-storage` and `focusforge-mistakes-storage` from `localStorage` upon logout.
  * Added `storage` event synchronization across browser tabs so logging out in one tab instantly logs out all open tabs and purges cached student data, guaranteeing User B never inherits User A's sessions.

---

## [1.2.6] — 2026-09-17

### 🔐 Master Authentication, Real User Profile & Dynamic JEE Target System Overhaul
* **Supabase Authentication & Permanent Data Isolation**:
  * Fixed database triggers (`handle_new_user`) to automatically populate new user records with dynamic metadata (`country`, `target_exam`, `target_year`, `daily_goal`), zero starting statistics, and conflict upsert handlers.
  * Reset default column statistics in `public.profiles` so new accounts start with clean, authentic 0 metrics.
  * Added RLS public read access on `public.usernames` for real-time handle availability checks on signup.
  * Enabled `REPLICA IDENTITY FULL` on `public.profiles` for instant cross-tab and cross-device Realtime subscriptions.
* **Dynamic JEE Examination Target Year System ([src/lib/jee-years.ts](file:///d:/JEE/src/lib/jee-years.ts))**:
  * Implemented dynamic calculation for upcoming JEE examination cycles (`getUpcomingJeeYears(4)`), automatically advancing to the next cycle once the current year's exam season has passed.
  * Added validation (`isPastJeeYear`) to block past years from new registrations and display a warning banner on user profiles with outdated examination years.
  * Added reactive options generator (`getJeeExamOptions`) for JEE Main & Advanced, JEE Main only, and JEE Advanced only for any selected target cycle.
* **Authoritative Mathematical XP & Level Engine ([src/hooks/use-user-profile.ts](file:///d:/JEE/src/hooks/use-user-profile.ts))**:
  * Resolved discrepancy between level calculations (`sqrt(xp/100) + 1`) and visual progress bars (`xp % 1000`) across Sidebar, Header, Dashboard, and Profile.
  * Standardized all UI components on `useXpProgress()` and `xpService.getLevelProgress` for strictly synchronized lifetime XP, level, and next-tier progress metrics.
* **True Calendar-Based Study Streak Engine ([src/lib/streak-calc.ts](file:///d:/JEE/src/lib/streak-calc.ts))**:
  * Derived active study streaks strictly from completed session history (`calculateStreakFromSessions`) using local date keys.
  * Zero-session accounts accurately display 0-day streaks rather than hardcoded mock figures.
* **Component Polishing & Full Lifecycle Data Sync**:
  * **[Login / Signup](file:///d:/JEE/src/app/login/page.tsx)**: Added dynamic target year selector pills, target exam options, country select, and daily study goal inputs with instant username availability feedback.
  * **[User Profile](file:///d:/JEE/src/app/profile/page.tsx)**: Fully overhauled to display authenticated user data without fallback mock figures, added loading skeletons, past-year warning alerts, and an interactive Edit Profile modal with username checking.
  * **[Sidebar & Header](file:///d:/JEE/src/components/)**: Replaced hardcoded names and handles with reactive profile data and synchronized XP bars and streak badges.
  * **[Dashboard & Coach](file:///d:/JEE/src/app/)**: Personalized greetings, dynamic daily goal targets, and unified analytics metrics.

---

## [1.2.5] — 2026-09-05

### ☁️ Permanent Account Distraction Persistence & High-Efficiency O(N+M) Cognitive Analytics
* **Permanent Cloud Account Persistence for Distraction Logs & Waste Time**:
  * **Database Schema Migration**: Enhanced the Supabase `distraction_logs` table with `duration_seconds` (integer), `visit_count` (integer), `is_during_session` (boolean), and `session_id` (text) with complete anon/authenticated RLS policy coverage.
  * **Guest-to-Cloud Migration Engine ([blockerService.ts](file:///c:/Users/Lenovo/Desktop/JEE/src/services/blockerService.ts))**: Implemented `blockerService.migrateGuestLogs(userId)` which automatically detects any offline or guest distraction incident records and batch upserts them to the user's permanent Supabase account upon login or cloud sync.
  * **Account Cloud Hydration ([syncService.ts](file:///c:/Users/Lenovo/Desktop/JEE/src/services/syncService.ts))**: Integrated `blockerService.getVisitLogs(userId, 200)` directly into `syncService.hydrateUserData`, restoring all historical distraction incidents across any browser or device upon signing in.
  * **Multi-Device Real-Time Sync**: Attached a Supabase realtime channel listener on `distraction_logs` (`syncService.subscribeToUserRealtime`), instantly reflecting new distraction incidents across all open browsers and devices.
* **High-Performance O(N+M) Cognitive Calculation Engine ([analyticsService.ts](file:///c:/Users/Lenovo/Desktop/JEE/src/services/analyticsService.ts))**:
  * **Single-Pass Linear Aggregation**: Replaced redundant nested 7-day multi-filter loops with a pre-indexed date-keyed hash map (`calculateDistractionAnalytics`), accelerating calculation speed to O(N + M).
  * **JEE Questions Equivalent Lost**: Creatively calculates the number of JEE Main / Advanced questions lost based on a competitive solving pace (~3.5 minutes per numerical/PYQ problem).
  * **Peak Vulnerability Window Analysis**: Evaluates hourly distraction timestamps across 4 distinct cognitive slots (Late Night `22:00-04:00`, Early Morning `04:00-10:00`, Mid Day `10:00-16:00`, and Evening Prime `16:00-22:00`), identifying where focus leaks cluster and generating actionable psychological recommendations.
  * **Focus Leakage Index & In-Session Contamination Rate**: Determines the percentage of total study energy leaked and distinguishes leaks that breached active study sessions from casual off-session browsing.
* **Tracker Interface Upgrades ([tracker/page.tsx](file:///c:/Users/Lenovo/Desktop/JEE/src/app/tracker/page.tsx))**:
  * **4-Metric Cognitive Grid**: Displays Wasted Time, Productive Time, Focus Efficiency with severity pill, and Questions Lost indicator.
  * **Peak Vulnerability Diagnostic Banner**: Displays slot breakdown, in-session breach minutes, contamination rate, and behavioral coaching guidance.
  * **Dynamic Donut & Legend**: Shows exact minutes and percentages per domain with reactive filter indicators.

---

## [1.2.4] — 2026-09-05

### ⏱️ Automatic Social Media Waste Time Tracking & Real-Time Sync Engine
* **Automatic Social Media & Distraction Time Recording**:
  * Implemented an active tab and window focus tracking engine in [background.js](file:///c:/Users/Lenovo/Desktop/JEE/public/extension/background.js) across all major social media platforms (`youtube.com`, `instagram.com`, `reddit.com`, `x.com`, `tiktok.com`, `facebook.com`, `netflix.com`, `twitch.tv`, `discord.com`, etc.) and user-defined custom blocked sites.
  * Added dual-layer tracking with [content.js](file:///c:/Users/Lenovo/Desktop/JEE/public/extension/content.js): pulses every 6 seconds while the page is actively visible and focused, tracking video watching, scrolling, and interaction without battery waste.
  * Captures tab switches (`onActivated`), URL navigations (`onUpdated`), tab closures (`onRemoved`), and window minimization/blur (`onFocusChanged`), automatically accumulating and flushing exact seconds spent.
* **0ms Real-Time Sync to Web Application**:
  * Broadcasts `FOCUSFORGE_WASTE_TIME_UPDATE` events through the content script bridge into [workspace-layout.tsx](file:///c:/Users/Lenovo/Desktop/JEE/src/components/workspace-layout.tsx) and [use-study-store.ts](file:///c:/Users/Lenovo/Desktop/JEE/src/store/use-study-store.ts).
  * Implemented `blockerService.recordDistractionTime` and `useStudyStore.recordDistractionTime` to aggregate and accumulate time per visit session in local cache and Supabase cloud.
* **Creative Distraction Logs UI Upgrades ([tracker/page.tsx](file:///c:/Users/Lenovo/Desktop/JEE/src/app/tracker/page.tsx))**:
  * Enhanced every registry row with an illuminated **Duration Pill** (`⏳ X min wasted (Ys)`).
  * Added dynamic status badges: `📱 Active Social Browsing` vs `🛡️ Blocked Shield`.
  * Added session context badges: `🚨 Leaked in Focus Zone` vs `☕ Casual Browsing`.
  * Added quick test waste time buttons: `+ 2m YouTube`, `+ 15m YouTube`, `+ 5m Insta`.
* **Chrome Extension Popup Visual Enhancements ([popup.html](file:///c:/Users/Lenovo/Desktop/JEE/public/extension/popup/popup.html) / [popup.js](file:///c:/Users/Lenovo/Desktop/JEE/public/extension/popup/popup.js))**:
  * Upgraded stats strip to prominently display **Wasted Time** in red (`Xm`).
  * Upgraded the activity feed to display exact duration spent on social media (`⏳ 14m spent • youtube.com`).

---

## [1.2.3] — 2026-09-05

### 🗑️ Distraction Incident Registry Instant Delete & Clear All Fix
* **Resolved Delete Button Inoperability in Distraction Logs ([tracker/page.tsx](file:///c:/Users/Lenovo/Desktop/JEE/src/app/tracker/page.tsx))**:
  * **Root Cause Identified**: Clicking the trash icon previously filtered the component's `logs` state without deleting from Zustand's `simulatedDistractions`. Whenever `logs` became empty, `allLogs` automatically fell back to `simulatedDistractions`, causing deleted items to immediately reappear or fail to delete.
  * **Zustand Store Actions ([use-study-store.ts](file:///c:/Users/Lenovo/Desktop/JEE/src/store/use-study-store.ts))**: Added `deleteDistraction(id, domain)` and `clearDistractions()` to immediately update persisted Zustand state and decrement `distractionLogsCount`.
  * **Supabase PostgreSQL RLS Fix**: Added policy `Allow anon delete on distraction_logs` (`FOR DELETE TO anon USING (true)`), resolving silent database delete rejections.
  * **Unified Deduplication Memo**: Redesigned `allLogs` in [tracker/page.tsx](file:///c:/Users/Lenovo/Desktop/JEE/src/app/tracker/page.tsx) to merge and deduplicate entries from real database logs and simulated items by ID and domain/timestamp.
  * **Dual-Layer Deletion ([blockerService.ts](file:///c:/Users/Lenovo/Desktop/JEE/src/services/blockerService.ts))**: Upgraded `deleteVisitLog` to purge entries from `localStorage["focusforge_distraction_logs"]`, remove from Supabase cloud, and emit `focusforge_distraction_logged` event with domain fallback matching.
  * **Added "Clear All" Toolbar Button**: Added a red-accented Clear All button allowing aspirants to wipe all recorded distraction logs with 1 click.
  * **Added API DELETE Handler ([src/app/api/blocker/route.ts](file:///c:/Users/Lenovo/Desktop/JEE/src/app/api/blocker/route.ts))**: Added `DELETE` route handler supporting both single-log deletion (`?id=...`) and bulk wipe (`?all=true`).

---

## [1.2.2] — 2026-09-05

### 🕒 Creative Session History Time Display & Rock-Solid Distraction Shield Logging
* **Creative & Decent Study Session History Time Display**:
  * Added `getSessionTimeDetails` helper calculating exact wall-clock intervals (`04:30 PM → 05:15 PM`) using local user timezone formatting.
  * Designed an illuminated **Session Time Ribbon** in [study/page.tsx](file:///c:/Users/Lenovo/Desktop/JEE/src/app/study/page.tsx) featuring a recessed dark glass clock badge, Time-of-Day period pill (`🌅 Early Bird Dawn`, `☀️ Morning Peak`, `🌤️ Afternoon Focus`, `🌇 Evening Sprint`, `🌙 Night Owl Study`, `🌌 Midnight Deep Work`), and relative recency indicator (`Today • 2h ago`, `Yesterday`).
  * Updated [study-session-summary-modal.tsx](file:///c:/Users/Lenovo/Desktop/JEE/src/components/study/study-session-summary-modal.tsx) to display exact session start/end intervals and date directly in the completion banner.
* **Rock-Solid Distraction Log Feature Repair (Web App & Chrome Extension)**:
  * Fixed missing primary key `id` and column mismatches (`website`, `focus_session_id`, `duration_minutes`, `device`) in [background.js](file:///c:/Users/Lenovo/Desktop/JEE/public/extension/background.js) when inserting into Supabase `distraction_logs`.
  * Added Supabase Postgres RLS policies allowing `anon` role insert and select on `distraction_logs` with valid `user_id`.
  * Wired [block-page/index.html](file:///c:/Users/Lenovo/Desktop/JEE/public/extension/block-page/index.html) and [content.js](file:///c:/Users/Lenovo/Desktop/JEE/public/extension/content.js) to dispatch `LOG_DISTRACTION` messages to the service worker whenever a blocked site or DNR redirection occurs.
  * Bi-directional Extension-to-Web Relay: Background worker broadcasts `FOCUSFORGE_DISTRACTION_LOGGED` back to open web tabs via `content.js` and [workspace-layout.tsx](file:///c:/Users/Lenovo/Desktop/JEE/src/components/workspace-layout.tsx), instantly updating the active session's distraction counter without page reloads.
  * Upgraded [blockerService.ts](file:///c:/Users/Lenovo/Desktop/JEE/src/services/blockerService.ts) with dual-layer caching in `localStorage["focusforge_distraction_logs"]`, guaranteeing zero event drops for guest and offline users.
  * Added interactive 1-click test simulation buttons (`+ YouTube`, `+ Insta`) in [tracker/page.tsx](file:///c:/Users/Lenovo/Desktop/JEE/src/app/tracker/page.tsx).
  * Added a creative **Shield Interceptions Feed** directly inside the Chrome Extension popup ([popup.html](file:///c:/Users/Lenovo/Desktop/JEE/public/extension/popup/popup.html) / [popup.js](file:///c:/Users/Lenovo/Desktop/JEE/public/extension/popup/popup.js)) showing the latest blocked domains and timestamps.

---

## [1.2.1] — 2026-09-05

### ⏱️ Live Extension Countdown Sync, Creative Popup Ring & Permanent Blocker Storage
* **High-Precision Live Countdown Sync**:
  * Broadcasts millisecond synchronization checkpoints (`syncTimestamp`, `timerStartedAtTimestamp`, `accumulatedElapsedSeconds`, `sessionStatus`) on every start, pause, resume, cancel, and 5-second tick interval.
  * Extension background service worker runs a live 1-second ticker (`startLiveTicker`) dynamically updating action badge (`${mins}m`, `${secs}s`, `PAUS`, `COOL`, `EXAM`, `DONE`) and action hover title without waiting for full minute ticks.
  * Upgraded popup and block-page countdown timers to use high-precision formula `Math.max(0, timeLeftSeconds - elapsedSinceSync)` during active focus, freezing exactly when paused.
* **Creative Circular Progress Ring Popup Overhaul**:
  * Redesigned `popup.html` and `popup.js` with an aesthetic circular SVG progress ring (156px diameter) featuring dynamic gradient stroke and animated dashoffset.
  * Integrated prominent tabular monospace digits (`MM:SS`) with live 500ms ticker, color-coded subject pills (`Physics`, `Chemistry`, `Maths`), and dynamic status pills (`● FOCUS`, `⏸ PAUSED`, `🔒 EXAM LOCK`, `❄️ COOLING LOCK`, `SHIELD READY`).
  * Instant action buttons for "Open Study Space", "Quick Pause/Resume", and "JEE Dashboard".
* **Persistent Web Blocker Preferences & Memory**:
  * Upgraded `blockerService.saveBlockedSites` and `getBlockedSites` to write and read from local backup storage (`localStorage["focusforge_blocker_preferences"]`) alongside Supabase cloud DB.
  * Resolved restore synchronization hierarchy: `Supabase Cloud > Local Preferences > Current Store > Default Catalog`, guaranteeing custom blocked and whitelisted domains are never wiped or overwritten when users refresh, sign in, or re-open the app.
  * Connected all 6 blocker store actions (`addBlockedWebsite`, `removeBlockedWebsite`, `addWhitelistedWebsite`, `removeWhitelistedWebsite`, `setWhitelistOnly`, `setExamModeEnabled`) to immediate cloud and local persistence.

---

## [1.2.0] — 2026-09-05

### 🛡️ Whitelist-Only Mode & Exam Mode (Monk Lockdown) End-to-End Implementation
* **Whitelist-Only Mode**:
  * Added strict domain whitelisting across web app, Zustand store (`useStudyStore`), and Chrome extension (Manifest V3).
  * Preloaded official JEE & study domains (`khanacademy.org`, `physicswallah.live`, `unacademy.com`, `nta.ac.in`, `jeemain.nta.ac.in`, `allen.ac.in`, `vedantu.com`, `byjus.com`).
  * Interactive domain manager on `/blocker`: add custom domains, remove domains, persist to Supabase `extension_state.whitelisted_sites`.
  * Dynamic redirection: DeclarativeNetRequest rules block all non-whitelisted domains during focus and redirect to `block-page/index.html?whitelist=true`.
  * Block page displays allowed study domain chips with direct launch links.
* **Exam Mode (Monk Lockdown)**:
  * Toggling Exam Mode automatically forces Whitelist-Only Mode to ON and locks it from being disabled.
  * Focus timers are completely locked: Pause button is disabled with lock icon (`🔒 Timers Locked (Exam Mode Active)`), and keyboard spacebar pause is blocked.
  * **Emergency Exit Penalty**: Abandoning a session during Exam Mode triggers a confirmation modal warning of consequences. Confirming exit activates a strict **5-minute emergency cooling block** (`coolingBlockUntil`).
  * Live cooling countdown banner displayed across the Study Space and extension block page.
  * During the cooling period, all non-study browsing remains locked to Whitelisted Study Domains even though the focus session has ended.
  * Extension displays cyan `COOL` badge during cooling countdown and switches to red `EXAM` during active exam focus.
* **Dual-Channel Cloud & Local Synchronization**:
  * Extended `notifyBridge` with `whitelistOnly`, `examModeEnabled`, `whitelistedWebsites`, and `coolingBlockUntil`.
  * Updated Supabase schema `extension_state` with `whitelist_only`, `exam_mode_enabled`, `whitelisted_sites`, and `cooling_block_until`.
  * Background service worker and periodic alarms reconcile cooling periods and unblock automatically upon timer expiration.
  * Workspace layout timer keeps ticking during cooling lockdown to clear expired state without requiring an active focus session.

---

## [1.1.0] — 2026-09-04

### ⚡ Chrome Companion Extension v1.0.5 & Supabase Realtime Bi-directional Sync
* **Supabase Realtime Cloud Integration in Background Service Worker**:
  * Bundled standalone `@supabase/supabase-js` UMD engine directly into extension (`public/extension/supabase.js`).
  * `background.js` establishes WebSocket subscriptions across `study_sessions`, `extension_state`, and `blocked_sites` filtered by `user_id`.
  * Single Source of Truth: When a study session starts on web, the extension receives live cloud update, engages DeclarativeNetRequest dynamic rules, updates badge countdown, and triggers desktop notifications.
* **Dual-Channel Synchronization Engine**:
  * **Channel 1 (0ms Local PostMessage Relay)**: In-page DOM bridge via `content.js` handles immediate zero-latency start/pause/cancel events.
  * **Channel 2 (Supabase Realtime Cloud Sync)**: Guarantees state synchronization across browsers, tabs, and devices with automatic cloud state reconciliation on service worker startup or wakeup.
* **Strict In-Session Distraction Tracking & Zero Mock Policy**:
  * Distraction logs are logged to Supabase `distraction_logs` *only* during active `StudySession`s.
  * Debounced 15-second rate limiter prevents duplicate log storms.
  * Unauthenticated / offline visits queued safely in `chrome.storage.local`.
  * Instant dynamic unblocking: When a study session concludes or cancels, DeclarativeNetRequest rules are immediately cleared, restoring full web browsing instantly.
* **Preloaded Distraction Catalog & Web Blocker Enhancements**:
  * Added `DEFAULT_DISTRACTION_CATALOG` in `blockerService.ts` covering Social Media, Video & Entertainment, Messaging & Community, and Other Distractions.
  * Integrated interactive 1-click category blocking chips on `/blocker`.
  * Live Supabase Realtime streaming on `/tracker` using `blockerService.subscribeDistractionLogs`.
* **Zero Security Leakage**:
  * Strictly verified that only the public client anonymous publishable key is present in extension bundles. No service-role keys, passwords, or connection strings.

---

## [1.0.0] — 2026-09-04

### 🚀 Production Audit, Single Source of Truth & Zero Baseline Architecture
* **`StudySession` as Single Source of Truth**:
  * All progress, analytics, streaks, XP, level, charts, and extension state derive dynamically from actual user `StudySession` records.
  * Completely eliminated all mock/seeded/fallback progress data (`348m`, `14 sessions`, `100 XP`, `streak 1`, `50% Monk Challenge`, `fakeNextDate` revisions, and hardcoded usernames).
* **Deterministic Streak & Focus Score Service Engines**:
  * Rewrote `focusScoreService.ts` to cleanly evaluate zero-session states without fake fallbacks (`|| 90`).
  * Updated `consistencyGridService.ts` to count streaks strictly from the user's first real logged session.
  * Added uniform leveling via `xpService.getLevelProgress` eliminating UI leveling inconsistencies.
* **Chrome Companion Extension (Manifest V3) Overhaul**:
  * Reset `background.js` and `popup.html` initial state to authentic zero defaults.
  * Built window `postMessage` content script bridge relaying `FOCUSFORGE_SYNC` events to the extension background service worker.
  * Rewrote `scripts/package-extension.js` using native platform compression (`Compress-Archive` on Windows / `zip` on Unix) without third-party dependencies.
* **Zero Security Leakage & Build Stability**:
  * Replaced all client-side service-role key imports with standard authenticated Supabase clients.
  * Resolved all TypeScript errors and ESLint warnings. Full Next.js 16 production build (`npm run build`) passing cleanly across all 24 routes.

---

## [0.5.3] — 2026-09-03

### 🗄️ Supabase Cloud Storage Data Engine Verification & Integrity Fixes
* **UUID Guard & Guest Session Isolation**:
  * Implemented `isValidUuid(id)` and `getAuthenticatedUserId()` in `@/lib/supabase/client`.
  * Guarded all database operations in `studySessionService`, `focusService`, `blockerService`, `consistencyGridService`, `revisionService`, `mistakeJournalService`, and `mistakeReviewService`.
  * Completely eliminated PostgreSQL UUID syntax errors (`invalid input syntax for type uuid: "guest_..."`) when operating in unauthenticated / guest mode, ensuring local offline persistence while keeping cloud database clean.
* **Database Column Name & Foreign Key Realignment**:
  * Fixed column name mismatch in `mistakeReviewService` (`review_count` -> `reviewed_count`) which previously caused PostgreSQL `column does not exist` query exceptions.
  * Verified live Supabase schema across `profiles`, `study_sessions`, `daily_stats`, `consistency_grid`, `mistake_journal`, `revision_plans`, and `jee_progress`.
* **Multi-Table Atomic Sync on Session Completion**:
  * Enhanced `studySessionService.saveCompletedSession` to update `profiles.streak` and `profiles.statistics` (`completedSessions`, `totalFocusMinutes`) alongside `study_sessions`, `daily_stats`, and `consistency_grid`.
  * Added defensive ISO string date parsing and safe warning loggers for Supabase error responses.

---

## [0.5.2] — 2026-09-03

### 🛡️ Study Session Chapter Validation & High-Feedback Error Shake
* **Strict Chapter Guardrail**: Blocks focus zone initiation when no chapter is selected, eliminating orphan/untracked focus sessions that corrupt syllabus statistics.
* **Vibrating / Error Shaking Red Alert Box**:
  * Added high-frequency tactile shake animation (`x` and `y` displacement keyframes) to the Chapter selection container upon failed initiation.
  * Added blinking pulsing red halo (`border-2 border-red-500 bg-red-500/10 ring-4 ring-red-500/30 shadow-[0_0_28px_rgba(239,68,68,0.55)] animate-pulse`).
  * Integrated Web Audio procedural double-buzz error cue (`playErrorSound`) and mobile haptic vibration (`navigator.vibrate([100, 50, 100, 50, 150])`).
  * Pure visual & tactile focus: removed all text error ribbons and pop-up overlays, providing a minimal, clean vibrating red box indicator that clears as soon as a chapter is selected.

---
## [0.5.1] — 2026-09-03

### ⏱️ Automated Study Session Completion & Procedural Web Audio Engine
* **Automatic Session Completion on Timer Expiry**: When a focus session countdown reaches 0:00 without manual interaction, the session automatically concludes, persists full duration metrics to history, syncs cloud Firestore/Supabase, increments daily streak, awards +200 XP, and advances syllabus completion by +20%.
* **Global Study Session Summary Popup**: Integrated global `<StudySessionSummaryModal />` inside `WorkspaceLayout`, providing immediate post-session review with celebratory confetti, interactive 1-5 star productivity rating, difficulty & mood selectors, focus score slider, goal completion toggle, and editable key learnings/notes.
* **Procedural Web Audio Synthesizer (`src/lib/sound-effects.ts`)**: Built zero-latency, offline procedural Web Audio synthesis for timer milestones:
  * **Focus Start**: 4-note uplifting harmonic chime (C5 -> E5 -> G5 -> C6).
  * **30 Seconds Remaining**: Gentle, non-startling two-tone focus alert (F5 -> A5).
  * **5 Seconds Remaining**: Attentive digital countdown pings (5..1s).
  * **Time Over / Complete**: Resonant celebratory chord chime accompanying confetti explosion.

---

## [0.5.0] — 2026-07-31

### 📊 Redesigned Consistency Grid & Single Source of Truth Analytics
* **GitHub-Style Contribution Grid**: Redesigned Consistency Grid with equal-spaced `22×22px` cubes (`8px` radius, `10px` gap) and 5 strict study hour intensity thresholds (`0h` dark gray, `0-1h` Level 1, `1-2h` Level 2, `2-4h` Level 3, `4-6h` Level 4, `6h+` Level 5 purple glow).
* **Compact Statistics Row (5 Stat Chips)**: Redesigned statistics row into 5 compact ~60px chips (🔥 Daily Streak, 🏆 Longest Streak, ⚡ Weekly Sessions, 📅 Monthly Sessions, ❌ Missed Days).
* **Fixed Hover Popup**: Fixed contribution cube hover tooltip displaying Date, Study Time, Sessions, Average Focus %, XP Earned, Subjects, and Mistakes Revised.
* **Single Source of Truth (SSOT)**: Eliminated all mock/fake datasets across the application. All analytics, subject breakdowns, focus scores, XP levels, daily streaks, and monthly insights are computed dynamically via `analyticsService.ts` backed by real-time Firestore `onSnapshot` listeners.

---

## [0.4.0] — 2026-07-31

### 🔥 Firebase Cloud Backend & 27 Service Modules
* **Firebase v11 Integration**: Connected Firebase Authentication and Cloud Firestore as the primary multi-user database backend.
* **27 Cloud Firestore Services (`src/services/`)**: Built 27 modular TypeScript services encapsulating user profiles, XP progression, focus timers, mistake journal CRUD, spaced repetition intervals, JEE syllabus completion rates, distraction blocklists, notes, formula bookmarks, and notifications.
* **IndexedDB Offline Persistence**: Enabled `enableIndexedDbPersistence()` for offline mutation queueing and sync.
* **Security Rules (`firestore.rules`)**: Deployed granular security rules enforcing document ownership for all 15 Firestore collections (`users`, `usernames`, `focusSessions`, `blockedSites`, `extensionState`, `browserDevices`, `analytics`, `jeeTracker`, `studySessions`, `visitLogs`, `mistakeJournal`, `notes`, `formulaBookmarks`, `revisionPlans`, `notifications`).

### 🧩 Companion Chrome Extension (v1.0.4)
* **Manifest V3 Companion**: Built Chrome Companion Extension (`public/extension/`) enforcing real-time website blacklists using `declarativeNetRequest`.
* **Distraction Interception & Block Page**: Intercepts blocked domain visits (e.g., `instagram.com`, `youtube.com`) and redirects to a high-contrast dark focus block screen (`block-page/index.html`).
* **Visit Logging & Extension Heartbeat**: Intercepted visits automatically log to `visitLogs` in Cloud Firestore; service worker pings `extensionState/{userId}` every 60s.
* **Packaging & API Endpoint**: Created automated packaging script (`scripts/package-extension.js`) and Next.js API route (`GET /api/download-extension`) serving `FocusForge-Extension-v1.0.4.zip`.

### 📚 Master Documentation Modernization
* **Complete Documentation Sync**: Completely audited and modernized all Markdown files in root and `docs/` to mirror the actual codebase without assumptions or non-existent features.
* **Root `README.md` Overhaul**: Updated with modern tech stack badges, system architecture Mermaid diagram, detailed installation steps, environment variables table, folder tree, and feature catalog.
* **New Core Documents**:
  * **[CONTRIBUTING.md](file:///c:/Users/Lenovo/Desktop/JEE/CONTRIBUTING.md)**: Open-source setup, branching strategy, commit format, code style, and PR guidelines.
  * **[docs/FIREBASE.md](file:///c:/Users/Lenovo/Desktop/JEE/docs/FIREBASE.md)**: Dedicated Firebase Auth, 15 Firestore collections, security rules, and offline persistence spec.
  * **[docs/EXTENSION.md](file:///c:/Users/Lenovo/Desktop/JEE/docs/EXTENSION.md)**: Dedicated Chrome Extension Manifest V3 architecture, permissions, messaging, block page, and packaging guide.
  * **[docs/API.md](file:///c:/Users/Lenovo/Desktop/JEE/docs/API.md)**: API reference for Next.js API routes, Express server endpoints, and 27 Firestore Service SDKs.

---

## [0.3.1] — 2026-07-28

### 🔄 Global 4-Way Data Sync Engine & Real-Time Persistence
* **Unified 4-Way Sync Architecture**: Connected `/study`, `/mistakes`, `/revisions`, and `/jee` through client-side Zustand store persistence (`useStudyStore` & `useMistakeStore`).
  * Focus Session completion awards +20% topic progress and advances revision cycles.
  * Logging a mistake auto-tags weak topics into syllabus cards.
  * Revising due mistakes awards +100 XP and advances SuperMemo-2 spaced repetition intervals `[1, 3, 7, 15, 30]`.
  * Live JEE Tracker displays updated overall percentage, completed chapters grid, and tagged weak concepts in real time.

### ⏱️ Drift-Free Focus Timer Engine & Session History (`/study`)
* **Real-Time Timestamp Delta Calculation**: Upgraded timer loop in `useStudyStore` to compare real-time timestamp deltas (`Date.now() - timerStartedAtTimestamp`). Tab switching, minimizing browser windows, or OS background throttling never freezes or drifts timer state.
* **Study Session Summary Modal**: Added post-session modal capturing Subject, Chapter, Subchapter, Type, Start/End Time, Duration, Date, Productivity Rating (★ 1-5), Difficulty, Mood, Focus Score %, Was Goal Completed?, and Session Notes.

---

## [0.3.0] — 2026-07-28

### 🤖 Award-Winning 3D WebGL & GSAP Login Portal (`/login`)
* **Three.js PBR 3D AI Robot ([RobotScene.tsx](file:///c:/Users/Lenovo/Desktop/JEE/src/components/3d/RobotScene.tsx))**: Real-time 3D PBR healthcare inflatable AI assistant ("Baymax-inspired") with soft clearcoat (`MeshPhysicalMaterial`), 3D glowing Holo E-Book tablet prop, and 3D particle neural network constellation.
* **Procedural Kinematics & Form Interactivity ([page.tsx](file:///c:/Users/Lenovo/Desktop/JEE/src/app/login/page.tsx))**: Smooth mouse raycasting lerp, password stealth cover-eyes animation, typing chest pulse, and `canvas-confetti` celebration.

---

## [0.2.0] — 2026-07-27

### 🎨 Design System & Theme Engine Update
* **Physics Domain Theme Color**: Updated Physics subject color token across design system and feature pages to **Electric Cyan (`#06b6d4`)**.

---

## [0.1.0] — 2026-07-27

### ✨ Initial FocusForge Core Release
* **App Router Shell**: Initialized Next.js 16 App Router workspace layout wrapping Sidebar, Header, and SoundPlayer.
* **Focus Study Timers**: Integrated Pomodoro, Deep Work, and Custom timers with Monk Mode collapse and browser Web Audio procedural noise synthesizer.
