# Focus Forge YouTube Study Guard — Comprehensive System Audit & Architectural Diagnostic Report

**Audit Date**: September 24, 2026  
**Auditor**: Antigravity AI Subsystem Engineering  
**Subsystem**: FocusForgeYouTubeGuard  
**Workspace**: `d:\JEE`

---

## Executive Summary

The Focus Forge YouTube Study Guard was designed as a multi-tier focus protection system combining Declarative Net Request (DNR) session rules, in-page recommendation filtering, and an academic classification engine. However, the current system exhibits severe behavioral defects:
1. **False Blocks on Study Videos**: Direct URL entry to YouTube `/watch` sends blank video metadata (`title: ""`, `channelName: ""`), causing the classification fallback to immediately classify valid lectures as `NON_STUDY` or block them in strict mode. Furthermore, DNR allow rules are updated asynchronously without awaiting browser installation, causing race conditions where `YT_RULE_GATEWAY_REDIRECT` triggers on approved videos.
2. **False Allows on Distraction Videos**: Multiple independent keyword checkers (in `background.js`, `youtube-study-controller.js`, and `academicEngine`) rely on flat keyword arrays. A single occurrence of words like "waves", "friction", or "gravity" allows entertainment, vlogs, and gaming videos.
3. **Fragmented & Conflicting Implementations**: Three separate classification pipelines exist with divergent rules, distinct caches, and duplicated keyword tables.
4. **Dashboard State Disconnect**: The web dashboard calculates guard status using a client-side boolean (`isFocusActive && !!activeSession`) and displays mock hardcoded strings (`"Layer A + Layer B"`, `"VALID (120s Rolling)"`) instead of querying the extension service worker or verifying DNR rule installation.
5. **Player Policy Violation**: The content script hooks HTML5 video element `play` and `playing` events, intercepting media playback in violation of YouTube Developer Terms.

---

## 1. Current YouTube Entry Points

The codebase intercepts YouTube interactions across three distinct entry points:
- **Direct Address Bar / External Links**: Navigating directly to `https://www.youtube.com/watch?v=...` triggers Chrome's Declarative Net Request engine.
- **YouTube In-Page Recommendation Clicks (SPA)**: Handled by `youtube-study-controller.js` through document capture-phase listeners (`click`, `auxclick`, `keydown`).
- **YouTube Single-Page App (SPA) History Updates**: Intercepted by `chrome.webNavigation.onHistoryStateUpdated` in `background.js` matching `*://*.youtube.com/*`.

---

## 2. Current Classifiers (Duplicate & Fragmented)

Three conflicting classification engines operate concurrently:
1. **`runLocalFallbackClassification(input)` in `background.js` (lines 445–650)**:
   - Evaluates a flat list of 25 negative regex patterns and a flat string array of academic entities.
   - Does not perform structured intent extraction or multi-anchor verification.
   - If `title` is empty (as in direct navigation), it defaults to `NON_STUDY` in strict mode or `REVIEW`.
2. **`runFastClassifier(meta, videoId)` in `youtube-study-controller.js` (lines 481–615)**:
   - Duplicates the same flat lists inside the content script.
   - Evaluates client-side before communicating with `background.js`.
3. **`classifyAcademicVideo(input)` in `src/services/academicEngine/index.ts` & `youtubeGuardService.ts`**:
   - The authoritative backend classifier, incorporating `matchKnowledgeGraph` from `src/lib/academic-knowledge-graph.ts`, `POSITIVE_ACADEMIC_TAXONOMY`, `NEGATIVE_TAXONOMY`, and `EvidenceConflictResolver`.
   - Bypassed in many cases by the extension's local fallbacks due to offline checks or API timeouts.

---

## 3. Current Enforcement Layer

Enforcement is split across two layers:
- **Declarative Net Request (DNR) Session Rules (Layer B)**:
  - `YT_RULE_SHORTS` (Priority 50): Redirects `/shorts/*` to `block-page/index.html`.
  - `YT_RULE_GATEWAY_REDIRECT` (Priority 10): Redirects all unapproved `/watch?v=...` to `youtube-verify.html`.
  - `YT_RULE_EXACT_ALLOW` (Priority 100): Allows specific approved `videoId`s via `urlFilter: "||youtube.com/watch?*v=${vid}*"`.
- **In-Page DOM & Navigation Cancellation (Layer A)**:
  - `youtube-study-controller.js` intercepts recommendation clicks, cancels events via `event.preventDefault()` and `event.stopImmediatePropagation()`, displays a custom toast notification, and manages verification queues.
  - Also attaches `play` and `playing` event listeners on HTML5 video elements to pause playback.

---

## 4. Current Caches

Multiple desynchronized caches exist:
- **`youtubeClassificationCache` in `background.js`**: In-memory `Map<string, CacheEntry>` with 1-hour expiration. Not shared with the web app.
- **`localDecisionCache` in `youtube-study-controller.js`**: Page-lifetime `Map<string, Decision>`. Discarded on page refresh.
- **`memoryClassificationCache` in `src/services/youtubeGuardService.ts`**: In-memory `Map<string, YouTubeClassificationResult>`.
- **`youtube_classification_cache` Supabase Table**: Global Postgres cache with 14-day expiration.
- **`FocusPassManager` in `background.js`**: Session-scoped temporary pass map, cleared on session termination.

---

## 5. Current Supabase Database Tables

Managed under `supabase/migrations/20260922100000_youtube_study_guard.sql`:
1. `youtube_topics`: Taxonomy topics, chapters, and keywords.
2. `youtube_trusted_channels`: Verified educational channels and subjects.
3. `youtube_allowed_videos`: User-specific manual approvals.
4. `youtube_classification_cache`: Global classification results.
5. `youtube_guard_settings`: Per-user mode (`strict`, `balanced`, `custom`) and scope.
6. `youtube_access_logs`: Telemetry logs of study watch duration and distractions.

---

## 6. Current Session State Source

Session state is sourced from:
1. `extensionState` in `background.js`: Synchronized via Supabase Realtime channel `ff_presence_channel` and WebApp bridge messages (`FOCUSFORGE_SYNC`).
2. `youtubeGuardState` in `background.js`: Holds `verifiedSessionId`, `leaseUntil` (120-second rolling heartbeat), `status` (`ON`, `OFF`, `ENABLING`, `ERROR`), and `approvedVideoIds`.
3. `isStudySessionActive()`: Evaluates `authenticatedUserId && extensionState.isFocusActive && extensionState.activeSessionId === youtubeGuardState.verifiedSessionId && Date.now() < youtubeGuardState.leaseUntil`.
4. Web App Store (`useStudyStore` in `src/store/use-study-store.ts`): Holds active session object and focus timer.

---

## 7. Current Declarative Net Request (DNR) Rules

| Rule ID | Priority | Condition | Action |
| :--- | :--- | :--- | :--- |
| `90001` (`YT_RULE_SHORTS`) | 50 | `||youtube.com/shorts/*` | Redirect to `block-page/index.html?reason=shorts` |
| `90002` (`YT_RULE_GATEWAY_REDIRECT`) | 10 | `^https?://(?:www\.)?youtube\.com/watch\?...` | Redirect to `youtube-verify.html?targetUrl=...&v=...` |
| `90100`–`99999` (`YT_RULE_EXACT_ALLOW`) | 100 | `||youtube.com/watch?*v=${vid}*` | `allow` |

---

## 8. Current Content Scripts

1. `content.js` (matches `<all_urls>`):
   - Bridges Focus Forge web app messages with extension worker.
   - Cleans domain block overlays (`#focusforge-block-overlay`).
2. `youtube-study-controller.js` (matches `*://*.youtube.com/*`):
   - 1,457 lines of procedural logic containing its own classifier, recommendation observers, click interceptors, watch ticker, player pause hooks, and overlay injector.

---

## 9. Current Navigation Listeners

1. `chrome.webNavigation.onHistoryStateUpdated`:
   - Listens on `*://*.youtube.com/*`.
   - Intercepts SPA history changes and redirects unverified `/watch` routes to `youtube-verify.html`.
2. Content Script In-Page Listeners:
   - `window.addEventListener("yt-navigate-finish", evaluateCurrentRoute)`
   - `window.addEventListener("yt-page-data-updated", evaluateCurrentRoute)`
   - `window.addEventListener("popstate", evaluateCurrentRoute)`
   - `document.addEventListener("click", onDocumentClickCapture, true)`
   - `document.addEventListener("auxclick", onDocumentAuxClickCapture, true)`
   - `document.addEventListener("keydown", onDocumentKeydownCapture, true)`

---

## 10. Duplicate & Conflicting Implementations

- **Double Filtering**: Both `youtube-study-controller.js` and `background.js` execute independent fallback classification using duplicate hardcoded lists.
- **Double Gateway**: If a user clicks a recommendation, `youtube-study-controller.js` intercepts it in DOM. If it misses or if navigation occurs via address bar, `background.js` DNR rules redirect to `youtube-verify.html`.
- **DNR Rule Update Race**: `background.js` issues a focus pass and starts an asynchronous rule update (`updateSessionRules`), but responds to the content script before the rule is actually committed. When the content script replays the click, the DNR rule redirect intercepts the request.
- **Multiple Cache Layers with Divergent Keys**: Some caches key by `videoId`, others key by `userId_videoId`, and neither incorporates the user's active academic profile hash or taxonomy version consistently.

---

## 11. Exact Reasons Study Videos Are Being Blocked

1. **Empty Metadata on Gateway Verification**: When a user opens a YouTube video directly in the address bar or via an external link, `background.js` handles `VERIFY_GATEWAY_DESTINATION` with `title: ""` and `channelName: ""` (line 3483). The classifier receives no title or channel, taxonomy matching fails, and the local fallback classifies it as `NON_STUDY` or blocks it under strict mode.
2. **Rule Installation Race Condition**: When an approved video is granted access, `YouTubeStudyGuardManager.approveVideo` initiates `chrome.declarativeNetRequest.updateSessionRules`. The background worker responds immediately without awaiting resolution. The browser attempts to navigate to `youtube.com/watch?v=...` before Chrome has applied the rule, triggering `YT_RULE_GATEWAY_REDIRECT` and looping back to `youtube-verify.html`.
3. **Overly Aggressive Strict Mode on Unresolved Subtopics**: In strict mode, if a video covers a specific topic that has slightly different phrasing from the knowledge graph and oEmbed fails to load description tags, the confidence is rated LOW, and strict mode immediately forces a block instead of routing to student confirmation (`REVIEW`).
4. **Stale Session Lease Lockout**: When the 120-second rolling heartbeat alarm experiences service worker suspension or timing jitter, `isStudySessionActive()` returns false, but lingering rules or inconsistent state prevent normal navigation.

---

## 12. Exact Reasons Irrelevant Videos Are Being Allowed

1. **Isolated Keyword Matching Without Intent Verification**: Simple entity matching checks if `normText.includes(entityNorm)`. Words like `"waves"`, `"friction"`, `"gravity"`, or `"solution"` trigger `STUDY` even when used in non-academic contexts (e.g., "Relaxing ocean waves", "Friction in marriage", "Minecraft chemistry solution").
2. **Trusted Channel Blind Allowance**: In balanced mode, any video from a channel whose name includes a keyword like "unacademy" or "physics wallah" receives an automatic `STUDY` classification with 0.85 confidence, even if the video is an IIT campus tour, hostel food vlog, motivational speech, or brand announcement.
3. **Recommendation SPA Click Interception Leaks**: In YouTube's modern Polymer interface, clicking certain elements (such as video titles wrapped in `#video-title`, channel avatars, or playlist thumbnails) does not always bubble up as an anchor click with `/watch` in `href` at the exact moment of the event, allowing the native YouTube SPA router to execute the navigation before the classifier intercepts it.
4. **Keyword Overriding Lifestyle Signals**: In previous iterations, if a title contained both an academic keyword ("JEE") and lifestyle keywords ("vlog", "hostel tour"), the positive keyword match outweighed the negative context, allowing "My JEE Preparation Vlog" to pass.
