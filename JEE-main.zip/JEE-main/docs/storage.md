# FocusForge — Supabase Storage & Assets Architecture

This document describes object storage configurations for avatars, mistake screenshots, and study note PDF attachments.

---

## 📦 Storage Buckets & Policies

- **Bucket**: `user-attachments` (Private)
- **Bucket**: `avatars` (Public read, authenticated write)
- Access is restricted to `auth.uid() = (storage.foldername(name))[1]::uuid`.
