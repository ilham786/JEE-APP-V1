# FocusForge — Realtime Synchronization & Extension Messaging

This document outlines the real-time subscriptions, state updates, and Chrome Extension message-passing architecture.

---

## 📡 Realtime Subscriptions

Realtime updates are enabled on core tables in PostgreSQL:
```sql
ALTER PUBLICATION supabase_realtime ADD TABLE public.study_sessions, public.consistency_grid, public.mistake_journal, public.extension_state;
```

### Subscribed Modules
- `studySessionService.subscribeUserStudySessions()`: Listens for session inserts and updates Dashboard, Trend Graphs, and Consistency Grid.
- `blockerService.subscribeBlockedSites()`: Listens for site blacklist changes and pushes updated rules to the Chrome Extension.
- `extensionService.subscribeExtensionState()`: Syncs active focus session status between website and browser extension.
