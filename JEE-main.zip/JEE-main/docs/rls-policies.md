# FocusForge — Row Level Security (RLS) Policies

This document documents the security rules enforcing multi-tenant isolation across all user tables in PostgreSQL.

---

## 🔒 Security Principles

1. **Default Deny**: Row Level Security is explicitly enabled on all public tables (`ALTER TABLE ... ENABLE ROW LEVEL SECURITY`).
2. **Owner Isolation**: Users can only perform `SELECT`, `INSERT`, `UPDATE`, and `DELETE` operations on rows where `user_id = auth.uid()` (or `id = auth.uid()` for profiles).

---

## 📜 Complete RLS Policy Definitions

```sql
-- Profiles Policy
CREATE POLICY "Users can manage own profile" 
  ON public.profiles FOR ALL 
  USING (auth.uid() = id);

-- User-owned Data Tables Policies
CREATE POLICY "Users can manage usernames" ON public.usernames FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "Users can manage study_sessions" ON public.study_sessions FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "Users can manage daily_stats" ON public.daily_stats FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "Users can manage consistency_grid" ON public.consistency_grid FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "Users can manage revision_plans" ON public.revision_plans FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "Users can manage custom_revision_plans" ON public.custom_revision_plans FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "Users can manage mistake_journal" ON public.mistake_journal FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "Users can manage jee_progress" ON public.jee_progress FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "Users can manage notes" ON public.notes FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "Users can manage formula_sheets" ON public.formula_sheets FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "Users can manage blocked_sites" ON public.blocked_sites FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "Users can manage distraction_logs" ON public.distraction_logs FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "Users can manage browser_devices" ON public.browser_devices FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "Users can manage extension_state" ON public.extension_state FOR ALL USING (auth.uid() = user_id);
```
