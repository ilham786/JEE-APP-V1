# FocusForge — Technical Systems Architecture

This document provides an exhaustive specification of the technical systems architecture, data persistence layers, state management flows, Firebase Firestore services, Chrome Extension synchronization engine, and component routing hierarchy in **FocusForge**.

---

## 📋 Table of Contents

1. [High-Level Systems Architecture](#1-high-level-systems-architecture)
2. [Folder & Module Layout](#2-folder--module-layout)
3. [Client Component Hierarchy & App Shell](#3-client-component-hierarchy--app-shell)
4. [State Management & 4-Way Sync Engine](#4-state-management--4-way-sync-engine)
5. [Firebase Cloud Backend & 27 Service Modules](#5-firebase-cloud-backend--27-service-modules)
6. [Companion Chrome Extension Sync Engine](#6-companion-chrome-extension-sync-engine)
7. [Algorithmic Engines (SuperMemo-2 & AI Coach)](#7-algorithmic-engines-supermemo-2--ai-coach)
8. [Audio & Sound Synthesis Architecture](#8-audio--sound-synthesis-architecture)

---

## 1. 🏛️ High-Level Systems Architecture

FocusForge is designed as a multi-tier, high-availability architecture composed of four synchronized subsystems:

```
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                                CLIENT APPLICATION LAYER                                │
│  ┌──────────────────────────────────────────────────────────────────────────────────┐  │
│  │ Next.js 16 App Router UI Pages (/study, /mistakes, /revisions, /jee, /blocker)  │  │
│  └──────────────────────────────────┬───────────────────────────────────────────────┘  │
│                                     │                                                  │
│  ┌──────────────────────────────────▼───────────────────────────────────────────────┐  │
│  │ Zustand Persisted Stores (useStudyStore & useMistakeStore)                      │  │
│  └──────────────────────────────────┬───────────────────────────────────────────────┘  │
└─────────────────────────────────────┼──────────────────────────────────────────────────┘
                                      │
              ┌───────────────────────┴───────────────────────┐
              ▼                                               ▼
┌───────────────────────────┐                   ┌───────────────────────────┐
│ SUPABASE CLOUD BACKEND    │                   │ CHROME COMPANION EXT      │
│ - Supabase Auth           │                   │ - Manifest V3 Worker      │
│ - PostgreSQL Database     │<─────────────────>│ - DeclarativeNetRequest   │
│ - Supabase Realtime PubSub│ real-time sync    │ - Content Scripts Bridge  │
│ - Dedicated Service Layer │                   │ - Block Page Redirects    │
└───────────────────────────┘                   └───────────────────────────┘
```

---

## 2. 📂 Folder & Module Layout

```
FocusForge/
├── .agents/                 # AI Assistant skills & guidelines config
├── docs/                    # Technical & architectural specifications
├── public/                  # Static assets & Chrome Extension source
│   └── extension/           # Manifest V3 companion Chrome extension
├── scripts/                 # Maintenance and extension packaging scripts
├── src/
│   ├── app/                 # Next.js 16 App Router routes
│   │   ├── analytics/       # Progress & study distribution page (/analytics)
│   │   ├── api/             # API routes (/api/download-extension)
│   │   ├── blocker/         # Distraction shield & web blocker (/blocker)
│   │   ├── coach/           # Heuristic AI study coach (/coach)
│   │   ├── dashboard/       # Main workspace dashboard (/dashboard)
│   │   ├── jee/             # JEE chapter syllabus & formulas (/jee)
│   │   ├── login/           # 3D WebGL split-screen login page (/login)
│   │   ├── mistakes/        # Mistake Journal logging page (/mistakes)
│   │   ├── profile/         # User profile & extension status (/profile)
│   │   ├── revisions/       # Spaced repetition scheduler page (/revisions)
│   │   ├── study/           # Focus study timer & Monk Mode (/study)
│   │   ├── tracker/         # Distraction log history page (/tracker)
│   │   ├── globals.css      # Tailwind CSS v4 inputs & glass utilities
│   │   ├── layout.tsx       # Root layout defining viewport & fonts
│   │   └── page.tsx         # Standalone marketing landing page (/)
│   ├── components/          # Structural React components
│   │   ├── 3d/              # Real-Time Three.js WebGL 3D robot scene
│   │   ├── jee/             # JEE syllabus cards & detail modals
│   │   ├── ui/              # Reusable design system primitives
│   │   ├── consistency-grid.tsx # 365-day study intensity heatmap
│   │   ├── header.tsx       # App shell header (Streak, volume dropdown, Monk mode)
│   │   ├── sidebar.tsx      # Sidebar navigation & XP Level progress
│   │   ├── sound-player.tsx # Headless Web Audio API ambient audio synthesizer
│   │   └── workspace-layout.tsx # Container wrapping Sidebar, Header, & SoundPlayer
│   ├── context/             # React Context Providers (AuthContext.tsx)
│   ├── data/                # Static JEE syllabus datasets & chapter list
│   ├── hooks/               # Custom React hooks (useIsClient, useKeyboardShortcuts)
│   ├── lib/                 # Auxiliary logic (firebase.ts, spaced-rep.ts, coach-logic.ts)
│   ├── services/            # 27 Cloud Firestore Service Modules
│   ├── store/               # Zustand Global State Stores
│   ├── theme/               # Subject color themes & helpers
│   └── types/               # TypeScript interface declarations
├── firestore.rules          # Firestore Database security rules
├── firebase.json            # Firebase hosting & Firestore rules config
├── server.js                # Standalone Express login server & static host fallback
└── package.json             # Root dependency manifests
```

---

## 3. 🧩 Client Component Hierarchy & App Shell

All workspace feature pages inherit a unified visual shell via `<WorkspaceLayout>` in `src/components/workspace-layout.tsx`:

```
                             ┌─────────────────────────┐
                             │   Root Layout           │
                             │  (src/app/layout.tsx)   │
                             └────────────┬────────────┘
                                          │
               ┌──────────────────────────┴──────────────────────────┐
               ▼                                                     ▼
 Standard Landing Page                                     Workspace Feature Page
   (src/app/page.tsx)                                   (e.g., src/app/study/page.tsx)
                                                                     │
                                                                     ▼
                                                          ┌─────────────────────┐
                                                          │   WorkspaceLayout   │
                                                          └──────────┬──────────┘
```

### Key UI Features
* **Sidebar (`sidebar.tsx`)**: Displays navigation links, active subject badges, and user XP / level bar. Automatically collapses during Monk Mode.
* **Header (`header.tsx`)**: Displays study streak counter, ambient sound volume control, Monk Mode toggle button, and user profile avatar.
* **SoundPlayer (`sound-player.tsx`)**: Headless Web Audio API synthesizer generating real-time procedural soundscapes (Rain, Lofi, White Noise).
* **Hydration Guards (`useIsClient.ts`)**: Prevents SSR hydration mismatches by delaying client-only store renders until after DOM mounting.

---

## 4. 🔄 State Management & 4-Way Sync Engine

FocusForge operates a real-time 4-way data synchronization engine powered by client-side Zustand store persistence (`useStudyStore` and `useMistakeStore`) coupled with Cloud Firestore subscriptions:

```
       [ Study Session ]  ------->  Completes focus session: +20% completion & +1 revision cycle
              │
       [ Mistake Journal ] ------>  Logs mistake: auto-tags weak topic into syllabus
              │                     Revises mistake: +15% completion & advances spaced repetition
              ▼
    ┌──────────────────┐
    │ Zustand Store /  │  ------->  Real-time state persistence across all active tabs
    │ Cloud Firestore  │
    └──────────────────┘
              ▲
              │
       [ Revision Plan ]  ------->  Executes due revision: completes spaced cycle & awards +100 XP
              │
       [  JEE Tracker  ]  ------->  Displays live overall completion %, completed cards & weak topics
```

---

## 5. ⚡ Supabase Cloud Backend & Service Layer

Supabase PostgreSQL functions as the primary persistent database with Row-Level Security (RLS) enabled on all tables, abstracted behind **dedicated service modules** in `src/services/`:

| Service Module | Purpose & Tables Interacted With |
| :--- | :--- |
| `userService.ts` | Manages `profiles` records, XP accumulation, and streak maintenance. |
| `studySessionService.ts` | **Primary Source of Truth**: Logs completed study sessions to `study_sessions` table. |
| `mistakeJournalService.ts` | CRUD operations for mistake entries in `mistake_journal` table. |
| `revisionService.ts` | Retrieves due items and updates SuperMemo-2 revision intervals. |
| `jeeService.ts` | Updates chapter completion rates and solved PYQ counts in `jeeTracker/{userId}`. |
| `analyticsService.ts` | **Single Source of Truth Analytics Engine**: Calculates real-time study trends (7D/30D/90D/1Y), subject distributions, focus scores, XP totals, streaks, and analytics metrics for all pages. |
| `consistencyGridService.ts` | Generates GitHub-style study contribution grid records, compact stat chips, and intelligent monthly insights from real-time session history. |
| `notesService.ts` | Manages notes CRUD in `notes/{noteId}` collection. |
| `formulaService.ts` | Bookmarks formula reference expressions in `formulaBookmarks`. |
| `notificationService.ts` | Dispatches revision due reminders and coaching notifications. |
| `deviceService.ts` | Tracks active connected browser devices in `browserDevices`. |
| `historyService.ts` | Manages historical logs and visit attempt records. |
| `customRevisionService.ts` | Handles user-created custom revision schedules. |
| `randomRevisionService.ts` | Generates randomized revision quizzes from weak topics. |
| `mistakeAnalyticsService.ts` | Computes error category analytics (Conceptual vs. Calculation). |
| `mistakeReviewService.ts` | Manages review execution sessions. |
| `dashboardService.ts` | Aggregates daily metrics for the main workspace dashboard. |
| `xpService.ts` | XP formula calculations and level threshold milestones. |
| `focusScoreService.ts` | Evaluates session duration and distraction attempts to rate focus. |
| `schedulerService.ts` | Manages study schedule reminders and calendar events. |

---

## 6. 🧩 Companion Chrome Extension Sync Engine & YouTube Content Guard

The Companion Chrome Extension (`public/extension/`) enforces distraction shielding and academic focus in real-time through two synchronized mechanisms:

### Website Distraction Shield
1. **Window Message Bridge**: When focus mode or blacklists change in the FocusForge web app, a `FOCUSFORGE_SYNC` event is posted via `window.postMessage`.
2. **Content Script Relay**: `content.js` listens to messages across matching pages and forwards them to `background.js` via `chrome.runtime.sendMessage`.
3. **Declarative Net Request**: `background.js` maintains dynamic DNR rules and updates the extension icon badge in real-time.
4. **Distraction Lock Overlay**: On visits to blocked domains during active sessions, `content.js` injects a dark modal locking access and directing the student back to `/study`.
5. **Zero-Default Popup**: The popup UI displays active session state, countdown timer, today's focus minutes, and blocked count starting from genuine zero baseline.

### 🛡️ Authoritative FocusForge YouTube Study Content Guard Subsystem (`FocusForgeYouTubeGuard`)
The YouTube Study Content Guard (`src/services/academicEngine/`, `src/services/youtubeGuardService.ts`, and `public/extension/`) provides zero-distraction YouTube study capability with strict YouTube API Policy compliance:
* **YouTube API Policy Invariant**: Zero manipulation or inspection of `<video>` elements, video streams, or playback events. Standard playback, pause, and recommendations function natively without synthetic play locks. When a study session is inactive, paused, or completed, YouTube operates with zero filtering, blocking, or interception.
* **Layer A (In-Page Pre-Navigation Click Firewall)** (`youtube-study-controller.js`):
  * Document-level capture-phase interception (`click`, `auxclick`, `keydown`) running at `document_start`.
  * Pre-evaluates destination video links against the Academic Engine before the browser navigates.
  * Active study video plays with zero interruption while candidate links are pre-verified.
* **Layer B (Network-Level Declarative Net Request Gateway)** (`background.js`):
  * Handles direct address bar URLs and external navigations at the declarative network layer.
  * `Priority 100` (`YT_PRIORITY_EXACT_ALLOW`): Instant allow rule for approved video IDs with valid session Focus Pass.
  * `Priority 50` (`YT_PRIORITY_SHORTS`): Blocks short-form rabbit holes redirecting to study reminder.
  * `Priority 10` (`YT_PRIORITY_GATEWAY_REDIRECT`): Intercepts unverified `/watch?v=...` requests and directs them to the verification gateway (`youtube-verify.html`).
* **Academic Knowledge Graph & Semantic Classifier (Taxonomy `2026.2`, Engine `v3.0-focusforge-guard`)**:
  * Multi-tier hierarchy across JEE (Physics, Chemistry, Mathematics), NEET (Biology, Botany, Zoology), and CBSE Class 12 (English Core).
  * Canonical coaching alias expansion (`com`, `lmvt`, `aod`, `p&c`, `itf`, `goc`).
  * Token-bounded word boundary matching (`(^|\\s)entity(\\s|$)`) to eliminate partial-word collisions.
  * Multi-anchor intent resolution ensuring negative lifestyle vlogs, gaming, campus tours, and tech unboxings are rejected even when exam tags are mentioned.
  * Three-Way Classification Decision: `STUDY` (allow), `NON_STUDY` (block), and `REVIEW` (verification gateway). Strict mode fails ambiguous content safely to `NON_STUDY`.
* **Profile-Aware Caching & Diagnostics**:
  * 64-bit FNV-1a profile hashing (`computeAcademicProfileHash`) and versioned cache key generator (`buildClassificationCacheKey`).
  * Standardized `/api/youtube/classify` (Section 29 format) and `/api/youtube/diagnostics` endpoints.

---

## 7. 🧠 Algorithmic Engines: SuperMemo-2 & ForgeCoach AI Study OS

### 7.1 SuperMemo-2 Spaced Repetition (`src/lib/spaced-rep.ts`)
Calculates optimal review intervals based on rating quality ($Q \in [0, 5]$):

$$\text{EF}' = \text{EF} + \left(0.1 - (5 - Q) \times (0.08 + (5 - Q) \times 0.02)\right)$$

* Default interval steps: `1 -> 3 -> 7 -> 15 -> 30` days.
* Ensures mistakes are reviewed before conceptual decay occurs.
* Fully synchronized with the 4-way global state engine: executing a due revision awards +100 XP and advances interval progression.

---

### 7.2 FocusForge AI Study Coach Architecture (`src/services/coach/`, `src/app/coach/`)

ForgeCoach is a context-aware **Academic Study Operating System** engineered specifically for rigorous STEM and Board examination preparation (JEE Main & Advanced, NEET, CBSE Class 12 SQP 2026–27, NCERT). It operates on genuine student data, deterministic mathematical evaluation, official curriculum retrieval, and structured academic reasoning.

#### 🏛️ Four-Zone Interface Architecture (`src/app/coach/page.tsx`)
1. **Zone A: Coach Header**
   * Dynamic status indicators: `● Ready`, `● Session Active`, `● Context Synced`, or `● Checking Sources...`
   * Dynamic academic profile tag: Displays configured curriculum (e.g., `JEE • Class 12 • PCM`, `NEET • Class 12 • PCB`, `CBSE • Class 12`).
   * Mode Selector Pills: Quick routing for `Ask`, `Solve`, `Explain`, `Quiz`, `Revise`, and `Analyze`.
2. **Zone B: Live Study Context Bar**
   * Real-time subject, chapter, and topic tracking directly from `useStudyStore`.
   * Displays active session elapsed time, today's total focus duration, and current streak.
   * Graceful fallback when no session is active: shows "No active study session" and last studied topic.
3. **Zone C: Intelligent Chat & Multimodal Interaction**
   * Multimodal Question Upload: Accepts question screenshots, diagrams, textbook excerpts, and handwritten problems via client-side FileReader preview.
   * Mixed Markdown + KaTeX Mathematical Typesetting (`src/components/ui/math-text.tsx`): Renders LaTeX expressions, chemical reactions, units, and matrices without unparsed raw symbols.
   * Dynamic Prompt Chips: Contextually synthesized from active subject and chapter (e.g., electrostatics vs organic chemistry vs English literature).
   * Structured Answer Blocks: Sectioned into Answer, Key Idea, Formula, Step-by-Step, Example, Common Mistake, Exam Note, and Sources.
   * Interactive Suggested Action Buttons: Execute tasks directly (e.g., `[Start 25-min Session]`, `[Review Mistakes]`, `[Practice Questions]`).
   * Answer Feedback Controls: Thumbs-up/down with rating capture for continuous quality evaluation.
4. **Zone D: Live Insight & Diagnostics Panel**
   * **Study Load Signal**: Classifies observable weekly volume variance into `Balanced`, `Heavy`, `Light`, or `Irregular` based on 7-day vs prior 7-day focus minutes. Never issues pseudo-medical "burnout" diagnoses.
   * **Mistake Trends**: Tracks 7-day error rates, percentage trends ($\downarrow$ or $\uparrow$), top error categories (e.g., `Conceptual`, `Calculation`), and affected subjects.
   * **Preparation Snapshot**: Measurable syllabus coverage %, recent practice volume, weak topics count, and pending revisions with confidence scoring.
   * **Four Dynamic Quick Action Cards**: State-aware cards (`Weak Right Now`, `Revision Due`, `Mistake Pattern`, `Next Best Task`) adapting to real user data.
   * **Proactive Forge Insight**: Surfaces actionable study balance advice derived exclusively from empirical store records.

#### 🔄 Multi-Tier Orchestration Pipeline
```
[User Input / Multimodal Question]
               │
               ▼
   ┌───────────────────────┐
   │   Coach Orchestrator  │ ────► Client Context Builder (Compact Minimization)
   └───────────────────────┘
               │
               ▼
   ┌───────────────────────┐
   │     Intent Router     │ ────► Detects Mode (EXPLAIN, SOLVE, HINT, PRACTICE, REVISE, ANALYZE)
   └───────────────────────┘       & Classifies Question Difficulty (NCERT, CBSE 12, JEE Main/Adv, NEET)
               │
               ▼
   ┌───────────────────────┐
   │    Tool Layer (22)    │ ────► Permission Gate (READ vs WRITE boundaries)
   │ ───────────────────── │
   │ • Study State Tools   │
   │ • Mistake Tools       │
   │ • Revision Tools      │
   │ • Syllabus Tools      │
   │ • Official Knowledge  │
   │ • Calculator Tool     │ ────► Deterministic Shunting-Yard AST (Zero floating-point LLM errors)
   └───────────────────────┘
               │
               ▼
   ┌───────────────────────┐
   │  AIProvider Interface │ ────► OpenAiProvider (JSON Schema Structured Outputs)
   │                       │       └── Automatic Fallback ──► ForgeAcademicProvider (Offline Zero-Hallucination)
   └───────────────────────┘
               │
               ▼
   ┌───────────────────────┐
   │  Structured Response  │ ────► Validated JSON Schema: answer, intent, sources, suggestedActions, confidence
   └───────────────────────┘
               │
               ▼
   ┌───────────────────────┐
   │ KaTeX Answer Renderer │ ────► Structured Visual Cards + Math Rendering + Action Triggers
   └───────────────────────┘
```

#### 🛠️ 22-Tool Agent Permission Layer (`src/services/coach/coachTools.ts`)
| Tool Name | Permission | Purpose & Scope |
| :--- | :--- | :--- |
| `getUserProfile` | READ | Retrieves configured exam, class, board, stream, and target year. |
| `getActiveStudySession` | READ | Returns current active timer, subject, chapter, and elapsed time. |
| `getRecentStudySessions` | READ | Fetches recent session durations, topics, and completed pomodoros. |
| `getTodayStudyStats` | READ | Calculates today's completed focus minutes, session count, and streak. |
| `getSubjectStudyTime` | READ | Aggregates 7-day and all-time distribution across Physics, Chemistry, Math, Biology, English. |
| `getWeakTopics` | READ | Identifies weak topics tagged from mistakes or low syllabus mastery. |
| `getRevisionPlan` | READ | Retrieves pending SuperMemo-2 revision items and overdue topics. |
| `getMistakeJournal` | READ | Fetches mistake logs with status, topics, and question notes. |
| `getMistakePatterns` | READ | Aggregates error categories (`conceptual`, `calculation`, `formula`, `sign_convention`). |
| `getSyllabus` | READ | Retrieves hierarchical syllabus for subject and configured academic year. |
| `getCurrentChapter` | READ | Extracts active chapter details and sub-topics from knowledge graph. |
| `getCurrentTopic` | READ | Identifies active sub-topic under study. |
| `getDistractionLogs` | READ | Inspects blocked domain attempts and off-task triggers. |
| `getConsistencyData` | READ | Computes 14-day study consistency score and streak continuity. |
| `getAnalytics` | READ | Returns combined study metrics, practice volume, and completion statistics. |
| `searchAcademicKnowledge` | READ | Queries verified academic knowledge graph for definitions, formulas, and pitfalls. |
| `getChapterDetails` | READ | Fetches detailed chapter prerequisites, key formulas, and exam weightings. |
| `getRelevantCurriculumSource` | READ | Retrieves official CBSE Class XII 2026–27 SQP and NCERT syllabus references. |
| `calculate` | READ | Evaluates mathematical/physical formulas with deterministic precision. |
| `generatePracticeSet` | READ | Generates targeted 5-question drills aligned to subject, topic, and difficulty. |
| `saveCoachNote` | WRITE | Persists key coach insights or summary notes (requires user confirmation). |
| `createRevisionTask` | WRITE | Schedules an explicit spaced repetition revision task (requires user confirmation). |

#### 🧮 Deterministic Scientific Calculator (`src/services/coach/calculator.ts`)
* Eliminates language model hallucinations in arithmetic, physical unit evaluations, and algebraic computations.
* Custom tokenizer and Shunting-Yard AST evaluator supporting scientific notation (`1.6e-19`), trigonometry (`sin`, `cos`, `tan`), logarithms (`log`, `ln`), powers (`^`), roots (`sqrt`), and absolute values (`abs`).
* Pre-loaded with fundamental physical and mathematical constants:
  * Speed of light ($c = 2.99792458 \times 10^8\text{ m/s}$)
  * Planck's constants ($h = 6.62607015 \times 10^{-34}\text{ J}\cdot\text{s}$, $\hbar$)
  * Elementary charge ($e = 1.602176634 \times 10^{-19}\text{ C}$)
  * Electron & proton mass ($m_e = 9.1093837 \times 10^{-31}\text{ kg}$, $m_p = 1.6726219 \times 10^{-27}\text{ kg}$)
  * Vacuum permittivity & permeability ($\epsilon_0 = 8.8541878128 \times 10^{-12}\text{ F/m}$, $\mu_0 = 1.256637062 \times 10^{-6}\text{ N/A}^2$)
  * Coulomb's constant ($k_e = 8.9875517923 \times 10^9\text{ N}\cdot\text{m}^2/\text{C}^2$)
  * Gravitational constant ($G = 6.6743 \times 10^{-11}\text{ N}\cdot\text{m}^2/\text{kg}^2$)
  * Gas constant ($R = 8.314462618\text{ J/(mol}\cdot\text{K)}$)
  * Avogadro's number ($N_A = 6.02214076 \times 10^{23}\text{ mol}^{-1}$)
  * Boltzmann's constant ($k_B = 1.380649 \times 10^{-23}\text{ J/K}$)
  * Faraday's constant ($F = 96485.33212\text{ C/mol}$)
  * Standard gravity ($g = 9.80665\text{ m/s}^2$)
  * Mathematical constants ($\pi$, $e$)

#### 📚 Official Academic Knowledge & Curriculum Sources (`src/services/coach/curriculumSources.ts`)
* Grounded in official **CBSE Class XII 2026–27 Sample Question Papers & Marking Schemes**:
  * Physics (Code 042)
  * Chemistry (Code 043)
  * Mathematics (Code 041)
  * Biology (Code 044)
  * English Core (Code 301) — Reading Skills, Creative Writing Skills, Literature
* **NCERT Textbooks**: Classes 11 & 12 across Physics, Chemistry, Mathematics, and Biology.
* Source Attribution: When an answer relies on official guidelines, source chips (`CBSE Class XII 2026-27 (SQP & Marking Scheme)`, `NCERT Physics Class XII`) are attached with official citation URLs.

#### 🛡️ Zero Fake Intelligence & Data Grounding Policy
* **Strict Empirical Grounding**: The AI Coach never invents study minutes, streak numbers, mock percentages, or fake readiness scores.
* **Honest Fallback Thresholds**:
  * If a user has fewer than 3 logged sessions or fewer than 3 recorded mistakes, the system displays honest states: `"Not enough study data yet to compute load signal"` and `"No repeat mistake patterns detected yet"`.
  * Preparation snapshot displays `"Insufficient baseline data"` with confidence: `"Low"` until meaningful syllabus and practice items are recorded.

---

## 🎵 8. Audio & Sound Synthesis Architecture

FocusForge generates ambient study soundscapes locally using the **Web Audio API** in `src/components/sound-player.tsx`:
* **Rain Noise**: White noise generator filtered through a low-pass biquad filter with gain oscillation.
* **Lofi Rain Drops**: Random frequency sine wave bursts simulating raindrops.
* **White Noise**: Pink noise buffer algorithm.
* Zero external audio file downloads required, guaranteeing 100% offline usability.
