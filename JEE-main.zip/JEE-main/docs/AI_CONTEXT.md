# FocusForge — AI Agent Handbook & Context Reference

> **System Prompt Directive for AI Assistants**: Read this document thoroughly before proposing or executing code modifications on the FocusForge codebase. Maintain strict compliance with Next.js 16 App Router standards, Tailwind CSS v4 CSS-first design engine configurations, Supabase PostgreSQL service modules, Zustand state storage patterns, and all installed design and engineering skill suites.

---

## 📋 Table of Contents

1. [Critical Operational Rules & Stack Mandates](#1-critical-operational-rules--stack-mandates)
2. [Project Goals & Target Persona](#2-project-goals--target-persona)
3. [Technology Stack & Dependency Matrix](#3-technology-stack--dependency-matrix)
4. [Installed Skill Suites & Responsibilities](#4-installed-skill-suites--responsibilities)
5. [Protected Files & Safe Area Boundaries](#5-protected-files--safe-area-boundaries)
6. [Active Architecture Checklist](#6-active-architecture-checklist)

---

## 1. 🚨 Critical Operational Rules & Stack Mandates

### Framework Stack
* **Next.js**: `16.2.6` (App Router). All feature routes exist in `src/app/` (`/study`, `/mistakes`, `/revisions`, `/jee`, `/blocker`, `/analytics`, `/coach`, `/tracker`, `/profile`).
* **React**: `19.2.4`. Interactive pages reading browser state MUST begin with `"use client"`.
* **TypeScript**: `5.x`. Strict type definitions required across all components and service modules.

### Tailwind CSS v4 Engine
* **No `tailwind.config.js`**: All theme tokens, color mappings, and glassmorphism helpers exist in `src/app/globals.css` within the `@theme` block.
* Do not attempt to create or require `tailwind.config.js`.

### Backend Architecture
* **Supabase PostgreSQL & Auth**: All database transactions MUST use dedicated service modules in `src/services/` (e.g., `userService.ts`, `studySessionService.ts`, `blockerService.ts`).
* Do NOT write raw inline database calls inside component pages.

---

## 2. 🎯 Project Goals & Target Persona

FocusForge is an elite, high-focus productivity operating system built specifically for competitive exam aspirants across two authoritative tracks:
- **IIT-JEE (Main & Advanced)**: Physics, Chemistry, and Mathematics.
- **NEET-UG (Medical Entrance)**: Physics, Chemistry, Botany, and Zoology (NMC/NTA 2026 syllabus).

1. **Focus Timers**: Pomodoro (25m), Deep Work (50m), and Custom timers with Web Audio ambient sound generation (Rain, Lofi, White Noise).
2. **Mistake Journal**: Conceptual mistake logging categorized by subject, chapter, and exam-tailored error categories (e.g., Assertion-Reason, NCERT Fact Recall).
3. **Revision Scheduler**: SuperMemo-2 algorithmically spaced repetition (`[1, 3, 7, 15, 30]` days).
4. **Curriculum Hub & Tracker**: Dynamic syllabus visualizer tracking completeness, solved PYQs, NCERT Fact Vault, and formula quick-references across JEE and NEET tracks.
5. **Distraction Shield**: Domain blacklists, whitelist restrictions, schedule slots, and companion Chrome Extension (`public/extension/`).
6. **Analytics Dashboard**: Recharts-based progress analytics and focus score ratings across 3 or 4 subjects.
7. **AI Coach (ForgeCoach)**: Context-aware academic study operating system powered by a 22-tool permission layer, deterministic scientific calculator, official CBSE Class XII 2026–27 & NCERT knowledge retrieval, KaTeX mathematical typesetting, and zero-fake-intelligence observable metrics.

---

## 3. 🛠️ Technology Stack & Dependency Matrix

| Layer | Technology | Target Version | Key Usage & Constraint |
| :--- | :--- | :--- | :--- |
| **Core Framework** | Next.js | `16.2.6` | App Router routing engine. |
| **Cloud Backend** | Supabase | `v2.x` | Supabase Auth & PostgreSQL database (16 tables & RLS policies). |
| **Chrome Extension**| Manifest V3 | `1.0.4` | `public/extension/` website blocking & distraction logger. |
| **3D WebGL Engine** | Three.js | `^0.185.0` | PBR robot rendering in `RobotScene.tsx`. |
| **Kinematics Engine**| GSAP | `^3.15.0` | Mouse tracking lerp, password stealth cover-eyes in `/login`. |
| **UI Framework** | Bootstrap | `5.3.3` | Grid system and responsive layout foundations. |
| **UI Library** | React | `19.2.4` | Component tree rendering. |
| **Language** | TypeScript | `5.x` | Strict type safety. |
| **Styling Engine** | Tailwind CSS | `v4.x` | CSS-first theme variables in `globals.css`. |
| **State Management** | Zustand | `^5.0.13` | Persisted store layer (`useStudyStore` & `useMistakeStore`). |
| **Backend Server** | Express | `^5.2.0` | Standalone server serving static assets and auth APIs (`server.js`). |

---

## 4. 🧠 Installed Skill Suites & Responsibilities

AI agents working on FocusForge MUST comply with installed skill directives:

1. **Leonxlnx Taste Skill (`taste-skill`, `design-taste-frontend`)**: Anti-slop frontend engineering. Infer `DESIGN_VARIANCE`, `MOTION_INTENSITY`, and `VISUAL_DENSITY`. Avoid generic LLM defaults.
2. **Emil Kowalski Motion Skills (`emil-design-eng`, `apple-design`)**: Use spring physics over linear easings for interactive elements.
3. **Impeccable Skill Suite (`impeccable`)**: Maintain production-grade code craft, clean typography tracking (`typeset`), and balanced layouts (`layout`).
4. **Official GSAP Skills (`gsap-skills`)**: Use `useGSAP()` hook for timeline animations and proper cleanup on unmount.

---

## 🔒 5. Protected Files & Safe Area Boundaries

### ⚠️ DO NOT MODIFY Without Explicit User Approval:
* `src/lib/spaced-rep.ts`: Core SuperMemo-2 algorithm calculation logic.
* `src/components/sound-player.tsx`: Headless Web Audio API ambient noise generator.
* `supabase/schema.sql`: Core database schema definitions and RLS policies.
* `public/extension/manifest.json`: Chrome extension Manifest V3 permission configuration.

### ✅ SAFE to Modify:
* Feature page layouts in `src/app/`.
* Reusable visual primitives in `src/components/ui/`.
* Service modules in `src/services/`.
* CSS theme tokens in `src/app/globals.css`.

---

## 📝 6. Active Architecture Checklist

* [x] **Supabase Authentication & PostgreSQL Integration**: Complete service layer in `src/services/` with RLS policies and zero service-role leakage.
* [x] **StudySession Single Source of Truth**: All progress, XP, streaks, analytics, level progress, and dashboard metrics derived dynamically from actual study records.
* [x] **Zero Mock Data Baseline**: Elimination of all mock/seeded progress (`348m`, `14 sessions`, `100 XP`, fake revision dates).
* [x] **Companion Chrome Extension**: Manifest V3 site blocker in `public/extension/` with window postMessage content script bridge.
* [x] **Authoritative YouTube Study Guard Subsystem (`FocusForgeYouTubeGuard`)**: Single authoritative academic classifier (`src/services/academicEngine/`, `Taxonomy 2026.2`, `Classifier v3.0-focusforge-guard`) and companion gateway with strict YouTube API Policy compliance (zero `<video>` element hooks, zero playback tampering, normal behavior when session inactive). Evaluated across 385 test samples with 100.00% precision, 0.00% false allow rate, and 0.00% false block rate.
* [x] **4-Way Sync Engine**: Real-time state persistence between study sessions, mistake journal, revision scheduler, and JEE tracker.
* [x] **FocusForge AI Study Coach Subsystem (`ForgeCoach`)**: Real-time academic operating system with four-zone glassmorphic interface (`/coach`), multi-tier orchestration pipeline (`src/services/coach/`), 22-tool permission layer (READ vs WRITE boundaries), deterministic scientific calculator with zero `eval`, official CBSE Class XII 2026–27 SQP / NCERT knowledge retrieval, KaTeX mathematical typesetting, and zero-fake-intelligence observable metrics engine. Fully verified across 400+ evaluation cases covering Physics, Chemistry, Mathematics, Biology, English Core, JEE Main/Advanced, NEET, CBSE, analytics, mistake diagnostics, and regression suites.
* [x] **Documentation Modernization**: 100% synchronized Markdown files across `docs/` and root `README.md`.
