# FocusForge — Tailwind v4 & Styling Manual

This document provides complete operational guidance on writing, maintaining, and extending CSS styles inside FocusForge using **Tailwind CSS v4**'s CSS-first design engine.

---

## 📋 Table of Contents

1. [Tailwind CSS v4 Engine Configuration](#1-tailwind-css-v4-engine-configuration)
2. [Glassmorphism & Design Tokens (`src/app/globals.css`)](#2-glassmorphism--design-tokens-srcappglobalscss)
3. [Subject Theme Colors](#3-subject-theme-colors)
4. [Responsive Layout & Breakpoint Rules](#4-responsive-layout--breakpoint-rules)
5. [Typography & Tabular Numerals](#5-typography--tabular-numerals)
6. [Styling Best Practices](#6-styling-best-practices)

---

## 1. ⚡ Tailwind CSS v4 Engine Configuration

Tailwind v4 standardizes theme tokens, font scales, and utility overrides inside CSS using `@import "tailwindcss";` and `@theme`.

### Primary File: `src/app/globals.css`

```css
@import "tailwindcss";

@theme {
  --color-background: #08090d;
  --color-foreground: #f3f4f6;

  --color-card-bg: rgba(15, 17, 24, 0.75);
  --color-card-border: rgba(255, 255, 255, 0.08);
  --color-card-hover-border: rgba(255, 255, 255, 0.18);

  --color-physics: #06b6d4;
  --color-chemistry: #10b981;
  --color-maths: #f59e0b;
  --color-accent-purple: #8b5cf6;
  --color-accent-red: #ef4444;
}
```

---

## 2. 🎨 Glassmorphism & Design Tokens (`src/app/globals.css`)

Custom utility classes are registered in `globals.css`:

### 1. `.glass-panel`
* **Purpose**: Translucent background for dashboard cards, sidebars, and overlays.
* **Properties**: `background: rgba(13, 15, 22, 0.65)`, `backdrop-filter: blur(16px)`, `border: 1px solid rgba(255, 255, 255, 0.05)`.

### 2. `.glass-panel-hover`
* **Purpose**: Interactive translation effect on hover for grid items and cards.
* **Properties**: `transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1)`, hover translate `translateY(-2px)`, border illumination `rgba(255, 255, 255, 0.12)`.

### 3. `.glass-input`
* **Purpose**: Dark form fields for search inputs, mistake logs, and select dropdowns.
* **Properties**: Focus ring `rgba(139, 92, 246, 0.5)` with `box-shadow: 0 0 0 2px rgba(139, 92, 246, 0.25)`.

### 4. `.radial-glow`
* **Purpose**: Ambient background light glow behind timer displays and high-value metrics.

---

## 3. 🎯 Subject Theme Colors

Subject domain logic is anchored by distinct color tokens:

| Subject Domain | Theme Variable | Hex Code | Utility Classes |
| :--- | :--- | :--- | :--- |
| **Physics** | `--color-physics` | `#06b6d4` (Electric Cyan) | `text-cyan-400`, `bg-cyan-500/10`, `border-cyan-500/20` |
| **Chemistry** | `--color-chemistry` | `#10b981` (Emerald Green) | `text-emerald-400`, `bg-emerald-500/10`, `border-emerald-500/20` |
| **Mathematics**| `--color-maths` | `#f59e0b` (Warm Amber) | `text-amber-400`, `bg-amber-500/10`, `border-amber-500/20` |
| **Brand Accent**| `--color-accent-purple` | `#8b5cf6` (Focus Purple) | `text-purple-400`, `bg-purple-600`, `border-purple-500/30` |

---

## 4. 📱 Responsive Layout & Breakpoint Rules

FocusForge adheres to mobile-first responsive styling:

* **Mobile Viewports (`< 640px`)**: Single-column layout (`grid-cols-1`), compact padding (`p-3`), slide-over mobile navigation menu.
* **Tablet Viewports (`640px - 1024px`)**: 2-column KPI grids (`sm:grid-cols-2`), `p-4 md:p-6` container spacing.
* **Desktop Widescreen (`>= 1024px`)**: 3 to 4 column dashboards (`lg:grid-cols-3` / `lg:grid-cols-4`), fixed sidebar width (`w-64`), max container width constraint (`max-w-7xl`).

---

## 5. 🔤 Typography & Tabular Numerals

1. **Tabular Numerals**: All ticking counters, focus session timers, XP totals, and date displays MUST include `font-mono tabular-nums`.
2. **Heading Weights**: Page headers use `font-extrabold tracking-tight`. Section headers use `font-bold text-gray-100`.

---

## 6. 🚀 Styling Best Practices

1. **Never Hardcode Hex Values**: Always use Tailwind v4 theme variables (`text-physics`, `bg-accent-purple`, `border-card-border`) or standard utility tokens (`text-cyan-400`).
2. **Backdrop Filter Optimization**: Avoid nesting multiple glass filters inside each other to prevent GPU rendering lag.
3. **Framer Motion Integration**: Prefer Framer Motion `whileHover` and `whileTap` scale props over CSS `:hover` transforms on interactive buttons.
