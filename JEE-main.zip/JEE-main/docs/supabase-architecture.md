# FocusForge — Supabase Systems Architecture

This document describes the high-level architecture, layer separation, client instantiations, data flows, and security model powering the **FocusForge** web application and Chrome Companion Extension.

---

## 🏗️ 1. Core System Topology

```
                   ┌─────────────────────────────────────────┐
                   │    FocusForge Web Application (Next.js) │
                   └────────────────────┬────────────────────┘
                                        │
                 ┌──────────────────────┼──────────────────────┐
                 ▼                      ▼                      ▼
       Browser Supabase Client  Server Supabase Client  Supabase Middleware
         (src/lib/supabase/       (src/lib/supabase/    (src/lib/supabase/
            client.ts)               server.ts)            middleware.ts)
                 │                      │                      │
                 └──────────────────────┼──────────────────────┘
                                        │
                                        ▼
                         ┌─────────────────────────────┐
                         │   Supabase Cloud Platform   │
                         │                             │
                         │  • Supabase Auth Engine     │
                         │  • PostgreSQL DB Engine     │
                         │  • Supabase Realtime Hub    │
                         │  • Supabase Storage Buckets │
                         └──────────────┬──────────────┘
                                        │
                                        ▼
                         ┌─────────────────────────────┐
                         │  Chrome Extension Companion │
                         │  (public/extension/)        │
                         └─────────────────────────────┘
```

---

## 🔒 2. Multi-Tier Client Architecture

To strictly obey Next.js 16 App Router SSR/Client separation and prevent security credential leaks:

### A. Browser Client (`src/lib/supabase/client.ts`)
- Initialized using `createBrowserClient` with `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`.
- Used exclusively within interactive client components (`"use client"`), Zustand store hydrators, and browser-side service handlers.

### B. Server Client (`src/lib/supabase/server.ts`)
- Initialized using `@supabase/ssr` `createServerClient` with dynamic Next.js `cookies()`.
- Used within App Router Server Components, Server Actions, and Route Handlers (`src/app/api/`).

### C. Server-Only Privileged Client (`src/lib/supabase/admin.ts`)
- Initialized using `SUPABASE_SERVICE_ROLE_KEY`.
- Strictly prohibited from client-side bundle execution. Reserved for elevated administrative tasks and webhooks.

### D. Middleware Session Refresher (`src/lib/supabase/middleware.ts` & `src/middleware.ts`)
- Intercepts incoming web requests to refresh expired JWT auth cookies seamlessly without requiring user intervention.

---

## ⚡ 3. Unified Realtime Synchronization Engine

FocusForge features instant, multi-tab, and cross-device sync powered by Supabase Realtime:
1. **Study Session Synchronization**: When a focus session is finished on any device, `study_sessions` row insertion triggers a real-time event that immediately updates Dashboard totals, Consistency Grid tiles, and Study Graphs.
2. **Chrome Extension Synchronization**: The web app sends external messages to the Chrome extension worker (`background.js`) to sync focus state, active task, and website blocker domain rules in real-time.
