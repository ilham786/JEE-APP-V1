# FocusForge — Component Catalog & Visual Primitives Manual

This document provides a comprehensive catalog of structural components, reusable UI primitives, JEE-specific widgets, 3D WebGL scenes, and App Shell layout containers in **FocusForge**.

---

## 📋 Table of Contents

1. [App Shell Components (`src/components/`)](#1-app-shell-components-srccomponents)
2. [3D WebGL Components (`src/components/3d/`)](#2-3d-webgl-components-srccomponents3d)
3. [JEE Prep Components (`src/components/jee/`)](#3-jee-prep-components-srccomponentsjee)
4. [Consistency Grid (`src/components/consistency-grid.tsx`)](#4-consistency-grid-srccomponentsconsistency-gridtsx)
5. [Reusable Design Primitives (`src/components/ui/`)](#5-reusable-design-primitives-srccomponentsui)

---

## 1. 🏗️ App Shell Components (`src/components/`)

### 1. `WorkspaceLayout` (`src/components/workspace-layout.tsx`)
* **Purpose**: Primary app shell container wrapping all interactive feature pages (`/dashboard`, `/study`, `/mistakes`, `/jee`, etc.).
* **Features**: Houses `<Sidebar>`, `<Header>`, and headless `<SoundPlayer>`. Includes responsive mobile sidebar drawer and backdrop.
* **Props**: `children: React.ReactNode`.

### 2. `Sidebar` (`src/components/sidebar.tsx`)
* **Purpose**: Left-hand navigation sidebar displaying application links, active subject indicators, user level/XP progress, and Monk Mode auto-collapse.
* **Features**: Highlighted active route indicators (`/dashboard`, `/study`, `/mistakes`, `/revisions`, `/jee`, `/blocker`, `/analytics`, `/coach`, `/tracker`, `/profile`), XP progress bar.

### 3. `Header` (`src/components/header.tsx`)
* **Purpose**: Sticky header bar providing study streak metrics, volume control, Monk Mode toggle button, and user profile avatar.
* **Features**: Dynamic streak counter badge (`🔥 12 Days`), audio volume slider dropdown, mobile drawer trigger.

### 4. `SoundPlayer` (`src/components/sound-player.tsx`)
* **Purpose**: Headless Web Audio API synthesizer generating real-time procedural soundscapes.
* **Sound Modes**: `Rain` (Low-pass filtered biquad white noise), `Lofi` (Random frequency sine wave drops), `White Noise` (Pink noise buffer algorithm).

---

## 2. 🤖 3D WebGL Components (`src/components/3d/`)

### 1. `RobotScene` (`src/components/3d/RobotScene.tsx`)
* **Purpose**: Real-time 3D WebGL PBR Healthcare Inflatable AI Assistant scene rendered inside the split-screen login page (`/login`).
* **Technical Details**:
  * **Engine**: Three.js WebGL Renderer.
  * **Kinematics**: GSAP procedural interpolation (head look-at mouse tracking, breathing torso oscillation, limb lerp).
  * **Visual Assets**: PBR `MeshPhysicalMaterial` inflatable white vinyl body, glowing holo e-book tablet, particle neural grid network.
  * **Interactions**: Password stealth mode (eyes cover animation during password typing), magnetic GSAP button hover physics.

---

## 3. 📚 JEE Prep Components (`src/components/jee/`)

### 1. `ChapterCard` (`src/components/jee/chapter-card.tsx`)
* **Purpose**: Displays individual JEE chapter progress, completion status, solved PYQ count, and weak topic badges.
* **Props**:
  * `chapter`: JEE chapter data object.
  * `subject`: `'physics' | 'chemistry' | 'maths'`.
  * `onSelect`: Click handler to open detail modal.

### 2. `ChapterDetailModal` (`src/components/jee/chapter-detail-modal.tsx`)
* **Purpose**: Slide-over modal displaying chapter topic breakdown, formula quick-references, solved PYQ increments, and mistake log links.

### 3. `QuickToolsModals` (`src/components/jee/quick-tools-modals.tsx`)
* **Purpose**: Quick access modals for formula reference lookup, formula bookmarking, and notes creation.

### 4. `SubjectAnalytics` (`src/components/jee/subject-analytics.tsx`)
* **Purpose**: Subject completion progress distribution widget displaying completion percentage bars across Physics, Chemistry, and Maths.

---

## 4. 📅 Consistency Grid (`src/components/consistency-grid.tsx`)

### `ConsistencyGrid`
* **Purpose**: 365-day study intensity heatmap grid (GitHub-style contributions graph) visualization.
* **Features**: Displays daily focus time intensity levels (`0m`, `<1h`, `1-3h`, `3-5h`, `>5h`), monthly labels, study streak highlights, and total annual study hour tooltips.
* **Data Provider**: Integrated with `consistencyGridService.ts` and Firestore.

---

## 5. 🛠 Reusable Design Primitives (`src/components/ui/`)

### 1. `Card` (`src/components/ui/card.tsx`)
* **Purpose**: Translucent panel primitive for metrics, charts, forms, and feature cards.
* **Variants**: `.glass-panel` (Standard translucent panel), `.glass-panel-hover` (Interactive hover panel with border highlight).
* **Exports**: `Card`, `CardHeader`, `CardTitle`, `CardDescription`, `CardContent`, `CardFooter`.

### 2. `Controls` (`src/components/ui/controls.tsx`)
* **Exports**:
  * `Button`: Primary, secondary, outline, ghost, danger, physics, chemistry, maths.
  * `ProgressBar`: Smooth progress bar with subject color tokens (`physics`, `chemistry`, `maths`, `purple`).
  * `SectionHeader`: Standard section header with icon, title, and action slot.
  * `EmptyState`: Standardized empty state message placeholder with icon and CTA button.

### 3. `Select` (`src/components/ui/select.tsx`)
* **Purpose**: Accessible dropdown selection menu component supporting subject filters, chapter selection, and duration mode toggles.

### 4. `Carousel` (`src/components/ui/carousel.tsx`)
* **Purpose**: Interactive smooth carousel component for feature highlights, study tips, and formula cards.

### 5. `FocusBorderBeam` (`src/components/ui/focus-border-beam.tsx`)
* **Purpose**: High-signal, GPU-accelerated perimeter focus beam wrapper powered by `border-beam`.

### 6. `CoachThinkingOrb` (`src/components/ui/coach-thinking-orb.tsx`)
* **Purpose**: Semantic cognitive state indicator powered by `thinking-orbs`.

### 7. `Magnetic` (`src/components/ui/magnetic.tsx`)
* **Purpose**: Hardware-accelerated GSAP magnetic cursor-following interaction wrapper.
* **Physics Engine**: `gsap.quickTo` on X and Y axes with cubic-bezier spring return (`power3.out`).
* **Accessibility**: Encapsulates `gsap.matchMedia` for `(prefers-reduced-motion: no-preference)`, automatically disabling physics for users requesting reduced motion.
* **Usage**: Wraps interactive CTA buttons (`Launch Workspace`, `Download Extension`, `Complete Zone`) for tactile, award-winning feedback.

### 8. `LogoutModal` (`src/components/ui/logout-modal.tsx`)
* **Purpose**: High-craft confirmation and session revocation modal preventing accidental sign-outs.
* **Context Awareness**: Checks `useStudyStore().status === 'focus'`. Prominently highlights an active timer hazard if an ongoing focus session would be forfeited.
* **Security & Multi-Tab**: Displays authenticated identity, invokes `/api/auth/logout` HTTP cookie revocation, broadcasts to all open tabs via `BroadcastChannel`, and cleanly redirects to `/login` with an informative confirmation banner.
* **Animation**: Spring motion with backdrop blur, red danger radial glow, and `<ThinkingOrb>` revocation loading state.
