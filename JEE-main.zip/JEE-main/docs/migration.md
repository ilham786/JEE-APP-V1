# FocusForge — Firebase to Supabase Migration Playbook

This document details the step-by-step non-destructive migration process from Firebase/Firestore to Supabase PostgreSQL.

---

## 📋 Migration Steps Performed

1. **Service Layer Abstraction**: Retained exact TypeScript interface signatures across all 27 services in `src/services/`.
2. **Schema Translation**: Mapped Firestore collections (`users`, `studySessions`, `mistakeJournal`, `revisionPlans`, `jeeTracker`, `blockedSites`, `extensionState`) to relational PostgreSQL tables.
3. **Data Parity Verification**: Verified that user data fields (XP, levels, streaks, sessions, notes, formulas) map 1:1 to Supabase tables.
4. **Clean Handover**: Removed legacy inline Firestore listeners in favor of Supabase Realtime channels.
