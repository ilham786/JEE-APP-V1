# FocusForge — Production Design System Specification

FocusForge features a bespoke, dark-themed, glassmorphic design system tailored specifically for high-focus academic preparation. The design system uses Tailwind CSS v4's CSS-first theme architecture.

---

## 🎨 1. Color System & Design Tokens

### Core Color Tokens ([src/app/globals.css](file:///c:/Users/Lenovo/Desktop/JEE/src/app/globals.css))

```css
@theme {
  --color-background: #08090d;        /* Deep Space Black Canvas */
  --color-foreground: #f3f4f6;        /* High-Contrast Light Gray Text */
  
  --color-card-bg: rgba(15, 17, 24, 0.75);
  --color-card-border: rgba(255, 255, 255, 0.08);
  --color-card-hover-border: rgba(255, 255, 255, 0.18);

  --color-physics: #06b6d4;          /* Physics Domain Electric Cyan */
  --color-chemistry: #10b981;        /* Chemistry Domain Green */
  --color-maths: #f59e0b;            /* Mathematics Domain Amber */
  --color-accent-purple: #8b5cf6;    /* Brand Primary Accent / Focus Purple */
  --color-accent-red: #ef4444;       /* Alert / Danger Action Red */
}
```

### Domain Color Association Palette
* **Physics Domain** (`#06b6d4` / `text-cyan-400` / `bg-cyan-600`): Represents Physics chapters, mechanics metrics, and Physics mistake entries.
* **Chemistry Domain** (`#10b981` / `text-emerald-400` / `bg-emerald-600`): Represents Chemistry formulas, organic chemistry logs, and progress bars.
* **Mathematics Domain** (`#f59e0b` / `text-amber-400` / `bg-amber-600`): Represents Mathematics calculus problems, algebra mistakes, and stats.
* **Brand Focus Accent** (`#8b5cf6` / `text-purple-400` / `bg-purple-600`): Used for primary action buttons, streak counters, active timers, and Monk Mode highlights.

---

## 🔤 2. Typography System

* **Primary Body Font**: Inter (`font-sans`) — Modern, ultra-legible neutral sans-serif.
* **Numerical & Code Font**: Geist Mono (`font-mono`) — Monospaced font configured with `tabular-nums` to ensure static layout widths during timer countdown ticks.

### Typography Hierarchy Scale
| Hierarchy Level | Class Specifications | Visual Purpose |
| :--- | :--- | :--- |
| **Page Title** | `text-2xl font-extrabold md:text-3xl tracking-tight text-white` | Main feature page header title. |
| **Section Header** | `text-lg font-bold md:text-xl text-gray-100` | Section headings within feature pages. |
| **Card Title** | `text-base font-bold text-white` | Primary heading inside `.glass-panel` cards. |
| **KPI / Stat Value** | `text-2xl font-black md:text-3xl font-mono tabular-nums text-purple-400` | Large numerical callouts and timer values. |
| **Body Text** | `text-sm text-gray-300 leading-relaxed` | Standard paragraph text and log details. |
| **Subtitles / Labels** | `text-xs text-gray-400 font-medium` | Form labels, card descriptions, metadata. |
| **Micro Badges** | `text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full` | Chapter tags, error category chips. |

---

## 📐 3. Spacing, Radii & Grid System

### Border Radii Tokens
* **Panels & Cards**: `rounded-xl` (12px) — Standard container border radius.
* **Buttons, Inputs & Selects**: `rounded-lg` (8px) — Interactive element radius.
* **Gamification Badges & Chips**: `rounded-full` (9999px) — Streak chips and category tags.

### Grid & Responsive Breakpoints
* **Max Container Width**: `max-w-7xl mx-auto px-4 sm:px-6 lg:px-8`
* **KPI Metrics Grids**: `grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4`
* **Dashboard Layouts**: `grid grid-cols-1 lg:grid-cols-3 gap-6` (2 columns main analytical content, 1 column quick controls/journal).

---

## 🔮 4. Glassmorphic Tokens & Elevation

Defined as reusable CSS classes inside [src/app/globals.css](file:///c:/Users/Lenovo/Desktop/JEE/src/app/globals.css):

### `.glass-panel`
```css
.glass-panel {
  background: rgba(13, 15, 22, 0.65);
  backdrop-filter: blur(16px);
  border: 1px solid rgba(255, 255, 255, 0.05);
  box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.37);
}
```

### `.glass-panel-hover`
```css
.glass-panel-hover {
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}
.glass-panel-hover:hover {
  background: rgba(18, 21, 30, 0.85);
  border-color: rgba(255, 255, 255, 0.12);
  box-shadow: 0 12px 40px 0 rgba(0, 0, 0, 0.5);
  transform: translateY(-2px);
}
```

### `.glass-input`
```css
.glass-input {
  background: rgba(255, 255, 255, 0.03);
  border: 1px solid rgba(255, 255, 255, 0.06);
  border-radius: 8px;
  color: #ffffff;
  transition: all 0.2s ease;
}
.glass-input:focus {
  background: rgba(255, 255, 255, 0.06);
  border-color: rgba(139, 92, 246, 0.5);
  box-shadow: 0 0 0 2px rgba(139, 92, 246, 0.25);
  outline: none;
}
```

---

## 🎬 5. Motion Architecture & Physics Tokens

* **Framer Motion Transition Presets**:
  * `fadeUp`: `initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3, ease: 'easeOut' }}`
  * `buttonTap`: `whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}`
  * `modalSpring`: `type: 'spring', stiffness: 300, damping: 25`
* **CSS Pulse Glow**: Used for Monk Mode active signals:
```css
@keyframes pulse-glow {
  0%, 100% { opacity: 0.4; }
  50% { opacity: 0.9; }
}
.pulse-glow-effect {
  animation: pulse-glow 3s infinite ease-in-out;
}
```

---

## 🔗 Skill Integration Reference

| Design System Dimension | Skill Suite | Value Delivered |
| :--- | :--- | :--- |
| **Color Calibration** | `taste-skill`, `colorize` | Custom dark neutral base (`#090a0f`), subject-locked accent hierarchy. |
| **Typography & Grid** | `impeccable typeset/layout` | Geist Mono tabular numerals, responsive max-width bounds. |
| **Motion Physics** | `emil-design-eng`, `apple-design` | Spring stiffness presets, physical button tap feedback. |
