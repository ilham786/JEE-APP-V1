# FocusForge — Project Overview & Strategic Philosophy

FocusForge is an elite, dark-mode **Study Operating System** engineered specifically for students preparing for high-stakes competitive examinations such as the **IIT-JEE (Joint Entrance Examination)**.

---

## 🎯 1. Vision & Mission

### Vision
To empower students with an all-in-one focus workspace that turns study discipline, error analysis, and spaced repetition into a scientific, seamless habit.

### Mission
Scatter-brained preparation, unorganized mistake notes, and digital distractions cost students hundreds of rank positions every year. FocusForge consolidates time tracking, mistake journals, automated review schedules, distraction blocking, and heuristic coaching under a unified visual interface, transforming raw study hours into measurable academic performance.

---

## 👥 2. Target Persona & User Demographics

### Primary Persona: The IIT-JEE Aspirant
* **High Academic Stakes**: Preparing for JEE Main & Advanced across Physics, Chemistry, and Mathematics.
* **Core Pain Points**:
  * Forgetting previously solved problems and repeating silly mistakes.
  * Losing focus due to digital distractions, tabs, and social media.
  * Lack of structured, algorithmic revision timelines for completed chapters.
  * Difficulty tracking syllabus coverage vs. actual solved Past Year Questions (PYQs).
* **Product Expectations**: Blazing-fast performance, minimalist dark aesthetic, zero visual clutter, distraction-free Monk Mode, instantaneous offline state persistence, and real-time cross-device cloud sync.

---

## 🚀 3. Core Feature Modules

| Module | Route | Purpose & Functionality | Technical Highlights |
| :--- | :--- | :--- | :--- |
| **Marketing Hero** | `/` | Showcase page introducing application features, developer links, and Chrome Extension direct download. | High-impact hero section, feature grid, dark frosted cards. |
| **3D WebGL Login** | `/login` | Award-winning split-screen login portal featuring real-time Three.js 3D PBR AI robot assistant, GSAP kinematics, and Bootstrap 5.3 glassmorphic form. | Three.js PBR `MeshPhysicalMaterial`, glowing holo e-book tablet, particle neural network, mouse tracking lerp, password stealth cover-eyes, magnetic GSAP buttons, Firebase Auth & Guest login. |
| **Workspace Dashboard**| `/dashboard`| Central workspace displaying daily focus progress, active study streak, due revision counts, and subject completion cards. | Real-time metric feeds, quick session start triggers, 365-day consistency grid. |
| **Study Sessions** | `/study` | Focus timer supporting Pomodoro (25m), Deep Work (50m), and Custom duration modes with Monk Mode support. | Real-time Web Audio API ambient synthesizer (rain, lofi, white noise), tick sound effects, XP award triggers. |
| **Mistake Journal** | `/mistakes` | Log conceptual, calculation, silly, or time-pressure mistakes with chapter tags and difficulty ratings. | Full-text search, subject filters, automated SuperMemo-2 spaced repetition date calculation. |
| **Revision Planner** | `/revisions` | Automated review scheduler displaying due items based on SuperMemo-2 algorithms. | Dynamic review intervals (`[1, 3, 7, 15, 30]` days), calendar queue filters, batch revision actions, +100 XP rewards. |
| **JEE Prep Hub** | `/jee` | Syllabus completion matrix tracking progress percentages, solved PYQ totals, and formula quick-references. | Subject accent colors (Physics Electric Cyan, Chemistry Green, Maths Amber), interactive progress bars, formula reference panels. |
| **Distraction Shield** | `/blocker` | Digital blocker registry managing domain blacklists, whitelist restrictions, schedule slots, and exam mode lockouts. | Real-time sync with Companion Chrome Extension, active blocker toggles, visit attempt history logs. |
| **Analytics Dashboard**| `/analytics` | Comprehensive progress charts plotting daily study trends, subject distribution, and mistake categories. | Recharts integration, client mount guards (`useIsClient`), focus score ratings. |
| **AI Study Coach** | `/coach` | Adaptive advisory chat parsing session logs and mistake metrics to deliver actionable study tips. | Heuristic scoring engine (`coach-logic.ts`), burnout index calculation, customized recommendation cards. |
| **Distraction Tracker**| `/tracker` | Historical timeline logging blocked website attempts intercepted by the Chrome Extension. | Activity feed, duration counters, distraction category breakdowns. |
| **User Profile** | `/profile` | User profile overview managing display name, target exam year, total XP level progress, and connected extension status. | Connected browser devices, streak tracking, account settings. |

---

## 🔄 3.1 Global 4-Way Data Sync Engine

FocusForge features a unified, real-time 4-way data sync engine powered by client-side Zustand state persistence (`useStudyStore` & `useMistakeStore`) and Cloud Firestore real-time listeners:

```
       [ Study Session ]  ------->  Completes focus session: +20% completion & +1 revision cycle
              │
       [ Mistake Journal ] ------>  Logs mistake: auto-tags weak topic into syllabus
              │                     Revises mistake: +15% completion & advances spaced repetition
              ▼
    ┌──────────────────┐
    │ Zustand Store /  │  ------->  Real-time state persistence across all pages & devices
    │ Cloud Firestore  │
    └──────────────────┘
              ▲
              │
       [ Revision Plan ]  ------->  Executes due revision: completes spaced cycle & awards +100 XP
              │
       [  JEE Tracker  ]  ------->  Displays live overall completion %, completed cards & weak topics
```

---

## 🎨 4. Design Principles & Aesthetic Philosophy

FocusForge adheres to strict visual design principles to maximize focus and reduce cognitive fatigue:

1. **High-Focus Dark Aesthetic**: Built on a near-black canvas (`#08090d`) using translucent frosted glass overlays (`.glass-panel`) and subtle border contrasts (`rgba(255, 255, 255, 0.05)`).
2. **Subject Accent Identity**: Explicit color tokens anchor subject domain logic immediately:
   * **Physics** = `#06b6d4` (Electric Cyan)
   * **Chemistry** = `#10b981` (Emerald Green)
   * **Maths** = `#f59e0b` (Warm Amber)
   * **Brand Accent** = `#8b5cf6` (Focus Purple)
3. **Monk Mode Discipline**: Hides secondary navigation chrome, sidebars, and statistics when active, leaving only the primary task timer.
4. **Subtle Micro-Animations**: Powered by Framer Motion and GSAP physics. Motion is purposeful, celebrating achievements without creating visual distraction.

---

## 🏆 5. Quality Standards & Current Architecture

* **Multi-Tab Cloud Sync**: Powered by Cloud Firestore real-time listeners and 27 dedicated service modules (`src/services/`).
* **Chrome Companion Protection**: Manifest V3 extension intercepting blacklisted domains and logging visit attempts.
* **Performance**: Sub-100ms interaction latency. Heavy client charts are wrapped in hydration guards (`useIsClient`) to guarantee fast initial renders.
* **Accessibility**: Tab-accessible controls, high-contrast dark modes, and mono-spaced numerical fonts (`tabular-nums`) to prevent layout shifts during timer ticks.
* **Reliability**: 100% offline usability through Zustand `localStorage` persistence and Cloud Firestore `enableIndexedDbPersistence`.
