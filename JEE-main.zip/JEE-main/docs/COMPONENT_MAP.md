# FocusForge — Complete Component Map Catalog

This document provides a comprehensive component mapping catalog detailing every structural component, UI primitive, and feature page module in the FocusForge repository.

---

## 🗺️ Master Component Index

| Component | Category | Path | Reusable | Parent | Children |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **WorkspaceLayout** | Shell Container | [workspace-layout.tsx](file:///c:/Users/Lenovo/Desktop/JEE/src/components/workspace-layout.tsx) | Yes (App-wide) | Root Layout / App Router | Sidebar, Header, SoundPlayer, Children |
| **Header** | Shell Header | [header.tsx](file:///c:/Users/Lenovo/Desktop/JEE/src/components/header.tsx) | Yes | WorkspaceLayout | Sound Dropdown, Monk Mode Button, Streak Badge |
| **Sidebar** | Shell Navigation | [sidebar.tsx](file:///c:/Users/Lenovo/Desktop/JEE/src/components/sidebar.tsx) | Yes | WorkspaceLayout | Nav Link Items, User Level Progress Card |
| **SoundPlayer** | Audio Synth | [sound-player.tsx](file:///c:/Users/Lenovo/Desktop/JEE/src/components/sound-player.tsx) | Yes (Headless) | WorkspaceLayout | None |
| **Card** | UI Primitive | [card.tsx](file:///c:/Users/Lenovo/Desktop/JEE/src/components/ui/card.tsx) | Yes | Any Container | CardHeader, CardContent, CardFooter |
| **CardHeader** | UI Primitive | [card.tsx](file:///c:/Users/Lenovo/Desktop/JEE/src/components/ui/card.tsx) | Yes | Card | CardTitle, CardDescription |
| **CardTitle** | UI Primitive | [card.tsx](file:///c:/Users/Lenovo/Desktop/JEE/src/components/ui/card.tsx) | Yes | CardHeader | Heading Text |
| **CardDescription**| UI Primitive | [card.tsx](file:///c:/Users/Lenovo/Desktop/JEE/src/components/ui/card.tsx) | Yes | CardHeader | Subtitle Text |
| **CardContent** | UI Primitive | [card.tsx](file:///c:/Users/Lenovo/Desktop/JEE/src/components/ui/card.tsx) | Yes | Card | Body Elements |
| **CardFooter** | UI Primitive | [card.tsx](file:///c:/Users/Lenovo/Desktop/JEE/src/components/ui/card.tsx) | Yes | Card | Action Elements / Buttons |
| **Button** | UI Primitive | [controls.tsx](file:///c:/Users/Lenovo/Desktop/JEE/src/components/ui/controls.tsx) | Yes | Any Container | Icons, Labels |
| **ProgressBar** | UI Primitive | [controls.tsx](file:///c:/Users/Lenovo/Desktop/JEE/src/components/ui/controls.tsx) | Yes | Any Container | Inner Fill Bar |
| **EmptyState** | UI Primitive | [controls.tsx](file:///c:/Users/Lenovo/Desktop/JEE/src/components/ui/controls.tsx) | Yes | Any Container | Icon, Message, Action Button |
| **SectionHeader** | UI Primitive | [controls.tsx](file:///c:/Users/Lenovo/Desktop/JEE/src/components/ui/controls.tsx) | Yes | Any Container | Title, Subtitle, Badge |

---

## 🔍 Detailed Component Specifications

### 1. `WorkspaceLayout`
* **Path**: [src/components/workspace-layout.tsx](file:///c:/Users/Lenovo/Desktop/JEE/src/components/workspace-layout.tsx)
* **Purpose**: Primary App Shell wrapper managing sidebar visibility, header state, timer intervals, keyboard hotkeys, and Monk Mode layout collapse.
* **Props**:
  * `children`: `React.ReactNode` (Required) — Feature page content.
  * `title`: `string` (Optional) — Active page title passed to header.
* **Dependencies**: `useStudyStore`, `useKeyboardShortcuts`, `Sidebar`, `Header`, `SoundPlayer`.
* **Parent**: App Router feature pages (`src/app/*/page.tsx`).
* **Children**: `Sidebar`, `Header`, `SoundPlayer`, page content `children`.
* **Reusable Status**: Yes. Wraps all feature pages.
* **Styling**: `min-h-screen bg-[#08090d] text-gray-100 flex`.
* **Animations**: Responsive off-canvas sidebar drawer transition with dark blur backdrop on mobile viewports.
* **Accessibility Notes**: Registers global `Alt + 1..8` and `Space` keyboard shortcuts via `useKeyboardShortcuts`.

---

### 2. `Header`
* **Path**: [src/components/header.tsx](file:///c:/Users/Lenovo/Desktop/JEE/src/components/header.tsx)
* **Purpose**: Workspace top bar displaying page title, responsive mobile hamburger menu button (48x48px touch target), streak counter, volume control dropdown, ambient sound picker, and Monk Mode toggle button.
* **Props**:
  * `title`: `string` (Required) — Current page title.
  * `onMobileMenuToggle`: `() => void` (Optional) — Callback function opening/closing mobile navigation drawer.
* **Dependencies**: `useStudyStore`, `Lucide React` icons, `Framer Motion`.
* **Parent**: `WorkspaceLayout`.
* **Children**: Mobile hamburger button, sound selection menu, volume slider, streak badge, Monk mode toggle button.
* **Reusable Status**: Yes.
* **Styling**: `.glass-panel` background, `h-14 md:h-16 border-b border-white/[0.08] px-3 md:px-6 flex items-center justify-between`.
* **Animations**: Dropdown menu open/close spring scale transition via Framer Motion `AnimatePresence`.
* **Accessibility Notes**: Hamburger button has 48x48px hit-box, `relative z-50`, `pointer-events-auto`, and explicit `aria-label="Open navigation menu"`.

---

### 3. `Sidebar`
* **Path**: [src/components/sidebar.tsx](file:///c:/Users/Lenovo/Desktop/JEE/src/components/sidebar.tsx)
* **Purpose**: Navigation sidebar rendering route links, active page highlighting, user XP/Level progress widget, desktop collapse toggle, and mobile drawer close button.
* **Props**:
  * `onMobileClose`: `() => void` (Optional) — Callback function dismissing mobile off-canvas drawer.
* **Dependencies**: `useStudyStore`, `useIsClient`, `next/navigation` (`usePathname`), `Lucide React` icons.
* **Parent**: `WorkspaceLayout`.
* **Children**: Navigation items (`/dashboard`, `/study`, `/mistakes`, `/revisions`, `/jee`, `/blocker`, `/analytics`, `/coach`, `/tracker`), user Level card.
* **Reusable Status**: Yes.
* **Styling**: `w-64 border-r border-white/5 bg-[#0d0f16]/80 flex flex-col justify-between`.
* **Animations**: Active link indicator highlight slide via Framer Motion.
* **Accessibility Notes**: Uses semantic `<nav>` container and `aria-current="page"` for active routes.

---

### 4. `SoundPlayer`
* **Path**: [src/components/sound-player.tsx](file:///c:/Users/Lenovo/Desktop/JEE/src/components/sound-player.tsx)
* **Purpose**: Headless Web Audio API procedural sound synthesizer generating real-time rain, white noise, and lofi ambient sound loops.
* **Props**: None.
* **Dependencies**: `useStudyStore`.
* **Parent**: `WorkspaceLayout`.
* **Children**: None (Headless component returning `null`).
* **Reusable Status**: Yes.
* **Styling**: None (Renders no DOM markup).
* **Animations**: Smooth volume ramp transitions via `linearRampToValueAtTime`.
* **Accessibility Notes**: Responds immediately to volume and mute toggles from the global study store.

---

### 5. `Card` & UI Card Sub-components
* **Path**: [src/components/ui/card.tsx](file:///c:/Users/Lenovo/Desktop/JEE/src/components/ui/card.tsx)
* **Purpose**: Core translucent frosted glass card panel container supporting modular sub-components (`CardHeader`, `CardTitle`, `CardDescription`, `CardContent`, `CardFooter`).
* **Props**:
  * `className`: `string` (Optional) — Additional utility styles.
  * `children`: `React.ReactNode` — Card content.
* **Dependencies**: React standard props.
* **Parent**: Feature pages and containers.
* **Children**: `CardHeader`, `CardContent`, `CardFooter`.
* **Reusable Status**: High. Reusable across all pages.
* **Styling**: `.glass-panel` utility, `rounded-xl border border-white/5 bg-[#0d0f16]/70 shadow-lg`.
* **Animations**: Framer Motion hover elevation when wrapped in `.glass-panel-hover`.
* **Accessibility Notes**: Semantic `<div>` container with clear color contrast ratios.

---

### 6. `Button`
* **Path**: [src/components/ui/controls.tsx](file:///c:/Users/Lenovo/Desktop/JEE/src/components/ui/controls.tsx)
* **Purpose**: Standard interactive button supporting multiple variants (`primary`, `secondary`, `outline`, `ghost`, `danger`, `subject`).
* **Props**:
  * `variant`: `'primary' | 'secondary' | 'outline' | 'ghost' | 'danger' | 'physics' | 'chemistry' | 'maths'`
  * `size`: `'sm' | 'md' | 'lg'`
  * `children`, `className`, standard HTML button props.
* **Dependencies**: React button props, Tailwind class merger.
* **Parent**: Forms, action panels, cards.
* **Children**: Button text and icons.
* **Reusable Status**: High.
* **Styling**: Focus-visible ring styles, smooth background transitions.
* **Animations**: Scale-down tap feedback via Framer Motion `whileTap={{ scale: 0.98 }}`.
* **Accessibility Notes**: Includes `:focus-visible` ring indicators and `disabled` state handling.

---

### 7. `ProgressBar`
* **Path**: [src/components/ui/controls.tsx](file:///c:/Users/Lenovo/Desktop/JEE/src/components/ui/controls.tsx)
* **Purpose**: Animated progress bar supporting subject color variants (Physics Blue, Chemistry Green, Maths Amber, Accent Purple).
* **Props**:
  * `value`: `number` (0 - 100).
  * `color`: `'physics' | 'chemistry' | 'maths' | 'accent'`.
  * `height`: `'sm' | 'md' | 'lg'`.
* **Dependencies**: React props.
* **Parent**: Cards, Syllabus visualizers, Level indicator widgets.
* **Children**: Inner animated progress fill bar.
* **Reusable Status**: High.
* **Styling**: Outer track `bg-white/5 rounded-full overflow-hidden`, inner fill `h-full rounded-full transition-all duration-500`.
* **Animations**: Smooth width expansion transition.
* **Accessibility Notes**: Includes `role="progressbar"`, `aria-valuenow`, `aria-valuemin={0}`, `aria-valuemax={100}`.

---

### 8. `EmptyState`
* **Path**: [src/components/ui/controls.tsx](file:///c:/Users/Lenovo/Desktop/JEE/src/components/ui/controls.tsx)
* **Purpose**: Placeholder visual component displayed when lists (mistakes, revisions, logs) are empty.
* **Props**:
  * `icon`: `LucideIcon`
  * `title`: `string`
  * `description`: `string`
  * `actionLabel`: `string` (Optional)
  * `onAction`: `() => void` (Optional)
* **Dependencies**: `Lucide React` icons, `Button`.
* **Parent**: Feature list views (`/mistakes`, `/revisions`, `/tracker`).
* **Children**: Icon, heading text, description text, action button.
* **Reusable Status**: High.
* **Styling**: `flex flex-col items-center justify-center p-8 text-center border border-dashed border-white/10 rounded-xl`.
* **Animations**: Subdued entrance fade.
* **Accessibility Notes**: Descriptive heading tags and accessible action buttons.

---

## 🔗 Skill Integration Reference

| Component Architecture | Applied Skill Suite | Implementation Outcome |
| :--- | :--- | :--- |
| **Shell & Grid Layout** | `stitch-skill`, `impeccable shape` | Enforces consistent app shell dimensions, sidebars, and responsive break points. |
| **UI Primitives** | `impeccable craft`, `distill` | Standardized `Card`, `Button`, and `ProgressBar` tokens without redundant code. |
| **Motion Physics** | `emil-design-eng`, `apple-design` | Touch scale taps, dropdown spring physics, and list entry fades. |
