# FocusForge — Companion Chrome Extension Architecture & Setup Guide

This document provides a comprehensive specification of the **FocusForge Companion Chrome Extension** (`FocusForge Companion — IIT-JEE Focus Shield`, Version `1.0.4`), its Manifest V3 architecture, website blocking engine, real-time Firestore synchronization, and packaging workflows.

---

## 📋 Table of Contents

1. [Overview](#-overview)
2. [Extension Architecture & Directory Layout](#-extension-architecture--directory-layout)
3. [Manifest V3 Configuration (`manifest.json`)](#-manifest-v3-configuration-manifestjson)
4. [Background Service Worker (`background.js`)](#-background-service-worker-backgroundjs)
5. [Content Script Injection (`content.js`)](#-content-script-injection-contentjs)
6. [Extension Popup Interface (`popup.html` / `popup.js`)](#-extension-popup-interface-popuphtml--popupjs)
7. [Distraction Block Page (`block-page/`)](#-distraction-block-page-block-page)
8. [Real-time Web App Synchronization](#-real-time-web-app-synchronization)
9. [Extension Packaging & Download API](#-extension-packaging--download-api)
10. [Developer Installation Guide (Unpacked Extension)](#-developer-installation-guide-unpacked-extension)

---

## 🚀 Overview

The **FocusForge Companion Chrome Extension** acts as the client-side enforcement arm of the Distraction Shield (`/blocker`). It connects directly to the FocusForge web application via Cloud Firestore, intercepting distracting domain visits in real-time, redirecting blocked attempts to an interactive focus screen, and logging distraction attempt statistics.

---

## 📁 Extension Architecture & Directory Layout

The extension source files reside in `public/extension/`:

```
public/extension/
├── manifest.json              # Manifest V3 configuration manifest
├── background.js              # Service Worker managing declarativeNetRequest & alarms
├── content.js                 # Content script injected at document_start
├── popup/
│   ├── popup.html             # Extension status popup interface
│   └── popup.js               # Popup status script & state toggle
├── block-page/
│   ├── index.html             # High-contrast dark focus block screen
│   ├── style.css              # Glassmorphic styles for block screen
│   └── script.js              # Dynamic quote generator & return to app timer
├── icons/
│   ├── icon16.png             # 16x16 extension toolbar icon
│   ├── icon48.png             # 48x48 extension management icon
│   └── icon128.png            # 128x128 Chrome Web Store icon
```

---

## ⚙️ Manifest V3 Configuration (`manifest.json`)

```json
{
  "manifest_version": 3,
  "name": "FocusForge Companion — IIT-JEE Focus Shield",
  "version": "1.0.4",
  "description": "Commercial-grade Focus Operating System companion for site blocking, focus enforcement, and browser activity tracking.",
  "action": {
    "default_popup": "popup/popup.html",
    "default_title": "FocusForge Status"
  },
  "background": {
    "service_worker": "background.js"
  },
  "content_scripts": [
    {
      "matches": ["<all_urls>"],
      "js": ["content.js"],
      "run_at": "document_start"
    }
  ],
  "web_accessible_resources": [
    {
      "resources": ["block-page/index.html"],
      "matches": ["<all_urls>"]
    }
  ],
  "permissions": [
    "declarativeNetRequest",
    "declarativeNetRequestWithHostAccess",
    "storage",
    "tabs",
    "webNavigation",
    "notifications",
    "alarms",
    "scripting",
    "activeTab"
  ],
  "host_permissions": [
    "<all_urls>"
  ]
}
```

### Key API Permissions
* `declarativeNetRequest`: High-performance, declarative network request redirection for site blocking without latency overhead.
* `webNavigation`: Captures navigation events to detect block rule triggers and log visit statistics.
* `storage`: Persists local blocklists, active study timer session state, and user Auth credentials in `chrome.storage.local`.
* `alarms`: Schedules background ping heartbeats to maintain active connection status with Cloud Firestore.

---

## 🛠 Background Service Worker (`background.js`)

The background service worker functions as an autonomous event handler:

1. **Rule Generation**: Converts blacklisted domain arrays (e.g., `["instagram.com", "youtube.com"]`) into `declarativeNetRequest` dynamic rules.
2. **Redirection Handler**: Redirects blocked navigation requests to the local extension resource `block-page/index.html`.
3. **Firestore Heartbeat Ping**: Updates `extensionState/{userId}` document every 60 seconds with `lastPing` timestamps.
4. **Visit Attempt Logger**: Pushes blocked visit attempt events to the `visitLogs` collection in Cloud Firestore.

---

## 📜 Content Script Injection (`content.js`)

Injected at `document_start` across all web pages:
* Listens for postMessage signals from the active FocusForge web application (`http://localhost:3000` or production domain).
* Synchronizes `userId` authentication tokens and active Focus Session status (`isMonkMode`, `timerActive`).
* Automatically broadcasts state updates into `chrome.storage.local`.

---

## 📱 Extension Popup Interface (`popup.html` / `popup.js`)

The extension toolbar popup displays real-time connection status:
* **Active Status Indicator**: Visual indicator displaying `Shield Active` or `Shield Paused`.
* **Current Focus Mode**: Displays current session state (e.g., `Pomodoro Focus — Physics`).
* **Blocked Count**: Counter displaying total domain visits intercepted today.
* **Quick Toggle**: Manual shield override switch.

---

## 🚫 Distraction Block Page (`block-page/`)

When a user attempts to visit a blacklisted website during an active focus session or with active website blocking:

1. The navigation request is canceled via `declarativeNetRequest`.
2. Chrome renders `chrome-extension://<id>/block-page/index.html`.
3. The page presents:
   * **High-Focus Dark Aesthetic**: Glowing focus ring and dark glass panel.
   * **Motivational Advice**: Dynamic study tip / quote generator targeted at JEE aspirants.
   * **Interception Details**: Attempted domain name and block rule category (`Blacklisted Domain` or `Exam Lock Mode`).
   * **Quick Return CTA**: Button to jump directly back to the active FocusForge workspace session (`http://localhost:3000/study`).

---

## 🔄 Real-time Web App Synchronization

Synchronization between the Next.js web application and the Chrome Extension works via Cloud Firestore and `extensionService.ts`:

```
┌──────────────────────────┐          Firestore doc          ┌──────────────────────────┐
│  FocusForge Web App      │  ────────────────────────────>  │  extensionState/{userId} │
│  (/blocker & /study)     │                                 └─────────────┬────────────┘
└─────────────▲────────────┘                                               │
              │                                                            │ 60s Heartbeat
              │                 chrome.storage.local                       ▼
              └────────────────────────────────────────────  ┌──────────────────────────┐
                                                             │  Chrome Extension        │
                                                             │  (background.js worker)  │
                                                             └──────────────────────────┘
```

1. Changing block rules in `/blocker` calls `extensionService.updateExtensionState(uid, { activeBlocker: true })`.
2. Firestore updates the `blockedSites/{userId}` collection.
3. The Chrome Extension service worker detects Firestore document mutations, parses domain lists, and updates `declarativeNetRequest` rules instantly.

---

## 📦 Extension Packaging & Download API

FocusForge includes an automated build script and API endpoint for packaging and downloading the extension:

### Build Script (`scripts/package-extension.js`)
Generates a compressed `.zip` archive containing the production extension:
```bash
npm run package:extension
```
* Executable via Node.js script.
* Zips `public/extension/` directory.
* Outputs `public/FocusForge-Extension-v1.1.0.zip`.

### Download API Route (`src/app/api/download-extension/route.ts`)
Serves the generated `.zip` package directly to users from the website:
* **Endpoint**: `GET /api/download-extension`
* **Response**: Zip archive file buffer with `Content-Type: application/zip` and filename `FocusForge-Extension-v1.1.0.zip`.

---

## 🔧 Developer Installation Guide (Unpacked Extension)

To install the companion extension locally during development:

1. Click **Download Chrome Extension** on the FocusForge home page or run:
   ```bash
   npm run package:extension
   ```
2. Open Google Chrome and navigate to `chrome://extensions`.
3. Enable **Developer mode** toggle in the top right corner.
4. Click **Load unpacked**.
5. Select the `public/extension/` folder in your local repository directory.
6. The extension icon will appear in your Chrome extension toolbar.
7. Open [http://localhost:3000](http://localhost:3000) — the extension will automatically connect to your session!
