# FocusForge — PostgreSQL Database Schema Reference

This document catalogs the 16 core PostgreSQL database tables, relationships, indexes, and triggers powering FocusForge.

---

## 🗄️ Database Tables Overview

| Table Name | Primary Key | Foreign Key | Description |
| :--- | :--- | :--- | :--- |
| `profiles` | `id` (UUID) | `auth.users(id)` | User profile metadata, exam goals, XP, level, streaks, and preferences. |
| `usernames` | `username` (TEXT) | `profiles(id)` | Username availability mapping for student handles. |
| `study_sessions` | `id` (TEXT) | `profiles(id)` | Primary log of completed and active study sessions across Physics, Chem, Math. |
| `daily_stats` | `id` (TEXT) | `profiles(id)` | Daily aggregated study minutes and total session counts. |
| `consistency_grid` | `id` (TEXT) | `profiles(id)` | Daily GitHub-style heatmap records storing intensity levels and subject distributions. |
| `revision_plans` | `id` (TEXT) | `profiles(id)` | SuperMemo-2 scheduled revision cycles and recall history. |
| `custom_revision_plans` | `id` (TEXT) | `profiles(id)` | User-created custom revision tasks and due dates. |
| `mistake_journal` | `id` (TEXT) | `profiles(id)` | Conceptual mistake logs, error categories, wrong attempts, and solutions. |
| `jee_progress` | `id` (TEXT) | `profiles(id)` | NTA JEE syllabus completion percentage, solved PYQ counts, and bookmarks. |
| `notes` | `id` (TEXT) | `profiles(id)` | Student study notes, chapter references, and pinned entries. |
| `formula_sheets` | `id` (TEXT) | `profiles(id)` | Bookmarked formula entries, LaTeX expressions, and variable definitions. |
| `blocked_sites` | `id` (TEXT) | `profiles(id)` | Domain blacklist entries for Web Blocker enforcement. |
| `distraction_logs` | `id` (TEXT) | `profiles(id)` | Timestamped logs of blocked site visit attempts. |
| `browser_devices` | `id` (TEXT) | `profiles(id)` | Connected browser companion devices and status. |
| `extension_state` | `user_id` (UUID) | `profiles(id)` | Realtime Chrome Extension focus state and blocking rules. |

---

## 🔄 Automatic User Creation Trigger

```sql
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, email, display_name, photo_url, username)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'name', SPLIT_PART(NEW.email, '@', 1)),
    COALESCE(NEW.raw_user_meta_data->>'avatar_url', 'https://api.dicebear.com/7.x/bottts/svg?seed=' || NEW.id),
    SPLIT_PART(NEW.email, '@', 1)
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
```
