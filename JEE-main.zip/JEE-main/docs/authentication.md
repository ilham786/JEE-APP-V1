# FocusForge — Authentication Architecture & Lifecycle

This document describes the authentication flows, session handling, state management, and user identity model in FocusForge.

---

## 🔑 Primary User Identity Model

- **Universal Identifier**: `auth.users.id` (UUID).
- **Secondary Attributes**: Usernames (`@handle`), display names, and email addresses are secondary attributes stored in `public.profiles`. They are never used as primary keys.

---

## 🔐 Auth Operations Supported (`AuthContext.tsx`)

1. **Email & Password Signup**: Executes `supabase.auth.signUp()`, stores metadata in user profile, and initializes user state.
2. **Email & Password Login**: Executes `supabase.auth.signInWithPassword()`, restores session, and loads user profile.
3. **Google OAuth**: Executes `supabase.auth.signInWithOAuth({ provider: 'google' })`.
4. **Anonymous Guest Session**: Executes `supabase.auth.signInAnonymously()` with local storage session fallback (`focusforge_guest_uid`).
5. **Password Reset**: Executes `supabase.auth.resetPasswordForEmail()`.
6. **Session Refresh**: Managed automatically by `onAuthStateChange()` listener and Next.js middleware.
