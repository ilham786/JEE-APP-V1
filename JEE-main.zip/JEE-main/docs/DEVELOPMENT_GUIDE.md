# FocusForge — Developer & Contributor Handbook

Welcome to the FocusForge developer handbook. This guide covers local setup, directory conventions, adding new features, Firestore service module implementation, Chrome extension packaging, testing procedures, Git workflows, and AI skill suite usage.

---

## 📋 Table of Contents

1. [Quick Start & Setup](#1-quick-start--setup)
2. [Command Line Operations](#2-command-line-operations)
3. [Coding & Directory Standards](#3-coding--directory-standards)
4. [Step-by-Step Developer Tutorials](#4-step-by-step-developer-tutorials)
   - [Tutorial A: Adding a New Feature Page](#tutorial-a-adding-a-new-feature-page)
   - [Tutorial B: Creating a Cloud Firestore Service Module](#tutorial-b-creating-a-cloud-firestore-service-module)
   - [Tutorial C: Adding a Zustand Store Action](#tutorial-c-adding-a-zustand-store-action)
   - [Tutorial D: Packaging the Companion Chrome Extension](#tutorial-d-packaging-the-companion-chrome-extension)
5. [Hydration Guards & SSR Protection](#5-hydration-guards--ssr-protection)
6. [AI Agent Workflow & Skill Guidelines](#6-ai-agent-workflow--skill-guidelines)

---

## ⚡ 1. Quick Start & Setup

### Prerequisites
* **Node.js**: `v18.0.0` or higher (v20+ recommended).
* **Package Manager**: `npm` (`v9.x` or higher).
* **Git**: `v2.x`.
* **Google Chrome**: For Companion Extension development.

### Setup Instructions
1. **Clone the repository**:
   ```bash
   git clone https://github.com/ilham786/JEE.git
   cd JEE
   ```
2. **Install dependencies**:
   ```bash
   npm install
   ```
3. **Configure Environment Variables**:
   Copy `.env.example` to `.env` and fill in your Firebase project keys:
   ```bash
   cp .env.example .env
   ```
4. **Start Next.js development server**:
   ```bash
   npm run dev
   ```
5. Open [http://localhost:3000](http://localhost:3000) in your browser.

---

## 🛠️ 2. Command Line Operations

| Script Command | Action |
| :--- | :--- |
| `npm run dev` | Launches hot-reloading Next.js dev server on port `3000` (`0.0.0.0`) |
| `npm run build` | Compiles Next.js bundle and checks TypeScript types |
| `npm run start` | Serves compiled production build locally |
| `npm run server` | Starts standalone Node.js Express Auth Server (`server.js`) on port `3001` |
| `npm run package:extension` | Packages Chrome Extension into `public/FocusForge-Extension-v1.1.0.zip` |
| `npm run lint` | Runs ESLint analysis for code quality & formatting |
| `npm run prisma:generate` | Generates Prisma client types from `schema.prisma` |
| `npm run db:push` | Synchronizes local SQLite schema |
| `npm run db:seed` | Seeds local SQLite database with demo models |

---

## 📐 3. Coding & Directory Standards

### Directory Conventions
* **App Router Feature Pages**: `src/app/<feature-name>/page.tsx` (`kebab-case`).
* **Firestore Services**: `src/services/<domain>Service.ts` (`camelCase`).
* **3D WebGL Components**: `src/components/3d/<SceneName>.tsx` (`PascalCase`).
* **Structural Components**: `src/components/<component-name>.tsx` (`kebab-case`).
* **UI Primitives**: `src/components/ui/<primitive-name>.tsx`.
* **Zustand State Stores**: `src/store/use-<domain>-store.ts`.

### Component Writing Rules
1. **Client Directive**: Interactive components accessing browser APIs or Zustand stores MUST start with `"use client"`.
2. **App Shell Wrapping**: Feature pages MUST wrap content inside `<WorkspaceLayout title="...">`.
3. **No Direct Firestore Calls**: Component pages must call service methods in `src/services/` rather than raw `firebase/firestore` queries.
4. **Hydration Protection**: Wrap client-only renders or `localStorage` reads in `useIsClient()`.

---

## 🚀 4. Step-by-Step Developer Tutorials

### Tutorial A: Adding a New Feature Page
1. Create directory `src/app/new-feature/` and file `page.tsx`.
2. Structure page:
   ```tsx
   "use client";

   import { WorkspaceLayout } from "@/components/workspace-layout";
   import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
   import { useIsClient } from "@/hooks/use-is-client";

   export default function NewFeaturePage() {
     const isClient = useIsClient();
     if (!isClient) return null;

     return (
       <WorkspaceLayout title="New Feature">
         <Card className="glass-panel">
           <CardHeader>
             <CardTitle>New Feature Component</CardTitle>
           </CardHeader>
           <CardContent>
             <p className="text-gray-300">Feature logic implementation.</p>
           </CardContent>
         </Card>
       </WorkspaceLayout>
     );
   }
   ```
3. Add route entry to `src/components/sidebar.tsx`.

---

### Tutorial B: Creating a Cloud Firestore Service Module
1. Create file `src/services/myFeatureService.ts`.
2. Implement Firestore methods using `db` from `@/lib/firebase`:
   ```typescript
   import { db } from "@/lib/firebase";
   import { doc, getDoc, setDoc } from "firebase/firestore";

   export const myFeatureService = {
     async getFeatureData(userId: string) {
       const ref = doc(db, "myFeatureCollection", userId);
       const snap = await getDoc(ref);
       return snap.exists() ? snap.data() : null;
     },
     async setFeatureData(userId: string, data: any) {
       const ref = doc(db, "myFeatureCollection", userId);
       await setDoc(ref, data, { merge: true });
     }
   };
   ```

---

### Tutorial C: Adding a Zustand Store Action
1. Open `src/store/use-study-store.ts` or `src/store/use-mistake-store.ts`.
2. Declare action signature in state interface.
3. Implement action inside `create(...)` with immutable `set(...)` state mutations.

---

### Tutorial D: Packaging the Companion Chrome Extension
1. Update extension version in `public/extension/manifest.json`.
2. Run packaging command:
   ```bash
   npm run package:extension
   ```
3. Test generated ZIP archive `public/FocusForge-Extension-v1.1.0.zip` by uploading to Chrome (`chrome://extensions`).

---

## 🛡️ 5. Hydration Guards & SSR Protection

Next.js App Router renders pages on the server first. When accessing browser `localStorage` or `window` APIs:

```tsx
import { useIsClient } from "@/hooks/use-is-client";

export function ClientOnlyWidget() {
  const isClient = useIsClient();

  if (!isClient) {
    return <div className="animate-pulse bg-white/5 h-20 rounded-xl" />;
  }

  return <div>{window.location.hostname}</div>;
}
```

---

## 🤖 6. AI Agent Workflow & Skill Guidelines

AI coding assistants MUST follow the repository skill directives:
1. **Context Check**: Read `docs/AI_CONTEXT.md` and `docs/ARCHITECTURE.md`.
2. **Taste Skill (`taste-skill`)**: Output a one-line "Design Read" before outputting UI code. Avoid purple gradient LLM defaults.
3. **Impeccable (`impeccable`)**: Ensure clean typography tracking (`typeset`), balanced spacing (`layout`), and error boundaries.
4. **GSAP Skills (`gsap-skills`)**: Use `useGSAP()` hook for timeline animations and clean up triggers on unmount.
