/**
 * FocusForge — Standalone Express Login Server & Static Host
 * 
 * Serves the interactive split-screen login page with GSAP Baymax robot kinematics,
 * static assets, and authentication API endpoints.
 * 
 * @author ILHAM FAROOQUE
 * @version 1.0.0
 */

const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// API Routes
app.get('/api/health', (req, res) => {
  res.status(200).json({
    status: 'ok',
    service: 'FocusForge Login Auth Service',
    timestamp: new Date().toISOString(),
    uptime: process.uptime()
  });
});

app.post('/api/login', (req, res) => {
  const { email, password, rememberMe } = req.body;
  
  if (!email || !password) {
    return res.status(400).json({
      success: false,
      message: 'Please provide both email and password.'
    });
  }

  // Mock authentication logic
  return res.status(200).json({
    success: true,
    message: 'Authentication successful. Redirecting to FocusForge Workspace...',
    user: {
      email,
      name: email.split('@')[0],
      role: 'IIT-JEE Aspirant',
      targetYear: '2026'
    },
    token: `ff_token_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    redirectUrl: '/dashboard'
  });
});

app.post('/api/guest', (req, res) => {
  return res.status(200).json({
    success: true,
    message: 'Guest session created. Welcome to FocusForge Workspace!',
    user: {
      name: 'Guest Aspirant',
      role: 'IIT-JEE Aspirant (Guest)',
      isGuest: true
    },
    token: `ff_guest_${Date.now()}`,
    redirectUrl: '/dashboard'
  });
});

// Serve main login HTML page for root and login routes
app.get(['/', '/login'], (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

// Start Express server
app.listen(PORT, () => {
  console.log(`=======================================================`);
  console.log(`🚀 FocusForge Express Auth Server Running on Port ${PORT}`);
  console.log(`🔗 Local URL:   http://localhost:${PORT}`);
  console.log(`🔗 Health Check: http://localhost:${PORT}/api/health`);
  console.log(`=======================================================`);
});
