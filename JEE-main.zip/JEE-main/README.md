<p align="center">
  <img src="https://img.icons8.com/nolan/128/brain.png" alt="FocusForge Logo" width="90" />
</p>

<h1 align="center">FocusForge</h1>

<p align="center">
  <strong>An Elite, High-Focus Study Operating System & Academic Planner for IIT-JEE Aspirants.</strong>
</p>

<p align="center">
  <img src="https://img.shields.io/badge/version-0.3.0-blue.svg?style=for-the-badge&color=8b5cf6" alt="Version" />
  <img src="https://img.shields.io/badge/Next.js-16.2.6-black?style=for-the-badge&logo=next.js" alt="Next.js" />
  <img src="https://img.shields.io/badge/Supabase-PostgreSQL-emerald?style=for-the-badge&logo=supabase" alt="Supabase" />
  <img src="https://img.shields.io/badge/Chrome_Extension-Manifest_V3-green?style=for-the-badge&logo=googlechrome" alt="Chrome Extension" />
  <img src="https://img.shields.io/badge/TypeScript-5.x-blue?style=for-the-badge&logo=typescript" alt="TypeScript" />
  <img src="https://img.shields.io/badge/Tailwind_CSS-v4.x-38bdf8?style=for-the-badge&logo=tailwindcss" alt="Tailwind CSS" />
  <img src="https://img.shields.io/badge/Three.js-3D_WebGL-black?style=for-the-badge&logo=three.js" alt="Three.js" />
  <img src="https://img.shields.io/badge/GSAP-Kinematics-green?style=for-the-badge&logo=greensock" alt="GSAP" />
</p>

---

## 📖 Table of Contents

* [1. Executive Overview](#1-executive-overview)
* [2. High-Level System Architecture](#2-high-level-system-architecture)
* [3. Core Feature Catalog](#3-core-feature-catalog)
* [4. Chrome Extension Companion](#4-chrome-extension-companion)
* [5. Firebase & Database Architecture](#5-firebase--database-architecture)
* [6. Real-time 4-Way Data Sync Engine](#6-real-time-4-way-data-sync-engine)
* [7. Project Folder Structure](#7-project-folder-structure)
* [8. Quick Start & Detailed Installation](#8-quick-start--detailed-installation)
* [9. Environment Variables Reference](#9-environment-variables-reference)
* [10. Build & Operations Commands](#10-build--operations-commands)
* [11. User Guide & Workflow Walkthrough](#11-user-guide--workflow-walkthrough)
* [12. Developer Guide & Contributing](#12-developer-guide--contributing)
* [13. Documentation Index](#13-documentation-index)
* [14. License & Attribution](#14-license--attribution)

---

## 🎯 1. Executive Overview

Preparing for high-stakes competitive examinations like **IIT-JEE (Main & Advanced)** demands rigorous error logging, consistent revision discipline, and unyielding focus. **FocusForge** consolidates focus study timers, spaced repetition mistake journals, syllabus coverage trackers, website distraction blocking, and heuristic AI coaching under a unified, high-contrast dark visual interface—replacing fragmented study tools with a centralized **Study Operating System**.

### Core Value Proposition
* **Focus Enforcement**: Maintain study momentum with Pomodoro (25m), Deep Work (50m), and Custom timers backed by real-time Web Audio API ambient sound synthesis (Rain, Lofi, White Noise).
* **3D AI Login Portal**: Award-winning split-screen login page featuring a real-time 3D PBR Healthcare AI Assistant (Baymax-inspired) rendered in Three.js with GSAP procedural kinematics, password stealth cover-eyes, particle neural network, and Bootstrap 5.3 glassmorphic form.
* **Algorithmic Mistake Journal**: Log conceptual, calculation, silly, or time-pressure mistakes with subject tags and auto-calculated **SuperMemo-2** spaced repetition dates (`[1, 3, 7, 15, 30]` days).
* **Companion Chrome Extension**: Manifest V3 site-blocking extension enforcing real-time website blacklists, redirecting blocked attempts to an interactive focus screen, and logging distraction attempts directly to Cloud Firestore.
* **Cloud & Offline Sync**: Powered by Firebase Auth and Cloud Firestore across 27 dedicated service modules, with offline fallback via IndexedDB persistence.

Developed with 💜 by **ILHAM FAROOQUE** ([GitHub Profile](https://github.com/ilham786)). Package name: `focusforge`.

---

## 🏗️ 2. High-Level System Architecture

```mermaid
graph TD
    subgraph Client ["Client Layer (Browser & Web App)"]
        UI["Next.js 16 App Router UI (/study, /mistakes, /jee)"]
        Zustand["Zustand Client Store (LocalStorage Persistence)"]
        WebAudio["Web Audio API Synthesizer (Rain, Lofi)"]
    end

    subgraph ChromeExt ["Chrome Extension (Manifest V3)"]
        Worker["Background Service Worker (background.js)"]
        NetRules["DeclarativeNetRequest Rule Engine"]
        BlockPage["Distraction Block Page (/block-page)"]
    end

    subgraph FirebaseBackend ["Firebase Cloud Backend"]
        FirebaseAuth["Firebase Authentication (Email & Guest Mode)"]
        Firestore["Cloud Firestore (15 Real-time Collections)"]
        IndexedDB["Client IndexedDB (Offline Cache)"]
    end

    subgraph ExpressHost ["Express Host Server (Optional Standalone)"]
        ExpressApp["Express Auth Server (server.js)"]
    end

    UI <-->|Real-time Hooks| Zustand
    UI <-->|Auth & Firestore SDK| FirebaseAuth
    UI <-->|27 Service Modules| Firestore
    Firestore <-->|Offline Queue| IndexedDB
    Worker <-->|Firestore Listeners| Firestore
    NetRules -->|Redirect Intercepts| BlockPage
    UI -->|Extension Package Stream| ExpressApp
```

---

## 🚀 3. Core Feature Catalog

| Feature | Route | Description | Technical Highlight |
| :--- | :--- | :--- | :--- |
| **Marketing Hero** | `/` | Showcase page introducing application features, developer links, and Chrome Extension direct download. | Dynamic hero visualizer, dark frosted cards, feature grid. |
| **3D WebGL Login** | `/login` | Split-screen portal featuring Three.js PBR Baymax assistant, GSAP mouse lerp, password stealth, and Firebase Auth. | Three.js PBR materials, glowing holo tablet, particle neural grid, Bootstrap 5.3 glassmorphic form. |
| **Workspace Dashboard**| `/dashboard`| Central workspace displaying daily focus progress, active study streak, due revision counts, and subject completion cards. | Real-time metric feeds, quick session start triggers, 365-day consistency grid. |
| **Study Session & Monk Mode**| `/study` | Focus study timer supporting Pomodoro (25m), Deep Work (50m), Custom durations, and distraction-free Monk Mode. | Web Audio API ambient synthesizer (Rain, Lofi, White Noise), tick sounds, XP award triggers. |
| **Mistake Journal** | `/mistakes` | Algorithmic error journal categorizing conceptual, calculation, or silly errors with chapter tags and difficulty ratings. | SuperMemo-2 spaced repetition calculation, full-text search, subject filters. |
| **Revision Planner** | `/revisions` | Automated review queue displaying due mistakes based on SuperMemo-2 intervals (`[1, 3, 7, 15, 30]` days). | Calendar queue filter, review action triggers, +100 XP completion rewards. |
| **JEE Prep Hub** | `/jee` | Syllabus completeness matrix tracking completion %, solved PYQ totals, and formula quick-references across Physics, Chemistry, and Maths. | Subject accent themes (Electric Cyan, Emerald Green, Amber), chapter detail modals, formula bookmarks. |
| **Distraction Shield**| `/blocker` | Web blocker registry managing blacklisted domains, whitelisted URLs, schedule slots, and unbypassable Exam Mode lockout. | Real-time sync with Chrome Companion Extension, active shield toggles, visit log history. |
| **Analytics Dashboard**| `/analytics` | Interactive visual charts plotting daily study trends, subject focus distribution, and error category breakdowns. | Recharts integration, client mount guards (`useIsClient`), focus score ratings. |
| **AI Study Coach** | `/coach` | Adaptive advisory engine evaluating study session logs to compute burnout risk indices and study recommendations. | Heuristic scoring engine (`coach-logic.ts`), actionable advice cards. |
| **Distraction Tracker**| `/tracker` | Historical activity log recording blocked domain visit attempts intercepted by the Chrome Extension. | Real-time visit log timeline, attempt frequency metrics. |
| **User Profile** | `/profile` | User profile overview managing display name, target exam year, total XP level progress, and connected companion extension status. | Connected browser devices, streak tracking, account settings. |

---

## 🧩 4. Chrome Extension Companion

FocusForge includes a dedicated **Manifest V3 Companion Chrome Extension** (`FocusForge Companion — IIT-JEE Focus Shield`, v1.0.4) located in `public/extension/`:

* **Site Blocking Engine**: Leverages `declarativeNetRequest` for zero-latency website redirection.
* **Distraction Interception**: Redirects attempts to access blacklisted sites (e.g., `instagram.com`, `youtube.com`) to a high-contrast dark focus screen (`block-page/index.html`).
* **Firestore Sync**: Synchronizes blocklists and focus timer status in real-time with Cloud Firestore (`extensionService.ts`).
* **Distraction Logging**: Automatically records blocked domain visits into the `visitLogs` Firestore collection.
* **Download Package**: Pre-built ZIP archive is served via `GET /api/download-extension` or generated via `npm run package:extension`.

For full extension details, see [docs/EXTENSION.md](file:///c:/Users/Lenovo/Desktop/JEE/docs/EXTENSION.md).

---

## 🔥 5. Firebase & Database Architecture

FocusForge is powered by **Firebase v11** with **15 Cloud Firestore collections**:

1. `users/{userId}`: User profiles, XP, streaks, target exam year.
2. `usernames/{username}`: Unique handle claim registry.
3. `focusSessions/{userId}`: Live active focus timer state and Monk Mode toggles.
4. `blockedSites/{userId}`: Blacklisted/Whitelisted domains and Exam Lock mode.
5. `extensionState/{userId}`: Chrome extension status and heartbeat.
6. `browserDevices/{userId}/devices/{deviceId}`: Connected browser devices.
7. `analytics/{userId}`: Subject study totals and daily trend logs.
8. `jeeTracker/{userId}`: Chapter completion rates and solved PYQ counts.
9. `studySessions/{sessionId}`: Historical completed study session records.
10. `visitLogs/{logId}`: Blocked distraction attempt logs.
11. `mistakeJournal/{mistakeId}`: Error entries and SuperMemo-2 revision intervals.
12. `notes/{noteId}`: Notes Hub documents.
13. `formulaBookmarks/{formulaId}`: Bookmarked formula expressions.
14. `revisionPlans/{planId}`: Scheduled custom review sessions.
15. `notifications/{notifId}`: In-app notifications and coaching tips.

For complete database schema and security rules, see [docs/FIREBASE.md](file:///c:/Users/Lenovo/Desktop/JEE/docs/FIREBASE.md).

---

## 🔄 6. Real-time 4-Way Data Sync Engine

FocusForge utilizes a real-time 4-way data synchronization engine powered by client-side Zustand state persistence (`useStudyStore` & `useMistakeStore`) and Cloud Firestore real-time listeners (`onSnapshot`):

```
       [ Study Session ]  ------->  Completes focus session: +20% completion & +1 revision cycle
              │
       [ Mistake Journal ] ------>  Logs mistake: auto-tags weak topic into syllabus
              │                     Revises mistake: +15% completion & advances spaced repetition
              ▼
    ┌──────────────────┐
    │ Zustand / Cloud  │  ------->  Real-time state sync across all open tabs & devices
    │  Firestore Store │
    └──────────────────┘
              ▲
              │
       [ Revision Plan ]  ------->  Executes due revision: completes spaced cycle & awards +100 XP
              │
       [  JEE Tracker  ]  ------->  Displays live overall completion %, completed cards & weak topics
```

---

## 📂 7. Project Folder Structure

```
FocusForge/
├── .agents/                 # AI Assistant skills & guidelines configuration
├── docs/                    # Architectural & project technical documentation
│   ├── AI_CONTEXT.md        # Technical state, protected code, AI agent rules
│   ├── API.md               # REST API & Firestore 27 service SDK docs
│   ├── ARCHITECTURE.md      # Full systems architecture specification
│   ├── CHANGELOG.md          # Version history & release notes
│   ├── COMPONENTS.md         # Component catalog & prop signatures
│   ├── DEVELOPMENT_GUIDE.md # Developer onboarding & coding guide
│   ├── EXTENSION.md         # Chrome Extension Manifest V3 architecture
│   ├── FIREBASE.md          # Firebase Auth & Firestore schema specification
│   ├── PROJECT_OVERVIEW.md  # Vision, persona, & design philosophy
│   └── STYLING_GUIDE.md     # Tailwind CSS v4 theme variables & styling
├── public/                  # Static assets & Chrome Extension source
│   └── extension/           # Chrome Extension Manifest V3 companion app
│       ├── manifest.json    # Extension manifest definition
│       ├── background.js    # Service worker event listener
│       ├── content.js       # Content script for domain sync
│       ├── popup/           # Toolbar popup HTML & JS
│       └── block-page/      # High-contrast distraction block screen
├── scripts/                 # Node.js build & maintenance scripts
│   ├── generate-icons.js    # Extension icon generator
│   └── package-extension.js # Extension ZIP packaging script
├── src/
│   ├── app/                 # Next.js 16 App Router pages & styles
│   │   ├── analytics/       # Progress charts & study trends (/analytics)
│   │   ├── api/             # Next.js API routes (/api/download-extension)
│   │   ├── blocker/         # Distraction shield & web blocker (/blocker)
│   │   ├── coach/           # Heuristic AI study coach (/coach)
│   │   ├── dashboard/       # Main workspace dashboard (/dashboard)
│   │   ├── jee/             # JEE chapter syllabus matrix (/jee)
│   │   ├── login/           # 3D WebGL split-screen login page (/login)
│   │   ├── mistakes/        # Mistake Journal logging page (/mistakes)
│   │   ├── profile/         # User profile & extension status (/profile)
│   │   ├── revisions/       # Spaced repetition review queue (/revisions)
│   │   ├── study/           # Focus study timer & Monk Mode (/study)
│   │   ├── tracker/         # Distraction log history (/tracker)
│   │   ├── globals.css      # Tailwind v4 theme variables & glass styles
│   │   └── page.tsx         # Marketing landing page (/)
│   ├── components/          # Structural React UI components
│   │   ├── 3d/              # Three.js 3D WebGL canvas components
│   │   │   └── RobotScene.tsx # PBR Healthcare Inflatable AI Robot scene
│   │   ├── jee/             # JEE syllabus cards & detail modals
│   │   ├── ui/              # Reusable design primitives (Card, Select, Controls)
│   │   ├── consistency-grid.tsx # 365-day study intensity heatmap
│   │   ├── header.tsx       # App header (Volume dropdown, streak counter)
│   │   └── sidebar.tsx      # Sidebar navigation
│   ├── context/             # React Context Providers (AuthContext.tsx)
│   ├── data/                # Static JEE syllabus datasets & chapter list
│   ├── hooks/               # Custom hooks (useIsClient, useKeyboardShortcuts)
│   ├── lib/                 # Core logic (firebase.ts, spaced-rep.ts, coach-logic.ts)
│   ├── services/            # 27 Firestore Data Access Service modules
│   ├── store/               # Zustand persisted state stores
│   └── theme/               # Subject color themes & helpers
├── firestore.rules          # Firestore Database security rules
├── firebase.json            # Firebase hosting & Firestore config
├── server.js                # Express login server & static host fallback
└── package.json             # Root dependency manifest and scripts
```

---

## ⚡ 8. Quick Start & Detailed Installation

### Prerequisites
* **Node.js**: `v18.0.0` or higher (v20+ recommended).
* **npm**: `v9.x` or higher.
* **Google Chrome**: For testing the Companion Extension.

### Step-by-Step Installation

1. **Clone the repository**:
   ```bash
   git clone https://github.com/ilham786/JEE.git
   cd JEE
   ```

2. **Install dependencies**:
   ```bash
   npm install
   ```

3. **Configure Environment Variables**:
   Copy `.env.example` to `.env` and fill in your Firebase credentials:
   ```bash
   cp .env.example .env
   ```

4. **Start local development server**:
   ```bash
   npm run dev
   ```
   Open [http://localhost:3000](http://localhost:3000) in your browser.

5. **Install Companion Chrome Extension**:
   * Open Chrome and navigate to `chrome://extensions`.
   * Enable **Developer mode** in the top right corner.
   * Click **Load unpacked**.
   * Select the `public/extension/` folder in your repository directory.

---

## 🔑 9. Environment Variables Reference

Defined in `.env`:

| Variable Name | Required | Default / Example | Purpose |
| :--- | :--- | :--- | :--- |
| `NEXT_PUBLIC_FIREBASE_API_KEY` | **Yes** | `AIzaSyBJhzayBT-vTfRbn4y...` | Firebase Auth & API key |
| `NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN` | **Yes** | `jee-tracker-b62a1.firebaseapp.com` | Firebase Auth domain |
| `NEXT_PUBLIC_FIREBASE_PROJECT_ID` | **Yes** | `jee-tracker-b62a1` | Firebase project ID |
| `NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET` | **Yes** | `jee-tracker-b62a1.firebasestorage.app` | Firebase Storage bucket |
| `NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID` | **Yes** | `35950905151` | Cloud Messaging Sender ID |
| `NEXT_PUBLIC_FIREBASE_APP_ID` | **Yes** | `1:35950905151:web:0dac...` | Firebase Web App ID |
| `NEXT_PUBLIC_FIREBASE_MEASUREMENT_ID` | **Yes** | `G-QQFKZKRDFQ` | Google Analytics ID |
| `DATABASE_URL` | Optional | `"file:./dev.db"` | Relational database connection string |

---

## 🛠️ 10. Build & Operations Commands

| Command | Action |
| :--- | :--- |
| `npm run dev` | Starts hot-reloading Next.js development server on port 3000 (`0.0.0.0`) |
| `npm run build` | Compiles application bundle and verifies build correctness |
| `npm run start` | Serves compiled Next.js production build locally |
| `npm run server` | Starts standalone Express Auth & static host server (`server.js`) on port 3001 |
| `npm run package:extension` | Packages `public/extension/` into downloadable `FocusForge-Extension-v1.1.0.zip` |
| `npm run lint` | Runs ESLint analysis for code syntax and formatting |
| `npm run prisma:generate` | Generates Prisma client types from `prisma/schema.prisma` |
| `npm run db:push` | Synchronizes local SQLite schema |
| `npm run db:seed` | Seeds local SQLite database with sample data |

---

## 📖 11. User Guide & Workflow Walkthrough

### 1. Account Creation & Login
Navigate to `/login`. Use **Email Login**, register a new account, or click **Continue as Guest** for instant access without registration.

### 2. Conducting a Study Session
1. Navigate to `/study`.
2. Select your subject (Physics, Chemistry, or Maths) and active chapter.
3. Choose timer duration mode (**Pomodoro 25m**, **Deep Work 50m**, or **Custom**).
4. Optionally toggle **Monk Mode** to collapse interface chrome and enable ambient Web Audio (Rain / Lofi / White Noise).
5. Click **Start Focus Session**. Completing the timer awards XP and logs session metrics.

### 3. Logging Mistakes & Managing Revisions
1. When making an error during practice, open `/mistakes`.
2. Click **Log New Mistake**. Fill in subject, chapter, error category (*Conceptual*, *Calculation*, *Silly*, or *Time Pressure*), and solution notes.
3. FocusForge automatically calculates the initial SuperMemo-2 revision date.
4. Visit `/revisions` daily to complete due mistake reviews, advancing spaced intervals (`1 -> 3 -> 7 -> 15 -> 30 days`).

### 4. Activating Distraction Shield
1. Navigate to `/blocker`.
2. Add distracting domains (e.g., `youtube.com`, `reddit.com`) to your blacklist.
3. Load the companion extension in Chrome. The extension automatically blocks blacklisted domains and logs visit attempts to `/tracker`.

---

## 👩‍💻 12. Developer Guide & Contributing

We welcome open-source contributions! Please review our dedicated guides before submitting Pull Requests:

* **[CONTRIBUTING.md](file:///c:/Users/Lenovo/Desktop/JEE/CONTRIBUTING.md)**: Development setup, branch strategy, commit formats, and code style.
* **[docs/DEVELOPMENT_GUIDE.md](file:///c:/Users/Lenovo/Desktop/JEE/docs/DEVELOPMENT_GUIDE.md)**: Step-by-step guides for adding new routes, components, and Firestore services.

---

## 📚 13. Documentation Index

For in-depth technical documentation, refer to the `docs/` index:

1. **[docs/PROJECT_OVERVIEW.md](file:///c:/Users/Lenovo/Desktop/JEE/docs/PROJECT_OVERVIEW.md)** — Product vision, user persona, core features.
2. **[docs/ARCHITECTURE.md](file:///c:/Users/Lenovo/Desktop/JEE/docs/ARCHITECTURE.md)** — Full technical architecture and state flows.
3. **[docs/FIREBASE.md](file:///c:/Users/Lenovo/Desktop/JEE/docs/FIREBASE.md)** — Firebase Auth, 15 Firestore collections, and security rules.
4. **[docs/EXTENSION.md](file:///c:/Users/Lenovo/Desktop/JEE/docs/EXTENSION.md)** — Manifest V3 Chrome Extension architecture.
5. **[docs/API.md](file:///c:/Users/Lenovo/Desktop/JEE/docs/API.md)** — REST endpoints and 27 Firestore Service SDKs.
6. **[docs/COMPONENTS.md](file:///c:/Users/Lenovo/Desktop/JEE/docs/COMPONENTS.md)** — UI component catalog and prop signatures.
7. **[docs/STYLING_GUIDE.md](file:///c:/Users/Lenovo/Desktop/JEE/docs/STYLING_GUIDE.md)** — Tailwind CSS v4 theme tokens and glass styles.
8. **[docs/DEVELOPMENT_GUIDE.md](file:///c:/Users/Lenovo/Desktop/JEE/docs/DEVELOPMENT_GUIDE.md)** — Developer onboarding and coding tutorials.
9. **[docs/CHANGELOG.md](file:///c:/Users/Lenovo/Desktop/JEE/docs/CHANGELOG.md)** — Complete version release history.
10. **[docs/AI_CONTEXT.md](file:///c:/Users/Lenovo/Desktop/JEE/docs/AI_CONTEXT.md)** — Technical state, protected code, AI rules.

---

## 📜 14. License & Attribution

FocusForge is developed and maintained by **ILHAM FAROOQUE** ([GitHub Profile](https://github.com/ilham786)).

* **License**: Proprietary / Educational Use. All rights reserved.
* **Credits**: Designed for IIT-JEE Aspirants worldwide.
