# Project Vision & Constitution: FocusForge

> **AGENT INSTRUCTION:** Read this file before every iteration. It serves as the project's "Long-Term Memory."

## 1. Core Identity
* **Project Name:** FocusForge
* **Stitch Project ID:** `11990743289466431189`
* **Mission:** An elite aerospace-grade focus and study companion built for IIT-JEE aspirants. Combines real-time Pomodoro study sessions, dynamic distraction tracking, SuperMemo spaced-repetition mistake journaling, and JEE syllabus mastery tracking.
* **Target Audience:** Competitive engineering students (IIT-JEE Main & Advanced).
* **Voice:** Serious, disciplined, motivational, high-agency ("Monk Mode" focus).

## 2. Visual Language
* **Primary Vibe:** Neon Command Deck, High-Focus Dark Cockpit
* **Base Color:** Deep Void Black (`#08090d`)
* **Accents:** Focus Purple (`#8b5cf6`), Physics Cyan (`#06b6d4`), Chemistry Emerald (`#10b981`), Maths Amber (`#f59e0b`)
* **Surfaces:** Translucent frosted glass (`backdrop-filter: blur(24px)`) with specular 1px borders (`rgba(255, 255, 255, 0.08)`)
* **Design System Asset ID:** `51ff9a69e263483ba194b9a9d76c04f9`

## 3. Architecture & File Structure
* **Source App:** Next.js App Router (`src/app/`)
* **Staging HTML Snapshots:** `.stitch/designs/`
* **Design System Definition:** `.stitch/DESIGN.md`
* **Canvas Coordinates & Map:** `.stitch/metadata.json`

## 4. Live Sitemap & Stitch Canvas Layout
All screens have been exported at high fidelity from the running application and synchronized to the Stitch canvas:

* [x] **Design System Document** — Screen `6666050240286072776` (x: 0, 390x884)
* [x] `/dashboard` — Master productivity cockpit with streak, XP level, today's goal, consistency heatmaps, and Monk Warrior challenge. (Screen `14104987130180397456`, x: 490, 1280x800)
* [x] `/study` — Real-time focus session with 3D Baymax companion, Pomodoro/Deep Work timers, whitelist website blocker, ambient sounds, and distraction logger. (Screen `14928633420973837571`, x: 1870, 1280x800)
* [x] `/tracker` — Distraction intelligence with wasted time analysis, peak vulnerability cognitive slots, and domain breakdowns. (Screen `5818553599283153418`, x: 3250, 1280x800)
* [x] `/jee` — IIT-JEE Syllabus Matrix with Physics, Chemistry, and Maths chapter completion progress and PYQ tracker. (Screen `4927125802917848794`, x: 4630, 1280x800)
* [x] `/profile` — Student profile with lifetime statistics, JEE exam target year alerts, badge showcases, and profile customization. (Screen `17177796777776003701`, x: 6010, 1280x800)
* [x] `/login` — High-security authentication portal with dynamic upcoming JEE examination cycles, handle availability verification, and daily study goal inputs. (Screen `973991619018749142`, x: 7390, 1280x800)

## 5. Completed Milestones
* [x] Extract full design tokens & create `DESIGN.md`
* [x] Upload Design System to Stitch via `upload_design_md` and `create_design_system_from_design_md`
* [x] Extract pixel-perfect DOM snapshot of `/dashboard` with Puppeteer
* [x] Extract pixel-perfect DOM snapshot of `/study` with Puppeteer
* [x] Extract pixel-perfect DOM snapshot of `/tracker` with Puppeteer
* [x] Extract pixel-perfect DOM snapshot of `/jee` with Puppeteer
* [x] Extract pixel-perfect DOM snapshot of `/profile` with Puppeteer
* [x] Extract pixel-perfect DOM snapshot of `/login` with Puppeteer
* [x] Upload all 6 application screens into Stitch Project `11990743289466431189`
* [x] Position all screens sequentially on the Stitch canvas
