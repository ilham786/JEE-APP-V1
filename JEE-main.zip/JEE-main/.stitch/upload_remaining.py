import sys
import pathlib
import json
import time

# Add stitch-upload-to-stitch scripts to sys.path
sys.path.insert(0, str(pathlib.Path(r"d:\JEE\.agents\skills\stitch-upload-to-stitch\scripts").resolve()))
from upload_to_stitch import encode_file, build_screen_request, call_batch_create_screens

PROJECT_ID = "11990743289466431189"
API_KEY = "AQ.Ab8RN6IWADhLvEQCwATD1THabb4AuGgr3_OM26b0UFHEPxuamg"
API_URL = "https://stitch.googleapis.com"

FILES_TO_UPLOAD = [
    {"file": r"d:\JEE\.stitch\designs\study.html", "title": "/study"},
    {"file": r"d:\JEE\.stitch\designs\tracker.html", "title": "/tracker"},
    {"file": r"d:\JEE\.stitch\designs\jee.html", "title": "/jee"},
    {"file": r"d:\JEE\.stitch\designs\profile.html", "title": "/profile"},
    {"file": r"d:\JEE\.stitch\designs\login.html", "title": "/login"},
]

results_map = {}

for item in FILES_TO_UPLOAD:
    fpath = pathlib.Path(item["file"])
    title = item["title"]
    print(f"\n==========================================")
    print(f"Uploading {title} from {fpath.name}...")
    b64_data = encode_file(fpath)
    req = build_screen_request("text/html", b64_data, title=title, generated_by="stitch::extract-static-html")
    
    res = call_batch_create_screens(
        api_url=API_URL,
        api_key=API_KEY,
        project_id=PROJECT_ID,
        requests=[req],
        create_screen_instances=True
    )
    
    screen_id = None
    if "results" in res and len(res["results"]) > 0:
        screen_id = res["results"][0]["screen"]["id"]
        print(f"SUCCESS: {title} uploaded -> Screen ID: {screen_id}")
    else:
        print(f"WARNING: Unexpected response structure: {res}")
        
    results_map[title] = {
        "file": fpath.name,
        "screen_id": screen_id,
        "response": res
    }
    time.sleep(1)

with open(r"d:\JEE\.stitch\upload_results.json", "w", encoding="utf-8") as out:
    json.dump(results_map, out, indent=2)

print("\n==========================================")
print("All remaining screens successfully uploaded!")
