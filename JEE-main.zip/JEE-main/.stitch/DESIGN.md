# Design System Specification: FocusForge — High-Performance Study & Productivity

## 1. Overview & Creative North Star: "The Neon Command Deck"
FocusForge is an elite, mission-critical workspace engineered for high-cognitive-load competitive aspirants (IIT-JEE). 
The interface evokes the precision of an aerospace flight deck or quantum terminal: deep obsidian-void dark surfaces (`#08090d`), ultra-refined frosted glass panels with specular micro-borders (`rgba(255, 255, 255, 0.08)`), and subject-specific electromagnetic accents:
* **Physics:** Electric Cyan (`#06b6d4`)
* **Chemistry:** Emerald Green (`#10b981`)
* **Mathematics:** Warm Amber (`#f59e0b`)
* **Brand Core / Focus:** Focus Purple (`#8b5cf6`)
* **Urgency / Danger:** Radiant Red (`#ef4444`)

The UI rejects flat minimalism and generic AI purple gradients in favor of **Tonal Elevation, Depth Layering, and Tabular Precision**.

---

## 2. Colors & Surface Philosophy

### Surface Hierarchy & Depth Layers
* **Base Void (`surface`):** `#08090d` — Deep interstellar dark that eliminates eye fatigue during 8+ hour study marathons.
* **Level 1 Panels (`card-bg`):** `rgba(14, 17, 26, 0.75)` with `backdrop-filter: blur(24px)` and `1px solid rgba(255, 255, 255, 0.08)`.
* **Level 2 Interactive Cards (`card-bg-hover`):** `rgba(20, 25, 38, 0.90)` with border illumination `rgba(255, 255, 255, 0.18)` and soft colored backglows.
* **Surface Lowest (Inputs & Wells):** `rgba(255, 255, 255, 0.04)` with `1px solid rgba(255, 255, 255, 0.10)`.

### Signature Subject Tokens
* **`physics`:** `#06b6d4` | Badge: `bg-cyan-500/10 text-cyan-400 border-cyan-500/20`
* **`chemistry`:** `#10b981` | Badge: `bg-emerald-500/10 text-emerald-400 border-emerald-500/20`
* **`maths`:** `#f59e0b` | Badge: `bg-amber-500/10 text-amber-400 border-amber-500/20`
* **`accent-purple`:** `#8b5cf6` | Primary action buttons, active tab indicators, level meters.

### Glassmorphism & Specular Highlights
Cards feature an inset specular highlight: `box-shadow: 0 10px 38px 0 rgba(0, 0, 0, 0.48), inset 0 1px 0 0 rgba(255, 255, 255, 0.05)`.
Never use 100% opaque card fills or generic box-shadows.

---

## 3. Typography & Numerical Precision

* **Primary Font:** `Inter`, system-ui, -apple-system, sans-serif
* **Monospace / Numerical Font:** `JetBrains Mono` or tabular monospace (`font-mono tabular-nums`)
* **Rules:**
  * All ticking focus counters, timers, XP totals, streaks, and timestamps MUST use `font-mono tabular-nums` to eliminate character jitter.
  * Headings: `font-black tracking-tight text-white` (display: 24px - 32px).
  * Subheadings & Section Titles: `font-bold text-gray-200 text-sm tracking-wide uppercase`.
  * Body text: `text-gray-400 text-xs sm:text-sm leading-relaxed`.

---

## 4. Components & Primitives

### Buttons
* **Primary (Focus Action):** `bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-bold rounded-xl shadow-lg shadow-purple-950/40 hover:brightness-110 active:scale-95`.
* **Secondary / Glass:** `bg-white/[0.06] hover:bg-white/[0.12] text-gray-200 border border-white/[0.10] rounded-xl font-medium`.
* **Subject-Specific Buttons:** Colored low-opacity tint with matching border and glowing icon.

### Cards (`.glass-panel`)
* Rounded corners: `rounded-2xl` (16px) or `rounded-3xl` (24px).
* Padding: `p-4 sm:p-6`.
* Border: `border border-white/[0.08]`.

### Progress Bars
* Container: `h-1.5` or `h-2` with `bg-white/10 rounded-full overflow-hidden`.
* Fill: Subject-colored gradient (`from-purple-500 to-indigo-500` or `from-blue-500 to-cyan-400`) with smooth transition duration.

### Interactive Tags & Pills
* `px-2.5 py-1 rounded-full text-xs font-semibold border`.

---

## 5. Layout & Responsive Architecture

* **Desktop Layout:** Fixed left sidebar (`w-64`), sticky glass header (`h-16`), main scroll container (`max-w-7xl mx-auto p-4 md:p-6`).
* **Mobile Layout:** Collapsible slide-over drawer, bottom navigation, stacked single-column KPI cards.
* **Grid Hierarchy:** 4-column KPI cards (`grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4`), 2:1 analytical charts grid.

---

## 6. Design System Notes for Stitch Generation
* Always generate in **Dark Mode** (`colorMode: DARK`).
* Keep background obsidian: `#08090d`.
* Use semi-transparent glass cards with `1px solid rgba(255, 255, 255, 0.08)`.
* Incorporate subject badges (Physics: cyan, Chemistry: emerald, Maths: amber).
* Timers and statistics must render with monospace font styling.
