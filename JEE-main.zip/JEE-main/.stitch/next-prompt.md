---
page: mistakes
---
A high-cognitive-focus Spaced Repetition Mistake Journal & Review Deck for IIT-JEE aspirants.
The screen lets students log conceptual and calculation errors across Physics, Chemistry, and Mathematics, categorizing them by root cause (Silly mistake, Formula lapse, Conceptual gap, Time pressure). It displays active SuperMemo review queues with countdowns, mastery intervals, and flashcard review interfaces.

**DESIGN SYSTEM (REQUIRED):**
* **Theme:** Dark Mode (`colorMode: DARK`) with Obsidian Void base (`#08090d`).
* **Cards:** Translucent frosted glass (`rgba(14, 17, 26, 0.75)`, `backdrop-filter: blur(24px)`, `1px solid rgba(255, 255, 255, 0.08)`).
* **Subject Tokens:**
  * Physics: Electric Cyan (`#06b6d4`, badge `bg-cyan-500/10 text-cyan-400 border-cyan-500/20`)
  * Chemistry: Emerald Green (`#10b981`, badge `bg-emerald-500/10 text-emerald-400 border-emerald-500/20`)
  * Mathematics: Warm Amber (`#f59e0b`, badge `bg-amber-500/10 text-amber-400 border-amber-500/20`)
  * Core Accent: Focus Purple (`#8b5cf6`)
* **Typography:** `Inter` for headers and copy; `font-mono tabular-nums` for all stats, review counts, intervals, and memory retention percentages.

**Page Structure:**
1. **Header & Quick Stats:** Due for Revision today counter, Memory Retention Score %, and Total Logged Mistakes.
2. **Subject Breakdown Tabs:** All, Physics, Chemistry, Mathematics with active badges.
3. **Active Review Flashcard Deck:** Interactive card showing Question, Tagged Root Cause, Student's Original Wrong Answer, and Spaced Interval buttons (Hard, Good, Easy).
4. **Recent Mistake Log Table / Feed:** Searchable list of logged errors with status pills (Review Due, In Progress, Mastered).
5. **Quick Add Mistake Floating Action / Drawer:** Form to quickly record a question ID, subject, error type, and key takeaway formula.
