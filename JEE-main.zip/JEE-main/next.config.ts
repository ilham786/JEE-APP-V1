import type { NextConfig } from "next";
import path from "path";

const nextConfig: NextConfig = {
  outputFileTracingRoot: path.join(__dirname),
  images: {
    unoptimized: true,
  },
  allowedDevOrigins: [
    "127.0.0.1:3000",
    "localhost:3000",
    "127.0.0.1",
    "localhost",
    "0.0.0.0",
  ],
};


export default nextConfig;
