// FocusForge Companion Extension Background Service Worker (Manifest V3)
// Architecture: Single Source of Truth via Supabase & Web App Realtime State Engine
// Blocker: Declarative Net Request Session Rules with Pause Guard & Temporary Allow Priorities
// Realtime: Dual-Layer (Broadcast Control Channel + Postgres Changes Subscription)

try {
  importScripts("supabase.js");
} catch (e) {
  console.error("[FocusForge Background] Failed to import supabase.js:", e);
}

const SUPABASE_URL = "https://yhcowzmcvlsmcffbqryb.supabase.co";
const SUPABASE_ANON_KEY = "sb_publishable_F20ljth7U20W5cxupHPQiw_btbZuvGk";
const EXTENSION_VERSION = "1.2.0";

let supabaseClient = null;
if (typeof supabase !== "undefined" && typeof supabase.createClient === "function") {
  try {
    supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      auth: {
        persistSession: false,
        autoRefreshToken: true,
        detectSessionInUrl: false,
      },
      realtime: {
        params: {
          eventsPerSecond: 10,
        },
      },
    });
  } catch (err) {
    console.error("[FocusForge Background] Failed to initialize Supabase client:", err);
  }
}

// Durable Auth State Listener — keeps access token in sync across worker sleeps
if (supabaseClient && supabaseClient.auth) {
  try {
    supabaseClient.auth.onAuthStateChange((event, session) => {
      console.log(`[FocusForge Auth] onAuthStateChange event: ${event}`);
      if (session && session.user?.id) {
        authenticatedUserId = session.user.id;
        extensionState.userId = session.user.id;
        chrome.storage?.local?.set({ supabase_auth_session: session });
        if (session.access_token && supabaseClient.realtime && typeof supabaseClient.realtime.setAuth === "function") {
          try {
            supabaseClient.realtime.setAuth(session.access_token);
          } catch (e) {
            console.warn("[FocusForge Auth] realtime.setAuth error in onAuthStateChange:", e);
          }
        }
      } else if (event === "SIGNED_OUT") {
        authenticatedUserId = null;
        extensionState.userId = null;
        extensionState.syncStatus = "AUTHENTICATION_REQUIRED";
        chrome.storage?.local?.remove(["supabase_auth_session"]);
        BlockerManager.clearAllRules();
        updateDerivedStatus();
      }
    });
  } catch (authListenerErr) {
    console.warn("[FocusForge Auth] Failed to register onAuthStateChange:", authListenerErr);
  }
}

// ----------------------------------------------------
// Global State & Definitions
// ----------------------------------------------------

let installationId = null;
let authenticatedUserId = null;
let realtimeChannels = [];
let isRealtimeConnected = false;

// Priority constants for Declarative Net Request
// Hierarchy: System Whitelist (20000) > Temporary Pause Exception (10000) > Normal Blocker/Redirect (100)
const SYSTEM_ALLOW_PRIORITY = 20000;
const TEMPORARY_ALLOW_PRIORITY = 10000;
const BLOCK_RULE_PRIORITY = 100;

// User's Blocked Domains Registry governs all blocking.
// Strict Invariant: Only domains explicitly present in the user's registry are blocked.
const DEFAULT_DISTRACTION_DOMAINS = [];

// Preloaded distraction domains catalog (used strictly for distraction tracking, NOT for blocking)
const PRELOADED_DISTRACTION_DOMAINS = [
  "instagram.com", "facebook.com", "x.com", "twitter.com", "tiktok.com",
  "reddit.com", "snapchat.com", "threads.net", "pinterest.com", "tumblr.com",
  "youtube.com", "twitch.tv", "netflix.com", "dailymotion.com", "primevideo.com",
  "hotstar.com", "disneyplus.com", "vimeo.com", "spotify.com", "discord.com",
  "9gag.com", "imgur.com", "steamcommunity.com", "roblox.com", "chess.com",
  "epicgames.com",
];

// Approved IIT-JEE learning resources & study search engines (never classified as distractions)
const DEFAULT_WHITELISTED_STUDY_SITES = [
  "khanacademy.org",
  "physicswallah.live",
  "unacademy.com",
  "nta.ac.in",
  "jeemain.nta.ac.in",
  "allen.ac.in",
  "vedantu.com",
  "byjus.com",
  "doubtnut.com",
  "embibe.com",
  "esaral.com",
  "mathongo.com",
  "marks.app",
  "exams.nta.ac.in",
  "google.com",
  "google.co.in",
  "bing.com",
  "duckduckgo.com",
];

// Explicit State Machine:
// AUTHENTICATION_REQUIRED | CONNECTED | SESSION_ACTIVE | SESSION_PAUSED | SYNCING | DISCONNECTED
let extensionState = {
  syncStatus: "AUTHENTICATION_REQUIRED",
  userId: null,
  isFocusActive: false,
  activeSessionId: null,
  activeSubject: "No Active Session",
  activeChapter: "Idle",
  activeGoal: "Ready to focus",
  activeSessionMode: "Pomodoro",
  sessionStatus: "idle", // focus | paused | idle
  startTime: null,
  plannedDurationMinutes: 0,
  timeLeftSeconds: 0,
  syncTimestamp: null,
  todayFocusMinutes: 0,
  todayDistractionsCount: 0,
  todayWasteTimeSeconds: 0,
  todayBreakSeconds: 0,
  recentDistractions: [],
  blockedDomains: [],
  activeRuleCount: 0,
  lastSync: null,
  deviceInfo: "Chrome Desktop Companion v1.2.0",
};

// In-memory registry of temporary allow exceptions during paused session
let temporaryAllowState = {
  urls: [],
  domains: [],
  exceptions: [],
};

// Pending guarded requests awaiting user resolution on pause guard page (keyed by tabId)
// Schema: { tabId, originalUrl, domain, sessionId, sessionStatus, guardReason, timestamp }
let pendingGuardedRequests = new Map();

// Active tab-scoped temporary DNR exceptions
// Schema: [{ ruleId, tabId, domain, originalUrl, type: "single_url" | "site", createdAt, sessionId, sessionStatus, expiresWhen }]
let activeTemporaryExceptions = [];

// Track terminal sessions (completed, abandoned, cancelled) to prevent stale events from reactivating
const terminalSessionIds = new Set();

// Active Blocker Configuration Signature: prevents redundant rule re-installations & flicker
let currentInstalledBlockerHash = null;

// ====================================================================
// YouTube Study Content Guard State Machine & Single Source of Truth
// ====================================================================

const DEBUG_YT_GUARD = true;

function logYouTubeGuard(subsystem, ...args) {
  if (DEBUG_YT_GUARD) {
    console.log(`[FocusForge][${subsystem}]`, ...args);
  }
}

// Dedicated rule ID range for Focus Forge YouTube Study Guard session rules
const YT_RULE_RANGE_MIN = 95000;
const YT_RULE_RANGE_MAX = 99900;
const YT_RULE_HOME = 95001;
const YT_RULE_FEED = 95002;
const YT_RULE_SHORTS = 95003;
const YT_RULE_RESULTS = 95004;
const YT_RULE_EXPLORE = 95005;
const YT_RULE_TRENDING = 95006;
const YT_RULE_HANDLES = 95007;
const YT_RULE_CHANNELS = 95008;
const YT_RULE_CUSTOM = 95009;
const YT_RULE_USER = 95010;
const YT_RULE_GATEWAY_REDIRECT = 95020;
const YT_APPROVED_RULE_BASE = 96000;

// Focus Forge YouTube Content Gateway Priority Hierarchy:
// Priority 100: Exact Approved Video Allow (Overrides Gateway Redirect)
// Priority 50: Shorts Surface Restriction
// Priority 10: Video Gateway Redirect (Directs unapproved /watch to youtube-verify.html)
const YT_PRIORITY_EXACT_ALLOW = 100;
const YT_PRIORITY_SHORTS = 50;
const YT_PRIORITY_GATEWAY_REDIRECT = 10;

function logYouTubeDiagnostic(data) {
  if (!DEBUG_YT_GUARD) return;
  const parts = ["[FF][YT]"];
  if (data.session) parts.push(`session=${data.session}`);
  if (data.videoId) parts.push(`videoId=${data.videoId}`);
  if (data.state) parts.push(`state=${data.state}`);
  if (data.event) parts.push(data.event);
  if (data.subject) parts.push(`subject=${data.subject}`);
  if (data.topic) parts.push(`topic=${data.topic}`);
  if (data.decision) parts.push(`decision=${data.decision}`);
  if (data.reason) parts.push(`reason=${data.reason}`);
  if (data.playback) parts.push(`playback=${data.playback}`);
  if (data.blockedBeforeClassification) parts.push(`blockedBeforeClassification=${data.blockedBeforeClassification}`);
  console.log(parts.join(" "));
}

let youtubeGuardState = {
  status: "OFF", // 'OFF' | 'ENABLING' | 'ON' | 'DISABLING' | 'ERROR'
  enabled: false,
  mode: "strict", // 'strict' | 'balanced' | 'custom'
  activeSessionId: null,
  verifiedSessionId: null,
  activeSubject: null,
  activeChapter: null,
  leaseUntil: null,
  lastHeartbeat: null,
  todayStudyWatchSeconds: 0,
  approvedVideoIds: new Set(),
  installedRuleIds: [],
  lastConfigHash: null,
  lastBlockedVideo: null,
  lastAllowedVideo: null,
  error: null,
};

const youtubeClassificationCache = new Map();

// ----------------------------------------------------
// Focus Pass Authorization Model (Session Scoped)
// ----------------------------------------------------
const focusPassRegistry = new Map(); // videoId -> FocusPass

const FocusPassManager = {
  issuePass(videoId, meta = {}) {
    if (!videoId) return null;
    const now = Date.now();
    const ttl = meta.ttlMs || (2 * 60 * 60 * 1000); // 2 hours or study session duration
    const pass = {
      videoId,
      userId: authenticatedUserId || extensionState.userId,
      sessionId: extensionState.activeSessionId,
      decision: meta.decision || "ALLOW",
      subject: meta.subject || extensionState.activeSubject,
      chapter: meta.chapter || extensionState.activeChapter,
      topic: meta.topic || meta.title || "Academic Study",
      confidence: meta.confidence || 0.95,
      reason: meta.reason || "Approved academic content.",
      issuedAt: now,
      expiresAt: now + ttl,
    };
    focusPassRegistry.set(videoId, pass);
    youtubeGuardState.approvedVideoIds.add(videoId);
    youtubeGuardState.lastAllowedVideo = { videoId, title: meta.title, timestamp: now };
    persistGuardRuntimeState();
    return pass;
  },

  hasValidPass(videoId) {
    if (!videoId) return false;
    const pass = focusPassRegistry.get(videoId);
    if (!pass) return false;
    if (Date.now() > pass.expiresAt) {
      focusPassRegistry.delete(videoId);
      youtubeGuardState.approvedVideoIds.delete(videoId);
      persistGuardRuntimeState();
      return false;
    }
    return true;
  },

  getPass(videoId) {
    if (!this.hasValidPass(videoId)) return null;
    return focusPassRegistry.get(videoId);
  },

  clearPasses() {
    focusPassRegistry.clear();
    youtubeGuardState.approvedVideoIds.clear();
    persistGuardRuntimeState();
  },

  count() {
    return focusPassRegistry.size;
  }
};

// ----------------------------------------------------
// Runtime Guard State Persistence via chrome.storage.session
// Survives background service worker restarts and sleep
// ----------------------------------------------------
async function persistGuardRuntimeState() {
  if (!chrome.storage?.session) return;
  try {
    const payload = {
      status: youtubeGuardState.status,
      enabled: youtubeGuardState.enabled,
      mode: youtubeGuardState.mode,
      activeSessionId: extensionState.activeSessionId,
      verifiedSessionId: youtubeGuardState.verifiedSessionId,
      leaseUntil: youtubeGuardState.leaseUntil,
      approvedVideoIds: Array.from(youtubeGuardState.approvedVideoIds),
      installedRuleIds: youtubeGuardState.installedRuleIds,
      passes: Array.from(focusPassRegistry.entries()),
      lastBlockedVideo: youtubeGuardState.lastBlockedVideo || null,
      lastAllowedVideo: youtubeGuardState.lastAllowedVideo || null,
      updatedAt: Date.now(),
    };
    await chrome.storage.session.set({ focusforge_guard_runtime_state: payload });
  } catch (err) {
    logYouTubeGuard("Storage", "Error persisting guard runtime state:", err);
  }
}

async function restoreGuardRuntimeState() {
  if (!chrome.storage?.session) return;
  try {
    const data = await chrome.storage.session.get("focusforge_guard_runtime_state");
    const state = data?.focusforge_guard_runtime_state;
    if (!state) return;

    if (state.verifiedSessionId) {
      youtubeGuardState.verifiedSessionId = state.verifiedSessionId;
    }
    if (state.leaseUntil) {
      youtubeGuardState.leaseUntil = state.leaseUntil;
    }
    if (state.mode) {
      youtubeGuardState.mode = state.mode;
    }
    if (Array.isArray(state.approvedVideoIds)) {
      youtubeGuardState.approvedVideoIds = new Set(state.approvedVideoIds);
    }
    if (Array.isArray(state.installedRuleIds)) {
      youtubeGuardState.installedRuleIds = state.installedRuleIds;
    }
    if (Array.isArray(state.passes)) {
      for (const [vid, pass] of state.passes) {
        if (pass && pass.expiresAt > Date.now()) {
          focusPassRegistry.set(vid, pass);
        }
      }
    }
    if (state.lastBlockedVideo) youtubeGuardState.lastBlockedVideo = state.lastBlockedVideo;
    if (state.lastAllowedVideo) youtubeGuardState.lastAllowedVideo = state.lastAllowedVideo;

    logYouTubeGuard("Storage", "Restored guard runtime state from chrome.storage.session");
  } catch (err) {
    logYouTubeGuard("Storage", "Error restoring guard runtime state:", err);
  }
}

// Restore state on worker execution
restoreGuardRuntimeState();

// Deterministic rule ID generation for approved video (range 96000 - 99500)
function getApprovedVideoRuleId(videoId) {
  let hash = 5381;
  const str = String(videoId || "");
  for (let i = 0; i < str.length; i++) {
    hash = (hash << 5) + hash + str.charCodeAt(i);
    hash = hash & 0x7fffffff;
  }
  return YT_APPROVED_RULE_BASE + (hash % 3500);
}

// Master Invariant Gate:
// YouTube Study Guard MUST work only when a VERIFIED Focus Forge study session is ACTIVE.
// Master Invariant Gate:
// YouTube Study Guard MUST work only when a VERIFIED Focus Forge study session is ACTIVE.
// Condition: authenticated AND session status === ACTIVE/focus AND session ID is valid
// AND session ID matches verified session AND lease has not expired.
function isStudySessionActive() {
  const isAuth = Boolean(authenticatedUserId);
  const isFocus = Boolean(extensionState.isFocusActive) && (extensionState.sessionStatus === "focus" || extensionState.sessionStatus === "active");
  const hasSession = Boolean(extensionState.activeSessionId);
  const isVerifiedSession = hasSession && Boolean(youtubeGuardState.verifiedSessionId) && (youtubeGuardState.verifiedSessionId === extensionState.activeSessionId);
  const validLease = youtubeGuardState.leaseUntil ? Date.now() < youtubeGuardState.leaseUntil : false;

  return isAuth && isFocus && hasSession && isVerifiedSession && validLease;
}

function shouldEnableYouTubeGuard() {
  return isStudySessionActive();
}

function reconcileYouTubeGuardState(trigger = "MANUAL") {
  return YouTubeStudyGuardManager.reconcileState(trigger);
}

function isYouTubeGuardActive() {
  return isStudySessionActive() && youtubeGuardState.status === "ON";
}

function notifyYouTubeTabsGuardState() {
  const active = isYouTubeGuardActive();
  if (chrome.tabs && typeof chrome.tabs.query === "function") {
    chrome.tabs.query({ url: "*://*.youtube.com/*" }, (tabs) => {
      (tabs || []).forEach((t) => {
        if (t.id) {
          chrome.tabs.sendMessage(t.id, {
            type: "YOUTUBE_GUARD_STATE_CHANGED",
            active,
            status: youtubeGuardState.status,
            mode: youtubeGuardState.mode,
            subject: extensionState.activeSubject,
            chapter: extensionState.activeChapter,
            leaseUntil: youtubeGuardState.leaseUntil,
            approvedVideosCount: youtubeGuardState.approvedVideoIds.size,
            approvedVideoIds: Array.from(youtubeGuardState.approvedVideoIds),
          }).catch(() => {});
        }
      });
    });
  }
}

function isStudyAllowedDecision(decision) {
  return decision === "STUDY" || decision === "ALLOW";
}

function isStudyBlockedDecision(decision) {
  return decision === "NON_STUDY" || decision === "BLOCK";
}

function matchesEntityBounded(normText, entityNorm) {
  if (!normText || !entityNorm) return false;
  if (entityNorm.includes(" ") || entityNorm.includes("-")) {
    return normText.includes(entityNorm);
  }
  const escaped = entityNorm.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  return new RegExp(`(^|\\s)${escaped}(\\s|$)`, "i").test(normText);
}

// FocusForge Academic Intelligence Engine (Offline & Local Fallback v2.0-academic-intelligence)
function runLocalFallbackClassification(input) {
  const title = (input.title || "").toLowerCase();
  const channel = (input.channelName || "").toLowerCase();
  const desc = (input.description || "").toLowerCase();
  const combined = `${title} ${desc} ${channel}`.trim();

  // 1. Shorts check: ALWAYS blocked in active study sessions
  if ((input.durationSeconds && input.durationSeconds <= 60) || title.includes("#shorts") || title.includes("#short")) {
    return {
      videoId: input.videoId,
      decision: "NON_STUDY",
      confidence: 1.0,
      confidenceBand: "VERY_HIGH",
      reason: "Short-form video is strictly prohibited during active study sessions.",
      matchedKeywords: ["shorts"],
      isTrustedChannel: false,
      isManuallyApproved: false,
      isShort: true,
      taxonomyVersion: "2026.1",
      classifierVersion: "v2.0-academic-intelligence",
    };
  }

  // 2. Negative Taxonomy (Vlogs, Lifestyle, Hostel Tours, Gaming, Comedy, Tech Reviews, Finance/Hustle)
  const negativeTaxonomyPatterns = [
    /\b(vlog|vlogging|daily vlog|family vlog|travel vlog|vacation vlog)\b/i,
    /\b(day in my life|day in the life|diml|a day in the life of|my day at kota)\b/i,
    /\b(morning routine|night routine|5 am routine|evening routine|aesthetic routine)\b/i,
    /\b(hostel life|college life|school life|hostel tour|room tour|dorm tour|flat tour)\b/i,
    /\b(study setup|desk setup|workspace tour|room setup|desk tour|desk makeover)\b/i,
    /\b(mess food review|hostel food review|canteen vlog|stationery haul|what's in my bag|haul video)\b/i,
    /\b(campus tour|iit campus tour|iit bombay tour|iit delhi tour|college tour|campus walk)\b/i,
    /\b(iit hostel|iit hostel life|hostel room tour|campus vlog|college vlog)\b/i,
    /\b(iit fest|mood indigo|rendezvous|college fest|cultural night|celebration)\b/i,
    /\b(fresher party|freshers party|farewell party|school farewell|college drama|ragging story)\b/i,
    /\b(placement package|packages revealed|highest package at iit|iit salary|salary of iitian)\b/i,
    /\b(result reaction|emotional crying|family reaction|score reaction|college comparison)\b/i,
    /\b(funny moments|try not to laugh|roast|roasting|dank memes?|meme compilation|student memes?|exam memes?|backbenchers?|meme)\b/i,
    /\b(funny fails|classroom chaos|classroom comedy|lab fails|prank|pranks)\b/i,
    /\b(standup comedy|stand up comedy|comedy sketch|funny video|reaction video|reacting to)\b/i,
    /\b(movie clip|full movie|web series|official trailer|teaser trailer|box office)\b/i,
    /\b(music video|official audio|lyrics video|lofi remix|dj remix|romantic songs|bollywood lofi)\b/i,
    /\b(challenge video|24 hours challenge|last to leave|surviving 100 days|mrbeast|asmr|mukbang)\b/i,
    /\b(gaming|gameplay|lets play|speedrun|gaming highlights|streamer highlights)\b/i,
    /\b(minecraft|valorant|gta 5|gta v|gta 6|pubg|bgmi|free fire|fortnite|roblox|cs2|apex legends)\b/i,
    /\b(cricket highlights|ipl 202\d|match highlights|football highlights|messi|ronaldo|wwe)\b/i,
    /\b(unboxing|gadget review|phone review|smartphone unboxing|camera test)\b/i,
    /\b(best phone under|top \d+ phones|best laptops? for|top laptops? for|laptops? under \d+k|best budget picks)\b/i,
    /\b(trading crypto|crypto trading|bitcoin|ethereum|meme coins?|day trading|option trading)\b/i,
    /\b(stock market|investing in stocks|how i made \$\d+|how to make money online|dropshipping|side hustle)\b/i,
    /\b(motivational speech for students|study motivation status|emotional speech|sigma male|hustle motivation)\b/i,
  ];

  let matchedNegative = null;
  for (const pat of negativeTaxonomyPatterns) {
    const m = combined.match(pat);
    if (m) {
      matchedNegative = m[0];
      break;
    }
  }

  // 3. Positive Teaching Action Indicators
  const actionPatterns = [
    /\b(one shot|one-shot|full chapter|complete chapter|marathon|crash course|revision|pyqs?|previous year questions?|numericals?|sample paper|ncert line by line|derivations?)\b/i,
    /\b(solved problems?|question practice|dpp|mock test|formula sheet|mind map|board exam preparation)\b/i,
  ];
  const hasAcademicAction = actionPatterns.some((pat) => pat.test(combined));

  // 4. Negative Context Dominance Rule
  if (matchedNegative && !hasAcademicAction) {
    return {
      videoId: input.videoId,
      decision: "NON_STUDY",
      confidence: 0.98,
      confidenceBand: "VERY_HIGH",
      reason: `Non-academic content detected (${matchedNegative}). Genuinely academic instruction required.`,
      matchedKeywords: [matchedNegative],
      isTrustedChannel: false,
      isManuallyApproved: false,
      isShort: false,
      taxonomyVersion: "2026.1",
      classifierVersion: "v2.0-academic-intelligence",
    };
  }

  // 5. Comprehensive Academic Entities (JEE / NEET / CBSE / NCERT)
  const academicEntities = [
    // Physics
    "rotational motion", "electrostatics", "kinematics", "newton laws", "friction",
    "work energy power", "work and power", "gravitation", "thermodynamics", "oscillations", "waves",
    "electric charges", "current electricity", "magnetism", "electromagnetic induction", "emi",
    "alternating current", "ray optics", "wave optics", "photoelectric", "atoms and nuclei",
    "semiconductors", "logic gates", "capacitance", "electric potential", "biot savart",
    "ampere law", "faraday law", "lenz law", "ac generator", "transformer", "de broglie",
    "bohr model", "young double slit", "interference", "diffraction", "polarization",
    "total internal reflection", "prism formula", "carnot engine", "kinetic theory", "fluid mechanics",
    "surface tension", "center of mass", "moment of inertia", "shm", "doppler effect",
    // Chemistry
    "mole concept", "atomic structure", "periodic table", "chemical bonding", "hybridisation",
    "molecular orbital", "gas laws", "chemical thermodynamics", "enthalpy", "entropy",
    "gibbs free energy", "equilibrium", "le chatelier", "ionic equilibrium", "buffer solution",
    "solubility product", "redox", "oxidation number", "s block", "p block", "d block", "f block",
    "coordination compounds", "isomerism", "solid state", "solutions", "colligative properties",
    "raoult law", "electrochemistry", "nernst equation", "chemical kinetics", "rate law",
    "arrhenius equation", "surface chemistry", "adsorption", "organic chemistry", "iupac nomenclature",
    "reaction mechanism", "carbocation", "hydrocarbons", "alkanes", "alkenes", "alkynes", "benzene",
    "haloalkanes", "haloarenes", "sn1", "sn2", "alcohols phenols", "aldol condensation", "cannizzaro",
    "carboxylic acids", "amines", "diazotization", "biomolecules", "carbohydrates", "amino acids", "polymers",
    // Mathematics
    "sets relations", "trigonometric functions", "complex numbers", "quadratic equations",
    "permutations and combinations", "binomial theorem", "sequences and series", "arithmetic progression",
    "geometric progression", "straight lines", "circles", "parabola", "ellipse", "hyperbola",
    "conic sections", "three dimensional geometry", "3d geometry", "limits", "continuity",
    "differentiability", "differentiation", "derivatives", "maxima minima", "indefinite integrals",
    "definite integrals", "integration by parts", "area under curves", "differential equations",
    "vectors", "vector algebra", "dot product", "cross product", "probability", "bayes theorem",
    "matrices", "determinants", "cramer rule",
    // Biology (NEET)
    "cell the unit of life", "cell cycle", "mitosis", "meiosis", "genetics", "mendelian inheritance",
    "dna replication", "transcription", "translation", "biotechnology", "human physiology",
    "plant physiology", "photosynthesis", "plant respiration", "reproduction in organisms",
    "sexual reproduction flowering", "human reproduction", "evolution", "biodiversity",
    // CBSE Class 12 English
    "flamingo", "vistas", "the last lesson", "lost spring", "deep water", "the rattrap", "indigo",
    "poets and pancakes", "the interview", "going places", "my mother at sixty-six", "keeping quiet",
    "a thing of beauty", "a roadside stand", "aunt jennifer tigers", "third level", "tiger king",
    "journey to the end of the earth", "the enemy", "on the face of it", "memories of childhood",
    "english literature", "english grammar", "reading comprehension", "notice writing", "report writing",
    // Exam anchors
    "jee main", "jee advanced", "neet 202", "cbse class 12", "class 12 board", "pyq discussion",
    "one shot revision", "ncert line by line", "complete chapter revision", "previous year questions"
  ];

  const matchedEntities = [];
  for (const ent of academicEntities) {
    if (matchesEntityBounded(combined, ent)) {
      matchedEntities.push(ent);
    }
  }

  const trustedChannels = [
    "physics wallah", "unacademy", "khan academy", "vedantu", "mohit tyagi",
    "eduniti", "mathongo", "learnohub", "ncert", "apni kaksha", "ashish arora",
    "physics galaxy", "arvind arora", "competishun", "aman dhattarwal", "pankaj sir",
    "magnet brains", "dear sir", "simran sahni", "english academy"
  ];
  const isTrusted = trustedChannels.some((tc) => channel.includes(tc));

  if (matchedEntities.length > 0) {
    return {
      videoId: input.videoId,
      decision: "STUDY",
      confidence: 0.95,
      confidenceBand: "VERY_HIGH",
      reason: `Verified academic syllabus topic: ${matchedEntities.slice(0, 3).join(", ")}.`,
      matchedKeywords: matchedEntities,
      isTrustedChannel: isTrusted,
      isManuallyApproved: false,
      isShort: false,
      taxonomyVersion: "2026.1",
      classifierVersion: "v2.0-academic-intelligence",
    };
  }

  if (isTrusted && youtubeGuardState.mode !== "strict") {
    return {
      videoId: input.videoId,
      decision: "STUDY",
      confidence: 0.85,
      confidenceBand: "HIGH",
      reason: `Educational content from recognized academic channel: ${input.channelName}.`,
      matchedKeywords: ["trusted_channel"],
      isTrustedChannel: true,
      isManuallyApproved: false,
      isShort: false,
      taxonomyVersion: "2026.1",
      classifierVersion: "v2.0-academic-intelligence",
    };
  }

  if (youtubeGuardState.mode === "strict") {
    return {
      videoId: input.videoId,
      decision: "NON_STUDY",
      confidence: 0.85,
      confidenceBand: "HIGH",
      reason: "Strict guard mode active: Video could not be verified into active IIT-JEE / CBSE academic syllabus.",
      matchedKeywords: [],
      isTrustedChannel: isTrusted,
      isManuallyApproved: false,
      isShort: false,
      taxonomyVersion: "2026.1",
      classifierVersion: "v2.0-academic-intelligence",
    };
  }

  return {
    videoId: input.videoId,
    decision: "REVIEW",
    confidence: 0.40,
    confidenceBand: "LOW",
    reason: "Video lacks conclusive evidence to classify as verified curriculum lecture or definite non-study.",
    matchedKeywords: [],
    isTrustedChannel: isTrusted,
    isManuallyApproved: false,
    isShort: false,
    taxonomyVersion: "2026.1",
    classifierVersion: "v2.0-academic-intelligence",
  };
}

// ----------------------------------------------------
// YouTube Study Guard Manager (Session-Scoped DNR Engine)
// ----------------------------------------------------

const YouTubeStudyGuardManager = {
  computeConfigHash(mode, approvedIds, sessionId) {
    const sortedIds = Array.from(approvedIds || []).sort().join(",");
    return `${mode}:${sessionId}:${sortedIds}`;
  },

  calculateDesiredRules() {
    if (!shouldEnableYouTubeGuard()) {
      return [];
    }

    const redirectUrl = chrome.runtime.getURL("block-page/index.html");
    const verifyPageUrl = chrome.runtime.getURL("youtube-verify.html");
    const rules = [];

    // 1. Shorts Restriction: Block addictive short-form content during active study sessions (Priority 50)
    rules.push({
      id: YT_RULE_SHORTS,
      priority: YT_PRIORITY_SHORTS,
      action: {
        type: "redirect",
        redirect: { url: `${redirectUrl}?domain=youtube.com&reason=shorts` },
      },
      condition: {
        urlFilter: "||youtube.com/shorts/*",
        resourceTypes: ["main_frame"],
      },
    });

    // 2. Layer B: Video Gateway Redirect Rule (Priority 10)
    // Intercepts all unapproved /watch navigations (direct address bar, middle-click, missed clicks)
    // and sends them to the web-accessible verification page.
    // Crucial Architectural Invariant: YouTube Home (/), Search (/results), Channels (/@...),
    // and playlists are completely unblocked and untouched! Only /watch video entries are gated!
    rules.push({
      id: YT_RULE_GATEWAY_REDIRECT,
      priority: YT_PRIORITY_GATEWAY_REDIRECT,
      action: {
        type: "redirect",
        redirect: {
          regexSubstitution: `${verifyPageUrl}?targetUrl=\\0&v=\\1`,
        },
      },
      condition: {
        regexFilter: "^https?://(?:www\\.)?youtube\\.com/watch\\?(?:.*[&?])?v=([a-zA-Z0-9_-]{11})(?:&.*)?$",
        resourceTypes: ["main_frame"],
      },
    });

    // 3. Approved Exact Video Allow Rules (Priority 100)
    // Priority 100 strictly overrides Priority 10 Gateway Redirect!
    // Approved academic lectures load and play directly without redirecting.
    youtubeGuardState.approvedVideoIds.forEach((vid) => {
      const ruleId = getApprovedVideoRuleId(vid);
      rules.push({
        id: ruleId,
        priority: YT_PRIORITY_EXACT_ALLOW,
        action: { type: "allow" },
        condition: {
          urlFilter: `||youtube.com/watch?*v=${vid}*`,
          resourceTypes: ["main_frame"],
        },
      });
    });

    return rules;
  },

  async getInstalledGuardRuleIds() {
    if (!chrome.declarativeNetRequest?.getSessionRules) return [];
    try {
      const allSessionRules = await chrome.declarativeNetRequest.getSessionRules();
      return (allSessionRules || [])
        .filter((r) => r.id >= YT_RULE_RANGE_MIN && r.id <= YT_RULE_RANGE_MAX)
        .map((r) => r.id);
    } catch (err) {
      logYouTubeGuard("DNR", "Error reading getSessionRules:", err);
      return [];
    }
  },

  async enforceGuardRules() {
    if (!chrome.declarativeNetRequest?.updateSessionRules) {
      youtubeGuardState.status = "ERROR";
      youtubeGuardState.error = "DNR updateSessionRules not supported";
      return false;
    }

    const newHash = this.computeConfigHash(
      youtubeGuardState.mode,
      youtubeGuardState.approvedVideoIds,
      extensionState.activeSessionId
    );

    // Idempotency Invariant: If rules already installed and config hash matches, do nothing!
    if (
      youtubeGuardState.status === "ON" &&
      youtubeGuardState.lastConfigHash === newHash &&
      youtubeGuardState.installedRuleIds.length > 0
    ) {
      logYouTubeGuard("DNR", "Rules already installed and config hash matches. NO-OP.");
      return true;
    }

    youtubeGuardState.status = "ENABLING";
    const desiredRules = this.calculateDesiredRules();
    const existingIds = await this.getInstalledGuardRuleIds();

    logYouTubeGuard(
      "DNR",
      `Installing ${desiredRules.length} session rules (removing ${existingIds.length} existing guard rules)...`
    );

    try {
      await chrome.declarativeNetRequest.updateSessionRules({
        removeRuleIds: existingIds,
        addRules: desiredRules,
      });

      // Verification Step: Read back from browser
      const confirmedIds = await this.getInstalledGuardRuleIds();
      const allInstalled = desiredRules.every((r) => confirmedIds.includes(r.id));

      if (allInstalled && confirmedIds.length >= desiredRules.length) {
        youtubeGuardState.status = "ON";
        youtubeGuardState.enabled = true;
        youtubeGuardState.installedRuleIds = confirmedIds;
        youtubeGuardState.lastConfigHash = newHash;
        youtubeGuardState.error = null;

        logYouTubeGuard(
          "YouTubeGuard",
          `enabled=true status=ON rulesInstalled=${confirmedIds.length} approvedVideos=${youtubeGuardState.approvedVideoIds.size}`
        );
        persistGuardRuntimeState();
        notifyYouTubeTabsGuardState();
        return true;
      } else {
        throw new Error(`Rule verification mismatch: expected ${desiredRules.length}, confirmed ${confirmedIds.length}`);
      }
    } catch (err) {
      logYouTubeGuard("DNR", "Rule enforcement failed:", err);
      youtubeGuardState.status = "ERROR";
      youtubeGuardState.enabled = false;
      youtubeGuardState.error = err.message;
      persistGuardRuntimeState();
      notifyYouTubeTabsGuardState();
      return false;
    }
  },

  async disableGuard() {
    FocusPassManager.clearPasses();

    if (!chrome.declarativeNetRequest?.updateSessionRules) {
      youtubeGuardState.status = "OFF";
      youtubeGuardState.enabled = false;
      persistGuardRuntimeState();
      return true;
    }

    youtubeGuardState.status = "DISABLING";
    try {
      const existingIds = await this.getInstalledGuardRuleIds();
      if (existingIds.length > 0) {
        logYouTubeGuard("DNR", `Removing ${existingIds.length} YouTube Guard session rules...`);
        await chrome.declarativeNetRequest.updateSessionRules({
          removeRuleIds: existingIds,
          addRules: [],
        });
      }

      // Verify no remaining rules in namespace
      const remainingIds = await this.getInstalledGuardRuleIds();
      if (remainingIds.length > 0) {
        logYouTubeGuard("DNR", `Warning: ${remainingIds.length} lingering rules detected. Retrying removal...`);
        await chrome.declarativeNetRequest.updateSessionRules({
          removeRuleIds: remainingIds,
          addRules: [],
        });
      }

      youtubeGuardState.status = "OFF";
      youtubeGuardState.enabled = false;
      youtubeGuardState.installedRuleIds = [];
      youtubeGuardState.lastConfigHash = null;
      youtubeGuardState.error = null;

      logYouTubeGuard("YouTubeGuard", "enabled=false status=OFF rulesInstalled=0");
      persistGuardRuntimeState();
      notifyYouTubeTabsGuardState();
      return true;
    } catch (err) {
      logYouTubeGuard("DNR", "Error during disableGuard:", err);
      youtubeGuardState.status = "ERROR";
      youtubeGuardState.enabled = false;
      youtubeGuardState.error = err.message;
      persistGuardRuntimeState();
      return false;
    }
  },

  async reconcileState(trigger = "MANUAL") {
    const shouldEnable = shouldEnableYouTubeGuard();
    logYouTubeGuard(
      "Session",
      `reconcileState trigger=${trigger} shouldEnable=${shouldEnable} auth=${Boolean(authenticatedUserId)} status=${extensionState.sessionStatus} session=${extensionState.activeSessionId} verified=${youtubeGuardState.verifiedSessionId}`
    );

    if (shouldEnable) {
      await this.enforceGuardRules();
    } else {
      if (youtubeGuardState.status !== "OFF" || (await this.getInstalledGuardRuleIds()).length > 0) {
        await this.disableGuard();
      }
    }
  },

  async approveVideo(videoId, metadata = {}) {
    if (!videoId) return { success: false, error: "Missing videoId" };
    
    // Issue Focus Pass and record in approvedVideoIds set
    FocusPassManager.issuePass(videoId, metadata);
    youtubeGuardState.approvedVideoIds.add(videoId);

    if (metadata.title) {
      youtubeClassificationCache.set(videoId, {
        videoId,
        decision: "ALLOW",
        confidence: metadata.confidence || 1.0,
        reason: metadata.reason || "Approved academic content.",
        title: metadata.title,
        channelName: metadata.channelName || "",
        subject: metadata.subject || extensionState.activeSubject,
        chapter: metadata.chapter || extensionState.activeChapter,
        cachedAt: Date.now(),
      });
    }

    logYouTubeGuard("YouTube", `videoId=${videoId} decision=ALLOW action=GRANT_FOCUS_PASS_AND_INSTALL_RULE`);
    if (shouldEnableYouTubeGuard()) {
      await this.enforceGuardRules();
    }
    return { success: true, videoId };
  },
};

// Authoritative Central Reconcile Functions for YouTube Study Guard
function reconcileYouTubeGuardState(trigger = "MANUAL") {
  return YouTubeStudyGuardManager.reconcileState(trigger);
}

function reconcileYouTubeRules() {
  return YouTubeStudyGuardManager.enforceGuardRules();
}

// Telemetry Outbox: persistent buffer for finalized visits to survive temporary offline/network drops
let telemetryOutbox = [];

// Continuous Distraction Tracking (>= 60s threshold, session bounded)
let activeTracking = {
  tabId: null,
  domain: null,
  url: null,
  startTimeMs: null,
  accumulatedSeconds: 0,
  visitId: null,
  isPaused: false,
  lastFocusMs: null,
  sessionBoundaryId: null,
  sessionState: "active", // "active" | "paused"
  activityType: "distraction", // "distraction" | "pause_break"
};

// Live local tracking state ticker for UI synchronization
let liveTrackingTicker = null;

function computeBlockerConfigHash(mode, domains) {
  const clean = Array.from(new Set((domains || []).map(cleanDomain))).filter(Boolean).sort();
  const ytMode = isYouTubeGuardActive() ? youtubeGuardState.mode : "off";
  return `${mode}:${clean.join(",")}:yt_${ytMode}`;
}

async function enqueueTelemetry(event) {
  if (!event || !event.id) return;
  if (!telemetryOutbox.some((e) => e.id === event.id)) {
    telemetryOutbox.push(event);
    try {
      chrome.storage.local.set({ focusforge_telemetry_outbox: telemetryOutbox });
    } catch {}
  }
}

async function flushTelemetryOutbox() {
  if (!supabaseClient || !authenticatedUserId || telemetryOutbox.length === 0) return;
  const toSend = [...telemetryOutbox];
  for (const item of toSend) {
    try {
      const { error } = await supabaseClient.from("distraction_logs").upsert(item);
      if (!error) {
        telemetryOutbox = telemetryOutbox.filter((e) => e.id !== item.id);
        chrome.storage.local.set({ focusforge_telemetry_outbox: telemetryOutbox });
      }
    } catch (e) {
      console.warn("[FocusForge Outbox] Flush failed for item:", item.id, e);
      break;
    }
  }
}

// ----------------------------------------------------
// Helper Utilities
// ----------------------------------------------------

function generateUUID() {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
    return crypto.randomUUID();
  }
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === "x" ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

function cleanDomain(input) {
  if (!input) return "";
  return input
    .toLowerCase()
    .replace(/^https?:\/\//, "")
    .replace(/^www\./, "")
    .replace(/^(\*\.|\.)/, "")
    .split("/")[0]
    .split(":")[0]
    .trim();
}

function isDomainMatch(hostname, ruleDomain) {
  const h = cleanDomain(hostname);
  const r = cleanDomain(ruleDomain);
  if (!h || !r) return false;
  return h === r || h.endsWith("." + r);
}

function escapeRegex(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

// Deterministic rule ID generation via domain hash (1 to 1,000,000,000)
function getDeterministicRuleId(domain) {
  let hash = 5381;
  const str = cleanDomain(domain);
  for (let i = 0; i < str.length; i++) {
    hash = (hash << 5) + hash + str.charCodeAt(i);
    hash = hash & 0x7fffffff;
  }
  return (hash % 1000000000) + 1;
}

// Tab-scoped temporary allow rule ID generation (1,500,000,000 to 1,899,999,999)
function getTabTemporaryRuleId(tabId) {
  const numericTabId = Math.abs(Number(tabId) || 1);
  return 1500000000 + (numericTabId % 400000000);
}

// Temporary allow rule ID generation fallback by target string (1,500,000,000 to 1,999,999,999)
function getTemporaryRuleId(target) {
  let hash = 5381;
  const str = String(target).toLowerCase();
  for (let i = 0; i < str.length; i++) {
    hash = (hash << 5) + hash + str.charCodeAt(i);
    hash = hash & 0x7fffffff;
  }
  return 1500000000 + (hash % 400000000);
}

function formatSecs(secs) {
  const m = Math.floor(secs / 60);
  const s = secs % 60;
  return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
}

function computeTimeLeft() {
  if (
    !extensionState.isFocusActive ||
    extensionState.sessionStatus === "idle" ||
    extensionState.sessionStatus === "completed" ||
    extensionState.sessionStatus === "abandoned" ||
    extensionState.sessionStatus === "cancelled"
  ) {
    return 0;
  }
  // Paused session: strictly frozen at the paused second
  if (extensionState.sessionStatus === "paused") {
    return Math.max(0, extensionState.timeLeftSeconds || 0);
  }
  // Continuous sync snapshot derivation: immune to clock jumps after pause/resume cycles
  if (typeof extensionState.timeLeftSeconds === "number" && extensionState.syncTimestamp) {
    const elapsedSinceSync = Math.max(0, Math.floor((Date.now() - extensionState.syncTimestamp) / 1000));
    return Math.max(0, extensionState.timeLeftSeconds - elapsedSinceSync);
  }
  // Fallback: pure immutable start timestamp derivation
  if (extensionState.startTime && extensionState.plannedDurationMinutes) {
    const startMs = new Date(extensionState.startTime).getTime();
    if (!isNaN(startMs)) {
      const elapsed = Math.max(0, Math.floor((Date.now() - startMs) / 1000));
      const total = extensionState.plannedDurationMinutes * 60;
      return Math.max(0, total - elapsed);
    }
  }
  return Math.max(0, extensionState.timeLeftSeconds || 0);
}

function updateBadge() {
  if (!chrome.action) return;

  if (extensionState.syncStatus === "SYNCING") {
    chrome.action.setBadgeText({ text: "SYNC" });
    chrome.action.setBadgeBackgroundColor({ color: "#f59e0b" });
    chrome.action.setTitle({ title: "FocusForge: Synchronizing with cloud..." });
  } else if (extensionState.syncStatus === "AUTHENTICATION_REQUIRED") {
    chrome.action.setBadgeText({ text: "AUTH" });
    chrome.action.setBadgeBackgroundColor({ color: "#6b7280" });
    chrome.action.setTitle({ title: "FocusForge: Sign in to activate focus shield" });
  } else if (extensionState.isFocusActive) {
    const isPaused = extensionState.sessionStatus === "paused";
    const remaining = computeTimeLeft();
    const formatted = formatSecs(remaining);

    if (isPaused) {
      chrome.action.setBadgeText({ text: "PAUSE" });
      chrome.action.setBadgeBackgroundColor({ color: "#f59e0b" });
      chrome.action.setTitle({ title: `FocusForge: PAUSED (${extensionState.activeSubject})` });
    } else {
      chrome.action.setBadgeText({ text: "ON" });
      chrome.action.setBadgeBackgroundColor({ color: "#10b981" });
      chrome.action.setTitle({ title: `FocusForge Focus Zone: ${extensionState.activeSubject} (${formatted})` });
    }
  } else {
    chrome.action.setBadgeText({ text: "READY" });
    chrome.action.setBadgeBackgroundColor({ color: "#10b981" });
    chrome.action.setTitle({ title: "FocusForge: Connected & Ready" });
  }
}

function persistState() {
  chrome.storage.local.set({
    focusforge_state: extensionState,
    focusforge_tracking: activeTracking,
    focusforge_temp_allows: temporaryAllowState,
    focusforge_active_exceptions: activeTemporaryExceptions,
  });
}

function updateDerivedStatus() {
  if (!authenticatedUserId) {
    extensionState.syncStatus = "AUTHENTICATION_REQUIRED";
  } else if (extensionState.isFocusActive) {
    extensionState.syncStatus = extensionState.sessionStatus === "paused" ? "SESSION_PAUSED" : "SESSION_ACTIVE";
  } else if (isRealtimeConnected) {
    extensionState.syncStatus = "CONNECTED";
  } else {
    extensionState.syncStatus = "CONNECTED";
  }
  updateBadge();
  logTelemetry();
}

function logTelemetry() {
  console.log(
    `[FocusForge] STATE: ${extensionState.syncStatus} | USER: ${authenticatedUserId || "None"} | ` +
    `RULES: ${extensionState.activeRuleCount} | SESSION: ${extensionState.activeSessionId || "None"} (${extensionState.sessionStatus})`
  );
}

// ----------------------------------------------------
// Authoritative Study Session State Machine
// ----------------------------------------------------

const StudySessionManager = {
  STATES: {
    NO_SESSION: "NO_SESSION",
    ACTIVE: "ACTIVE",
    PAUSED: "PAUSED",
    COMPLETED: "COMPLETED",
    ABANDONED: "ABANDONED",
    CANCELLED: "CANCELLED",
  },

  isTerminal(sessionId) {
    return !sessionId || terminalSessionIds.has(sessionId);
  },

  markTerminal(sessionId) {
    if (sessionId) terminalSessionIds.add(sessionId);
  },

  clearTerminal(sessionId) {
    if (sessionId) terminalSessionIds.delete(sessionId);
  },

  async transitionTo(targetState, reason = "DIRECT", payload = {}) {
    console.log(`[StudySessionManager] Transition -> ${targetState} (${reason})`, payload);
    switch (targetState) {
      case "COMPLETED":
      case "ABANDONED":
      case "CANCELLED":
      case "NO_SESSION":
        await cleanupTerminalSession(reason, payload);
        break;
      case "ACTIVE":
        await handleSessionResumed(payload);
        break;
      case "PAUSED":
        await handleSessionPaused(payload);
        break;
      default:
        console.warn(`[StudySessionManager] Unknown target state: ${targetState}`);
    }
  },

  async reconcile(triggerReason = "MANUAL") {
    if (authenticatedUserId) {
      return reconcileWithCloud(authenticatedUserId, triggerReason);
    }
  },
};

// ----------------------------------------------------
// Blocker Manager: MV3 Declarative Net Request Session Rules
// ----------------------------------------------------

const BlockerManager = {
  async getExistingRuleIds() {
    const ids = { session: [], dynamic: [] };
    if (!chrome.declarativeNetRequest) return ids;

    try {
      if (typeof chrome.declarativeNetRequest.getSessionRules === "function") {
        const sessionRules = await chrome.declarativeNetRequest.getSessionRules();
        ids.session = (sessionRules || [])
          .filter((r) => r.id < YT_RULE_RANGE_MIN || r.id > YT_RULE_RANGE_MAX)
          .map((r) => r.id);
      }
    } catch (e) {
      console.warn("[FocusForge Blocker] getSessionRules warning:", e);
    }

    try {
      if (typeof chrome.declarativeNetRequest.getDynamicRules === "function") {
        const dynamicRules = await chrome.declarativeNetRequest.getDynamicRules();
        ids.dynamic = (dynamicRules || []).map((r) => r.id);
      }
    } catch (e) {
      console.warn("[FocusForge Blocker] getDynamicRules warning:", e);
    }

    return ids;
  },

  async clearAllRules() {
    if (!chrome.declarativeNetRequest) return;
    try {
      const { session, dynamic } = await this.getExistingRuleIds();

      if (session.length > 0 && typeof chrome.declarativeNetRequest.updateSessionRules === "function") {
        await chrome.declarativeNetRequest.updateSessionRules({
          removeRuleIds: session,
          addRules: [],
        });
      }

      if (dynamic.length > 0 && typeof chrome.declarativeNetRequest.updateDynamicRules === "function") {
        await chrome.declarativeNetRequest.updateDynamicRules({
          removeRuleIds: dynamic,
          addRules: [],
        });
      }

      currentInstalledBlockerHash = null;
      activeTemporaryExceptions = [];
      pendingGuardedRequests.clear();
      temporaryAllowState = { urls: [], domains: [], exceptions: [] };
      extensionState.activeRuleCount = 0;
      persistState();
      console.log("[FocusForge Blocker] Disengaged. All session, dynamic, and temporary rules removed.");
    } catch (err) {
      console.error("[FocusForge Blocker] Error clearing rules:", err);
    }
  },

  // Enforce Active Focus Session Rules (Redirect to block-page/index.html)
  async enforceActiveRules(blockedDomains) {
    if (!chrome.declarativeNetRequest) return;

    try {
      const cleanDomains = Array.from(new Set((blockedDomains || []).map(cleanDomain)))
        .filter(Boolean)
        .filter((d) => d !== "youtube.com" && !d.endsWith(".youtube.com") && !d.includes("youtu.be"))
        .sort();
      const newHash = computeBlockerConfigHash("focus", cleanDomains);

      // STABILITY INVARIANT: If active rules are already installed and match configuration, DO NOTHING!
      // This eliminates rule flicker and guarantees continuous un-interrupted blocking.
      if (currentInstalledBlockerHash === newHash && extensionState.activeRuleCount > 0) {
        console.log(`[FocusForge Blocker] Active rules already installed (${newHash}). NO-OP.`);
        return;
      }

      // Clear any prior temporary allows on entering active focus
      activeTemporaryExceptions = [];
      temporaryAllowState = { urls: [], domains: [], exceptions: [] };

      const redirectUrl = chrome.runtime.getURL("block-page/index.html");
      const rules = [];

      // Essential system whitelist allow rule (Priority 20000)
      rules.push({
        id: 999999,
        priority: SYSTEM_ALLOW_PRIORITY,
        action: { type: "allow" },
        condition: {
          urlFilter: "|http*",
          domains: [
            "localhost",
            "127.0.0.1",
            "supabase.co",
            "focusforge.app",
            "dicebear.com",
            "jee-made-easy-by-ilham.vercel.app",
            "vercel.app",
          ],
          resourceTypes: ["main_frame", "sub_frame", "stylesheet", "script", "image", "xmlhttprequest"],
        },
      });

      // Redirect rules for blocked domains (Priority 100)
      cleanDomains.forEach((dom) => {
        if (
          dom === "localhost" ||
          dom === "127.0.0.1" ||
          dom.includes("supabase") ||
          dom.includes("focusforge") ||
          dom.includes("jee-made-easy") ||
          dom.includes("vercel.app")
        ) {
          return;
        }

        if (dom === "youtube.com" || dom.endsWith(".youtube.com") || dom.includes("youtu.be")) {
          // YouTube domain is NEVER globally blocked - managed exclusively at content level by YouTubeStudyGuardManager
          return;
        }

        const ruleId = getDeterministicRuleId(dom);
        rules.push({
          id: ruleId,
          priority: BLOCK_RULE_PRIORITY,
          action: {
            type: "redirect",
            redirect: {
              url: `${redirectUrl}?domain=${encodeURIComponent(dom)}`,
            },
          },
          condition: {
            urlFilter: `||${dom}^`,
            resourceTypes: ["main_frame"],
          },
        });
      });

      const { session, dynamic } = await this.getExistingRuleIds();

      if (dynamic.length > 0 && typeof chrome.declarativeNetRequest.updateDynamicRules === "function") {
        await chrome.declarativeNetRequest.updateDynamicRules({
          removeRuleIds: dynamic,
          addRules: [],
        });
      }

      if (typeof chrome.declarativeNetRequest.updateSessionRules === "function") {
        await chrome.declarativeNetRequest.updateSessionRules({
          removeRuleIds: session,
          addRules: rules,
        });
      }

      currentInstalledBlockerHash = newHash;
      extensionState.activeRuleCount = rules.length;
      persistState();
      console.log(`[FocusForge Blocker] Active Focus Shield engaged! Enforced ${rules.length} session blocking rules.`);

      // Cleanly redirect any currently open tabs matching blocked domains to dedicated block page
      if (chrome.tabs && typeof chrome.tabs.query === "function") {
        chrome.tabs.query({}, (tabs) => {
          (tabs || []).forEach((tab) => {
            if (!tab.url) return;
            try {
              const host = cleanDomain(new URL(tab.url).hostname);
              if (host === "youtube.com" || host.endsWith(".youtube.com") || host.includes("youtu.be")) return;
              if (host && cleanDomains.some((d) => isDomainMatch(host, d))) {
                chrome.tabs.update(tab.id, { url: `${redirectUrl}?domain=${encodeURIComponent(host)}` });
              }
            } catch {}
          });
        });
      }
    } catch (err) {
      console.error("[FocusForge Blocker] Error enforcing active rules:", err);
    }
  },

  // Enforce Pause Guard Mode Rules (Redirect to pause-guard.html)
  async enforcePauseGuardRules(blockedDomains) {
    if (!chrome.declarativeNetRequest) return;

    try {
      const cleanDomains = Array.from(new Set((blockedDomains || []).map(cleanDomain)))
        .filter(Boolean)
        .filter((d) => d !== "youtube.com" && !d.endsWith(".youtube.com") && !d.includes("youtu.be"))
        .sort();
      const newHash = computeBlockerConfigHash("paused", cleanDomains) + `:temp_${activeTemporaryExceptions.length}`;

      if (currentInstalledBlockerHash === newHash && extensionState.activeRuleCount > 0) {
        console.log(`[FocusForge Blocker] Pause Guard rules already installed (${newHash}). NO-OP.`);
        return;
      }

      const pauseGuardUrl = chrome.runtime.getURL("pause-guard.html");

      const rules = [];

      // Essential system allow rule (Priority 20000)
      rules.push({
        id: 999999,
        priority: SYSTEM_ALLOW_PRIORITY,
        action: { type: "allow" },
        condition: {
          urlFilter: "|http*",
          domains: [
            "localhost",
            "127.0.0.1",
            "supabase.co",
            "focusforge.app",
            "dicebear.com",
            "jee-made-easy-by-ilham.vercel.app",
            "vercel.app",
          ],
          resourceTypes: ["main_frame", "sub_frame", "stylesheet", "script", "image", "xmlhttprequest"],
        },
      });

      // Pause Guard redirect rules (Priority 100)
      cleanDomains.forEach((dom) => {
        if (
          dom === "localhost" ||
          dom === "127.0.0.1" ||
          dom.includes("supabase") ||
          dom.includes("focusforge") ||
          dom.includes("jee-made-easy") ||
          dom.includes("vercel.app") ||
          dom === "youtube.com" ||
          dom.endsWith(".youtube.com") ||
          dom.includes("youtu.be")
        ) {
          return;
        }
        const ruleId = getDeterministicRuleId(dom);

        // Regex substitution captures full target URL
        try {
          rules.push({
            id: ruleId,
            priority: BLOCK_RULE_PRIORITY,
            action: {
              type: "redirect",
              redirect: {
                regexSubstitution: `${pauseGuardUrl}?targetUrl=\\0&domain=${encodeURIComponent(dom)}`,
              },
            },
            condition: {
              regexFilter: `^https?://([a-zA-Z0-9.-]*\\.)?${escapeRegex(dom)}(/.*)?$`,
              resourceTypes: ["main_frame"],
            },
          });
        } catch {
          // Fallback to urlFilter if regexFilter fails
          rules.push({
            id: ruleId,
            priority: BLOCK_RULE_PRIORITY,
            action: {
              type: "redirect",
              redirect: {
                url: `${pauseGuardUrl}?domain=${encodeURIComponent(dom)}`,
              },
            },
            condition: {
              urlFilter: `||${dom}^`,
              resourceTypes: ["main_frame"],
            },
          });
        }
      });

      // Re-apply any existing active tab-scoped temporary allow rules (Priority 10000)
      activeTemporaryExceptions.forEach((exc) => {
        if (!exc.tabId) return;
        // Tab-scoped temporary exception: allow all paths, redirects, and subresources on that domain for the tab
        const regex = `^https?://([a-zA-Z0-9.-]*\\.)?${escapeRegex(exc.domain)}(:[0-9]+)?(/.*)?$`;


        rules.push({
          id: exc.ruleId,
          priority: TEMPORARY_ALLOW_PRIORITY,
          action: { type: "allow" },
          condition: {
            regexFilter: regex,
            tabIds: [exc.tabId],
            resourceTypes: [
              "main_frame",
              "sub_frame",
              "stylesheet",
              "script",
              "image",
              "font",
              "xmlhttprequest",
              "ping",
              "media",
              "other",
            ],
          },
        });
      });

      const { session, dynamic } = await this.getExistingRuleIds();

      if (dynamic.length > 0 && typeof chrome.declarativeNetRequest.updateDynamicRules === "function") {
        await chrome.declarativeNetRequest.updateDynamicRules({
          removeRuleIds: dynamic,
          addRules: [],
        });
      }

      if (typeof chrome.declarativeNetRequest.updateSessionRules === "function") {
        await chrome.declarativeNetRequest.updateSessionRules({
          removeRuleIds: session,
          addRules: rules,
        });
      }

      currentInstalledBlockerHash = newHash;
      extensionState.activeRuleCount = rules.length;
      persistState();
      console.log(`[FocusForge Blocker] Pause Guard engaged! Enforced ${rules.length} session guard rules.`);

      // Redirect any currently open tabs matching blocked domains to pause-guard.html (unless tab has an active temporary allow exception)
      if (chrome.tabs && typeof chrome.tabs.query === "function") {
        chrome.tabs.query({}, (tabs) => {
          (tabs || []).forEach((tab) => {
            if (!tab.url) return;
            try {
              const host = cleanDomain(new URL(tab.url).hostname);
              if (!host || !cleanDomains.some((d) => isDomainMatch(host, d))) return;
              const hasException = activeTemporaryExceptions.some(
                (exc) => exc.tabId === tab.id && (exc.type === "site" || isDomainMatch(host, exc.domain))
              );
              if (hasException) return;
              chrome.tabs.update(tab.id, {
                url: `${pauseGuardUrl}?targetUrl=${encodeURIComponent(tab.url)}&domain=${encodeURIComponent(host)}`,
              });
            } catch {}
          });
        });
      }
    } catch (err) {
      console.error("[FocusForge Blocker] Error enforcing pause guard rules:", err);
    }
  },

  // Add Temporary Allow Rule scoped to specific tab (Priority 10000 overrides Pause Guard Priority 100)
  async addTemporaryAllowRule({ tabId, url, domain, mode }) {
    if (!chrome.declarativeNetRequest) return { success: false, error: "DNR not supported" };

    try {
      const cDomain = cleanDomain(domain);
      const numericTabId = Number(tabId);
      const ruleId = getTabTemporaryRuleId(numericTabId);

      // For tab-scoped temporary exceptions (both 'page' and 'site'), allow all subpaths,
      // internal redirects (e.g. /accounts/login/), and subresources on the destination domain for this specific tab.
      // 'page' mode is guarded by tabs.onUpdated which expires the exception if navigating away from this domain.
      const regexFilter = `^https?://([a-zA-Z0-9.-]*\\.)?${escapeRegex(cDomain)}(:[0-9]+)?(/.*)?$`;


      const allowRule = {
        id: ruleId,
        priority: TEMPORARY_ALLOW_PRIORITY, // 10000
        action: { type: "allow" },
        condition: {
          regexFilter: regexFilter,
          tabIds: [numericTabId],
          resourceTypes: [
            "main_frame",
            "sub_frame",
            "stylesheet",
            "script",
            "image",
            "font",
            "xmlhttprequest",
            "ping",
            "media",
            "other",
          ],
        },
      };

      // Atomic update: remove previous rule for this tabId if present, add new rule
      if (typeof chrome.declarativeNetRequest.updateSessionRules === "function") {
        await chrome.declarativeNetRequest.updateSessionRules({
          removeRuleIds: [ruleId],
          addRules: [allowRule],
        });
      }

      // Register active exception record
      const exceptionRecord = {
        ruleId,
        tabId: numericTabId,
        domain: cDomain,
        originalUrl: url,
        type: mode === "site" ? "site" : "single_url",
        createdAt: Date.now(),
        sessionId: extensionState.activeSessionId,
        sessionStatus: extensionState.sessionStatus,
        expiresWhen: "resume|complete|cancel|logout|tab_close",
      };

      activeTemporaryExceptions = activeTemporaryExceptions.filter((e) => e.tabId !== numericTabId);
      activeTemporaryExceptions.push(exceptionRecord);

      if (!temporaryAllowState.domains.includes(cDomain)) {
        temporaryAllowState.domains.push(cDomain);
      }
      if (mode === "page" && url && !temporaryAllowState.urls.includes(url)) {
        temporaryAllowState.urls.push(url);
      }
      temporaryAllowState.exceptions = [...activeTemporaryExceptions];

      currentInstalledBlockerHash = null;
      persistState();
      console.log(
        `[FocusForge Blocker] Temporary allow exception granted (${mode}): ${cDomain} (Tab: ${numericTabId}, RuleId: ${ruleId}, Priority: ${TEMPORARY_ALLOW_PRIORITY})`
      );
      return { success: true, ruleId };
    } catch (err) {
      console.error("[FocusForge Blocker] Error adding temporary allow rule:", err);
      return { success: false, error: err.message };
    }
  },

  // Verify temporary rule is installed in declarativeNetRequest session rules before navigation
  async verifyTemporaryRule(tabId, ruleId) {
    if (!chrome.declarativeNetRequest || typeof chrome.declarativeNetRequest.getSessionRules !== "function") {
      return true;
    }
    try {
      const rules = await chrome.declarativeNetRequest.getSessionRules();
      const found = (rules || []).find((r) => r.id === ruleId);
      if (!found) {
        console.warn(`[FocusForge Blocker] Rule ${ruleId} not found in active session rules.`);
        return false;
      }
      const priorityMatches = found.priority === TEMPORARY_ALLOW_PRIORITY;
      const tabMatches =
        Array.isArray(found.condition?.tabIds) && found.condition.tabIds.includes(Number(tabId));
      console.log(
        `[FocusForge Blocker] Rule ${ruleId} verified: priority=${found.priority} (${priorityMatches}), tab=${JSON.stringify(found.condition?.tabIds)} (${tabMatches})`
      );
      return priorityMatches && tabMatches;
    } catch (err) {
      console.error("[FocusForge Blocker] verifyTemporaryRule error:", err);
      return false;
    }
  },

  // Remove temporary allow rule for a specific closed or navigated tab
  async removeTabTemporaryRules(tabId) {
    if (!chrome.declarativeNetRequest) return;
    const numericTabId = Number(tabId);
    const toRemove = activeTemporaryExceptions.filter((e) => e.tabId === numericTabId);
    if (toRemove.length === 0) return;

    const ruleIds = toRemove.map((e) => e.ruleId);
    activeTemporaryExceptions = activeTemporaryExceptions.filter((e) => e.tabId !== numericTabId);

    temporaryAllowState.exceptions = [...activeTemporaryExceptions];
    temporaryAllowState.domains = Array.from(new Set(activeTemporaryExceptions.map((e) => e.domain)));
    temporaryAllowState.urls = activeTemporaryExceptions.filter((e) => e.type === "single_url").map((e) => e.originalUrl);

    currentInstalledBlockerHash = null;

    try {
      if (typeof chrome.declarativeNetRequest.updateSessionRules === "function") {
        await chrome.declarativeNetRequest.updateSessionRules({
          removeRuleIds: ruleIds,
        });
      }
      persistState();
      console.log(`[FocusForge Blocker] Removed temporary exceptions for tab ${tabId}: rules [${ruleIds.join(", ")}]`);
    } catch (err) {
      console.warn(`[FocusForge Blocker] Error removing rules for tab ${tabId}:`, err);
    }
  },

  // Clear all temporary allow rules
  async clearTemporaryAllowRules() {
    if (!chrome.declarativeNetRequest) return;
    try {
      const idsToRemove = [
        ...activeTemporaryExceptions.map((e) => e.ruleId),
        ...temporaryAllowState.domains.map(getTemporaryRuleId),
        ...temporaryAllowState.urls.map(getTemporaryRuleId),
      ];
      const uniqueIds = Array.from(new Set(idsToRemove));

      activeTemporaryExceptions = [];
      temporaryAllowState = { urls: [], domains: [], exceptions: [] };
      currentInstalledBlockerHash = null;

      if (uniqueIds.length > 0 && typeof chrome.declarativeNetRequest.updateSessionRules === "function") {
        await chrome.declarativeNetRequest.updateSessionRules({
          removeRuleIds: uniqueIds,
        });
      }
      persistState();
      console.log("[FocusForge Blocker] Cleared all temporary allow rules and exceptions.");
    } catch (e) {
      console.warn("[FocusForge Blocker] clearTemporaryAllowRules warning:", e);
    }
  },
};

// ----------------------------------------------------
// Presence Heartbeat Engine
// ----------------------------------------------------

async function sendPresenceHeartbeat() {
  if (!installationId) {
    installationId = generateUUID();
    try {
      chrome.storage.local.set({ installation_id: installationId });
    } catch {}
  }
  if (!supabaseClient || !authenticatedUserId || !installationId) return;

  try {
    const status = extensionState.isFocusActive
      ? extensionState.sessionStatus === "paused"
        ? "session_paused"
        : "session_active"
      : "connected";
    const nowIso = new Date().toISOString();

    const { error } = await supabaseClient.from("extension_presence").upsert({
      installation_id: installationId,
      user_id: authenticatedUserId,
      last_seen_at: nowIso,
      status: status,
      extension_version: EXTENSION_VERSION,
      browser: "Chrome Desktop",
      updated_at: nowIso,
    });

    if (!error) {
      extensionState.lastSync = nowIso;
    }
  } catch (e) {
    console.warn("[FocusForge Presence] Heartbeat push error:", e);
  }
}

// ----------------------------------------------------
// Authoritative Terminal Session Cleanup (Idempotent)
// ----------------------------------------------------

async function cleanupTerminalSession(reason = "TERMINAL", payload = {}) {
  const incomingUserId = payload.userId;
  if (incomingUserId && authenticatedUserId && incomingUserId !== authenticatedUserId) {
    console.log(
      `[FocusForge Session] Ignored terminal event for foreign user ${incomingUserId} (authenticated: ${authenticatedUserId})`
    );
    return;
  }

  const incomingSessionId = payload.sessionId;
  const currentSessionId = extensionState.activeSessionId;
  const targetSessionId = incomingSessionId || currentSessionId || "none";

  if (incomingSessionId) {
    terminalSessionIds.add(incomingSessionId);
  }
  if (currentSessionId) {
    terminalSessionIds.add(currentSessionId);
  }

  console.log(
    `[FocusForge Session] TERMINAL CLEANUP (${reason}) | user=${authenticatedUserId || "none"} | session=${targetSessionId}`
  );

  // 1. Mark local session state terminal immediately
  extensionState.isFocusActive = false;
  extensionState.sessionStatus = "idle";
  extensionState.activeSessionId = null;
  extensionState.timeLeftSeconds = 0;
  extensionState.startTime = null;
  extensionState.plannedDurationMinutes = 0;
  extensionState.syncTimestamp = null;

  // Immediately disengage YouTube Study Guard
  youtubeGuardState.verifiedSessionId = null;
  youtubeGuardState.leaseUntil = null;
  youtubeGuardState.approvedVideoIds.clear();
  await YouTubeStudyGuardManager.disableGuard();

  // 2. Finalize active distraction tracker bounded to session end
  await finalizeActiveDistraction(payload.timestamp || payload.endTime);

  // 3. Remove all temporary pause exceptions and allow rules
  await BlockerManager.clearTemporaryAllowRules();

  // 4. Remove all DNR session and dynamic rules
  await BlockerManager.clearAllRules();

  // 5. Clean up live tracking storage
  try {
    chrome.storage.local.remove(["focusforge_live_tracking"]);
  } catch {}

  // 6. Restore open blocked or guarded tabs back to the destination site
  if (chrome.tabs?.query) {
    chrome.tabs.query({}, (tabs) => {
      (tabs || []).forEach((t) => {
        if (!t.id || !t.url) return;
        try {
          if (t.url.includes("block-page/index.html") || t.url.includes("pause-guard.html")) {
            const u = new URL(t.url);
            const targetUrl = u.searchParams.get("targetUrl") || u.searchParams.get("url");
            const domain = u.searchParams.get("domain");
            let destination = targetUrl;
            if (!destination && domain) {
              destination = domain.startsWith("http") ? domain : `https://${domain}`;
            }
            if (destination && !destination.includes("chrome-extension:")) {
              console.log(`[FocusForge Session] Restoring open blocked tab ${t.id} to ${destination}`);
              chrome.tabs.update(t.id, { url: destination });
            }
          }
        } catch (e) {
          console.warn("[FocusForge Session] Error restoring blocked tab:", e);
        }
      });
    });
  }

  // 7. Update badge & UI state
  updateBadge();
  updateDerivedStatus();
  persistState();

  console.log(`[FocusForge Blocker] requiredRules=0 activeRules=${extensionState.activeRuleCount} status=disabled`);
  console.log(`[FocusForge Timer] action=STOP session=${targetSessionId}`);
}

// ----------------------------------------------------
// Authoritative Cloud Reconciliation
// ----------------------------------------------------

async function reconcileWithCloud(userId, triggerReason = "MANUAL") {
  if (!supabaseClient || !userId) return;

  try {
    extensionState.syncStatus = "SYNCING";
    extensionState.lastReconcileTrigger = triggerReason;
    updateBadge();

    console.log(`[FocusForge Reconcile] Triggered (${triggerReason}) for user ${userId}`);

    // Ensure client has current authenticated session before querying
    if (supabaseClient.auth) {
      try {
        const { data: authData } = await supabaseClient.auth.getSession();
        if (!authData?.session?.user?.id) {
          const stored = await new Promise((r) =>
            chrome.storage?.local?.get(["supabase_auth_session"], r)
          );
          const s = stored?.supabase_auth_session;
          if (s?.access_token && s?.refresh_token) {
            await supabaseClient.auth.setSession({
              access_token: s.access_token,
              refresh_token: s.refresh_token,
            });
          }
        }
      } catch (authRefreshErr) {
        console.warn("[FocusForge Reconcile] Auth check warning:", authRefreshErr);
      }
    }

    // 1. Fetch current active or paused study session AND extension_state from Supabase (Single Source of Truth)
    // CRITICAL: Strictly filter .in("status", ["active", "paused"]) — NEVER rely on completed=false!
    const [extStateRes, sessionRes, sitesRes] = await Promise.all([
      supabaseClient
        .from("extension_state")
        .select("*")
        .eq("user_id", userId)
        .maybeSingle(),
      supabaseClient
        .from("study_sessions")
        .select("*")
        .eq("user_id", userId)
        .in("status", ["active", "paused"])
        .order("start_time", { ascending: false })
        .limit(1),
      supabaseClient
        .from("blocked_sites")
        .select("domain")
        .eq("user_id", userId)
        .eq("is_active", true),
    ]);

    const extStateData = extStateRes.data;
    const activeSessions = sessionRes.data;
    const sessErr = sessionRes.error;
    const activeSession = activeSessions && activeSessions.length > 0 ? activeSessions[0] : null;

    // DECISION MATRIX FOR ACTIVE SESSION:
    if (activeSession) {
      // Supabase is authoritative. Clear any stale terminal status for this active session!
      terminalSessionIds.delete(activeSession.id);

      const isPaused = activeSession.status === "paused";
      const plannedMins = Number(
        activeSession.planned_duration_minutes || activeSession.total_duration_minutes || 50
      );
      const totalSecs = plannedMins * 60;
      let remainingSecs = totalSecs;

      if (isPaused) {
        if (typeof extStateData?.time_left_seconds === "number" && extStateData.time_left_seconds > 0) {
          remainingSecs = extStateData.time_left_seconds;
        } else if (typeof activeSession.accumulated_seconds === "number") {
          remainingSecs = Math.max(0, totalSecs - activeSession.accumulated_seconds);
        } else if (activeSession.start_time && activeSession.paused_at) {
          const pauseElapsed = Math.max(0, Math.floor((new Date(activeSession.paused_at).getTime() - new Date(activeSession.start_time).getTime()) / 1000));
          remainingSecs = Math.max(0, totalSecs - pauseElapsed);
        }
      } else {
        if (typeof activeSession.accumulated_seconds === "number" && activeSession.resumed_at) {
          const sinceResume = Math.max(0, Math.floor((Date.now() - new Date(activeSession.resumed_at).getTime()) / 1000));
          const totalElapsed = activeSession.accumulated_seconds + sinceResume;
          remainingSecs = Math.max(0, totalSecs - totalElapsed);
        } else if (typeof extStateData?.time_left_seconds === "number" && extStateData.time_left_seconds > 0 && extStateData.last_synced) {
          const sinceExtSync = Math.max(0, Math.floor((Date.now() - new Date(extStateData.last_synced).getTime()) / 1000));
          remainingSecs = Math.max(0, extStateData.time_left_seconds - sinceExtSync);
        } else if (activeSession.start_time) {
          const startMs = new Date(activeSession.start_time).getTime();
          const elapsedSecs = isNaN(startMs) ? 0 : Math.max(0, Math.floor((Date.now() - startMs) / 1000));
          remainingSecs = Math.max(0, totalSecs - elapsedSecs);
        }
      }

      // Check if session duration naturally elapsed (only if active, not paused)
      if (remainingSecs <= 0 && !isPaused) {
        console.log(`[FocusForge Session] Session ${activeSession.id} duration elapsed (0s remaining). Cleaning up.`);
        await cleanupTerminalSession("SESSION_TIME_ELAPSED", { sessionId: activeSession.id });
        return;
      }

      const isSameSession =
        extensionState.isFocusActive &&
        extensionState.activeSessionId === activeSession.id &&
        extensionState.sessionStatus === (isPaused ? "paused" : "focus");

      if (isSameSession) {
        // CONTINUITY INVARIANT: Identical incoming session state is a NO-OP for the Session Control Plane!
        // Do NOT touch startTime, do NOT reset timer, do NOT recreate blocker rules!
        extensionState.timeLeftSeconds = remainingSecs;
        extensionState.syncTimestamp = Date.now();
        console.log(
          `[FocusForge Session] Session ${activeSession.id} already active (${extensionState.sessionStatus}). Preserving continuous state (remaining: ${remainingSecs}s).`
        );
      } else {
        // Genuine state transition
        extensionState.isFocusActive = true;
        extensionState.activeSessionId = activeSession.id;
        extensionState.sessionStatus = isPaused ? "paused" : "focus";
        extensionState.activeSubject = activeSession.subject || "General Focus";
        extensionState.activeChapter = activeSession.chapter || "Study";
        extensionState.activeGoal = `Focus on ${activeSession.chapter || activeSession.subject || "Session Goal"}`;
        extensionState.activeSessionMode = activeSession.mode || "Pomodoro";
        extensionState.startTime = activeSession.start_time;
        extensionState.plannedDurationMinutes = plannedMins;
        extensionState.timeLeftSeconds = remainingSecs;
        extensionState.syncTimestamp = Date.now();

        console.log(
          `[FocusForge Session] SESSION TRANSITION RECONCILED (${triggerReason}): id=${activeSession.id} status=${extensionState.sessionStatus} remaining=${extensionState.timeLeftSeconds}s`
        );
      }
    } else if (extStateData && extStateData.is_focus_active === true && (extStateData.session_status === "focus" || extStateData.session_status === "paused")) {
      // Auxiliary table indicates active session: preserve active session state (Fail-Closed / Second Line of Truth)
      console.log(`[FocusForge Session] extension_state confirms active focus (${extStateData.active_subject}). Preserving active state.`);
      if (extStateData.active_session_id) terminalSessionIds.delete(extStateData.active_session_id);
      extensionState.isFocusActive = true;
      extensionState.sessionStatus = extStateData.session_status;
      if (extStateData.active_session_id) extensionState.activeSessionId = extStateData.active_session_id;
      if (extStateData.active_subject) extensionState.activeSubject = extStateData.active_subject;
      if (extStateData.active_chapter) extensionState.activeChapter = extStateData.active_chapter;
      if (typeof extStateData.time_left_seconds === "number" && extStateData.time_left_seconds > 0) {
        extensionState.timeLeftSeconds = extStateData.time_left_seconds;
        extensionState.syncTimestamp = Date.now();
      }
    } else if (extStateData && extStateData.is_focus_active === false && !activeSession) {
      console.log("[FocusForge Session] Cloud extension_state is_focus_active is false and no active study session. Enforcing terminal cleanup.");
      await cleanupTerminalSession("CLOUD_EXT_STATE_INACTIVE", {
        sessionId: extStateData.active_session_id || undefined,
      });
    } else if (!sessErr && !activeSession && (!extStateData || extStateData.is_focus_active === false)) {
      // NO ACTIVE OR PAUSED STUDY SESSION EXISTS IN SUPABASE!
      console.log("[FocusForge Session] No active/paused session in Supabase study_sessions or extension_state. Enforcing terminal cleanup.");
      await cleanupTerminalSession("NO_ACTIVE_SESSION_IN_CLOUD");
    } else if (sessErr) {
      // FAIL-CLOSED INVARIANT: On network timeout or query error, DO NOT UNBLOCK!
      console.warn("[FocusForge Session] Cloud query encountered error. Preserving active blocker (Fail-Closed Invariant):", sessErr);
    }

    // 2. Sync configured blocked domains strictly from user's Blocked Domains Registry
    const sitesData = sitesRes.data;
    if (sitesData && Array.isArray(sitesData)) {
      if (sitesData.length > 0) {
        extensionState.blockedDomains = Array.from(
          new Set(sitesData.map((s) => cleanDomain(s.domain)))
        ).filter(Boolean);
      } else if (Array.isArray(extStateData?.blocked_sites) && extStateData.blocked_sites.length > 0) {
        extensionState.blockedDomains = Array.from(
          new Set(extStateData.blocked_sites.map(cleanDomain))
        ).filter(Boolean);
      } else {
        // Explicitly 0 blocked sites in user's registry
        extensionState.blockedDomains = [];
      }
    } else if (Array.isArray(extStateData?.blocked_sites)) {
      extensionState.blockedDomains = Array.from(
        new Set(extStateData.blocked_sites.map(cleanDomain))
      ).filter(Boolean);
    }

    // 3. Enforce appropriate rules based on authoritative status
    if (extensionState.isFocusActive) {
      if (extensionState.sessionStatus === "focus") {
        youtubeGuardState.activeSessionId = extensionState.activeSessionId;
        youtubeGuardState.verifiedSessionId = extensionState.activeSessionId;
        youtubeGuardState.activeSubject = extensionState.activeSubject;
        youtubeGuardState.activeChapter = extensionState.activeChapter;
        youtubeGuardState.leaseUntil = Date.now() + 120_000;
        await YouTubeStudyGuardManager.reconcileState("RECONCILE_FOCUS_ACTIVE");
        await BlockerManager.enforceActiveRules(extensionState.blockedDomains);
      } else if (extensionState.sessionStatus === "paused") {
        youtubeGuardState.leaseUntil = null;
        await YouTubeStudyGuardManager.reconcileState("RECONCILE_PAUSED");
        // Prune any temporary exceptions for tabs that were closed while sleeping
        if (activeTemporaryExceptions.length > 0 && chrome.tabs?.query) {
          chrome.tabs.query({}, (tabs) => {
            const openTabIds = new Set((tabs || []).map((t) => t.id));
            const stale = activeTemporaryExceptions.filter((e) => !openTabIds.has(e.tabId));
            stale.forEach((e) => {
              BlockerManager.removeTabTemporaryRules(e.tabId);
            });
          });
        }
        await BlockerManager.enforcePauseGuardRules(extensionState.blockedDomains);
      }
    } else {
      // INVARIANT: Blocker MUST NOT outlive the session! 0 rules when inactive!
      await YouTubeStudyGuardManager.reconcileState("RECONCILE_INACTIVE");
      await BlockerManager.clearTemporaryAllowRules();
      await BlockerManager.clearAllRules();
    }

    // 3. Derive Waste Time & Today's Distractions from valid distraction logs (>= 60s, unblocked)
    const todayStr = new Date().toISOString().split("T")[0];
    const { data: logsData } = await supabaseClient
      .from("distraction_logs")
      .select("*")
      .eq("user_id", userId)
      .gte("timestamp", `${todayStr}T00:00:00.000Z`);

    if (logsData && Array.isArray(logsData)) {
      const validDistractions = logsData.filter(
        (l) => Number(l.duration_seconds || 0) >= 60 && !l.blocked && l.activity_type !== "pause_break"
      );
      const validBreaks = logsData.filter(
        (l) => Number(l.duration_seconds || 0) >= 60 && !l.blocked && l.activity_type === "pause_break"
      );

      const totalWasteSecs = validDistractions.reduce((sum, l) => sum + Number(l.duration_seconds || 0), 0);
      const totalBreakSecs = validBreaks.reduce((sum, l) => sum + Number(l.duration_seconds || 0), 0);

      extensionState.todayWasteTimeSeconds = totalWasteSecs;
      extensionState.todayBreakSeconds = totalBreakSecs;
      extensionState.todayDistractionsCount = validDistractions.length;
      extensionState.recentDistractions = validDistractions.slice(0, 10).map((l) => ({
        id: l.id,
        domain: l.domain,
        url: l.attempted_url || `https://${l.domain}`,
        timestamp: l.timestamp,
        durationSeconds: l.duration_seconds,
        blocked: false,
      }));
    }

    // 4. Send presence heartbeat
    await sendPresenceHeartbeat();

    updateDerivedStatus();
    persistState();
  } catch (err) {
    console.error("[FocusForge Background] Cloud reconciliation failed:", err);
    updateDerivedStatus();
  }
}

// ----------------------------------------------------
// Realtime Subscriptions (Dual-Layer: Broadcast + Postgres Changes)
// ----------------------------------------------------

function setupRealtimeSubscriptions(userId, token) {
  if (!supabaseClient || !userId) return;

  const applyToken = (t) => {
    if (t && supabaseClient.realtime && typeof supabaseClient.realtime.setAuth === "function") {
      try {
        supabaseClient.realtime.setAuth(t);
      } catch (e) {
        console.warn("[FocusForge Realtime] setAuth error:", e);
      }
    }
  };

  if (token) {
    applyToken(token);
  } else {
    chrome.storage?.local?.get(["supabase_auth_session"], (stored) => {
      const storedToken = stored?.supabase_auth_session?.access_token;
      if (storedToken) applyToken(storedToken);
    });
  }

  realtimeChannels.forEach((ch) => {
    try {
      supabaseClient.removeChannel(ch);
    } catch {}
  });
  realtimeChannels = [];
  isRealtimeConnected = false;

  // Layer 1: Low-Latency Broadcast Control Channel (< 50ms response)
  const controlChannel = supabaseClient
    .channel(`focusforge_control_${userId}`)
    .on("broadcast", { event: "control_event" }, async ({ payload }) => {
      console.log(`[FocusForge Broadcast] Control event received: ${payload?.type}`, payload);
      if (!payload || payload.userId !== authenticatedUserId) return;

      switch (payload.type) {
        case "STUDY_SESSION_STARTED":
          await handleSessionStarted(payload);
          break;
        case "STUDY_SESSION_PAUSED":
          await handleSessionPaused(payload);
          break;
        case "STUDY_SESSION_RESUMED":
          await handleSessionResumed(payload);
          break;
        case "STUDY_SESSION_COMPLETED":
          await handleSessionCompleted(payload);
          break;
        case "STUDY_SESSION_ABANDONED":
          await handleSessionAbandoned(payload);
          break;
        case "STUDY_SESSION_CANCELLED":
          await handleSessionCancelled(payload);
          break;
        case "BLOCK_LIST_CHANGED":
          await handleBlockListChanged(payload);
          break;
      }
    })
    .subscribe((status) => {
      console.log(`[FocusForge Broadcast] Subscription status: ${status}`);
      if (status === "SUBSCRIBED") {
        isRealtimeConnected = true;
        updateDerivedStatus();
      }
    });

  realtimeChannels.push(controlChannel);

  // Layer 2: Postgres Changes Subscription (Durable state persistence)
  const sessionChannel = supabaseClient
    .channel(`ext-study-sessions-${userId}`)
    .on(
      "postgres_changes",
      {
        event: "*",
        schema: "public",
        table: "study_sessions",
        filter: `user_id=eq.${userId}`,
      },
      (payload) => {
        console.log("[FocusForge Postgres Realtime] study_sessions change:", payload.eventType, payload.new?.status);
        if (
          payload.new &&
          (payload.new.status === "completed" ||
            payload.new.status === "abandoned" ||
            payload.new.status === "cancelled" ||
            payload.new.completed === true)
        ) {
          cleanupTerminalSession(`POSTGRES_${payload.new.status ? payload.new.status.toUpperCase() : "COMPLETED"}`, {
            sessionId: payload.new.id,
            timestamp: payload.new.end_time || payload.new.updated_at,
          });
        } else if (payload.eventType === "DELETE") {
          reconcileWithCloud(userId);
        } else {
          reconcileWithCloud(userId);
        }
      }
    )
    .subscribe();

  realtimeChannels.push(sessionChannel);

  const extStateChannel = supabaseClient
    .channel(`ext-state-${userId}`)
    .on(
      "postgres_changes",
      {
        event: "*",
        schema: "public",
        table: "extension_state",
        filter: `user_id=eq.${userId}`,
      },
      (payload) => {
        console.log("[FocusForge Postgres Realtime] extension_state change:", payload.eventType, payload.new?.is_focus_active);
        if (payload.new && payload.new.is_focus_active === false) {
          cleanupTerminalSession("POSTGRES_EXT_STATE_FALSE", {
            sessionId: payload.new.active_session_id,
          });
        } else if (payload.new && payload.new.is_focus_active === true) {
          reconcileWithCloud(userId);
        } else if (payload.eventType === "DELETE") {
          reconcileWithCloud(userId);
        }
      }
    )
    .subscribe();

  realtimeChannels.push(extStateChannel);

  const blockedChannel = supabaseClient
    .channel(`ext-blocked-sites-${userId}`)
    .on(
      "postgres_changes",
      {
        event: "*",
        schema: "public",
        table: "blocked_sites",
        filter: `user_id=eq.${userId}`,
      },
      () => {
        console.log("[FocusForge Postgres Realtime] blocked_sites change");
        reconcileWithCloud(userId);
      }
    )
    .subscribe();

  realtimeChannels.push(blockedChannel);
}

// ----------------------------------------------------
// Event Handlers for Broadcast Control Events
// ----------------------------------------------------

async function handleSessionStarted(payload) {
  if (!payload || !payload.sessionId) return;

  if (payload.userId && authenticatedUserId && payload.userId !== authenticatedUserId) {
    console.warn(`[FocusForge Session] Ignored start event for foreign user ${payload.userId}`);
    return;
  }

  // Supabase is authoritative. Clear any stale terminal status for this session!
  terminalSessionIds.delete(payload.sessionId);

  console.log(`[FocusForge Session] START: id=${payload.sessionId} subject=${payload.subject || "Physics"} duration=${payload.durationMinutes}m`);

  extensionState.isFocusActive = true;
  extensionState.sessionStatus = "focus";
  extensionState.activeSessionId = payload.sessionId;
  extensionState.activeSubject = payload.subject || "Physics";
  extensionState.activeChapter = payload.chapter || "General";
  extensionState.activeGoal = `Focus on ${payload.chapter || payload.subject || "Current Chapter"}`;
  extensionState.activeSessionMode = payload.mode || "Pomodoro";
  extensionState.startTime = payload.startTime || new Date().toISOString();
  extensionState.plannedDurationMinutes = Number(payload.durationMinutes || 50);
  extensionState.timeLeftSeconds = (payload.durationMinutes || 50) * 60;
  extensionState.syncTimestamp = Date.now();

  if (Array.isArray(payload.blockedWebsites)) {
    extensionState.blockedDomains = Array.from(
      new Set(payload.blockedWebsites.map(cleanDomain))
    ).filter(Boolean);
  }

  // Activate YouTube Study Content Guard with lease & DNR session rules
  youtubeGuardState.activeSessionId = payload.sessionId;
  youtubeGuardState.verifiedSessionId = payload.sessionId;
  youtubeGuardState.activeSubject = payload.subject || "Physics";
  youtubeGuardState.activeChapter = payload.chapter || "General";
  youtubeGuardState.mode = payload.youtubeGuardMode || youtubeGuardState.mode || "strict";
  youtubeGuardState.leaseUntil = Date.now() + 120_000;
  await YouTubeStudyGuardManager.reconcileState("SESSION_STARTED");

  await BlockerManager.clearTemporaryAllowRules();
  await BlockerManager.enforceActiveRules(extensionState.blockedDomains);
  updateDerivedStatus();
  persistState();

  if (chrome.notifications) {
    chrome.notifications.create("focus-start", {
      type: "basic",
      iconUrl: chrome.runtime.getURL("icon48.png"),
      title: "⚡ Focus Zone Engaged",
      message: `Shield activated for ${extensionState.activeSubject} — ${extensionState.activeChapter}`,
      priority: 2,
    });
  }
}

async function handleSessionPaused(payload) {
  if (!extensionState.isFocusActive) return;
  if (payload.sessionId && extensionState.activeSessionId && payload.sessionId !== extensionState.activeSessionId) return;

  console.log(`[FocusForge Session] PAUSE: session=${extensionState.activeSessionId}`);
  extensionState.sessionStatus = "paused";
  if (typeof payload.timeLeftSeconds === "number") {
    extensionState.timeLeftSeconds = payload.timeLeftSeconds;
    extensionState.syncTimestamp = Date.now();
  }

  // Disable YouTube Study Guard immediately upon pause
  youtubeGuardState.leaseUntil = null;
  await YouTubeStudyGuardManager.reconcileState("SESSION_PAUSED");

  await finalizeActiveDistraction(payload.timestamp);
  await BlockerManager.enforcePauseGuardRules(extensionState.blockedDomains);
  updateDerivedStatus();
  persistState();

  if (chrome.notifications) {
    chrome.notifications.create("focus-pause", {
      type: "basic",
      iconUrl: chrome.runtime.getURL("icon48.png"),
      title: "⏸️ Focus Session Paused",
      message: "Pause Guard engaged. Distracting sites require an intentional break choice.",
      priority: 1,
    });
  }
}

async function handleSessionResumed(payload) {
  if (!extensionState.isFocusActive && !payload.sessionId) return;
  if (payload.sessionId) terminalSessionIds.delete(payload.sessionId);

  console.log(`[FocusForge Session] RESUME: session=${payload.sessionId || extensionState.activeSessionId}`);
  extensionState.isFocusActive = true;
  extensionState.sessionStatus = "focus";
  if (payload.sessionId) extensionState.activeSessionId = payload.sessionId;
  if (typeof payload.timeLeftSeconds === "number") {
    extensionState.timeLeftSeconds = payload.timeLeftSeconds;
    extensionState.syncTimestamp = Date.now();
  }

  // Reactivate YouTube Study Guard upon session resume
  youtubeGuardState.activeSessionId = extensionState.activeSessionId;
  youtubeGuardState.verifiedSessionId = extensionState.activeSessionId;
  youtubeGuardState.activeSubject = extensionState.activeSubject;
  youtubeGuardState.activeChapter = extensionState.activeChapter;
  youtubeGuardState.leaseUntil = Date.now() + 120_000;
  await YouTubeStudyGuardManager.reconcileState("SESSION_RESUMED");
  await finalizeActiveDistraction(payload.timestamp);
  await BlockerManager.clearTemporaryAllowRules();
  await BlockerManager.enforceActiveRules(extensionState.blockedDomains);

  // Instantly redirect open tabs on blocked domains back to the block page
  if (chrome.tabs?.query) {
    chrome.tabs.query({}, (tabs) => {
      (tabs || []).forEach((t) => {
        if (t.id && t.url) {
          try {
            const h = cleanDomain(new URL(t.url).hostname);
            if (h === "youtube.com" || h.endsWith(".youtube.com") || h.includes("youtu.be")) return;
            if (extensionState.blockedDomains.some((d) => isDomainMatch(h, d))) {
              const blockPageUrl = chrome.runtime.getURL("block-page/index.html");
              chrome.tabs.update(t.id, { url: `${blockPageUrl}?domain=${encodeURIComponent(h)}` });
            }
          } catch {}
        }
      });
    });
  }

  updateDerivedStatus();
  persistState();

  if (chrome.notifications) {
    chrome.notifications.create("focus-resume", {
      type: "basic",
      iconUrl: chrome.runtime.getURL("icon48.png"),
      title: "⚡ Focus Session Resumed",
      message: `Back in the zone for ${extensionState.activeSubject}. All temporary exceptions locked.`,
      priority: 2,
    });
  }
}

async function handleSessionCompleted(payload) {
  await cleanupTerminalSession("COMPLETED", payload);

  if (chrome.notifications) {
    chrome.notifications.create("focus-complete", {
      type: "basic",
      iconUrl: chrome.runtime.getURL("icon48.png"),
      title: "🎉 Study Session Completed!",
      message: "Outstanding dedication. Normal browsing access has been restored.",
      priority: 2,
    });
  }
}

async function handleSessionAbandoned(payload) {
  await cleanupTerminalSession("ABANDONED", payload);

  if (chrome.notifications) {
    chrome.notifications.create("focus-abandon", {
      type: "basic",
      iconUrl: chrome.runtime.getURL("icon48.png"),
      title: "🛑 Study Session Abandoned",
      message: "Session ended. Normal browsing access has been restored.",
      priority: 1,
    });
  }
}

async function handleSessionCancelled(payload) {
  await cleanupTerminalSession("CANCELLED", payload);
}

async function handleBlockListChanged(payload) {
  if (payload.blockedWebsites && Array.isArray(payload.blockedWebsites)) {
    extensionState.blockedDomains = Array.from(
      new Set(payload.blockedWebsites.map(cleanDomain))
    ).filter(Boolean);
  }
  if (extensionState.isFocusActive) {
    if (extensionState.sessionStatus === "focus") {
      await BlockerManager.enforceActiveRules(extensionState.blockedDomains);
    } else if (extensionState.sessionStatus === "paused") {
      await BlockerManager.enforcePauseGuardRules(extensionState.blockedDomains);
    }
  }
  persistState();
}

// ----------------------------------------------------
// Central Tab Tracking & Distraction Engine (>= 60s)
// ----------------------------------------------------

function isDistractingDomain(hostname) {
  const h = cleanDomain(hostname);
  if (
    !h ||
    h === "localhost" ||
    h === "127.0.0.1" ||
    h.includes("focusforge") ||
    h.includes("jee-made-easy") ||
    h.includes("vercel.app") ||
    h.includes("supabase")
  ) {
    return false;
  }

  // Approved study sites and search engines are never considered distractions
  const whitelisted = [
    ...DEFAULT_WHITELISTED_STUDY_SITES,
    ...(extensionState.whitelistedDomains || []),
  ];
  if (whitelisted.some((w) => isDomainMatch(h, w))) {
    return false;
  }

  // Every other external website visited is tracked as a distraction / browsing activity
  return true;
}

function resetActiveTracking() {
  activeTracking = {
    tabId: null,
    domain: null,
    url: null,
    startTimeMs: null,
    accumulatedSeconds: 0,
    visitId: null,
    isPaused: false,
    lastFocusMs: null,
    sessionBoundaryId: null,
    sessionState: "active",
    activityType: "distraction",
  };
  chrome.storage.local.remove(["focusforge_live_tracking"]);
  persistState();
}

function startActiveDistraction(tabId, url) {
  if (!url) return;

  try {
    const parsed = new URL(url);
    if (
      parsed.protocol === "chrome:" ||
      parsed.protocol === "chrome-extension:" ||
      parsed.protocol === "about:" ||
      parsed.protocol === "edge:" ||
      parsed.protocol === "devtools:"
    ) {
      finalizeActiveDistraction();
      return;
    }

    const domain = cleanDomain(parsed.hostname);

    if (!isDistractingDomain(domain)) {
      finalizeActiveDistraction();
      return;
    }

    // Determine current activity type
    const isPaused = extensionState.sessionStatus === "paused";
    const activityType = isPaused ? "pause_break" : "distraction";
    const sessionState = extensionState.isFocusActive
      ? (isPaused ? "paused" : "active")
      : "casual";

    // If already tracking this tab and domain, keep accumulating
    if (activeTracking.tabId === tabId && activeTracking.domain === domain) {
      return;
    }

    // Finalize previous tracking
    finalizeActiveDistraction();

    const now = Date.now();
    activeTracking = {
      tabId,
      domain,
      url,
      startTimeMs: now,
      accumulatedSeconds: 0,
      visitId: generateUUID(),
      isPaused: false,
      lastFocusMs: now,
      sessionBoundaryId: extensionState.activeSessionId,
      sessionState,
      activityType,
    };

    persistState();
    console.log(`[FocusForge Distraction] Tracking started on ${domain} (${activityType}, visitId: ${activeTracking.visitId})`);
  } catch (e) {}
}

async function finalizeActiveDistraction(sessionBoundaryEndTime) {
  if (!activeTracking.domain || !activeTracking.startTimeMs) {
    resetActiveTracking();
    return;
  }

  const endMs = sessionBoundaryEndTime ? new Date(sessionBoundaryEndTime).getTime() : Date.now();
  const safeEndMs = isNaN(endMs) ? Date.now() : endMs;

  let totalSeconds = activeTracking.accumulatedSeconds;
  if (!activeTracking.isPaused && activeTracking.lastFocusMs) {
    const effectiveNow = Math.min(safeEndMs, Date.now());
    const delta = Math.max(0, Math.floor((effectiveNow - activeTracking.lastFocusMs) / 1000));
    totalSeconds += delta;
  }

  const visitRecord = { ...activeTracking, totalSeconds };
  resetActiveTracking();

  // Discard 0-second instantaneous bounces
  if (totalSeconds < 1) {
    console.log(`[FocusForge Distraction] Discarded ${visitRecord.domain}: 0s duration.`);
    return;
  }

  console.log(`[FocusForge Distraction] Qualifying visit on ${visitRecord.domain}: ${totalSeconds}s (${visitRecord.activityType}). Saving...`);

  // Update in-memory counters based on activity type
  if (visitRecord.activityType === "pause_break") {
    extensionState.todayBreakSeconds = (extensionState.todayBreakSeconds || 0) + totalSeconds;
  } else {
    extensionState.todayWasteTimeSeconds = (extensionState.todayWasteTimeSeconds || 0) + totalSeconds;
    extensionState.todayDistractionsCount = (extensionState.todayDistractionsCount || 0) + 1;
    extensionState.recentDistractions = [
      {
        id: visitRecord.visitId,
        domain: visitRecord.domain,
        url: visitRecord.url,
        timestamp: new Date(visitRecord.startTimeMs).toISOString(),
        durationSeconds: totalSeconds,
        blocked: false,
      },
      ...(extensionState.recentDistractions || []),
    ].slice(0, 10);
  }

  persistState();

  const targetUserId = authenticatedUserId || extensionState.userId;

  const payload = {
    id: visitRecord.visitId,
    user_id: targetUserId,
    session_id: visitRecord.sessionBoundaryId || extensionState.activeSessionId || null,
    domain: visitRecord.domain,
    attempted_url: visitRecord.url,
    duration_seconds: totalSeconds,
    visit_count: 1,
    blocked: false,
    is_during_session: extensionState.isFocusActive,
    session_state: visitRecord.sessionState || (extensionState.isFocusActive ? extensionState.sessionStatus : "casual"),
    activity_type: visitRecord.activityType || "distraction",
    ended_at: new Date(safeEndMs).toISOString(),
    visit_id: visitRecord.visitId,
    timestamp: new Date(visitRecord.startTimeMs).toISOString(),
  };

  // Broadcast to open FocusForge tabs immediately
  notifyFocusForgeTabs("FOCUSFORGE_DISTRACTION_LOGGED", payload);

  // Save to Supabase (Idempotent upsert via visitId UUID) with reliable Outbox fallback
  if (supabaseClient && targetUserId) {
    try {
      const { error } = await supabaseClient.from("distraction_logs").upsert(payload);
      if (error) {
        console.warn("[FocusForge Distraction] Supabase upsert error, enqueuing to outbox:", error);
        await enqueueTelemetry(payload);
      } else {
        console.log(`[FocusForge Distraction] Successfully saved to Supabase (visitId: ${visitRecord.visitId}, type: ${visitRecord.activityType})`);
      }
    } catch (err) {
      console.warn("[FocusForge Distraction] Network failure, enqueuing to outbox:", err);
      await enqueueTelemetry(payload);
    }
  } else {
    await enqueueTelemetry(payload);
  }
}

// Map to deduplicate rapid repeated blocked attempt events
const recentBlockedAttempts = new Map();

async function recordBlockedAttempt(domain, url) {
  const cleanDom = cleanDomain(domain);
  if (
    !cleanDom ||
    cleanDom === "localhost" ||
    cleanDom === "127.0.0.1" ||
    cleanDom.includes("focusforge") ||
    cleanDom.includes("jee-made-easy") ||
    cleanDom.includes("vercel.app") ||
    cleanDom.includes("supabase")
  ) {
    return;
  }

  // Deduplicate rapid duplicate events (e.g. refresh within 3 seconds)
  const now = Date.now();
  const lastTime = recentBlockedAttempts.get(cleanDom);
  if (lastTime && now - lastTime < 3000) {
    return;
  }
  recentBlockedAttempts.set(cleanDom, now);

  const targetUserId = authenticatedUserId || extensionState.userId;
  const visitId = generateUUID();
  const nowIso = new Date().toISOString();

  const payload = {
    id: visitId,
    user_id: targetUserId,
    session_id: extensionState.activeSessionId || null,
    domain: cleanDom,
    attempted_url: url || `https://${cleanDom}`,
    duration_seconds: 0,
    visit_count: 1,
    blocked: true,
    is_during_session: extensionState.isFocusActive,
    session_state: extensionState.isFocusActive ? extensionState.sessionStatus : "casual",
    activity_type: "distraction",
    ended_at: nowIso,
    visit_id: visitId,
    timestamp: nowIso,
  };

  extensionState.todayDistractionsCount = (extensionState.todayDistractionsCount || 0) + 1;
  extensionState.recentDistractions = [
    {
      id: visitId,
      domain: cleanDom,
      url: payload.attempted_url,
      timestamp: nowIso,
      durationSeconds: 0,
      blocked: true,
    },
    ...(extensionState.recentDistractions || []),
  ].slice(0, 10);
  persistState();

  console.log(`[FocusForge Distraction] Recorded blocked attempt on ${cleanDom}. Relaying and saving...`);

  // Broadcast to open FocusForge tabs immediately
  notifyFocusForgeTabs("FOCUSFORGE_DISTRACTION_LOGGED", payload);

  if (supabaseClient && targetUserId) {
    try {
      const { error } = await supabaseClient.from("distraction_logs").upsert(payload);
      if (error) {
        console.warn("[FocusForge Distraction] Blocked attempt upsert error:", error);
        await enqueueTelemetry(payload);
      } else {
        console.log(`[FocusForge Distraction] Blocked attempt saved to Supabase (id: ${visitId})`);
      }
    } catch (err) {
      console.warn("[FocusForge Distraction] Network failure on blocked attempt:", err);
      await enqueueTelemetry(payload);
    }
  } else {
    await enqueueTelemetry(payload);
  }
}

function notifyFocusForgeTabs(type, data) {
  if (chrome.tabs && typeof chrome.tabs.query === "function") {
    chrome.tabs.query({}, (tabs) => {
      (tabs || []).forEach((t) => {
        if (
          t.id &&
          t.url &&
          (t.url.includes("localhost") ||
            t.url.includes("focusforge") ||
            t.url.includes("jee-made-easy") ||
            t.url.includes("vercel.app") ||
            t.url.includes("127.0.0.1"))
        ) {
          try {
            chrome.tabs.sendMessage(t.id, { type, data }).catch(() => {});
          } catch {}
        }
      });
    });
  }
}

// Live tracking ticker updates storage every second for live popup / website viewing
setInterval(() => {
  if (activeTracking.domain && !activeTracking.isPaused && activeTracking.lastFocusMs) {
    const elapsed = activeTracking.accumulatedSeconds + Math.max(0, Math.floor((Date.now() - activeTracking.lastFocusMs) / 1000));
    chrome.storage.local.set({
      focusforge_live_tracking: {
        domain: activeTracking.domain,
        url: activeTracking.url,
        elapsedSeconds: elapsed,
        sessionState: activeTracking.sessionState,
        activityType: activeTracking.activityType,
        startedAt: activeTracking.startTimeMs,
      },
    });
  }
}, 1000);

// ----------------------------------------------------
// Tab & Window Event Listeners
// ----------------------------------------------------

chrome.tabs?.onActivated.addListener((activeInfo) => {
  chrome.tabs.get(activeInfo.tabId, (tab) => {
    if (chrome.runtime.lastError || !tab) {
      finalizeActiveDistraction();
      return;
    }
    startActiveDistraction(tab.id, tab.url || "");
  });
});

chrome.tabs?.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.url) {
    // Check if tab redirected to block-page/index.html to record blocked attempt
    if (changeInfo.url.includes("block-page/index.html")) {
      try {
        const u = new URL(changeInfo.url);
        const bDom = u.searchParams.get("domain");
        const bUrl = u.searchParams.get("url");
        if (bDom) {
          recordBlockedAttempt(bDom, bUrl || `https://${bDom}`);
        }
      } catch {}
    }

    // Check if tab has a single_url temporary exception and navigates away to a different domain
    const singleExc = activeTemporaryExceptions.find((e) => e.tabId === tabId && e.type === "single_url");
    if (singleExc && singleExc.originalUrl) {
      try {
        const currentDom = cleanDomain(new URL(changeInfo.url).hostname);
        const origDom = cleanDomain(new URL(singleExc.originalUrl).hostname);
        if (currentDom && origDom && currentDom !== origDom) {
          console.log(`[FocusForge Blocker] Tab ${tabId} navigated away from ${origDom} to ${currentDom}. Clearing single page exception.`);
          BlockerManager.removeTabTemporaryRules(tabId);
        }
      } catch {}
    }
  }

  if (changeInfo.url || changeInfo.status === "complete") {
    chrome.tabs.query({ active: true, currentWindow: true }, (activeTabs) => {
      if (activeTabs && activeTabs[0] && activeTabs[0].id === tabId) {
        startActiveDistraction(tabId, changeInfo.url || tab.url || "");
      }
    });
  }
});

chrome.tabs?.onRemoved.addListener((tabId) => {
  if (activeTracking.tabId === tabId) {
    finalizeActiveDistraction();
  }
  BlockerManager.removeTabTemporaryRules(tabId);
  pendingGuardedRequests.delete(tabId);
});

chrome.windows?.onFocusChanged.addListener((windowId) => {
  if (windowId === chrome.windows.WINDOW_ID_NONE) {
    // Window lost focus: pause active tracking
    if (activeTracking.domain && !activeTracking.isPaused && activeTracking.lastFocusMs) {
      activeTracking.accumulatedSeconds += Math.max(0, Math.floor((Date.now() - activeTracking.lastFocusMs) / 1000));
      activeTracking.isPaused = true;
      activeTracking.lastFocusMs = null;
      persistState();
    }
  } else {
    // Window regained focus: resume active tracking
    chrome.tabs.query({ active: true, windowId }, (activeTabs) => {
      if (activeTabs && activeTabs[0] && activeTabs[0].url) {
        if (activeTracking.domain && activeTracking.tabId === activeTabs[0].id) {
          activeTracking.isPaused = false;
          activeTracking.lastFocusMs = Date.now();
          persistState();
        } else {
          startActiveDistraction(activeTabs[0].id, activeTabs[0].url);
        }
      }
    });
  }
});

// ----------------------------------------------------
// Pause Guard Resolution Handler
// Flow: Validate state -> Install Tab-Scoped Allow Rule (Priority 10000)
//       -> Verify Rule in DNR -> Record Distraction -> Navigate Tab
// ----------------------------------------------------

async function handleResolvePauseGuard(message, tabId) {
  // 1. Validate session state
  if (!extensionState.isFocusActive || extensionState.sessionStatus !== "paused") {
    console.warn("[FocusForge Guard] Access rejected: Session is not paused.", extensionState);
    return {
      success: false,
      error: "Focus Session is not currently paused. Temporary exceptions are only permitted during pause.",
    };
  }

  // 2. Determine tabId
  const numericTabId = Number(tabId);
  if (!numericTabId || isNaN(numericTabId)) {
    return {
      success: false,
      error: "Unable to identify the requesting browser tab.",
    };
  }

  // 3. Extract and validate target URL & domain
  let rawUrl = message.url || "";
  let rawDomain = cleanDomain(message.domain || "");

  const pending = pendingGuardedRequests.get(numericTabId);
  if (pending && pending.originalUrl && !rawUrl) {
    rawUrl = pending.originalUrl;
    rawDomain = rawDomain || pending.domain;
  }

  if (!rawUrl && rawDomain) {
    rawUrl = `https://${rawDomain}`;
  }

  if (!rawUrl) {
    return {
      success: false,
      error: "Destination URL was not provided.",
    };
  }

  let parsedUrl;
  try {
    parsedUrl = new URL(rawUrl);
  } catch {
    return {
      success: false,
      error: "Malformed destination URL.",
    };
  }

  if (parsedUrl.protocol !== "http:" && parsedUrl.protocol !== "https:") {
    return {
      success: false,
      error: "Only HTTP and HTTPS destinations are permitted.",
    };
  }

  const urlDomain = cleanDomain(parsedUrl.hostname);
  if (!rawDomain) {
    rawDomain = urlDomain;
  }

  const mode = message.mode === "site" ? "site" : "page";
  const validDestination = parsedUrl.toString();

  // 4. Create tab-scoped temporary allow rule in DNR BEFORE navigation
  const ruleRes = await BlockerManager.addTemporaryAllowRule({
    tabId: numericTabId,
    url: validDestination,
    domain: rawDomain,
    mode,
  });

  if (!ruleRes.success) {
    return {
      success: false,
      error: ruleRes.error || "Failed to install temporary DNR allow exception.",
    };
  }

  // 5. Verify the rule exists in Declarative Net Request session rules
  const verified = await BlockerManager.verifyTemporaryRule(numericTabId, ruleRes.ruleId);
  if (!verified) {
    return {
      success: false,
      error: "Verification failed: Temporary exception was not installed in DNR engine.",
    };
  }

  // 6. Record and start distraction / break tracking
  startActiveDistraction(numericTabId, validDestination);

  // 7. Cleanup pending guard records
  try {
    chrome.tabs.sendMessage(numericTabId, { type: "REMOVE_BLOCK_OVERLAY" }, () => {
      if (chrome.runtime.lastError) {}
    });
  } catch {}

  pendingGuardedRequests.delete(numericTabId);

  return {
    success: true,
    verified: true,
    targetUrl: validDestination,
    domain: rawDomain,
    mode,
    tabId: numericTabId,
  };
}

// ----------------------------------------------------
// Message Communication Router
// ----------------------------------------------------

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "FOCUSFORGE_REGISTER_WEBAPP_ORIGIN" && message.origin) {
    try {
      chrome.storage.local.set({ focusforge_webapp_origin: message.origin });
    } catch {}
    if (sendResponse) sendResponse({ success: true, origin: message.origin });
    return true;
  }

  if (message.type === "FOCUSFORGE_SET_AUTH_SESSION") {
    const session = message.session;
    if (session && session.access_token && session.user?.id) {
      const newUserId = session.user.id;
      const isUserSwitch = authenticatedUserId && authenticatedUserId !== newUserId;

      if (isUserSwitch) {
        console.log(`[FocusForge Auth] User switched from ${authenticatedUserId} to ${newUserId}. Cleaning up prior context.`);
        realtimeChannels.forEach((ch) => {
          try {
            supabaseClient?.removeChannel(ch);
          } catch {}
        });
        realtimeChannels = [];
        BlockerManager.clearAllRules();
        resetActiveTracking();
      }

      authenticatedUserId = newUserId;
      extensionState.userId = newUserId;
      extensionState.syncStatus = "CONNECTED";

      chrome.storage.local.set({ supabase_auth_session: session });

      if (supabaseClient) {
        supabaseClient.auth
          .setSession({
            access_token: session.access_token,
            refresh_token: session.refresh_token,
          })
          .then(() => {
            setupRealtimeSubscriptions(authenticatedUserId, session.access_token);
            reconcileWithCloud(authenticatedUserId);
            sendPresenceHeartbeat();
          })
          .catch(() => {
            sendPresenceHeartbeat();
          });
      } else {
        sendPresenceHeartbeat();
      }

      updateDerivedStatus();
      if (sendResponse) sendResponse({ status: "AUTHENTICATED", userId: authenticatedUserId });
    }
    return true;
  }

  if (message.type === "FOCUSFORGE_LOGOUT") {
    console.log(`[FocusForge Auth] User logged out. Tearing down user context for: ${authenticatedUserId}`);
    authenticatedUserId = null;
    extensionState.userId = null;
    extensionState.isFocusActive = false;
    extensionState.sessionStatus = "idle";
    extensionState.syncStatus = "AUTHENTICATION_REQUIRED";
    extensionState.activeSessionId = null;
    extensionState.timeLeftSeconds = 0;
    extensionState.todayWasteTimeSeconds = 0;
    extensionState.todayBreakSeconds = 0;
    extensionState.todayDistractionsCount = 0;
    extensionState.recentDistractions = [];

    chrome.storage.local.remove([
      "supabase_auth_session",
      "focusforge_state",
      "focusforge_tracking",
      "focusforge_temp_allows",
      "focusforge_live_tracking",
    ]);

    realtimeChannels.forEach((ch) => {
      try {
        supabaseClient?.removeChannel(ch);
      } catch {}
    });
    realtimeChannels = [];
    isRealtimeConnected = false;

    if (supabaseClient) {
      supabaseClient.auth.signOut().catch(() => {});
    }

    BlockerManager.clearAllRules();
    resetActiveTracking();
    updateBadge();
    persistState();

    if (sendResponse) sendResponse({ status: "LOGGED_OUT" });
    return true;
  }

  // Helper to execute verified tab navigation after notifying the Pause Guard UI
  function executeGuardedNavigation(tabId, res) {
    if (res && res.success && res.targetUrl && tabId) {
      setTimeout(() => {
        try {
          chrome.tabs.update(Number(tabId), { url: res.targetUrl });
          console.log(`[FocusForge SW] Successfully navigated tab ${tabId} to ${res.targetUrl} with verified DNR allow exception.`);
        } catch (navErr) {
          console.warn("[FocusForge SW] chrome.tabs.update error:", navErr);
        }
      }, 60);
    }
  }

  // Handle Pause Guard Exception Request (Single URL or Domain Exception during Pause)
  if (message.type === "RESOLVE_PAUSE_GUARD") {
    const tabId = sender.tab?.id || message.tabId;
    handleResolvePauseGuard(message, tabId).then((res) => {
      if (sendResponse) sendResponse(res);
      executeGuardedNavigation(tabId, res);
    });
    return true;
  }

  // Handle Legacy Pause Guard: Allow Temporary Single Page URL
  if (message.type === "ALLOW_TEMPORARY_URL") {
    const tabId = sender.tab?.id || message.tabId;
    handleResolvePauseGuard({ ...message, mode: "page" }, tabId).then((res) => {
      if (sendResponse) sendResponse(res);
      executeGuardedNavigation(tabId, res);
    });
    return true;
  }

  // Handle Recording Blocked Site Attempts
  if (message.type === "RECORD_BLOCKED_ATTEMPT") {
    recordBlockedAttempt(message.domain, message.url);
    if (sendResponse) sendResponse({ success: true });
    return true;
  }

  // Handle Legacy Pause Guard: Allow Temporary Domain during Pause
  if (message.type === "ALLOW_TEMPORARY_DOMAIN") {
    const tabId = sender.tab?.id || message.tabId;
    handleResolvePauseGuard({ ...message, mode: "site" }, tabId).then((res) => {
      if (sendResponse) sendResponse(res);
      executeGuardedNavigation(tabId, res);
    });
    return true;
  }

  // Handle Pause Guard Context Inquiry & Pending Request Registration
  if (message.type === "GET_PAUSE_GUARD_CONTEXT") {
    const tabId = sender.tab?.id || message.tabId;
    if (tabId && (message.domain || message.url)) {
      pendingGuardedRequests.set(Number(tabId), {
        tabId: Number(tabId),
        originalUrl: message.url,
        domain: cleanDomain(message.domain),
        sessionId: extensionState.activeSessionId,
        sessionStatus: extensionState.sessionStatus,
        guardReason: "study_session_paused",
        timestamp: Date.now(),
      });
    }
    const startMs = extensionState.startTime ? new Date(extensionState.startTime).getTime() : Date.now();
    const elapsed = Math.max(0, Math.floor((Date.now() - startMs) / 1000));
    sendResponse({
      subject: extensionState.activeSubject,
      chapter: extensionState.activeChapter,
      sessionStatus: extensionState.sessionStatus,
      elapsedStudySeconds: elapsed,
      timeLeftSeconds: computeTimeLeft(),
      sessionId: extensionState.activeSessionId,
      pending: tabId ? pendingGuardedRequests.get(Number(tabId)) : null,
    });
    return true;
  }

  // Handle in-page content script block status inquiry
  // Guarantees: Never blocks during PAUSE, IDLE, or when tab has temporary allow exception
  if (message.type === "CHECK_TAB_BLOCK_STATUS") {
    const tabId = sender.tab?.id;
    let targetHost = "";
    try {
      targetHost = cleanDomain(new URL(message.url || sender.tab?.url || "").hostname);
    } catch {
      targetHost = cleanDomain(message.url);
    }

    // 1. YouTube domain is NEVER blocked by generic WebBlocker - managed exclusively by YouTubeStudyGuardManager
    if (targetHost === "youtube.com" || targetHost.endsWith(".youtube.com") || targetHost.includes("youtu.be")) {
      sendResponse({ shouldBlock: false, reason: "youtube_managed_by_youtube_study_guard" });
      return true;
    }

    // 2. If study session is not active or is currently PAUSED, NEVER block via in-page overlay
    if (!extensionState.isFocusActive || extensionState.sessionStatus !== "focus") {
      sendResponse({ shouldBlock: false, reason: "session_not_in_active_focus" });
      return true;
    }

    // 3. Check if domain is blocked
    const isDomainBlocked = extensionState.blockedDomains.some((d) => isDomainMatch(targetHost, d));
    if (!isDomainBlocked) {
      sendResponse({ shouldBlock: false, reason: "domain_not_blocked" });
      return true;
    }

    // 4. Check for tab-scoped temporary exception
    if (tabId) {
      const hasTabException = activeTemporaryExceptions.some(
        (exc) => exc.tabId === Number(tabId) && (exc.type === "site" || isDomainMatch(targetHost, exc.domain))
      );
      if (hasTabException) {
        sendResponse({ shouldBlock: false, reason: "tab_has_active_exception" });
        return true;
      }
    }

    // 5. Check temporaryAllowState
    if (temporaryAllowState.domains.includes(targetHost)) {
      sendResponse({ shouldBlock: false, reason: "temporary_allow_domain" });
      return true;
    }

    // Otherwise, active focus session with blocked domain and no exception
    sendResponse({
      shouldBlock: true,
      domain: targetHost,
      state: {
        activeSubject: extensionState.activeSubject,
        activeChapter: extensionState.activeChapter,
        activeGoal: extensionState.activeGoal,
      },
    });
    return true;
  }

  if (message.type === "GET_EXTENSION_STATUS") {
    const doRespond = () => {
      extensionState.timeLeftSeconds = computeTimeLeft();
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const currentUrl = tabs && tabs[0] ? tabs[0].url || "" : "";
        const currentHost = cleanDomain(currentUrl);
        const isBlocked =
          extensionState.isFocusActive &&
          extensionState.sessionStatus === "focus" &&
          currentHost !== "youtube.com" &&
          !currentHost.endsWith(".youtube.com") &&
          !currentHost.includes("youtu.be") &&
          extensionState.blockedDomains.some((d) => isDomainMatch(currentHost, d));

        sendResponse({
          ...extensionState,
          currentTabDomain: currentHost,
          currentTabBlocked: isBlocked,
          temporaryAllows: temporaryAllowState,
          installationId,
          realtimeConnected: isRealtimeConnected,
          rulesCount: extensionState.activeRuleCount,
          debug: {
            authenticatedUserId,
            syncStatus: extensionState.syncStatus,
            isFocusActive: extensionState.isFocusActive,
            sessionStatus: extensionState.sessionStatus,
            activeRuleCount: extensionState.activeRuleCount,
            blockedDomainsCount: extensionState.blockedDomains.length,
            temporaryDomainsCount: temporaryAllowState.domains.length,
            lastSync: extensionState.lastSync,
            lastReconcileTrigger: extensionState.lastReconcileTrigger,
          },
        });
      });
    };

    if (authenticatedUserId) {
      // Reconcile against cloud with a bounded 500ms race for instantaneous UI paint
      Promise.race([
        reconcileWithCloud(authenticatedUserId, "GET_EXTENSION_STATUS"),
        new Promise((r) => setTimeout(r, 500)),
      ])
        .catch((e) => console.warn("[FocusForge Status] Reconciliation error:", e))
        .finally(() => doRespond());
      return true;
    } else {
      // Attempt to recover auth session from storage before responding
      chrome.storage?.local?.get(["supabase_auth_session"], (stored) => {
        const s = stored?.supabase_auth_session;
        if (s?.user?.id) {
          authenticatedUserId = s.user.id;
          extensionState.userId = s.user.id;
          if (supabaseClient && s.access_token) {
            supabaseClient.auth
              .setSession({ access_token: s.access_token, refresh_token: s.refresh_token })
              .catch(() => {});
          }
          Promise.race([
            reconcileWithCloud(authenticatedUserId, "GET_EXTENSION_STATUS_RECOVERED"),
            new Promise((r) => setTimeout(r, 500)),
          ])
            .catch((e) => console.warn("[FocusForge Status] Reconciliation error:", e))
            .finally(() => doRespond());
        } else {
          doRespond();
        }
      });
      return true;
    }
  }

  if (message.type === "FORCE_SYNC") {
    extensionState.syncStatus = "SYNCING";
    updateBadge();

    if (authenticatedUserId) {
      reconcileWithCloud(authenticatedUserId, "FORCE_SYNC").then(() => {
        extensionState.timeLeftSeconds = computeTimeLeft();
        sendResponse(extensionState);
      });
      return true;
    } else {
      setTimeout(() => {
        extensionState.syncStatus = "AUTHENTICATION_REQUIRED";
        updateBadge();
        sendResponse(extensionState);
      }, 300);
      return true;
    }
  }

  if (message.type === "FOCUSFORGE_SYNC") {
    // Direct sync fallback from web app
    const incomingToken = message.token || message.accessToken;
    if (message.userId) {
      authenticatedUserId = message.userId;
      extensionState.userId = message.userId;
      if (incomingToken) {
        setupRealtimeSubscriptions(message.userId, incomingToken);
      } else {
        setupRealtimeSubscriptions(message.userId);
      }
      reconcileWithCloud(message.userId, "FOCUSFORGE_SYNC");
      sendPresenceHeartbeat();
    } else if (authenticatedUserId) {
      sendPresenceHeartbeat();
    }
    const rawSites = message.blockedSites || message.blockedWebsites;
    if (Array.isArray(rawSites)) {
      extensionState.blockedDomains = Array.from(
        new Set(rawSites.map(cleanDomain))
      ).filter(Boolean);
    }
    if (typeof message.isFocusActive === "boolean") {
      if (!message.isFocusActive || message.sessionStatus === "idle") {
        cleanupTerminalSession("FOCUSFORGE_SYNC_INACTIVE", message).then(() => {
          if (sendResponse) sendResponse({ status: "SYNCED", active: false });
        });
        return true;
      } else {
        extensionState.isFocusActive = true;
        extensionState.sessionStatus = message.sessionStatus || "focus";
        extensionState.activeSessionId = message.sessionId || extensionState.activeSessionId;
        extensionState.activeSubject = message.subject || extensionState.activeSubject;
        extensionState.activeChapter = message.chapter || extensionState.activeChapter;
        extensionState.timeLeftSeconds = typeof message.timeLeftSeconds === "number" ? message.timeLeftSeconds : extensionState.timeLeftSeconds;
        extensionState.syncTimestamp = Date.now();

        if (typeof message.coolingBlockUntil !== "undefined") {
          extensionState.coolingBlockUntil = message.coolingBlockUntil;
        }
        if (typeof message.whitelistOnly === "boolean") {
          extensionState.whitelistOnly = message.whitelistOnly;
        }
        if (typeof message.examModeEnabled === "boolean") {
          extensionState.examModeEnabled = message.examModeEnabled;
        }

        if (extensionState.sessionStatus === "focus") {
          youtubeGuardState.activeSessionId = extensionState.activeSessionId;
          youtubeGuardState.verifiedSessionId = extensionState.activeSessionId;
          youtubeGuardState.activeSubject = extensionState.activeSubject;
          youtubeGuardState.activeChapter = extensionState.activeChapter;
          youtubeGuardState.mode = message.youtubeGuardMode || youtubeGuardState.mode || "strict";
          youtubeGuardState.leaseUntil = message.sessionLeaseUntil || (Date.now() + 120_000);
          YouTubeStudyGuardManager.reconcileState("FOCUSFORGE_SYNC_FOCUS");

          BlockerManager.clearTemporaryAllowRules();
          BlockerManager.enforceActiveRules(extensionState.blockedDomains);
        } else if (extensionState.sessionStatus === "paused") {
          youtubeGuardState.leaseUntil = null;
          YouTubeStudyGuardManager.reconcileState("FOCUSFORGE_SYNC_PAUSED");

          BlockerManager.enforcePauseGuardRules(extensionState.blockedDomains);
        }
        updateDerivedStatus();
        persistState();
      }
    }
    if (sendResponse) sendResponse({ status: "SYNCED" });
    return true;
  }

  // ----------------------------------------------------
  // YouTube Study Content Guard Message Handlers
  // ----------------------------------------------------

  if (message.type === "GET_YOUTUBE_GUARD_STATUS" || message.type === "GET_YOUTUBE_GUARD_STATE" || message.type === "GET_FOCUS_GATEWAY_DIAGNOSTICS") {
    const active = isYouTubeGuardActive();
    sendResponse({
      active,
      gatewayActive: active,
      firewallActive: active,
      status: active ? "ON" : "OFF",
      mode: youtubeGuardState.mode,
      sessionId: extensionState.activeSessionId,
      verifiedSessionId: youtubeGuardState.verifiedSessionId,
      subject: extensionState.activeSubject,
      chapter: extensionState.activeChapter,
      leaseUntil: youtubeGuardState.leaseUntil,
      studyWatchSeconds: youtubeGuardState.todayStudyWatchSeconds,
      approvedVideosCount: youtubeGuardState.approvedVideoIds.size,
      approvedVideoIds: Array.from(youtubeGuardState.approvedVideoIds),
      installedRulesCount: youtubeGuardState.installedRuleIds.length,
      focusPassCount: FocusPassManager.count(),
      lastBlockedVideo: youtubeGuardState.lastBlockedVideo || null,
      lastAllowedVideo: youtubeGuardState.lastAllowedVideo || null,
      classifierOnline: true,
      error: youtubeGuardState.error,
    });
    return true;
  }

  if (message.type === "SET_YOUTUBE_GUARD_MODE" && message.mode) {
    youtubeGuardState.mode = message.mode;
    YouTubeStudyGuardManager.reconcileState("SET_MODE");
    sendResponse({ success: true, mode: youtubeGuardState.mode });
    return true;
  }

  // Gateway Landing Page Verification Handler (Layer B)
  if (message.type === "VERIFY_GATEWAY_DESTINATION") {
    const videoId = message.videoId;
    const targetUrl = message.targetUrl || (videoId ? `https://www.youtube.com/watch?v=${videoId}` : "");

    if (!shouldEnableYouTubeGuard()) {
      sendResponse({
        isSessionActive: false,
        decision: "ALLOW",
        videoId,
        targetUrl,
        reason: "Study session inactive",
      });
      return true;
    }

    if (!videoId) {
      sendResponse({
        isSessionActive: true,
        decision: "BLOCK",
        reason: "Invalid destination video identifier.",
      });
      return true;
    }

    // 1. Check active Focus Pass
    if (FocusPassManager.hasValidPass(videoId)) {
      const pass = FocusPassManager.getPass(videoId);
      sendResponse({
        isSessionActive: true,
        decision: "ALLOW",
        videoId,
        targetUrl,
        activeSubject: extensionState.activeSubject,
        activeChapter: extensionState.activeChapter,
        reason: pass?.reason || "Active Focus Pass",
      });
      return true;
    }

    // 2. Check classification cache
    const cached = youtubeClassificationCache.get(videoId);
    if (cached && Date.now() - (cached.cachedAt || 0) < 3600_000) {
      if (isStudyAllowedDecision(cached.decision)) {
        YouTubeStudyGuardManager.approveVideo(videoId, cached).then(() => {
          sendResponse({
            isSessionActive: true,
            decision: "ALLOW",
            videoId,
            targetUrl,
            activeSubject: extensionState.activeSubject,
            activeChapter: extensionState.activeChapter,
            reason: cached.reason,
          });
        });
        return true;
      } else {
        youtubeGuardState.lastBlockedVideo = { videoId, reason: cached.reason, timestamp: Date.now() };
        persistGuardRuntimeState();
        sendResponse({
          isSessionActive: true,
          decision: "BLOCK",
          videoId,
          reason: cached.reason,
          activeSubject: extensionState.activeSubject,
        });
        return true;
      }
    }

    // 3. Classify candidate with metadata enrichment
    chrome.storage.local.get(["focusforge_webapp_origin"], async (res) => {
      const origin = res?.focusforge_webapp_origin || "http://localhost:3000";
      let title = message.title || "";
      let channelName = message.channelName || "";

      if (!title && videoId) {
        try {
          const oembedRes = await fetch(
            `https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=${encodeURIComponent(videoId)}&format=json`
          );
          if (oembedRes.ok) {
            const odata = await oembedRes.json();
            if (odata?.title) title = odata.title;
            if (odata?.author_name) channelName = odata.author_name;
          }
        } catch (e) {
          logYouTubeGuard("oEmbed", "Failed to fetch oEmbed metadata in Gateway:", e);
        }
      }

      const payload = {
        candidates: [{
          videoId,
          title,
          channelName,
          userId: authenticatedUserId,
          activeSessionSubject: extensionState.activeSubject,
          activeSessionChapter: extensionState.activeChapter,
          guardMode: youtubeGuardState.mode,
        }],
        userId: authenticatedUserId,
      };

      try {
        const r = await fetch(`${origin}/api/youtube/classify`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        const data = await r.json();
        let verdict = null;
        if (data && data.success && Array.isArray(data.results) && data.results[0]) {
          verdict = data.results[0];
        } else {
          verdict = runLocalFallbackClassification({ videoId, title, channelName });
        }

        youtubeClassificationCache.set(videoId, { ...verdict, cachedAt: Date.now() });

        if (isStudyAllowedDecision(verdict.decision)) {
          await YouTubeStudyGuardManager.approveVideo(videoId, verdict);
          sendResponse({
            isSessionActive: true,
            decision: "ALLOW",
            videoId,
            targetUrl,
            activeSubject: extensionState.activeSubject,
            activeChapter: extensionState.activeChapter,
            reason: verdict.reason,
          });
        } else if (verdict.decision === "REVIEW") {
          sendResponse({
            isSessionActive: true,
            decision: "REVIEW",
            videoId,
            targetUrl,
            title,
            channelName,
            subject: verdict.subject || extensionState.activeSubject,
            chapter: verdict.chapter || extensionState.activeChapter,
            topic: verdict.topic || "",
            reason: verdict.reason,
            reasonCodes: verdict.reasonCodes || ["INSUFFICIENT_EVIDENCE"],
            activeSubject: extensionState.activeSubject,
          });
        } else {
          youtubeGuardState.lastBlockedVideo = { videoId, reason: verdict.reason, timestamp: Date.now() };
          persistGuardRuntimeState();
          sendResponse({
            isSessionActive: true,
            decision: "BLOCK",
            videoId,
            reason: verdict.reason,
            activeSubject: extensionState.activeSubject,
          });
        }
      } catch (err) {
        logYouTubeGuard("Gateway", "Classification error, using fallback:", err);
        const fallback = runLocalFallbackClassification({ videoId, title, channelName });
        youtubeClassificationCache.set(videoId, { ...fallback, cachedAt: Date.now() });

        if (isStudyAllowedDecision(fallback.decision)) {
          await YouTubeStudyGuardManager.approveVideo(videoId, fallback);
          sendResponse({
            isSessionActive: true,
            decision: "ALLOW",
            videoId,
            targetUrl,
            activeSubject: extensionState.activeSubject,
            activeChapter: extensionState.activeChapter,
            reason: fallback.reason,
          });
        } else if (fallback.decision === "REVIEW") {
          sendResponse({
            isSessionActive: true,
            decision: "REVIEW",
            videoId,
            targetUrl,
            title,
            channelName,
            subject: fallback.subject || extensionState.activeSubject,
            chapter: fallback.chapter || extensionState.activeChapter,
            topic: fallback.topic || "",
            reason: fallback.reason,
            reasonCodes: fallback.reasonCodes || ["INSUFFICIENT_EVIDENCE"],
            activeSubject: extensionState.activeSubject,
          });
        } else {
          youtubeGuardState.lastBlockedVideo = { videoId, reason: fallback.reason, timestamp: Date.now() };
          persistGuardRuntimeState();
          sendResponse({
            isSessionActive: true,
            decision: "BLOCK",
            videoId,
            reason: fallback.reason,
            activeSubject: extensionState.activeSubject,
          });
        }
      }
    });

    return true;
  }

  if (message.type === "GRANT_FOCUS_PASS") {
    const videoId = message.videoId;
    if (videoId) {
      YouTubeStudyGuardManager.approveVideo(videoId, message.meta || {}).then(() => {
        sendResponse({ success: true, videoId });
      });
      return true;
    }
    sendResponse({ success: false, error: "Missing videoId" });
    return true;
  }

  if (message.type === "VERIFY_AND_UNLOCK_VIDEO") {
    const videoId = message.videoId;
    if (!videoId) {
      sendResponse({ success: false, error: "Missing videoId" });
      return true;
    }

    // Master check: If guard is NOT enabled or session is not active, allow immediately
    if (!shouldEnableYouTubeGuard()) {
      sendResponse({
        success: true,
        decision: "ALLOW",
        videoId,
        reason: "Study Guard inactive",
        approvedUrl: `https://www.youtube.com/watch?v=${videoId}`,
      });
      return true;
    }

    // If already approved, return ALLOW immediately
    if (youtubeGuardState.approvedVideoIds.has(videoId)) {
      sendResponse({
        success: true,
        decision: "ALLOW",
        videoId,
        alreadyApproved: true,
        approvedUrl: `https://www.youtube.com/watch?v=${videoId}`,
      });
      return true;
    }

    // Check classification cache
    const cached = youtubeClassificationCache.get(videoId);
    if (cached && Date.now() - (cached.cachedAt || 0) < 3600_000) {
      if (isStudyAllowedDecision(cached.decision)) {
        YouTubeStudyGuardManager.approveVideo(videoId, cached).then(() => {
          sendResponse({
            success: true,
            decision: "ALLOW",
            videoId,
            result: cached,
            approvedUrl: `https://www.youtube.com/watch?v=${videoId}`,
          });
        });
      } else {
        sendResponse({
          success: false,
          decision: "BLOCK",
          videoId,
          result: cached,
        });
      }
      return true;
    }

    // Perform classification via web app API or local fallback with oEmbed metadata enrichment
    (async () => {
      let title = message.title || "";
      let channelName = message.channelName || "";
      let description = message.description || "";
      let durationSeconds = Number(message.durationSeconds || 0);

      // Fast oEmbed resolver if title is missing (e.g. direct address bar entry or refresh on watch page)
      if (!title) {
        try {
          const oembedRes = await fetch(
            `https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=${encodeURIComponent(videoId)}&format=json`
          );
          if (oembedRes.ok) {
            const odata = await oembedRes.json();
            if (odata?.title) title = odata.title;
            if (odata?.author_name) channelName = odata.author_name;
          }
        } catch (e) {
          logYouTubeGuard("oEmbed", "Failed to fetch oEmbed metadata:", e);
        }
      }

      const enrichedPayload = {
        videoId,
        title,
        description,
        channelName,
        durationSeconds,
        userId: authenticatedUserId,
        activeSessionSubject: extensionState.activeSubject,
        activeSessionChapter: extensionState.activeChapter,
        guardMode: youtubeGuardState.mode,
      };

      chrome.storage.local.get(["focusforge_webapp_origin"], (res) => {
        const origin = res?.focusforge_webapp_origin || "http://localhost:3000";
        fetch(`${origin}/api/youtube/classify`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(enrichedPayload),
        })
          .then((r) => r.json())
          .then((data) => {
            const result = data?.result || runLocalFallbackClassification(enrichedPayload);
            youtubeClassificationCache.set(videoId, { ...result, cachedAt: Date.now() });

            if (isStudyAllowedDecision(result.decision)) {
              YouTubeStudyGuardManager.approveVideo(videoId, result).then(() => {
                sendResponse({
                  success: true,
                  decision: "ALLOW",
                  videoId,
                  result,
                  approvedUrl: `https://www.youtube.com/watch?v=${videoId}`,
                });
              });
            } else {
              sendResponse({
                success: false,
                decision: "BLOCK",
                videoId,
                result,
              });
            }
          })
          .catch((err) => {
            logYouTubeGuard("Classify", "Fetch error, using local fallback:", err);
            const fallback = runLocalFallbackClassification(enrichedPayload);
            youtubeClassificationCache.set(videoId, { ...fallback, cachedAt: Date.now() });

            if (isStudyAllowedDecision(fallback.decision)) {
              YouTubeStudyGuardManager.approveVideo(videoId, fallback).then(() => {
                sendResponse({
                  success: true,
                  decision: "ALLOW",
                  videoId,
                  result: fallback,
                  approvedUrl: `https://www.youtube.com/watch?v=${videoId}`,
                });
              });
            } else {
              sendResponse({
                success: false,
                decision: "BLOCK",
                videoId,
                result: fallback,
              });
            }
          });
      });
    })();
    return true;
  }

  if (message.type === "APPROVE_STUDY_VIDEO" || message.type === "APPROVE_YOUTUBE_VIDEO") {
    const videoId = message.videoId;
    if (videoId) {
      const meta = message.metadata || {
        title: message.title || "",
        channelName: message.channelName || "",
        reason: "Student confirmed curriculum study video at gateway.",
      };
      YouTubeStudyGuardManager.approveVideo(videoId, meta).then(() => {
        sendResponse({
          success: true,
          videoId,
          approvedUrl: `https://www.youtube.com/watch?v=${videoId}`,
        });
      });
      return true;
    }
  }

  if (message.type === "CLASSIFY_YOUTUBE_VIDEO") {
    if (!isYouTubeGuardActive()) {
      sendResponse({
        success: true,
        result: {
          videoId: message.videoId,
          decision: "ALLOW",
          confidence: 1.0,
          reason: "Study Guard dormant: No active study session.",
          isTrustedChannel: false,
          isManuallyApproved: false,
          isShort: false,
        },
      });
      return true;
    }

    const videoId = message.videoId;
    logYouTubeDiagnostic({
      session: "ACTIVE",
      videoId,
      state: "VERIFYING",
      event: "CLASSIFICATION_REQUEST",
    });

    const cached = youtubeClassificationCache.get(videoId);
    if (cached && Date.now() - (cached.cachedAt || 0) < 3600_000) {
      if (isStudyAllowedDecision(cached.decision)) {
        YouTubeStudyGuardManager.approveVideo(videoId, cached);
      }
      logYouTubeDiagnostic({
        session: "ACTIVE",
        videoId,
        subject: cached.subject || extensionState.activeSubject,
        topic: cached.topic || extensionState.activeChapter,
        decision: cached.decision,
        reason: cached.reason,
        playback: isStudyAllowedDecision(cached.decision) ? "UNLOCKED" : "LOCKED",
      });
      sendResponse({ success: true, result: cached });
      return true;
    }

    chrome.storage.local.get(["focusforge_webapp_origin"], (res) => {
      const origin = res?.focusforge_webapp_origin || "http://localhost:3000";
      fetch(`${origin}/api/youtube/classify`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          videoId,
          title: message.title || "",
          description: message.description || "",
          channelName: message.channelName || "",
          durationSeconds: Number(message.durationSeconds || 0),
          userId: authenticatedUserId,
          activeSessionSubject: extensionState.activeSubject,
          activeSessionChapter: extensionState.activeChapter,
          guardMode: youtubeGuardState.mode,
        }),
      })
        .then((r) => r.json())
        .then((data) => {
          if (data?.result) {
            youtubeClassificationCache.set(videoId, { ...data.result, cachedAt: Date.now() });
            if (isStudyAllowedDecision(data.result.decision)) {
              YouTubeStudyGuardManager.approveVideo(videoId, data.result);
            }
            logYouTubeDiagnostic({
              session: "ACTIVE",
              videoId,
              subject: data.result.subject || extensionState.activeSubject,
              topic: data.result.topic || extensionState.activeChapter,
              decision: data.result.decision,
              reason: data.result.reason,
              playback: isStudyAllowedDecision(data.result.decision) ? "UNLOCKED" : "LOCKED",
            });
            sendResponse({ success: true, result: data.result });
          } else {
            const fallback = runLocalFallbackClassification(message);
            youtubeClassificationCache.set(videoId, { ...fallback, cachedAt: Date.now() });
            if (isStudyAllowedDecision(fallback.decision)) {
              YouTubeStudyGuardManager.approveVideo(videoId, fallback);
            }
            logYouTubeDiagnostic({
              session: "ACTIVE",
              videoId,
              subject: fallback.subject || extensionState.activeSubject,
              topic: fallback.topic || extensionState.activeChapter,
              decision: fallback.decision,
              reason: fallback.reason,
              playback: isStudyAllowedDecision(fallback.decision) ? "UNLOCKED" : "LOCKED",
            });
            sendResponse({ success: true, result: fallback });
          }
        })
        .catch((err) => {
          logYouTubeGuard("Classify", "Classify fetch error, using local fallback:", err);
          const fallback = runLocalFallbackClassification(message);
          youtubeClassificationCache.set(videoId, { ...fallback, cachedAt: Date.now() });
          if (isStudyAllowedDecision(fallback.decision)) {
            YouTubeStudyGuardManager.approveVideo(videoId, fallback);
          }
          logYouTubeDiagnostic({
            session: "ACTIVE",
            videoId,
            subject: fallback.subject || extensionState.activeSubject,
            topic: fallback.topic || extensionState.activeChapter,
            decision: fallback.decision,
            reason: fallback.reason,
            playback: isStudyAllowedDecision(fallback.decision) ? "UNLOCKED" : "LOCKED",
          });
          sendResponse({ success: true, result: fallback });
        });
    });
    return true;
  }

  if (message.type === "LOG_YOUTUBE_STUDY_TIME") {
    const sec = Number(message.durationSeconds || 0);
    if (sec > 0 && isYouTubeGuardActive()) {
      youtubeGuardState.todayStudyWatchSeconds += sec;
      if (message.videoId) {
        youtubeGuardState.approvedVideoIds.add(message.videoId);
      }

      chrome.storage.local.get(["focusforge_webapp_origin"], (res) => {
        const origin = res?.focusforge_webapp_origin || "http://localhost:3000";
        fetch(`${origin}/api/youtube/logs`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            userId: authenticatedUserId,
            sessionId: extensionState.activeSessionId,
            videoId: message.videoId,
            title: message.title,
            channelName: message.channelName,
            decision: "ALLOW",
            subject: message.subject || extensionState.activeSubject,
            chapter: message.chapter || extensionState.activeChapter,
            topic: message.topic,
            durationSeconds: sec,
          }),
        }).catch(() => {});
      });
    }
    sendResponse({ success: true });
    return true;
  }

  if (message.type === "LOG_YOUTUBE_DISTRACTION") {
    if (isYouTubeGuardActive()) {
      const targetUserId = authenticatedUserId || extensionState.userId;
      recordBlockedAttempt(targetUserId, message.url || "https://www.youtube.com", "youtube.com", extensionState.activeSessionId);
    }
    sendResponse({ success: true });
    return true;
  }

  // Handle batch pre-verification of recommended video candidates
  if (message.type === "PREFETCH_YOUTUBE_RECOMMENDATIONS") {
    const candidates = Array.isArray(message.candidates) ? message.candidates : [];
    if (!candidates.length) {
      sendResponse({ success: true, decisions: {} });
      return true;
    }

    if (!isYouTubeGuardActive()) {
      const decisions = {};
      for (const c of candidates) {
        if (c.videoId) {
          decisions[c.videoId] = {
            videoId: c.videoId,
            decision: "ALLOW",
            reason: "YouTube Guard inactive",
          };
        }
      }
      sendResponse({ success: true, decisions });
      return true;
    }

    const decisions = {};
    const uncachedCandidates = [];

    for (const c of candidates) {
      if (!c.videoId) continue;
      if (youtubeGuardState.approvedVideoIds.has(c.videoId)) {
        decisions[c.videoId] = {
          videoId: c.videoId,
          decision: "ALLOW",
          alreadyApproved: true,
          reason: "Previously approved study video",
        };
        continue;
      }
      const cached = youtubeClassificationCache.get(c.videoId);
      if (cached && Date.now() - (cached.cachedAt || 0) < 3600_000) {
        decisions[c.videoId] = cached;
        if (isStudyAllowedDecision(cached.decision)) {
          YouTubeStudyGuardManager.approveVideo(c.videoId, cached);
        }
      } else {
        uncachedCandidates.push({
          videoId: c.videoId,
          title: c.title || "",
          channelName: c.channelName || "",
          description: c.description || "",
          durationSeconds: Number(c.durationSeconds || 0),
        });
      }
    }

    if (uncachedCandidates.length === 0) {
      sendResponse({ success: true, decisions });
      return true;
    }

    chrome.storage.local.get(["focusforge_webapp_origin"], (res) => {
      const origin = res?.focusforge_webapp_origin || "http://localhost:3000";
      const payload = {
        candidates: uncachedCandidates.slice(0, 25).map((cand) => ({
          ...cand,
          userId: authenticatedUserId,
          activeSessionSubject: extensionState.activeSubject,
          activeSessionChapter: extensionState.activeChapter,
          guardMode: youtubeGuardState.mode,
        })),
        userId: authenticatedUserId,
      };

      fetch(`${origin}/api/youtube/classify`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      })
        .then((r) => r.json())
        .then((data) => {
          if (data && data.success && Array.isArray(data.results)) {
            data.results.forEach((resItem) => {
              if (resItem.videoId) {
                youtubeClassificationCache.set(resItem.videoId, { ...resItem, cachedAt: Date.now() });
                decisions[resItem.videoId] = resItem;
                if (isStudyAllowedDecision(resItem.decision)) {
                  YouTubeStudyGuardManager.approveVideo(resItem.videoId, resItem);
                }
              }
            });
          } else {
            uncachedCandidates.forEach((cand) => {
              const fallback = runLocalFallbackClassification(cand);
              youtubeClassificationCache.set(cand.videoId, { ...fallback, cachedAt: Date.now() });
              decisions[cand.videoId] = fallback;
              if (isStudyAllowedDecision(fallback.decision)) {
                YouTubeStudyGuardManager.approveVideo(cand.videoId, fallback);
              }
            });
          }
          sendResponse({ success: true, decisions });
        })
        .catch((err) => {
          logYouTubeGuard("Prefetch", "Batch fetch error, using local fallback:", err);
          uncachedCandidates.forEach((cand) => {
            const fallback = runLocalFallbackClassification(cand);
            youtubeClassificationCache.set(cand.videoId, { ...fallback, cachedAt: Date.now() });
            decisions[cand.videoId] = fallback;
            if (isStudyAllowedDecision(fallback.decision)) {
              YouTubeStudyGuardManager.approveVideo(cand.videoId, fallback);
            }
          });
          sendResponse({ success: true, decisions });
        });
    });
    return true;
  }

  // Handle immediate pre-navigation click verification
  if (message.type === "CHECK_OR_CLASSIFY_CLICK") {
    const videoId = message.videoId;
    const token = message.navigationToken;
    if (!videoId) {
      sendResponse({ success: false, error: "Missing videoId", navigationToken: token });
      return true;
    }

    if (!isYouTubeGuardActive()) {
      sendResponse({
        success: true,
        decision: "ALLOW",
        videoId,
        navigationToken: token,
        reason: "YouTube Guard inactive",
      });
      return true;
    }

    if (youtubeGuardState.approvedVideoIds.has(videoId)) {
      sendResponse({
        success: true,
        decision: "ALLOW",
        videoId,
        navigationToken: token,
        alreadyApproved: true,
      });
      return true;
    }

    const cached = youtubeClassificationCache.get(videoId);
    if (cached && Date.now() - (cached.cachedAt || 0) < 3600_000) {
      if (isStudyAllowedDecision(cached.decision)) {
        YouTubeStudyGuardManager.approveVideo(videoId, cached);
      }
      sendResponse({
        success: true,
        decision: cached.decision,
        videoId,
        navigationToken: token,
        result: cached,
      });
      return true;
    }

    chrome.storage.local.get(["focusforge_webapp_origin"], (res) => {
      const origin = res?.focusforge_webapp_origin || "http://localhost:3000";
      const payload = {
        videoId,
        title: message.title || "",
        channelName: message.channelName || "",
        description: message.description || "",
        durationSeconds: Number(message.durationSeconds || 0),
        userId: authenticatedUserId,
        activeSessionSubject: extensionState.activeSubject,
        activeSessionChapter: extensionState.activeChapter,
        guardMode: youtubeGuardState.mode,
      };

      fetch(`${origin}/api/youtube/classify`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      })
        .then((r) => r.json())
        .then((data) => {
          const result = data?.result || runLocalFallbackClassification(payload);
          youtubeClassificationCache.set(videoId, { ...result, cachedAt: Date.now() });
          if (isStudyAllowedDecision(result.decision)) {
            YouTubeStudyGuardManager.approveVideo(videoId, result);
          }
          sendResponse({
            success: true,
            decision: result.decision,
            videoId,
            navigationToken: token,
            result,
          });
        })
        .catch((err) => {
          logYouTubeGuard("ClickClassify", "Error, using local fallback:", err);
          const fallback = runLocalFallbackClassification(payload);
          youtubeClassificationCache.set(videoId, { ...fallback, cachedAt: Date.now() });
          if (isStudyAllowedDecision(fallback.decision)) {
            YouTubeStudyGuardManager.approveVideo(videoId, fallback);
          }
          sendResponse({
            success: true,
            decision: fallback.decision,
            videoId,
            navigationToken: token,
            result: fallback,
          });
        });
    });
    return true;
  }
});

// ----------------------------------------------------
// YouTube SPA Navigation Listener (Layer 1 + Layer 3 Bridge)
// ----------------------------------------------------
if (chrome.webNavigation?.onHistoryStateUpdated) {
  chrome.webNavigation.onHistoryStateUpdated.addListener(
    async (details) => {
      if (details.frameId !== 0) return;
      if (!details.url || !details.url.includes("youtube.com")) return;
      if (!shouldEnableYouTubeGuard()) return;

      try {
        const url = new URL(details.url);
        const pathname = url.pathname;
        const redirectUrl = chrome.runtime.getURL("block-page/index.html");

        // 1. Shorts Restriction: Block addictive short-form content during active study
        if (pathname.startsWith("/shorts")) {
          logYouTubeGuard("SPA", "Blocked shorts SPA navigation");
          chrome.tabs.update(details.tabId, { url: `${redirectUrl}?domain=youtube.com&reason=shorts` });
          return;
        }

        // Note: YouTube Home ("/"), Search ("/results"), Channels, and Playlists remain accessible
        // for students to search and discover study lectures. Content-level access is gated at /watch.

        // 2. /watch SPA navigation check:
        // If the destination video does not have an approved Focus Pass, intercept and redirect to gateway!
        if (pathname === "/watch") {
          const videoId = url.searchParams.get("v");
          logYouTubeGuard("SPA", `Watch SPA navigation to videoId: ${videoId}`);

          if (videoId && !FocusPassManager.hasValidPass(videoId) && !youtubeGuardState.approvedVideoIds.has(videoId)) {
            logYouTubeGuard("SPA", `Unverified SPA navigation deflected to Gateway: ${videoId}`);
            const verifyUrl = `${chrome.runtime.getURL("youtube-verify.html")}?targetUrl=${encodeURIComponent(details.url)}&v=${videoId}`;
            chrome.tabs.update(details.tabId, { url: verifyUrl });
            return;
          }

          logYouTubeDiagnostic({
            session: "ACTIVE",
            videoId,
            state: "VERIFIED",
            event: "SPA_NAVIGATION",
            playback: "PLAYING",
          });
          chrome.tabs.sendMessage(details.tabId, {
            type: "FF_YOUTUBE_NAVIGATED",
            url: details.url,
            videoId,
          }).catch(() => {});
        }
      } catch (err) {
        logYouTubeGuard("SPA", "Error in onHistoryStateUpdated:", err);
      }
    },
    { url: [{ hostContains: "youtube.com" }] }
  );
}

// ----------------------------------------------------
// Periodic Alarms & Service Worker Lifecycle
// ----------------------------------------------------

chrome.alarms?.create("focusforge_heartbeat", { periodInMinutes: 1 });

chrome.alarms?.onAlarm.addListener((alarm) => {
  if (alarm.name === "focusforge_heartbeat") {
    sendPresenceHeartbeat();
    flushTelemetryOutbox();

    // Maintain YouTube Guard active session lease & DNR rule consistency
    if (shouldEnableYouTubeGuard()) {
      youtubeGuardState.leaseUntil = Date.now() + 120_000;
      YouTubeStudyGuardManager.reconcileState("HEARTBEAT_ALARM");
    } else {
      if (youtubeGuardState.status !== "OFF") {
        YouTubeStudyGuardManager.reconcileState("HEARTBEAT_EXPIRED");
      }
    }

    if (extensionState.isFocusActive) {
      extensionState.timeLeftSeconds = computeTimeLeft();
      updateBadge();

      // Check if session has naturally reached 0 seconds
      if (extensionState.timeLeftSeconds <= 0 && authenticatedUserId && extensionState.sessionStatus !== "paused") {
        reconcileWithCloud(authenticatedUserId, "ALARM_TIMER_ELAPSED");
      }
    } else {
      // Defensive Safety Invariant: Ensure 0 rules if not in active study
      BlockerManager.getExistingRuleIds().then(({ session, dynamic }) => {
        if (session.length > 0 || dynamic.length > 0) {
          console.warn("[FocusForge Alarm] Leftover DNR rules detected while inactive. Purging.");
          BlockerManager.clearAllRules();
        }
      });
    }
  }
});

// Service Worker Startup & Hydration
chrome.storage.local.get(
  [
    "installation_id",
    "supabase_auth_session",
    "focusforge_state",
    "focusforge_tracking",
    "focusforge_temp_allows",
    "focusforge_active_exceptions",
    "focusforge_telemetry_outbox",
  ],
  (res) => {
    // 1. Installation ID (UUID)
    if (res.installation_id) {
      installationId = res.installation_id;
    } else {
      installationId = generateUUID();
      chrome.storage.local.set({ installation_id: installationId });
    }

    // 2. Hydrate in-memory state
    if (res.focusforge_state) {
      extensionState = { ...extensionState, ...res.focusforge_state };
      // Safety: On fresh wake, if session was stored as active, verify if clock time expired
      if (extensionState.isFocusActive && extensionState.startTime && extensionState.plannedDurationMinutes) {
        const startMs = new Date(extensionState.startTime).getTime();
        const plannedMs = extensionState.plannedDurationMinutes * 60 * 1000;
        if (!isNaN(startMs) && Date.now() > startMs + plannedMs && extensionState.sessionStatus !== "paused") {
          console.log("[FocusForge Startup] Stored active session has elapsed. Setting inactive on wake.");
          extensionState.isFocusActive = false;
          extensionState.sessionStatus = "idle";
          extensionState.activeSessionId = null;
        }
      }
      // Safety: On fresh wake, mark as syncing and verify against authoritative cloud
      extensionState.syncStatus = "SYNCING";
      updateBadge();
    }

    if (res.focusforge_temp_allows) {
      temporaryAllowState = res.focusforge_temp_allows;
    }

    if (Array.isArray(res.focusforge_active_exceptions)) {
      activeTemporaryExceptions = res.focusforge_active_exceptions;
    }

    if (Array.isArray(res.focusforge_telemetry_outbox)) {
      telemetryOutbox = res.focusforge_telemetry_outbox;
    }

    // 3. Restore active tracking
    if (res.focusforge_tracking && res.focusforge_tracking.domain) {
      activeTracking = {
        ...activeTracking,
        ...res.focusforge_tracking,
        lastFocusMs: Date.now(),
      };
    }

    // 4. Authenticate Supabase client and reconcile state
    const session = res.supabase_auth_session;
    if (session && session.access_token && session.user?.id) {
      authenticatedUserId = session.user.id;
      extensionState.userId = session.user.id;

      if (supabaseClient) {
        supabaseClient.auth
          .setSession({
            access_token: session.access_token,
            refresh_token: session.refresh_token,
          })
          .then(() => {
            setupRealtimeSubscriptions(authenticatedUserId, session.access_token);
            reconcileWithCloud(authenticatedUserId);
          })
          .catch((e) => {
            console.warn("[FocusForge Auth] setSession failed on startup:", e);
            // Fallback: if session was past its planned end time, ensure it does not stay blocked offline
            if (extensionState.startTime && extensionState.plannedDurationMinutes) {
              const startMs = new Date(extensionState.startTime).getTime();
              const plannedMs = extensionState.plannedDurationMinutes * 60 * 1000;
              if (Date.now() > startMs + plannedMs) {
                cleanupTerminalSession("OFFLINE_SESSION_EXPIRED");
              }
            }
          });
      }
    } else {
      extensionState.syncStatus = "AUTHENTICATION_REQUIRED";
      updateDerivedStatus();
      BlockerManager.clearAllRules();
    }
  }
);
