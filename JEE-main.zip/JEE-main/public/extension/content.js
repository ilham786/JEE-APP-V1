// FocusForge Content Script (Manifest V3)
// Clean Web-to-Extension Bridge & Fallback In-Page Focus Shield
// Note: All actual distraction duration tracking is handled centrally by background.js

(function () {
  function cleanDomain(input) {
    if (!input) return "";
    return input
      .toLowerCase()
      .replace(/^https?:\/\//, "")
      .replace(/^(\*\.|\.)/, "")
      .split("/")[0]
      .split(":")[0]
      .trim();
  }

  function isDomainMatch(hostname, ruleDomain) {
    const h = cleanDomain(hostname);
    const r = cleanDomain(ruleDomain);
    if (!h || !r) return false;
    return h === r || h.endsWith("." + r);
  }

  function checkIsFocusForgeHost() {
    const hostname = (window.location.hostname || "").toLowerCase();
    if (
      hostname === "localhost" ||
      hostname === "127.0.0.1" ||
      hostname.includes("focusforge") ||
      hostname.includes("jee-made-easy") ||
      hostname === "jee-made-easy-by-ilham.vercel.app" ||
      (hostname.endsWith(".vercel.app") && hostname.includes("ilham"))
    ) {
      return true;
    }
    try {
      if (
        document.querySelector('meta[name="focusforge-app"]') !== null ||
        document.querySelector('meta[name="application-name"]')?.getAttribute("content") === "FocusForge"
      ) {
        return true;
      }
    } catch {}
    return false;
  }

  const isFocusForgeHost = checkIsFocusForgeHost();

  // ----------------------------------------------------
  // 1. FocusForge Web App Communication Bridge
  // ----------------------------------------------------
  if (isFocusForgeHost) {
    // Notify background service worker of the active FocusForge web app origin
    try {
      chrome.runtime.sendMessage({
        type: "FOCUSFORGE_REGISTER_WEBAPP_ORIGIN",
        origin: window.location.origin,
        hostname: window.location.hostname,
      });
    } catch {}

    // Tag the DOM so in-page React/scripts instantly recognize the companion extension
    function tagExtensionPresence() {
      try {
        if (document.documentElement) {
          document.documentElement.setAttribute("data-focusforge-extension", "1.2.0");
        }
      } catch {}
    }
    tagExtensionPresence();

    // Handshake: Announce extension presence and request active auth session from web application
    function sendHandshake() {
      tagExtensionPresence();
      window.postMessage(
        {
          type: "FOCUSFORGE_EXTENSION_PONG",
          version: "1.2.0",
          connected: true,
          origin: window.location.origin,
        },
        "*"
      );
      window.postMessage({ type: "FOCUSFORGE_REQUEST_AUTH_SESSION" }, "*");
    }

    // Fire immediately at document_start
    sendHandshake();

    // Retries to ensure React has fully mounted and registered listeners
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", sendHandshake);
    }
    window.addEventListener("load", sendHandshake);
    setTimeout(sendHandshake, 500);
    setTimeout(sendHandshake, 1500);
    setTimeout(sendHandshake, 3000);

    // Listen for events from FocusForge web app
    window.addEventListener("message", (event) => {
      if (event.source !== window || !event.data) return;
      const data = event.data;

      if (data.type === "FOCUSFORGE_PING_EXTENSION") {
        sendHandshake();
      } else if (data.type === "FOCUSFORGE_AUTH_SESSION") {
        try {
          chrome.runtime.sendMessage({
            type: "FOCUSFORGE_SET_AUTH_SESSION",
            session: data.session,
          });
        } catch {}
      } else if (data.type === "FOCUSFORGE_AUTH_LOGOUT" || data.type === "FOCUSFORGE_LOGOUT") {
        try {
          chrome.runtime.sendMessage({ type: "FOCUSFORGE_LOGOUT" });
        } catch {}
      } else if (data.type === "FOCUSFORGE_SYNC") {
        try {
          chrome.runtime.sendMessage(data);
        } catch {}
      }
    });

    // Relay messages from background worker to the web page if needed
    try {
      chrome.runtime.onMessage.addListener((msg) => {
        if (msg && (msg.type === "FOCUSFORGE_DISTRACTION_LOGGED" || msg.type === "FOCUSFORGE_WASTE_TIME_UPDATE")) {
          window.postMessage(msg, "*");
        }
      });

      // Relay live distraction / break tracking to web page in real time
      chrome.storage.onChanged.addListener((changes, area) => {
        if (area === "local" && changes.focusforge_live_tracking) {
          window.postMessage(
            {
              type: "FOCUSFORGE_LIVE_TRACKING",
              data: changes.focusforge_live_tracking.newValue || null,
            },
            "*"
          );
        }
      });

      chrome.storage.local.get(["focusforge_live_tracking"], (res) => {
        if (res?.focusforge_live_tracking) {
          window.postMessage(
            {
              type: "FOCUSFORGE_LIVE_TRACKING",
              data: res.focusforge_live_tracking,
            },
            "*"
          );
        }
      });
    } catch {}
  }

  // ----------------------------------------------------
  // 2. Active In-Page Overlay Removal & Teardown
  // Ensures #focusforge-block-overlay is completely removed from the DOM
  // (All site blocking is handled natively by Chrome Declarative Net Request via block-page/index.html & pause-guard.html)
  // ----------------------------------------------------
  function purgeBlockOverlay() {
    try {
      const existing = document.getElementById("focusforge-block-overlay");
      if (existing) {
        existing.remove();
      }
    } catch {}
  }

  // Purge immediately at script execution
  purgeBlockOverlay();

  // Purge on DOMContentLoaded and readyState changes
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", purgeBlockOverlay);
  }

  // Also purge on window load
  window.addEventListener("load", purgeBlockOverlay);

  // Listen for explicit overlay teardown messages from the service worker
  try {
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg && msg.type === "REMOVE_BLOCK_OVERLAY") {
        purgeBlockOverlay();
      }
    });
  } catch {}

  // ----------------------------------------------------
  // 3. YouTube Study Content Guard
  // Authoritative implementation is isolated in youtube-study-controller.js (Manifest V3)
  // ----------------------------------------------------
})();

