document.addEventListener("DOMContentLoaded", () => {
  const syncBadge = document.getElementById("sync-badge");
  const syncText = document.getElementById("sync-text");
  const unauthBanner = document.getElementById("unauth-banner");
  const focusCard = document.getElementById("focus-card");
  const focusSubject = document.getElementById("focus-subject");
  const focusTimer = document.getElementById("focus-timer");
  const focusGoal = document.getElementById("focus-goal");
  const statusPill = document.getElementById("status-pill");
  const progressBar = document.getElementById("progress-bar");
  const modeBadge = document.getElementById("mode-badge");

  const statFocus = document.getElementById("stat-focus");
  const statDistract = document.getElementById("stat-distract");
  const statBlocked = document.getElementById("stat-blocked");
  const currentTabText = document.getElementById("current-tab-text");
  const deviceName = document.getElementById("device-name");
  const lastSyncTime = document.getElementById("last-sync-time");

  const ytGuardCard = document.getElementById("yt-guard-card");
  const ytGuardBadge = document.getElementById("yt-guard-badge");
  const ytGuardSubtext = document.getElementById("yt-guard-subtext");
  const ytGuardMeta = document.getElementById("yt-guard-meta");
  const ytGuardMode = document.getElementById("yt-guard-mode");
  const ytGuardTopic = document.getElementById("yt-guard-topic");

  const RING_CIRCUMFERENCE = 408.4; // 2 * Math.PI * 65

  let cachedStatus = null;

  // High-precision accurate remaining seconds calculation in sync with web app
  function computeAccurateRemaining(res) {
    if (!res || !res.isFocusActive || res.sessionStatus === "idle" || res.sessionStatus === "completed" || res.sessionStatus === "abandoned" || res.sessionStatus === "cancelled") {
      return 0;
    }

    // Paused state: time remains static at the exact paused second
    if (res.sessionStatus === "paused") {
      return Math.max(0, res.timeLeftSeconds || 0);
    }

    // High precision sync timestamp calculation (immune to pauses / resume elapsed jumps)
    if (typeof res.timeLeftSeconds === "number" && res.syncTimestamp) {
      const elapsedSinceSync = Math.max(0, Math.floor((Date.now() - res.syncTimestamp) / 1000));
      return Math.max(0, res.timeLeftSeconds - elapsedSinceSync);
    }

    // Fallback: start timestamp derivation
    if (res.startTime && res.plannedDurationMinutes) {
      const startMs = new Date(res.startTime).getTime();
      if (!isNaN(startMs)) {
        const elapsed = Math.max(0, Math.floor((Date.now() - startMs) / 1000));
        const total = res.plannedDurationMinutes * 60;
        return Math.max(0, total - elapsed);
      }
    }

    return Math.max(0, res.timeLeftSeconds || 0);
  }

  // Format seconds to MM:SS or HH:MM:SS
  function formatMMSS(secs) {
    if (secs >= 3600) {
      const hrs = Math.floor(secs / 3600);
      const mins = Math.floor((secs % 3600) / 60);
      const s = secs % 60;
      return `${hrs.toString().padStart(2, "0")}:${mins.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
    }
    const mins = Math.floor(secs / 60);
    const s = secs % 60;
    return `${mins.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
  }

  function formatWasteTime(secs) {
    if (secs >= 60) {
      return `${Math.floor(secs / 60)}m`;
    }
    if (secs > 0) {
      return `${secs}s`;
    }
    return "0m";
  }

  // Render the live UI tick
  function tickUI() {
    if (!cachedStatus) return;
    const res = cachedStatus;

    const isCooling = typeof res.coolingBlockUntil === "number" && res.coolingBlockUntil > Date.now();
    const coolingRemaining = isCooling ? Math.max(0, Math.floor((res.coolingBlockUntil - Date.now()) / 1000)) : 0;

    // 1. Authentic Sync Badge Status
    if (syncBadge && syncText) {
      if (!res.userId) {
        syncBadge.className = "sync-badge disconnected";
        syncText.textContent = "Not Linked";
      } else if (res.syncStatus === "SESSION_ACTIVE" || (res.isFocusActive && res.sessionStatus === "focus")) {
        syncBadge.className = "sync-badge connected";
        syncText.textContent = "Focus Active";
      } else if (res.syncStatus === "SESSION_PAUSED" || (res.isFocusActive && res.sessionStatus === "paused")) {
        syncBadge.className = "sync-badge syncing";
        syncText.textContent = "Paused";
      } else if (res.syncStatus === "SYNCING") {
        syncBadge.className = "sync-badge syncing";
        syncText.textContent = "Syncing";
      } else if (res.syncStatus === "AUTHENTICATING") {
        syncBadge.className = "sync-badge syncing";
        syncText.textContent = "Authenticating";
      } else if (res.syncStatus === "DISCONNECTED") {
        syncBadge.className = "sync-badge disconnected";
        syncText.textContent = "Disconnected";
      } else {
        syncBadge.className = "sync-badge connected";
        syncText.textContent = "Live Connected";
      }
    }

    // 2. Auth Banner
    if (unauthBanner) {
      unauthBanner.style.display = !res.userId ? "block" : "none";
    }

    // 3. Current Tab Inspector
    if (currentTabText) {
      if (res.currentTabDomain) {
        if (res.currentTabBlocked) {
          currentTabText.innerHTML = `<span style="color: #f87171;">🛡️ ${res.currentTabDomain} (BLOCKED)</span>`;
        } else {
          currentTabText.innerHTML = `<span style="color: #38bdf8;">🌐 ${res.currentTabDomain}</span>`;
        }
      } else {
        currentTabText.innerHTML = `<span style="color: #64748b;">Internal Browser Page</span>`;
      }
    }

    // 4. Mode Banner
    if (modeBadge) {
      if (isCooling) {
        modeBadge.style.display = "block";
        modeBadge.style.background = "rgba(6, 182, 212, 0.15)";
        modeBadge.style.color = "#67e8f9";
        modeBadge.style.border = "1px solid rgba(6, 182, 212, 0.4)";
        modeBadge.textContent = `❄️ Cooling Lockdown: ${formatMMSS(coolingRemaining)}`;
      } else if (res.examModeEnabled) {
        modeBadge.style.display = "block";
        modeBadge.style.background = "rgba(239, 68, 68, 0.15)";
        modeBadge.style.color = "#fca5a5";
        modeBadge.style.border = "1px solid rgba(239, 68, 68, 0.4)";
        modeBadge.textContent = `🔒 Exam Mode — Pausing Locked`;
      } else if (res.whitelistOnly) {
        modeBadge.style.display = "block";
        modeBadge.style.background = "rgba(168, 85, 247, 0.15)";
        modeBadge.style.color = "#d8b4fe";
        modeBadge.style.border = "1px solid rgba(168, 85, 247, 0.4)";
        modeBadge.textContent = `🛡️ Whitelist-Only Active`;
      } else {
        modeBadge.style.display = "none";
      }
    }

    // 4b. YouTube Study Content Guard Card State
    if (ytGuardCard && ytGuardBadge && ytGuardSubtext) {
      if (res.isFocusActive && res.sessionStatus === "focus") {
        ytGuardCard.className = "yt-guard-card active";
        ytGuardBadge.className = "yt-guard-badge on";
        ytGuardBadge.textContent = "ON";
        ytGuardSubtext.textContent = "🟢 Only relevant educational content is allowed.";
        if (ytGuardMeta) {
          ytGuardMeta.style.display = "flex";
          if (ytGuardMode) ytGuardMode.textContent = (res.youtubeGuardMode || "BALANCED").toUpperCase();
          if (ytGuardTopic) ytGuardTopic.textContent = `${res.activeSubject || "JEE"} • ${res.activeChapter || "Study"}`;
        }
      } else if (res.isFocusActive && res.sessionStatus === "paused") {
        ytGuardCard.className = "yt-guard-card paused";
        ytGuardBadge.className = "yt-guard-badge paused";
        ytGuardBadge.textContent = "OFF";
        ytGuardSubtext.textContent = "🟡 YouTube is unrestricted while session is paused.";
        if (ytGuardMeta) ytGuardMeta.style.display = "none";
      } else {
        ytGuardCard.className = "yt-guard-card";
        ytGuardBadge.className = "yt-guard-badge off";
        ytGuardBadge.textContent = "OFF";
        ytGuardSubtext.textContent = "⚪ Start a study session to activate Study Guard.";
        if (ytGuardMeta) ytGuardMeta.style.display = "none";
      }
    }

    const isTerminalOrIdle = !res.isFocusActive || res.sessionStatus === "idle" || res.sessionStatus === "completed" || res.sessionStatus === "abandoned" || res.sessionStatus === "cancelled";

    // 5. Focus Session Card & Circular Timer
    if (!isTerminalOrIdle) {
      const remainingSecs = computeAccurateRemaining(res);
      const totalPlanned = Math.max(1, (res.plannedDurationMinutes || 50) * 60);

      if (focusCard) {
        focusCard.classList.remove("inactive");
        if (res.examModeEnabled) {
          focusCard.className = "focus-card exam-mode";
        } else {
          focusCard.className = "focus-card";
        }
      }

      if (focusTimer) {
        focusTimer.textContent = remainingSecs > 0 ? formatMMSS(remainingSecs) : "00:00";
      }

      // Progress Ring Bar Offset & Color
      if (progressBar) {
        const offset = RING_CIRCUMFERENCE * (1 - (remainingSecs / totalPlanned));
        progressBar.style.strokeDashoffset = `${offset}`;

        if (res.sessionStatus === "paused") {
          progressBar.style.stroke = "#f59e0b";
        } else if (res.examModeEnabled) {
          progressBar.style.stroke = "#ef4444";
        } else {
          progressBar.style.stroke = "#8b5cf6";
        }
      }

      // Status Pill
      if (statusPill) {
        if (res.sessionStatus === "paused") {
          statusPill.className = "status-pill paused";
          statusPill.textContent = "⏸ PAUSED";
        } else if (res.examModeEnabled) {
          statusPill.className = "status-pill exam";
          statusPill.textContent = "🔒 EXAM LOCK";
        } else {
          statusPill.className = "status-pill focus";
          statusPill.textContent = `● ${res.activeSessionMode || "FOCUS"}`;
        }
      }

      // Subject Badge
      if (focusSubject) {
        const subj = res.activeSubject || "Focus Zone";
        const chap = res.activeChapter && res.activeChapter !== "Idle" ? ` • ${res.activeChapter}` : "";
        focusSubject.textContent = `${subj}${chap}`;

        const lowerSubj = subj.toLowerCase();
        if (lowerSubj.includes("phys")) {
          focusSubject.className = "focus-subject-tag physics";
        } else if (lowerSubj.includes("chem")) {
          focusSubject.className = "focus-subject-tag chemistry";
        } else if (lowerSubj.includes("math")) {
          focusSubject.className = "focus-subject-tag maths";
        } else {
          focusSubject.className = "focus-subject-tag";
        }
      }

      // Goal Description
      if (focusGoal) {
        focusGoal.textContent = res.activeGoal || "Focus Zone in progress";
      }

    } else if (isCooling) {
      if (focusCard) {
        focusCard.className = "focus-card cooling-mode";
      }
      if (focusTimer) {
        focusTimer.textContent = formatMMSS(coolingRemaining);
      }
      if (progressBar) {
        const totalCooling = 5 * 60;
        const offset = RING_CIRCUMFERENCE * (1 - (coolingRemaining / totalCooling));
        progressBar.style.strokeDashoffset = `${offset}`;
        progressBar.style.stroke = "#06b6d4";
      }
      if (statusPill) {
        statusPill.className = "status-pill cooling";
        statusPill.textContent = "❄️ COOLING LOCK";
      }
      if (focusSubject) {
        focusSubject.className = "focus-subject-tag physics";
        focusSubject.textContent = "Emergency Penalty";
      }
      if (focusGoal) {
        focusGoal.textContent = "Take a breath before resuming study";
      }

    } else {
      if (focusCard) {
        focusCard.className = "focus-card inactive";
      }
      if (focusTimer) {
        focusTimer.textContent = "00:00";
      }
      if (progressBar) {
        progressBar.style.strokeDashoffset = `${RING_CIRCUMFERENCE}`;
        progressBar.style.stroke = "#8b5cf6";
      }
      if (statusPill) {
        statusPill.className = "status-pill idle";
        statusPill.textContent = "SHIELD READY";
      }
      if (focusSubject) {
        focusSubject.className = "focus-subject-tag";
        focusSubject.textContent = "No Active Session";
      }
      if (focusGoal) {
        focusGoal.textContent = "Start a focus zone in the web workspace";
      }
    }

    // 5.1 Pause Guard Banner
    const pauseGuardBanner = document.getElementById("pause-guard-banner");
    const pauseAllowedBox = document.getElementById("pause-allowed-box");
    if (pauseGuardBanner) {
      if (res.isFocusActive && res.sessionStatus === "paused") {
        pauseGuardBanner.style.display = "block";
        const tempDomains = res.temporaryAllows?.domains || [];
        if (tempDomains.length > 0 && pauseAllowedBox) {
          pauseAllowedBox.style.display = "block";
          pauseAllowedBox.textContent = `Allowed for break: ${tempDomains.join(", ")}`;
        } else if (pauseAllowedBox) {
          pauseAllowedBox.style.display = "none";
        }
      } else {
        pauseGuardBanner.style.display = "none";
      }
    }

    // 5.2 Live Active Tab Distraction / Break Ticker
    const liveBanner = document.getElementById("live-distraction-banner");
    const liveText = document.getElementById("live-distraction-text");
    const liveTimer = document.getElementById("live-distraction-timer");
    const liveDot = document.getElementById("live-distraction-dot");

    try {
      chrome.storage.local.get(["focusforge_live_tracking"], (s) => {
        const lt = s?.focusforge_live_tracking;
        if (lt && lt.domain && typeof lt.elapsedSeconds === "number" && !isTerminalOrIdle) {
          if (liveBanner) liveBanner.style.display = "flex";
          const isBreak = lt.activityType === "pause_break";
          if (liveDot) liveDot.style.background = isBreak ? "#f59e0b" : "#ef4444";
          if (liveText) {
            liveText.style.color = isBreak ? "#fde68a" : "#fca5a5";
            liveText.textContent = isBreak ? `Break: ${lt.domain}` : `Distraction: ${lt.domain}`;
          }
          if (liveTimer) {
            liveTimer.textContent = formatMMSS(lt.elapsedSeconds);
          }
        } else {
          if (liveBanner) liveBanner.style.display = "none";
        }
      });
    } catch {}

    // 6. Metrics Strip
    const wasteSecs = typeof res.todayWasteTimeSeconds === "number"
      ? res.todayWasteTimeSeconds
      : ((res.todayDistractionMinutes || 0) * 60);

    if (statFocus) statFocus.textContent = `${res.todayFocusMinutes || 0}m`;
    if (statDistract) statDistract.textContent = formatWasteTime(wasteSecs);
    if (statBlocked) {
      statBlocked.textContent = (!isTerminalOrIdle && res.isFocusActive)
        ? `${(res.blockedDomains || []).length}`
        : "0 (Idle)";
    }
    if (deviceName) deviceName.textContent = res.deviceInfo || "Chrome Desktop";

    // 7. Render Interceptions & Distractions Feed
    const distractList = document.getElementById("distraction-list");
    const distractBadge = document.getElementById("distraction-badge");
    if (distractBadge) {
      distractBadge.textContent = `${Math.floor(wasteSecs / 60)}m WASTED`;
    }
    if (distractList) {
      const recents = Array.isArray(res.recentDistractions) ? res.recentDistractions : [];
      if (recents.length === 0) {
        distractList.innerHTML = `<div class="distraction-empty">🛡️ Zero focus leaks today • Shield active</div>`;
      } else {
        distractList.innerHTML = recents
          .slice(0, 5)
          .map((d) => {
            const t = new Date(d.timestamp);
            const timeStr = !isNaN(t.getTime())
              ? t.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: true })
              : "Just now";
            const dur = d.durationSeconds || d.duration_seconds
              ? Math.max(1, Math.round((d.durationSeconds || d.duration_seconds) / 60))
              : (d.durationMinutes || 1);
            const badgeIcon = d.blocked ? "🛡️ Blocked" : `⏳ ${dur}m spent`;
            return `
              <div class="distraction-item">
                <span class="distraction-domain">${badgeIcon} • ${d.domain}</span>
                <span class="distraction-time">${timeStr}</span>
              </div>
            `;
          })
          .join("");
      }
    }

    if (lastSyncTime) {
      if (res.lastSync) {
        const timeStr = new Date(res.lastSync).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
        lastSyncTime.textContent = `Sync: ${timeStr}`;
      } else {
        lastSyncTime.textContent = "Sync: Ready";
      }
    }

    // 8. Live System Telemetry Drawer
    const dbgState = document.getElementById("dbg-state");
    const dbgUser = document.getElementById("dbg-user");
    const dbgRealtime = document.getElementById("dbg-realtime");
    const dbgRules = document.getElementById("dbg-rules");
    const dbgSession = document.getElementById("dbg-session");
    const dbgInstall = document.getElementById("dbg-install");

    if (dbgState) dbgState.textContent = res.syncStatus || "DISCONNECTED";
    if (dbgUser) dbgUser.textContent = res.userId || "None (Unauthenticated)";
    if (dbgRealtime) {
      dbgRealtime.textContent = res.realtimeConnected ? "CONNECTED" : "DISCONNECTED";
      dbgRealtime.style.color = res.realtimeConnected ? "#34d399" : "#f87171";
    }
    if (dbgRules) dbgRules.textContent = `${res.rulesCount || res.activeRuleCount || 0} active`;
    if (dbgSession) dbgSession.textContent = res.activeSessionId ? `${res.activeSessionId} (${res.sessionStatus})` : "None";
    if (dbgInstall) dbgInstall.textContent = res.installationId || "Unknown";

    // 9. YouTube Content Gateway Diagnostics
    const dbgFwStatus = document.getElementById("dbg-fw-status");
    const dbgFwGate = document.getElementById("dbg-fw-gate");
    const dbgGatewayStatus = document.getElementById("dbg-gateway-status");
    const dbgFocusPasses = document.getElementById("dbg-focus-passes");
    const dbgFwApproved = document.getElementById("dbg-fw-approved");
    const dbgFwMode = document.getElementById("dbg-fw-mode");
    const dbgFwClassifier = document.getElementById("dbg-fw-classifier");

    const isGuardActive = res.isFocusActive && res.sessionStatus === "focus";
    if (dbgFwStatus) {
      dbgFwStatus.textContent = isGuardActive ? "ARMED — STUDY CONTENT ONLY" : "STANDBY (NORMAL YOUTUBE)";
      dbgFwStatus.style.color = isGuardActive ? "#34d399" : "#94a3b8";
    }
    if (dbgFwGate) {
      dbgFwGate.textContent = isGuardActive ? "Pre-Navigation Intercept Active" : "Standby";
      dbgFwGate.style.color = isGuardActive ? "#38bdf8" : "#94a3b8";
    }
    if (dbgGatewayStatus) {
      dbgGatewayStatus.textContent = isGuardActive ? "DNR Video Gateway Armed (P100/P10)" : "Inactive";
      dbgGatewayStatus.style.color = isGuardActive ? "#fbbf24" : "#94a3b8";
    }
    if (dbgFocusPasses) {
      dbgFocusPasses.textContent = `${res.focusPassCount || res.approvedVideosCount || 0} active`;
    }
    if (dbgFwApproved) {
      dbgFwApproved.textContent = `${res.approvedVideosCount || 0} verified`;
    }
    if (dbgFwMode) {
      dbgFwMode.textContent = (res.youtubeGuardMode || "STRICT").toUpperCase();
    }
    if (dbgFwClassifier) {
      dbgFwClassifier.textContent = "ONLINE";
      dbgFwClassifier.style.color = "#34d399";
    }
  }

  // Fetch status from service worker
  function fetchStatus() {
    chrome.runtime.sendMessage({ type: "GET_EXTENSION_STATUS" }, (res) => {
      if (chrome.runtime.lastError || !res) {
        if (syncBadge && syncText) {
          syncBadge.className = "sync-badge disconnected";
          syncText.textContent = "Disconnected";
        }
        return;
      }
      cachedStatus = res;
      tickUI();
    });
  }

  function openAppUrl(path) {
    chrome.storage?.local?.get(["focusforge_webapp_origin"], (res) => {
      const baseOrigin = res?.focusforge_webapp_origin || "https://jee-made-easy-by-ilham.vercel.app";
      const targetUrl = `${baseOrigin}${path}`;
      chrome.tabs.query({}, (tabs) => {
        const existingTab = tabs.find(
          (t) =>
            t.url &&
            (t.url.includes("jee-made-easy-by-ilham.vercel.app") ||
              t.url.includes("focusforge") ||
              t.url.includes("localhost:3000") ||
              t.url.includes("127.0.0.1:3000"))
        );
        if (existingTab && existingTab.id) {
          chrome.tabs.update(existingTab.id, { active: true, url: targetUrl });
        } else {
          chrome.tabs.create({ url: targetUrl });
        }
      });
    });
  }

  // Initial fetch and start intervals
  fetchStatus();
  const pollInterval = setInterval(fetchStatus, 2000); // Poll background every 2s
  const tickInterval = setInterval(tickUI, 500); // Live countdown tick every 500ms

  // Instant reactivity to storage updates
  const storageListener = (changes, area) => {
    if (area === "local") {
      if (changes.focusforge_state && changes.focusforge_state.newValue) {
        cachedStatus = { ...cachedStatus, ...changes.focusforge_state.newValue };
        tickUI();
      }
    }
  };
  chrome.storage?.onChanged?.addListener(storageListener);

  // Button Listeners
  document.getElementById("open-app-btn")?.addEventListener("click", () => {
    openAppUrl("/study");
  });

  document.getElementById("dashboard-btn")?.addEventListener("click", () => {
    openAppUrl("/dashboard");
  });

  document.getElementById("open-settings-btn")?.addEventListener("click", () => {
    openAppUrl("/blocker");
  });

  document.getElementById("sync-now-btn")?.addEventListener("click", () => {
    if (syncBadge && syncText) {
      syncBadge.className = "sync-badge syncing";
      syncText.textContent = "Syncing";
    }
    chrome.runtime.sendMessage({ type: "FORCE_SYNC" }, (res) => {
      if (res) cachedStatus = res;
      tickUI();
    });
  });

  window.addEventListener("unload", () => {
    clearInterval(pollInterval);
    clearInterval(tickInterval);
    chrome.storage?.onChanged?.removeListener(storageListener);
  });
});
