// FocusForge — Authoritative YouTube Study Content Guard Controller
// Manifest V3 Content Script for https://*.youtube.com/*
// Architecture: NAVIGATION FIREWALL (Pre-Navigation Click Interception + Priority Queue Pre-Verification + Current Video Immunity)

(function () {
  "use strict";

  // Prevent multiple controller instances in the same frame
  if (window.__FF_YT_CONTROLLER_INITIALIZED__) return;
  window.__FF_YT_CONTROLLER_INITIALIZED__ = true;

  // ====================================================================
  // 1. Explicit State Machine & Global Controller Context
  // ====================================================================
  const STATES = {
    OFF: "OFF",                             // Guard dormant: normal YouTube (no active study session)
    STARTING: "STARTING",                   // Establishing sync with background service worker
    ARMED: "ARMED",                         // Verified study session active: firewall & pre-verification active
    VERIFYING_DESTINATION: "VERIFYING_DESTINATION", // Clicked link actively undergoing CRITICAL classification
    ALLOWING: "ALLOWING",                   // Approved destination navigating
    BLOCKING: "BLOCKING",                   // Destination blocked: current lecture uninterrupted, toast shown
    ERROR: "ERROR",                         // Error state
  };

  let currentState = STATES.OFF;
  let currentVideoId = null;
  let isCurrentVideoImmune = false;

  let activeSession = {
    isActive: false,
    status: "idle", // 'focus' | 'paused' | 'idle'
    sessionId: null,
    verifiedSessionId: null,
    leaseUntil: null,
    mode: "strict", // 'strict' | 'balanced' | 'custom'
    subject: "",
    chapter: "",
    exam: "JEE",
    approvedVideoIds: new Set(),
  };

  // Approved Navigation Token & Latest-Click-Wins Token
  let approvedNavigationToken = null;
  let activeClickToken = null;

  // Study Watch Ticker
  let watchTicker = null;
  let videoWatchSeconds = 0;
  let pausedByGuard = false;

  // Diagnostic metrics
  const diagnosticsData = {
    cacheHits: 0,
    cacheMisses: 0,
    totalClicksIntercepted: 0,
    totalBlocksDeflected: 0,
    totalAllowsPermitted: 0,
    lastNavigation: null,
  };

  // Local Decision Cache: videoId -> { videoId, decision: 'ALLOW'|'BLOCK'|'REVIEW', confidence, reason, subject, chapter, topic, verifiedAt, expiresAt }
  const localDecisionCache = new Map();

  const DEBUG = true;
  function logDiagnostic(event, details = {}) {
    if (!DEBUG) return;
    const parts = [`[FF][YT]`, event];
    for (const [k, v] of Object.entries(details)) {
      parts.push(`${k}=${v}`);
    }
    console.log(parts.join(" "));
  }

  // ====================================================================
  // 2. Session Gate Invariant: isStudyGuardActive()
  // ====================================================================
  function isStudyGuardActive() {
    const isAuth = Boolean(activeSession.isActive);
    const isFocus = activeSession.status === "focus" || activeSession.status === "active";
    const hasSession = Boolean(activeSession.sessionId);
    const isVerified = hasSession && Boolean(activeSession.verifiedSessionId) && activeSession.sessionId === activeSession.verifiedSessionId;
    const validLease = activeSession.leaseUntil ? Date.now() < activeSession.leaseUntil : false;

    return isAuth && isFocus && hasSession && isVerified && validLease;
  }

  // ====================================================================
  // 3. Robust YouTube Video ID Extraction
  // ====================================================================
  function extractYouTubeVideoId(urlOrStr) {
    if (!urlOrStr) return null;
    try {
      const cleanStr = String(urlOrStr).trim();
      // Raw 11-character video ID
      if (/^[a-zA-Z0-9_-]{11}$/.test(cleanStr)) {
        return cleanStr;
      }
      const parsed = new URL(cleanStr, window.location.origin);
      // /watch?v=VIDEO_ID
      if (parsed.pathname === "/watch") {
        const v = parsed.searchParams.get("v");
        if (v && /^[a-zA-Z0-9_-]{11}$/.test(v)) return v;
      }
      // /v/VIDEO_ID or /embed/VIDEO_ID
      const embedMatch = parsed.pathname.match(/^\/(?:v|embed)\/([a-zA-Z0-9_-]{11})/);
      if (embedMatch) return embedMatch[1];
      // /shorts/VIDEO_ID
      if (parsed.pathname.startsWith("/shorts/")) {
        const sid = parsed.pathname.replace("/shorts/", "").split("/")[0].split("?")[0];
        if (sid && /^[a-zA-Z0-9_-]{11}$/.test(sid)) return sid;
      }
      // youtu.be/VIDEO_ID
      if (parsed.hostname === "youtu.be" || parsed.hostname.endsWith(".youtu.be")) {
        const yid = parsed.pathname.slice(1).split("/")[0].split("?")[0];
        if (yid && /^[a-zA-Z0-9_-]{11}$/.test(yid)) return yid;
      }
    } catch {
      const match = String(urlOrStr).match(/[?&]v=([a-zA-Z0-9_-]{11})/);
      if (match) return match[1];
    }
    return null;
  }

  // ====================================================================
  // 4. UI Injections (Toast, Verifying Micro-Spinner, Level 2 Fallback)
  // ====================================================================
  function injectStyles() {
    if (document.getElementById("focusforge-yt-firewall-styles")) return;
    const style = document.createElement("style");
    style.id = "focusforge-yt-firewall-styles";
    style.textContent = `
      /* Stay in the Zone Block Notification */
      #focusforge-yt-toast {
        position: fixed;
        bottom: 24px;
        right: 24px;
        z-index: 9999999;
        max-width: 440px;
        width: calc(100vw - 48px);
        background: linear-gradient(135deg, rgba(15, 23, 42, 0.96) 0%, rgba(30, 27, 75, 0.96) 100%);
        border: 1px solid rgba(139, 92, 246, 0.5);
        border-radius: 16px;
        box-shadow: 0 20px 40px rgba(0, 0, 0, 0.75), 0 0 30px rgba(139, 92, 246, 0.3);
        backdrop-filter: blur(20px);
        -webkit-backdrop-filter: blur(20px);
        color: #f3f4f6;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        padding: 16px 18px;
        display: flex;
        flex-direction: column;
        gap: 8px;
        user-select: none;
        box-sizing: border-box;
        animation: ffToastSlideIn 0.25s cubic-bezier(0.16, 1, 0.3, 1) forwards;
      }
      @keyframes ffToastSlideIn {
        from { opacity: 0; transform: translateY(16px) scale(0.96); }
        to { opacity: 1; transform: translateY(0) scale(1); }
      }
      @keyframes ffToastFadeOut {
        from { opacity: 1; transform: translateY(0) scale(1); }
        to { opacity: 0; transform: translateY(12px) scale(0.96); }
      }
      .ff-toast-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
      }
      .ff-toast-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        background: rgba(239, 68, 68, 0.2);
        border: 1px solid rgba(239, 68, 68, 0.4);
        border-radius: 9999px;
        padding: 4px 10px;
        font-size: 11px;
        font-weight: 700;
        color: #f87171;
        letter-spacing: 0.5px;
        text-transform: uppercase;
      }
      .ff-toast-close {
        background: transparent;
        border: none;
        color: #94a3b8;
        font-size: 18px;
        line-height: 1;
        cursor: pointer;
        padding: 2px 6px;
        border-radius: 6px;
      }
      .ff-toast-close:hover {
        color: #ffffff;
        background: rgba(255, 255, 255, 0.1);
      }
      .ff-toast-title {
        font-size: 14px;
        font-weight: 700;
        color: #ffffff;
        line-height: 1.3;
      }
      .ff-toast-body {
        font-size: 12px;
        color: #cbd5e1;
        line-height: 1.4;
      }
      .ff-toast-progress-bar {
        height: 3px;
        width: 100%;
        background: rgba(255, 255, 255, 0.1);
        border-radius: 2px;
        overflow: hidden;
        margin-top: 4px;
      }
      .ff-toast-progress-fill {
        height: 100%;
        background: linear-gradient(90deg, #a855f7, #ec4899);
        width: 100%;
        animation: ffToastProgress 4.5s linear forwards;
      }
      @keyframes ffToastProgress {
        from { width: 100%; }
        to { width: 0%; }
      }

      /* Card Verifying Micro-Indicator */
      .ff-card-verifying-badge {
        position: absolute;
        top: 6px;
        left: 6px;
        z-index: 1000;
        background: rgba(15, 23, 42, 0.92);
        border: 1px solid rgba(139, 92, 246, 0.65);
        border-radius: 8px;
        padding: 4px 8px;
        font-size: 10px;
        font-weight: 700;
        color: #c084fc;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        box-shadow: 0 4px 14px rgba(0,0,0,0.6);
        pointer-events: none;
      }
      .ff-spinner-micro {
        width: 10px;
        height: 10px;
        border: 2px solid rgba(139, 92, 246, 0.3);
        border-top-color: #c084fc;
        border-radius: 50%;
        animation: ffSpin 0.7s linear infinite;
      }
      @keyframes ffSpin {
        to { transform: rotate(360deg); }
      }

      /* Fallback Level 2 Overlays for Direct URL entry */
      #focusforge-yt-verifying-overlay,
      #focusforge-yt-block-overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 2000;
        background: rgba(10, 12, 22, 0.94);
        backdrop-filter: blur(24px);
        -webkit-backdrop-filter: blur(24px);
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        color: #f3f4f6;
        user-select: none;
        border-radius: 12px;
        padding: 24px;
        box-sizing: border-box;
      }
      .ff-yt-card {
        max-width: 500px;
        width: 100%;
        background: linear-gradient(180deg, rgba(30, 27, 75, 0.75) 0%, rgba(15, 23, 42, 0.9) 100%);
        border: 1px solid rgba(139, 92, 246, 0.35);
        border-radius: 20px;
        padding: 28px 24px;
        text-align: center;
        box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.8), 0 0 35px rgba(139, 92, 246, 0.2);
      }
      .ff-badge-blocked {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 6px 14px;
        border-radius: 9999px;
        background: rgba(239, 68, 68, 0.15);
        border: 1px solid rgba(239, 68, 68, 0.35);
        color: #f87171;
        font-size: 11px;
        font-weight: 700;
        letter-spacing: 0.8px;
        text-transform: uppercase;
        margin-bottom: 14px;
      }
      .ff-btn-study {
        background: linear-gradient(135deg, #7c3aed 0%, #4f46e5 100%);
        color: #ffffff;
        border: none;
        padding: 12px 22px;
        border-radius: 12px;
        font-size: 13px;
        font-weight: 700;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        box-shadow: 0 4px 14px rgba(124, 58, 237, 0.35);
        transition: transform 0.15s ease, box-shadow 0.15s ease;
      }
      .ff-btn-study:hover {
        transform: translateY(-1px);
        box-shadow: 0 6px 20px rgba(124, 58, 237, 0.5);
      }
      .ff-pulse-dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background: #ef4444;
        box-shadow: 0 0 10px #ef4444;
      }
    `;
    document.head.appendChild(style);
  }

  let toastTimeout = null;
  function showStayInZoneToast(blockedTitle, reason) {
    injectStyles();
    document.getElementById("focusforge-yt-toast")?.remove();
    if (toastTimeout) clearTimeout(toastTimeout);

    const toast = document.createElement("div");
    toast.id = "focusforge-yt-toast";
    const subject = activeSession.subject || "Study";
    const cleanTitle = (blockedTitle || "Selected video").slice(0, 75);

    toast.innerHTML = `
      <div class="ff-toast-header">
        <div class="ff-toast-badge">
          <span class="ff-pulse-dot"></span>
          <span>STUDY MODE ACTIVE</span>
        </div>
        <button class="ff-toast-close" id="ff-toast-close-btn" title="Dismiss">&times;</button>
      </div>
      <div class="ff-toast-title">This video isn't within your academic study scope</div>
      <div class="ff-toast-body">
        <strong>${cleanTitle}</strong> was filtered out (${reason || "Non-academic content"}). FocusForge kept your <strong>${subject}</strong> lecture active!
      </div>
      <div class="ff-toast-progress-bar">
        <div class="ff-toast-progress-fill"></div>
      </div>
    `;

    document.body.appendChild(toast);

    document.getElementById("ff-toast-close-btn")?.addEventListener("click", () => {
      toast.remove();
    });

    toastTimeout = setTimeout(() => {
      toast.style.animation = "ffToastFadeOut 0.25s ease-out forwards";
      setTimeout(() => toast.remove(), 250);
    }, 4500);
  }

  function setCardVerifyingIndicator(cardEl, isVerifying) {
    if (!cardEl) return;
    const existing = cardEl.querySelector(".ff-card-verifying-badge");
    if (!isVerifying && existing) {
      existing.remove();
      return;
    }
    if (isVerifying && !existing) {
      injectStyles();
      const badge = document.createElement("div");
      badge.className = "ff-card-verifying-badge";
      badge.innerHTML = `
        <div class="ff-spinner-micro"></div>
        <span>Verifying study content...</span>
      `;
      if (window.getComputedStyle(cardEl).position === "static") {
        cardEl.style.position = "relative";
      }
      cardEl.appendChild(badge);
    }
  }

  // ====================================================================
  // 5. Metadata Extraction Helpers
  // ====================================================================
  function extractCardMetadata(cardEl, anchorEl) {
    const card = cardEl || anchorEl?.closest("ytd-compact-video-renderer, ytd-rich-item-renderer, ytd-video-renderer, ytd-grid-video-renderer") || anchorEl;
    const titleEl = card?.querySelector("#video-title, #title, .ytd-compact-video-renderer #video-title") || anchorEl;
    const title = titleEl?.textContent?.trim() || titleEl?.getAttribute("title") || "";

    const channelEl = card?.querySelector("#channel-name, ytd-channel-name, .ytd-channel-name, #byline");
    const channelName = channelEl?.textContent?.trim() || "";

    const descEl = card?.querySelector("#description-text, .metadata-snippet-container");
    const description = descEl?.textContent?.trim() || "";

    const durationEl = card?.querySelector("ytd-thumbnail-overlay-time-status-renderer, .badge-shape-wiz--thumbnail-badge");
    let durationSeconds = 0;
    if (durationEl) {
      const durText = durationEl.textContent?.trim() || "";
      const parts = durText.split(":").map(Number);
      if (parts.length === 2 && !isNaN(parts[0]) && !isNaN(parts[1])) {
        durationSeconds = parts[0] * 60 + parts[1];
      } else if (parts.length === 3 && !isNaN(parts[0]) && !isNaN(parts[1]) && !isNaN(parts[2])) {
        durationSeconds = parts[0] * 3600 + parts[1] * 60 + parts[2];
      }
    }

    return { title, channelName, description, durationSeconds };
  }

  function extractCurrentPageMetadata() {
    const titleEl =
      document.querySelector("h1.style-scope.ytd-watch-metadata yt-formatted-string") ||
      document.querySelector("h1.title.style-scope.ytd-video-primary-info-renderer") ||
      document.querySelector("meta[name='title']");
    const title =
      titleEl?.textContent?.trim() ||
      titleEl?.getAttribute("content")?.trim() ||
      document.title.replace(" - YouTube", "").trim();

    const channelEl =
      document.querySelector("#owner #channel-name a") ||
      document.querySelector("ytd-channel-name a") ||
      document.querySelector("meta[itemprop='name']");
    const channelName =
      channelEl?.textContent?.trim() ||
      channelEl?.getAttribute("content")?.trim() ||
      "";

    const descEl =
      document.querySelector("meta[name='description']") ||
      document.querySelector("#description-inline-expander");
    const description =
      descEl?.getAttribute("content")?.trim() ||
      descEl?.textContent?.trim() ||
      "";

    const video = document.querySelector("video");
    const durationSeconds = video?.duration || 0;

    return { title, channelName, description, durationSeconds };
  }

  function isStudyAllowed(decision) {
    return decision === "ALLOW" || decision === "STUDY";
  }

  function isStudyBlocked(decision) {
    return decision === "BLOCK" || decision === "NON_STUDY";
  }

  function matchesEntityBounded(normText, entityNorm) {
    if (!normText || !entityNorm) return false;
    if (entityNorm.includes(" ") || entityNorm.includes("-")) {
      return normText.includes(entityNorm);
    }
    const escaped = entityNorm.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    return new RegExp(`(^|\\s)${escaped}(\\s|$)`, "i").test(normText);
  }

  // ====================================================================
  // 6. Fast Local Semantic Rules (Local-First Classification)
  // ====================================================================
  function runFastClassifier(meta, videoId) {
    const title = (meta.title || "").toLowerCase();
    const channel = (meta.channelName || "").toLowerCase();
    const desc = (meta.description || "").toLowerCase();
    const combined = `${title} ${channel} ${desc}`;

    // 1. Shorts check: ALWAYS blocked in active study
    if ((meta.durationSeconds > 0 && meta.durationSeconds <= 60) || title.includes("#shorts") || title.includes("#short")) {
      return {
        videoId,
        decision: "BLOCK",
        confidence: 1.0,
        reason: "Shorts are strictly blocked during active study sessions.",
        subject: "",
        topic: "Shorts",
      };
    }

    // 2. Strict Negative Taxonomy (Vlogs, Lifestyle, Hostel Tours, Gadget Reviews, Routines, Memes)
    const negativePatterns = [
      "vlog", "daily vlog", "my day at kota", "my day in the life", "day in my life", "day in the life",
      "room tour", "hostel tour", "campus tour", "hostel life", "campus life", "campus vlog", "lifestyle",
      "study setup", "desk setup", "workspace tour", "what's in my bag", "haul",
      "top 10 gadgets", "gadgets for students", "top laptops", "best laptops", "laptops for students",
      "funny school compilation", "funny school", "funny moments", "student memes", "school memes", "exam memes",
      "prank", "reaction", "roast", "gaming", "gameplay", "gaming after", "walkthrough", "trailer",
      "music video", "official video song", "remix song", "lyrics", "dance cover", "comedy",
      "standup comedy", "skit", "unboxing", "morning routine", "night routine", "5 am routine",
      "asmr", "tiktok", "reels compilation", "anime episode", "pubg", "bgmi", "valorant",
      "free fire", "gta", "minecraft", "cricket highlights", "football highlights", "wwe",
      "movie clips", "web series", "entertainment news", "challenge video", "24 hours challenge",
      "motivation for", "study motivation", "motivational speech", "motivational video",
      "iit fest", "iit mood indigo", "iit celebration", "iit placement", "iit admission"
    ];

    for (const kw of negativePatterns) {
      if (combined.includes(kw)) {
        return {
          videoId,
          decision: "BLOCK",
          confidence: 0.98,
          reason: `Non-academic lifestyle content detected (${kw}).`,
          subject: "",
          topic: kw,
        };
      }
    }

    // 3. IIT/NIT campus lifestyle check
    if (combined.includes("iit") || combined.includes("nit") || combined.includes("bits")) {
      const campusTerms = [
        "campus", "hostel", "tour", "vlog", "lifestyle", "memes", "celebration",
        "placement", "admission", "fresher", "farewell", "canteen", "mess food", "room tour"
      ];
      for (const term of campusTerms) {
        if (combined.includes(term)) {
          return {
            videoId,
            decision: "BLOCK",
            confidence: 0.99,
            reason: `Campus lifestyle content detected (${term}). Genuinely academic instruction required.`,
            subject: "",
            topic: term,
          };
        }
      }
    }

    // 4. Comprehensive Academic Syllabus (IIT-JEE Main/Adv, NEET, CBSE Class 12/11)
    const academicKeywords = [
      // Physics
      "rotational motion", "electrostatics", "kinematics", "newton laws", "friction",
      "work energy power", "gravitation", "thermodynamics", "oscillations", "waves",
      "electric charges", "current electricity", "magnetism", "electromagnetic induction", "emi",
      "alternating current", "ray optics", "wave optics", "photoelectric", "atoms and nuclei",
      "semiconductors", "logic gates", "capacitance", "electric potential", "biot savart",
      "ampere law", "faraday law", "lenz law", "ac generator", "transformer", "de broglie",
      "bohr model", "young double slit", "interference", "diffraction", "polarization",
      "total internal reflection", "prism formula", "carnot engine", "kinetic theory", "fluid mechanics",
      "surface tension", "center of mass", "moment of inertia", "shm", "doppler effect",
      // Chemistry
      "mole concept", "atomic structure", "periodic table", "chemical bonding", "hybridisation",
      "molecular orbital", "gas laws", "chemical thermodynamics", "enthalpy", "entropy",
      "gibbs free energy", "equilibrium", "le chatelier", "ionic equilibrium", "buffer solution",
      "solubility product", "redox", "oxidation number", "s block", "p block", "d block", "f block",
      "coordination compounds", "isomerism", "solid state", "solutions", "colligative properties",
      "raoult law", "electrochemistry", "nernst equation", "chemical kinetics", "rate law",
      "arrhenius equation", "surface chemistry", "adsorption", "organic chemistry", "iupac nomenclature",
      "reaction mechanism", "carbocation", "hydrocarbons", "alkanes", "alkenes", "alkynes", "benzene",
      "haloalkanes", "haloarenes", "sn1", "sn2", "alcohols phenols", "aldol condensation", "cannizzaro",
      "carboxylic acids", "amines", "diazotization", "biomolecules", "carbohydrates", "amino acids", "polymers",
      // Mathematics
      "sets relations", "trigonometric functions", "complex numbers", "quadratic equations",
      "permutations and combinations", "binomial theorem", "sequences and series", "arithmetic progression",
      "geometric progression", "straight lines", "circles", "parabola", "ellipse", "hyperbola",
      "conic sections", "three dimensional geometry", "3d geometry", "limits", "continuity",
      "differentiability", "differentiation", "derivatives", "maxima minima", "indefinite integrals",
      "definite integrals", "integration by parts", "area under curves", "differential equations",
      "vectors", "vector algebra", "dot product", "cross product", "probability", "bayes theorem",
      "matrices", "determinants", "cramer rule",
      // Biology (NEET)
      "cell the unit of life", "cell cycle", "mitosis", "meiosis", "genetics", "mendelian inheritance",
      "dna replication", "transcription", "translation", "biotechnology", "human physiology",
      "plant physiology", "photosynthesis", "plant respiration", "reproduction in organisms",
      "sexual reproduction flowering", "human reproduction", "evolution", "biodiversity",
      // CBSE Class 12 English
      "flamingo", "vistas", "the last lesson", "lost spring", "deep water", "the rattrap", "indigo",
      "poets and pancakes", "the interview", "going places", "my mother at sixty-six", "keeping quiet",
      "a thing of beauty", "a roadside stand", "aunt jennifer tigers", "third level", "tiger king",
      "journey to the end of the earth", "the enemy", "on the face of it", "memories of childhood",
      "english literature", "english grammar", "reading comprehension", "notice writing", "report writing",
      // Exam prefixes & lecture indicators
      "jee main", "jee advanced", "neet 202", "cbse class 12", "class 12 board", "pyq discussion",
      "one shot revision", "ncert line by line", "complete chapter revision", "previous year questions"
    ];

    const matchedAcademic = academicKeywords.filter((akw) => matchesEntityBounded(combined, akw));
    if (matchedAcademic.length > 0) {
      return {
        videoId,
        decision: "ALLOW",
        confidence: 0.95,
        reason: `Verified academic study lecture: ${matchedAcademic.slice(0, 3).join(", ")}.`,
        subject: activeSession.subject || "Academic Study",
        topic: matchedAcademic[0],
      };
    }

    return null;
  }

  // ====================================================================
  // 7. Priority Pre-Verification Queue (Subsystem 3)
  // Priorities: CRITICAL (Clicked) > HIGH (Hover) > MED (Visible) > LOW
  // ====================================================================
  class VerificationQueueManager {
    constructor() {
      this.queue = [];
      this.inFlight = new Set();
      this.batchTimer = null;
      this.maxConcurrentBatches = 2;
      this.activeBatchesCount = 0;
    }

    enqueue(item, priority = "MEDIUM") {
      if (!isStudyGuardActive()) return;
      if (!item.videoId || localDecisionCache.has(item.videoId) || this.inFlight.has(item.videoId)) {
        return;
      }

      // Pre-check approved list
      if (activeSession.approvedVideoIds.has(item.videoId)) {
        localDecisionCache.set(item.videoId, {
          videoId: item.videoId,
          decision: "ALLOW",
          reason: "Pre-approved study video",
        });
        return;
      }

      // Fast local classification
      const fast = runFastClassifier(item, item.videoId);
      if (fast) {
        localDecisionCache.set(item.videoId, fast);
        return;
      }

      // Remove any existing duplicate in queue
      this.queue = this.queue.filter((q) => q.item.videoId !== item.videoId);

      // Priority ordering: CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3
      const priorityOrder = { CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3 };
      const rank = priorityOrder[priority] ?? 2;

      this.queue.push({ item, rank });
      this.queue.sort((a, b) => a.rank - b.rank);

      if (priority === "CRITICAL" || priority === "HIGH") {
        this.flushImmediate();
      } else {
        this.scheduleFlush(300);
      }
    }

    scheduleFlush(delayMs) {
      if (this.batchTimer) clearTimeout(this.batchTimer);
      this.batchTimer = setTimeout(() => this.flush(), delayMs);
    }

    flushImmediate() {
      if (this.batchTimer) clearTimeout(this.batchTimer);
      this.flush();
    }

    flush() {
      if (!isStudyGuardActive() || this.queue.length === 0) return;
      if (this.activeBatchesCount >= this.maxConcurrentBatches) return;

      const batch = [];
      while (this.queue.length > 0 && batch.length < 20) {
        const entry = this.queue.shift();
        if (!this.inFlight.has(entry.item.videoId) && !localDecisionCache.has(entry.item.videoId)) {
          batch.push(entry.item);
          this.inFlight.add(entry.item.videoId);
        }
      }

      if (batch.length === 0) return;

      this.activeBatchesCount++;
      logDiagnostic("PREFETCH_BATCH_DISPATCH", { count: batch.length });

      chrome.runtime.sendMessage(
        {
          type: "PREFETCH_YOUTUBE_RECOMMENDATIONS",
          candidates: batch,
        },
        (res) => {
          this.activeBatchesCount--;
          batch.forEach((c) => this.inFlight.delete(c.videoId));

          if (chrome.runtime.lastError || !res || !res.decisions) {
            return;
          }

          for (const [vid, dec] of Object.entries(res.decisions)) {
            if (dec && dec.decision) {
              localDecisionCache.set(vid, dec);
            }
          }

          // Continue if more items in queue
          if (this.queue.length > 0) {
            this.scheduleFlush(150);
          }
        }
      );
    }

    clear() {
      this.queue = [];
      this.inFlight.clear();
      if (this.batchTimer) clearTimeout(this.batchTimer);
    }
  }

  const verificationQueue = new VerificationQueueManager();

  // ====================================================================
  // 8. Recommendation Observers (Discovery Engine)
  // ====================================================================
  let cardIntersectionObserver = null;
  function setupRecommendationObservers() {
    if (cardIntersectionObserver) cardIntersectionObserver.disconnect();

    cardIntersectionObserver = new IntersectionObserver(
      (entries) => {
        if (!isStudyGuardActive()) return;
        for (const entry of entries) {
          if (entry.isIntersecting) {
            const card = entry.target;
            const anchor = card.querySelector("a#thumbnail, a.ytd-thumbnail, a[href*='/watch']");
            if (anchor) {
              const videoId = extractYouTubeVideoId(anchor.href);
              if (videoId && videoId !== currentVideoId) {
                const meta = extractCardMetadata(card, anchor);
                verificationQueue.enqueue({ videoId, ...meta }, "MEDIUM");
              }
            }
          }
        }
      },
      { rootMargin: "300px 0px" }
    );

    const cards = document.querySelectorAll(
      "ytd-compact-video-renderer, ytd-rich-item-renderer, ytd-video-renderer, ytd-grid-video-renderer"
    );
    cards.forEach((c) => cardIntersectionObserver.observe(c));
  }

  const recommendationContainerObserver = new MutationObserver((mutations) => {
    if (!isStudyGuardActive() || !cardIntersectionObserver) return;
    for (const m of mutations) {
      for (const node of m.addedNodes) {
        if (node.nodeType === 1) {
          if (node.matches?.("ytd-compact-video-renderer, ytd-rich-item-renderer, ytd-video-renderer, ytd-grid-video-renderer")) {
            cardIntersectionObserver.observe(node);
          } else if (node.querySelectorAll) {
            const nested = node.querySelectorAll("ytd-compact-video-renderer, ytd-rich-item-renderer, ytd-video-renderer, ytd-grid-video-renderer");
            nested.forEach((c) => cardIntersectionObserver.observe(c));
          }
        }
      }
    }
  });

  function startObservingRecommendations() {
    setupRecommendationObservers();
    const related =
      document.getElementById("related") ||
      document.querySelector("ytd-watch-next-secondary-results-renderer") ||
      document.querySelector("#secondary") ||
      document.body;

    if (related) {
      recommendationContainerObserver.observe(related, { childList: true, subtree: true });
    }
  }

  // Pointerover / Hover priority escalation
  function onPointerOverRecommendations(event) {
    if (!isStudyGuardActive()) return;
    const anchor = event.target.closest("a[href*='/watch'], a[href*='youtu.be']");
    if (!anchor) return;

    const videoId = extractYouTubeVideoId(anchor.href);
    if (!videoId || videoId === currentVideoId) return;

    if (!localDecisionCache.has(videoId)) {
      const card = anchor.closest("ytd-compact-video-renderer, ytd-rich-item-renderer, ytd-video-renderer, ytd-grid-video-renderer") || anchor;
      const meta = extractCardMetadata(card, anchor);
      logDiagnostic("HOVER_HIGH_PRIORITY_PREWARM", { videoId, title: meta.title.slice(0, 30) });
      verificationQueue.enqueue({ videoId, ...meta }, "HIGH");
    }
  }

  document.addEventListener("pointerover", onPointerOverRecommendations, { capture: true, passive: true });

  // ====================================================================
  // 9. THE CORE: NAVIGATION FIREWALL (Capture-Phase Interceptor)
  // ====================================================================
  function isExcludedInteractiveElement(target) {
    return Boolean(
      target.closest(
        ".ytp-chrome-bottom, .ytp-button, .ytp-play-button, .ytp-volume-panel, " +
        ".ytp-progress-bar, .ytp-settings-button, .ytp-fullscreen-button, .ytp-subtitles-button, " +
        "ytd-menu-renderer, #subscribe-button, ytd-comments, ytd-comment-thread-renderer, " +
        "#channel-name, a[href^='/@'], a[href^='/channel/'], a[href^='/c/'], #endpoint, " +
        "ytd-searchbox, #search-form, #search-icon-legacy"
      )
    );
  }

  function handleVideoNavigationAttempt(event, anchor) {
    // INVARIANT 1: If Study Guard is not active, allow 100% normal YouTube navigation!
    if (!isStudyGuardActive()) {
      return;
    }

    const targetUrl = anchor.getAttribute("href") || anchor.href;
    const destinationVideoId = extractYouTubeVideoId(targetUrl);
    if (!destinationVideoId) return;

    // INVARIANT 2: If clicking currently playing verified lecture (or timestamp link), pass through immediately!
    if (destinationVideoId === currentVideoId) {
      logDiagnostic("FIREWALL_CURRENT_LECTURE_PASS", { videoId: destinationVideoId });
      return;
    }

    // INVARIANT 3: Controlled approved transition replay bypass
    if (approvedNavigationToken && approvedNavigationToken === destinationVideoId) {
      logDiagnostic("FIREWALL_APPROVED_TRANSITION_PASS", { videoId: destinationVideoId });
      approvedNavigationToken = null;
      return;
    }

    diagnosticsData.totalClicksIntercepted++;
    const card = anchor.closest("ytd-compact-video-renderer, ytd-rich-item-renderer, ytd-video-renderer, ytd-grid-video-renderer") || anchor;
    const meta = extractCardMetadata(card, anchor);

    // --- CASE A: CACHE HIT ALLOW ---
    const cached = localDecisionCache.get(destinationVideoId);
    if (cached && isStudyAllowed(cached.decision)) {
      diagnosticsData.cacheHits++;
      diagnosticsData.totalAllowsPermitted++;
      diagnosticsData.lastNavigation = { videoId: destinationVideoId, decision: "ALLOW", timestamp: Date.now() };

      currentState = STATES.ALLOWING;
      approvedNavigationToken = destinationVideoId;
      chrome.runtime.sendMessage({
        type: "GRANT_FOCUS_PASS",
        videoId: destinationVideoId,
        meta: { title: meta.title, channelName: meta.channelName },
      }).catch(() => {});
      logDiagnostic("FIREWALL_CACHE_ALLOW -> PASS", { videoId: destinationVideoId });
      return; // Allow native YouTube SPA click immediately with ZERO interruption!
    }

    // --- CASE B: CACHE HIT BLOCK ---
    if (cached && isStudyBlocked(cached.decision)) {
      diagnosticsData.cacheHits++;
      diagnosticsData.totalBlocksDeflected++;
      diagnosticsData.lastNavigation = { videoId: destinationVideoId, decision: "BLOCK", timestamp: Date.now() };

      // CANCEL NAVIGATION BEFORE THE BROWSER ENTERS THE DESTINATION
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();

      currentState = STATES.BLOCKING;
      logDiagnostic("FIREWALL_CACHE_BLOCK -> CANCELLED", { videoId: destinationVideoId, reason: cached.reason });

      // Current study video stays playing undisturbed!
      showStayInZoneToast(meta.title, cached.reason);

      chrome.runtime.sendMessage({
        type: "LOG_YOUTUBE_DISTRACTION",
        url: anchor.href,
        videoId: destinationVideoId,
      }).catch(() => {});
      return;
    }

    // --- CASE C: FAST LOCAL SEMANTIC RULES ---
    diagnosticsData.cacheMisses++;
    const fastDecision = runFastClassifier(meta, destinationVideoId);
    if (fastDecision) {
      localDecisionCache.set(destinationVideoId, fastDecision);

      if (isStudyAllowed(fastDecision.decision)) {
        diagnosticsData.totalAllowsPermitted++;
        diagnosticsData.lastNavigation = { videoId: destinationVideoId, decision: "ALLOW", timestamp: Date.now() };

        currentState = STATES.ALLOWING;
        approvedNavigationToken = destinationVideoId;
        chrome.runtime.sendMessage({
          type: "GRANT_FOCUS_PASS",
          videoId: destinationVideoId,
          meta: { title: meta.title, channelName: meta.channelName, reason: fastDecision.reason },
        }).catch(() => {});
        logDiagnostic("FIREWALL_FAST_ALLOW -> PASS", { videoId: destinationVideoId });
        return;
      } else {
        diagnosticsData.totalBlocksDeflected++;
        diagnosticsData.lastNavigation = { videoId: destinationVideoId, decision: "BLOCK", timestamp: Date.now() };

        // CANCEL NAVIGATION BEFORE THE BROWSER ENTERS THE DESTINATION
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();

        currentState = STATES.BLOCKING;
        logDiagnostic("FIREWALL_FAST_BLOCK -> CANCELLED", { videoId: destinationVideoId, reason: fastDecision.reason });

        showStayInZoneToast(meta.title, fastDecision.reason);

        chrome.runtime.sendMessage({
          type: "LOG_YOUTUBE_DISTRACTION",
          url: anchor.href,
          videoId: destinationVideoId,
        }).catch(() => {});
        return;
      }
    }

    // --- CASE D: UNKNOWN (PREVENT NAVIGATION TEMPORARILY & CLASSIFY) ---
    // The current study lecture continues playing completely undisturbed!
    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();

    currentState = STATES.VERIFYING_DESTINATION;
    const navigationToken = `${destinationVideoId}_${Date.now()}_${Math.random()}`;
    activeClickToken = navigationToken;
    setCardVerifyingIndicator(card, true);

    logDiagnostic("FIREWALL_UNKNOWN -> INTERCEPTED_VERIFYING", { videoId: destinationVideoId, token: navigationToken });

    // CRITICAL priority request to background worker
    chrome.runtime.sendMessage(
      {
        type: "CHECK_OR_CLASSIFY_CLICK",
        videoId: destinationVideoId,
        title: meta.title,
        channelName: meta.channelName,
        description: meta.description,
        durationSeconds: meta.durationSeconds,
        navigationToken,
      },
      (res) => {
        setCardVerifyingIndicator(card, false);

        // LATEST-CLICK-WINS GUARD: Discard if user clicked another recommendation in the meantime
        if (activeClickToken !== navigationToken) {
          logDiagnostic("DISCARD_STALE_CLICK_RESPONSE", { token: navigationToken, activeToken: activeClickToken });
          return;
        }

        if (chrome.runtime.lastError || !res) {
          currentState = STATES.ARMED;
          logDiagnostic("FIREWALL_VERIFY_ERROR", { videoId: destinationVideoId });
          showStayInZoneToast(meta.title, "Could not verify syllabus alignment. Unknown content blocked.");
          return;
        }

        if (isStudyAllowed(res.decision)) {
          diagnosticsData.totalAllowsPermitted++;
          diagnosticsData.lastNavigation = { videoId: destinationVideoId, decision: "ALLOW", timestamp: Date.now() };

          localDecisionCache.set(destinationVideoId, res.result || { decision: "ALLOW" });
          approvedNavigationToken = destinationVideoId;
          currentState = STATES.ALLOWING;

          logDiagnostic("FIREWALL_CLASSIFIED_ALLOW -> EXECUTING_APPROVED_TRANSITION", { videoId: destinationVideoId });

          // Re-trigger native click with approvedNavigationToken set so firewall lets it pass
          anchor.click();
        } else {
          diagnosticsData.totalBlocksDeflected++;
          diagnosticsData.lastNavigation = { videoId: destinationVideoId, decision: "BLOCK", timestamp: Date.now() };

          localDecisionCache.set(destinationVideoId, res.result || { decision: "BLOCK" });
          currentState = STATES.BLOCKING;

          logDiagnostic("FIREWALL_CLASSIFIED_BLOCK -> REMAINS_ON_CURRENT_LECTURE", { videoId: destinationVideoId });
          showStayInZoneToast(meta.title, res.result?.reason || "Non-academic video");

          chrome.runtime.sendMessage({
            type: "LOG_YOUTUBE_DISTRACTION",
            url: anchor.href,
            videoId: destinationVideoId,
          }).catch(() => {});
        }
      }
    );
  }

  function onDocumentClickCapture(event) {
    if (!isStudyGuardActive()) return;
    if (isExcludedInteractiveElement(event.target)) return;

    const anchor = event.target.closest("a[href*='/watch'], a[href*='youtu.be']");
    if (anchor) {
      handleVideoNavigationAttempt(event, anchor);
    }
  }

  function onDocumentAuxClickCapture(event) {
    if (!isStudyGuardActive()) return;
    if (event.button === 1) { // Middle click / new tab
      const anchor = event.target.closest("a[href*='/watch'], a[href*='youtu.be']");
      if (anchor) {
        handleVideoNavigationAttempt(event, anchor);
      }
    }
  }

  function onDocumentKeydownCapture(event) {
    if (!isStudyGuardActive()) return;
    if (event.key === "Enter" || event.key === " ") {
      const activeEl = document.activeElement;
      if (activeEl && !isExcludedInteractiveElement(activeEl)) {
        const anchor = activeEl.closest("a[href*='/watch'], a[href*='youtu.be']");
        if (anchor) {
          handleVideoNavigationAttempt(event, anchor);
        }
      }
    }
  }

  // Install Document Capture-Phase Listeners immediately at document_start
  document.addEventListener("click", onDocumentClickCapture, true);
  document.addEventListener("auxclick", onDocumentAuxClickCapture, true);
  document.addEventListener("keydown", onDocumentKeydownCapture, true);

  // ====================================================================
  // 10. Study Watch Ticker (Continuous Academic Session Logging)
  // ====================================================================
  function startWatchTicker(videoId, meta, decision) {
    if (watchTicker) clearInterval(watchTicker);
    videoWatchSeconds = 0;

    watchTicker = setInterval(() => {
      if (!isStudyGuardActive() || currentVideoId !== videoId) {
        clearInterval(watchTicker);
        return;
      }

      const vid = document.querySelector("video");
      const isPlaying = vid && !vid.paused && !vid.ended && vid.readyState > 2;
      const isVisible = document.visibilityState === "visible";

      if (isPlaying && isVisible) {
        videoWatchSeconds += 5;
        if (videoWatchSeconds >= 30) {
          chrome.runtime.sendMessage({
            type: "LOG_YOUTUBE_STUDY_TIME",
            videoId,
            title: meta.title,
            channelName: meta.channelName,
            subject: decision.subject || activeSession.subject,
            chapter: decision.topic || activeSession.chapter,
            durationSeconds: videoWatchSeconds,
          }).catch(() => {});
          videoWatchSeconds = 0;
        }
      }
    }, 5000);
  }

  // ====================================================================
  // 11. Level 2 Fallback: Direct URL / Address Bar / Reload Gate
  // ====================================================================
  function removeOverlays() {
    document.getElementById("focusforge-yt-verifying-overlay")?.remove();
    document.getElementById("focusforge-yt-block-overlay")?.remove();
  }

  function showBlockOverlay(decision) {
    injectStyles();
    removeOverlays();

    const parent =
      document.getElementById("movie_player") ||
      document.querySelector("ytd-player #container") ||
      document.querySelector("#player-container") ||
      document.body;

    if (!parent) return;

    if (parent !== document.body && window.getComputedStyle(parent).position === "static") {
      parent.style.position = "relative";
    }

    const overlay = document.createElement("div");
    overlay.id = "focusforge-yt-block-overlay";
    overlay.innerHTML = `
      <div class="ff-yt-card">
        <div class="ff-badge-blocked">
          <span class="ff-pulse-dot"></span>
          <span>STUDY MODE ACTIVE</span>
        </div>
        <div style="font-size:18px; font-weight:800; color:#fff; margin-bottom:8px;">
          This video isn't within your academic study scope.
        </div>
        <div style="font-size:13px; color:#cbd5e1; margin-bottom:16px;">
          <strong>Detected:</strong> ${decision.reason || "Non-academic content"}
        </div>
        <div style="background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); border-radius:12px; padding:12px; font-size:11px; color:#94a3b8; margin-bottom:20px;">
          Allowed scope: <strong>JEE • NEET • CBSE Class 11 & 12 • Physics • Chemistry • Mathematics • Biology • English</strong>
        </div>
        <div>
          <button class="ff-btn-study" id="ff-btn-back-to-yt-study">
            <span>🔍 Back to YouTube Study</span>
          </button>
        </div>
      </div>
    `;
    parent.appendChild(overlay);

    document.getElementById("ff-btn-back-to-yt-study")?.addEventListener("click", () => {
      window.location.href = "https://www.youtube.com";
    });
  }

  function applyDirectWatchDecision(videoId, meta, decision) {
    localDecisionCache.set(videoId, decision);

    if (isStudyAllowed(decision.decision)) {
      currentState = STATES.ARMED;
      isCurrentVideoImmune = true;
      removeOverlays();

      logDiagnostic("DIRECT_WATCH_ALLOW -> PLAYBACK_ACTIVE", { videoId });

      const vid = document.querySelector("video");
      if (vid && vid.paused) {
        vid.play().catch(() => {});
      }
      try {
        document.getElementById("movie_player")?.playVideo?.();
      } catch {}

      startWatchTicker(videoId, meta, decision);

      chrome.runtime.sendMessage({
        type: "APPROVE_STUDY_VIDEO",
        videoId,
        metadata: meta,
      }).catch(() => {});
    } else {
      currentState = STATES.BLOCKING;
      isCurrentVideoImmune = false;
      if (watchTicker) clearInterval(watchTicker);

      const vid = document.querySelector("video");
      if (vid) vid.pause();
      try {
        document.getElementById("movie_player")?.pauseVideo?.();
      } catch {}

      showBlockOverlay(decision);
      logDiagnostic("DIRECT_WATCH_BLOCK -> LOCKED", { videoId, reason: decision.reason });

      chrome.runtime.sendMessage({
        type: "LOG_YOUTUBE_DISTRACTION",
        url: window.location.href,
        videoId,
      }).catch(() => {});
    }
  }

  function verifyDirectWatchPage(videoId) {
    if (!isStudyGuardActive()) {
      restoreNormalYouTube();
      return;
    }
    if (!videoId) return;

    currentVideoId = videoId;

    // Check pre-approved list
    if (activeSession.approvedVideoIds.has(videoId)) {
      applyDirectWatchDecision(videoId, extractCurrentPageMetadata(), {
        videoId,
        decision: "ALLOW",
        reason: "Pre-approved study video",
      });
      return;
    }

    // Check local decision cache
    const cached = localDecisionCache.get(videoId);
    if (cached) {
      applyDirectWatchDecision(videoId, extractCurrentPageMetadata(), cached);
      return;
    }

    // Direct entry fallback: lock player and verify
    currentState = STATES.VERIFYING_DESTINATION;
    const vid = document.querySelector("video");
    if (vid) vid.pause();

    function attemptMetadataClassification(retriesLeft) {
      if (currentVideoId !== videoId || !isStudyGuardActive()) return;

      const meta = extractCurrentPageMetadata();
      const fastResult = runFastClassifier(meta, videoId);
      if (fastResult) {
        applyDirectWatchDecision(videoId, meta, fastResult);
        return;
      }

      if ((!meta.title || meta.title === "YouTube") && retriesLeft > 0) {
        setTimeout(() => attemptMetadataClassification(retriesLeft - 1), 350);
        return;
      }

      chrome.runtime.sendMessage(
        {
          type: "CHECK_OR_CLASSIFY_CLICK",
          videoId,
          title: meta.title,
          channelName: meta.channelName,
          description: meta.description,
          durationSeconds: meta.durationSeconds,
          navigationToken: `direct_${videoId}`,
        },
        (res) => {
          if (currentVideoId !== videoId || !isStudyGuardActive()) return;

          if (chrome.runtime.lastError || !res) {
            applyDirectWatchDecision(videoId, meta, {
              videoId,
              decision: "BLOCK",
              reason: "Could not verify academic syllabus alignment.",
            });
            return;
          }

          applyDirectWatchDecision(videoId, meta, res.result || { videoId, decision: res.decision });
        }
      );
    }

    setTimeout(() => attemptMetadataClassification(3), 200);
  }

  // Policy Compliance (Section 0): Academic Classification is cleanly separated from Player Modification.
  // Standard YouTube player/playback events are never intercepted or hooked.

  // ====================================================================
  // 12. Lifecycle & Route Evaluation
  // ====================================================================
  function restoreNormalYouTube() {
    currentState = STATES.OFF;
    currentVideoId = null;
    isCurrentVideoImmune = false;
    approvedNavigationToken = null;
    activeClickToken = null;
    verificationQueue.clear();

    if (watchTicker) clearInterval(watchTicker);
    removeOverlays();
    document.getElementById("focusforge-yt-toast")?.remove();

    if (pausedByGuard) {
      pausedByGuard = false;
      const vid = document.querySelector("video");
      if (vid && vid.paused) {
        vid.play().catch(() => {});
      }
    }
  }

  function evaluateCurrentRoute() {
    if (!isStudyGuardActive()) {
      restoreNormalYouTube();
      return;
    }

    const pathname = window.location.pathname;

    // Shorts check: strictly blocked in active study
    if (pathname.startsWith("/shorts")) {
      window.location.href = chrome.runtime.getURL("block-page/index.html?domain=youtube.com&reason=shorts");
      return;
    }

    // Watch page
    if (pathname === "/watch") {
      const videoId = extractYouTubeVideoId(window.location.href);
      if (!videoId) return;

      // Start recommendation prefetching in background
      startObservingRecommendations();

      if (videoId !== currentVideoId) {
        verifyDirectWatchPage(videoId);
      }
      return;
    }

    // Search, Home, Channels, Playlists: allowed for searching study lectures
    currentState = STATES.ARMED;
    currentVideoId = null;
    isCurrentVideoImmune = false;
    if (watchTicker) clearInterval(watchTicker);
    removeOverlays();

    // Start pre-verifying search results so clicks will be instantaneous
    startObservingRecommendations();
  }

  // ====================================================================
  // 13. Session State Synchronization & Communication
  // ====================================================================
  function syncSessionState() {
    currentState = STATES.STARTING;
    chrome.runtime.sendMessage({ type: "GET_YOUTUBE_GUARD_STATE" }, (res) => {
      if (chrome.runtime.lastError || !res) {
        currentState = STATES.OFF;
        return;
      }

      const wasActive = isStudyGuardActive();
      activeSession.isActive = Boolean(res.active);
      activeSession.status = res.status === "ON" ? "focus" : "idle";
      activeSession.sessionId = res.sessionId || null;
      activeSession.verifiedSessionId = res.verifiedSessionId || null;
      activeSession.leaseUntil = res.leaseUntil || null;
      activeSession.mode = res.mode || "strict";
      activeSession.subject = res.subject || "";
      activeSession.chapter = res.chapter || "";
      if (Array.isArray(res.approvedVideoIds)) {
        activeSession.approvedVideoIds = new Set(res.approvedVideoIds);
      }

      const nowActive = isStudyGuardActive();
      logDiagnostic("SESSION_SYNC", { active: nowActive, subject: activeSession.subject });

      if (nowActive) {
        currentState = STATES.ARMED;
        evaluateCurrentRoute();
      } else if (wasActive) {
        restoreNormalYouTube();
      } else {
        currentState = STATES.OFF;
      }
    });
  }

  chrome.runtime.onMessage.addListener((msg) => {
    if (!msg) return;

    if (msg.type === "YOUTUBE_GUARD_STATE_CHANGED") {
      const wasActive = isStudyGuardActive();
      activeSession.isActive = Boolean(msg.active);
      activeSession.status = msg.status === "ON" ? "focus" : "idle";
      activeSession.leaseUntil = msg.leaseUntil || null;
      activeSession.mode = msg.mode || "strict";
      activeSession.subject = msg.subject || "";
      activeSession.chapter = msg.chapter || "";
      if (Array.isArray(msg.approvedVideoIds)) {
        activeSession.approvedVideoIds = new Set(msg.approvedVideoIds);
      }

      const nowActive = isStudyGuardActive();
      logDiagnostic("STATE_CHANGED", { active: nowActive, subject: activeSession.subject });

      if (nowActive) {
        currentState = STATES.ARMED;
        evaluateCurrentRoute();
      } else if (wasActive) {
        restoreNormalYouTube();
      } else {
        currentState = STATES.OFF;
      }
    }
  });

  // SPA Navigation Event Handlers
  window.addEventListener("yt-navigate-finish", evaluateCurrentRoute);
  window.addEventListener("yt-page-data-updated", evaluateCurrentRoute);
  window.addEventListener("popstate", evaluateCurrentRoute);

  let lastUrl = window.location.href;
  setInterval(() => {
    if (window.location.href !== lastUrl) {
      lastUrl = window.location.href;
      evaluateCurrentRoute();
    }
  }, 350);

  // ====================================================================
  // 14. Developer Diagnostics Panel API
  // ====================================================================
  window.__FOCUSFORGE_YT_GUARD__ = {
    getDiagnostics: () => {
      const totalDecisions = diagnosticsData.cacheHits + diagnosticsData.cacheMisses;
      const hitRate = totalDecisions > 0 ? ((diagnosticsData.cacheHits / totalDecisions) * 100).toFixed(1) + "%" : "N/A";
      return {
        SESSION: isStudyGuardActive() ? "ACTIVE" : "INACTIVE",
        GUARD: isStudyGuardActive() ? "ARMED" : currentState === STATES.ERROR ? "ERROR" : "OFF",
        CURRENT_VIDEO: currentVideoId || "None",
        CURRENT_DECISION: isCurrentVideoImmune ? "ALLOW (IMMUNE)" : currentState,
        PREVERIFIED_CANDIDATES: localDecisionCache.size,
        CACHE_HIT_RATE: hitRate,
        PENDING_VERIFICATIONS: verificationQueue.queue.length + verificationQueue.inFlight.size,
        LAST_NAVIGATION: diagnosticsData.lastNavigation,
        NAVIGATION_FIREWALL: isStudyGuardActive() ? "ARMED" : "OFF",
        PLAYER_FALLBACK: "READY",
        CLASSIFIER: "ONLINE",
      };
    },
    getState: () => ({
      currentState,
      currentVideoId,
      isCurrentVideoImmune,
      activeSession: { ...activeSession, approvedVideoIdsCount: activeSession.approvedVideoIds.size },
    }),
    getCache: () => Array.from(localDecisionCache.entries()).map(([k, v]) => ({ videoId: k, ...v })),
    clearCache: () => localDecisionCache.clear(),
  };

  // Initial Sync
  syncSessionState();
})();
