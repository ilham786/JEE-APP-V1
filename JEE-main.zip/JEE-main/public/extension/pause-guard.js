// FocusForge Pause Guard Controller
(function () {
  const urlParams = new URLSearchParams(window.location.search);
  let targetUrl = urlParams.get("targetUrl") || urlParams.get("url") || "";
  let targetDomain = urlParams.get("domain") || "";

  // Normalize target domain if not provided
  if (!targetDomain && targetUrl) {
    try {
      targetDomain = new URL(targetUrl).hostname.replace(/^www\./, "");
    } catch {
      targetDomain = targetUrl.split("/")[0];
    }
  }

  // Fallback if URL is missing
  if (!targetUrl && targetDomain) {
    targetUrl = `https://${targetDomain}`;
  }

  const domDomain = document.getElementById("dest-domain");
  const domSubject = document.getElementById("session-subject");
  const domChapter = document.getElementById("session-chapter");
  const domTime = document.getElementById("session-time");

  const btnDashboard = document.getElementById("btn-dashboard");
  const btnContinuePage = document.getElementById("btn-continue-page");
  const btnContinueSite = document.getElementById("btn-continue-site");
  const feedbackEl = document.getElementById("status-feedback");

  if (domDomain) {
    domDomain.textContent = targetDomain || "Distraction Site";
  }

  function formatTime(seconds) {
    const s = Math.max(0, Math.floor(seconds || 0));
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = s % 60;
    if (h > 0) {
      return `${h}h ${m.toString().padStart(2, "0")}m`;
    }
    return `${m}m ${sec.toString().padStart(2, "0")}s`;
  }

  function showStatus(text, type = "info") {
    if (!feedbackEl) return;
    feedbackEl.style.display = "flex";
    feedbackEl.className = `status-feedback status-${type}`;
    feedbackEl.textContent = text;
  }

  function setButtonsDisabled(disabled) {
    if (btnContinuePage) btnContinuePage.disabled = disabled;
    if (btnContinueSite) btnContinueSite.disabled = disabled;
    if (btnDashboard) btnDashboard.disabled = disabled;
  }

  let currentTabId = null;
  if (chrome.tabs && typeof chrome.tabs.getCurrent === "function") {
    chrome.tabs.getCurrent((tab) => {
      if (tab?.id) currentTabId = tab.id;
    });
  }

  // Request fresh session context from background service worker and register pending guard
  try {
    chrome.runtime.sendMessage(
      {
        type: "GET_PAUSE_GUARD_CONTEXT",
        domain: targetDomain,
        url: targetUrl,
        tabId: currentTabId,
      },
      (response) => {
        if (chrome.runtime.lastError || !response) {
          console.warn("[PauseGuard] Could not retrieve telemetry from background:", chrome.runtime.lastError);
          return;
        }
        if (domSubject && response.subject) domSubject.textContent = response.subject;
        if (domChapter && response.chapter) domChapter.textContent = response.chapter;
        if (domTime && typeof response.elapsedStudySeconds === "number") {
          domTime.textContent = formatTime(response.elapsedStudySeconds);
        }
      }
    );
  } catch (err) {
    console.warn("[PauseGuard] Runtime messaging error:", err);
  }

  function formatSiteName(domain) {
    if (!domain) return "Destination";
    const d = domain.toLowerCase().replace(/^www\./, "").split(".")[0];
    if (d === "youtube") return "YouTube";
    return d.charAt(0).toUpperCase() + d.slice(1);
  }

  // Action: Return to Dashboard
  btnDashboard?.addEventListener("click", () => {
    chrome.storage?.local?.get(["focusforge_webapp_origin"], (res) => {
      const baseOrigin = res?.focusforge_webapp_origin || "https://jee-made-easy-by-ilham.vercel.app";
      const dashboardUrl = `${baseOrigin}/study`;
      window.location.replace(dashboardUrl);
    });
  });

  // Action: Continue to This Page (Single URL temporary exception)
  btnContinuePage?.addEventListener("click", () => {
    setButtonsDisabled(true);
    showStatus("Allowing this page...", "info");

    chrome.runtime.sendMessage(
      {
        type: "RESOLVE_PAUSE_GUARD",
        mode: "page",
        url: targetUrl,
        domain: targetDomain,
        tabId: currentTabId,
      },
      (res) => {
        if (chrome.runtime.lastError || !res?.success) {
          const err = chrome.runtime.lastError?.message || res?.error || "Unknown error";
          console.error("[PauseGuard] Failed to allow page:", err);
          showStatus("Could not temporarily allow this page. Try again.", "error");
          setButtonsDisabled(false);
          btnContinuePage.textContent = "Retry Opening Page";
          return;
        }

        const siteLabel = formatSiteName(targetDomain);
        showStatus(`Loading ${siteLabel}...`, "success");

        // The background service worker performs chrome.tabs.update() immediately.
        // Safety net fallback only in case browser update was delayed:
        setTimeout(() => {
          if (res.targetUrl || targetUrl) {
            window.location.replace(res.targetUrl || targetUrl);
          }
        }, 2000);
      }
    );
  });

  // Action: Continue on This Site (Domain-wide temporary exception during pause)
  btnContinueSite?.addEventListener("click", () => {
    setButtonsDisabled(true);
    showStatus("Allowing this site...", "info");

    chrome.runtime.sendMessage(
      {
        type: "RESOLVE_PAUSE_GUARD",
        mode: "site",
        domain: targetDomain,
        url: targetUrl,
        tabId: currentTabId,
      },
      (res) => {
        if (chrome.runtime.lastError || !res?.success) {
          const err = chrome.runtime.lastError?.message || res?.error || "Unknown error";
          console.error("[PauseGuard] Failed to allow site:", err);
          showStatus("Could not temporarily allow this site. Try again.", "error");
          setButtonsDisabled(false);
          btnContinueSite.textContent = "Retry Opening Site";
          return;
        }

        const siteLabel = formatSiteName(targetDomain);
        showStatus(`Loading ${siteLabel}...`, "success");

        // The background service worker performs chrome.tabs.update() immediately.
        // Safety net fallback only in case browser update was delayed:
        setTimeout(() => {
          if (res.targetUrl || targetUrl) {
            window.location.replace(res.targetUrl || targetUrl);
          }
        }, 2000);
      }
    );
  });

  // Keyboard navigation
  window.addEventListener("keydown", (e) => {
    if (e.key === "Escape" || (e.key === "Enter" && document.activeElement === btnDashboard)) {
      btnDashboard?.click();
    }
  });
})();
