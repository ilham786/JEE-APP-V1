// FocusForge — YouTube Content Gateway Verification Client
// Controller for youtube-verify.html (Layer B DNR Gateway)

(function () {
  "use strict";

  const params = new URLSearchParams(window.location.search);
  let targetUrl = params.get("targetUrl") || "";
  let videoId = params.get("v") || "";

  // Helper to extract 11-char YouTube ID if not in query param directly
  if (!videoId && targetUrl) {
    try {
      const parsed = new URL(targetUrl);
      const v = parsed.searchParams.get("v");
      if (v && /^[a-zA-Z0-9_-]{11}$/.test(v)) {
        videoId = v;
      }
    } catch {}
  }

  // Fallback normalization
  if (!targetUrl && videoId) {
    targetUrl = `https://www.youtube.com/watch?v=${videoId}`;
  }

  // Elements
  const elVerifying = document.getElementById("state-verifying");
  const elAllowed = document.getElementById("state-allowed");
  const elReview = document.getElementById("state-review");
  const elBlocked = document.getElementById("state-blocked");
  const elError = document.getElementById("state-error");

  const elVerifyVidDisplay = document.getElementById("verify-vid-display");
  const elBlockedVidDisplay = document.getElementById("blocked-vid-display");
  const elBlockedReason = document.getElementById("blocked-reason-display");

  const elReviewSubject = document.getElementById("review-subject-display");
  const elReviewTopic = document.getElementById("review-topic-display");
  const elReviewCode = document.getElementById("review-code-display");
  const elReviewReason = document.getElementById("review-reason-display");
  const btnConfirmStudy = document.getElementById("btn-confirm-study");
  const btnReviewSearch = document.getElementById("btn-review-search");

  const btnOpenNow = document.getElementById("btn-open-now");
  const btnRetry = document.getElementById("btn-retry");
  const btnSearch = document.getElementById("btn-yt-search");

  if (elVerifyVidDisplay) {
    elVerifyVidDisplay.textContent = videoId || (targetUrl ? "Target URL" : "Unknown");
  }

  function showState(state) {
    elVerifying.classList.add("hidden");
    elAllowed.classList.add("hidden");
    if (elReview) elReview.classList.add("hidden");
    elBlocked.classList.add("hidden");
    elError.classList.add("hidden");

    if (state === "VERIFYING") elVerifying.classList.remove("hidden");
    else if (state === "ALLOWED") elAllowed.classList.remove("hidden");
    else if (state === "REVIEW") elReview?.classList.remove("hidden");
    else if (state === "BLOCKED") elBlocked.classList.remove("hidden");
    else if (state === "ERROR") elError.classList.remove("hidden");
  }

  function verifyDestination() {
    if (!videoId && !targetUrl) {
      showState("ERROR");
      return;
    }

    showState("VERIFYING");

    if (typeof chrome === "undefined" || !chrome.runtime || !chrome.runtime.sendMessage) {
      console.warn("[FocusForge Gateway] Chrome extension runtime not available.");
      showState("ERROR");
      return;
    }

    chrome.runtime.sendMessage(
      {
        type: "VERIFY_GATEWAY_DESTINATION",
        targetUrl,
        videoId,
      },
      (response) => {
        if (chrome.runtime.lastError || !response) {
          console.warn("[FocusForge Gateway] Error communicating with background worker:", chrome.runtime.lastError);
          showState("ERROR");
          return;
        }

        // 1. Guard Inactive -> Pass through immediately
        if (response.isSessionActive === false) {
          console.log("[FocusForge Gateway] Study session is inactive. Redirecting to normal YouTube.");
          window.location.replace(targetUrl || "https://www.youtube.com");
          return;
        }

        // 2. Decision: ALLOW / STUDY
        if (response.decision === "ALLOW" || response.decision === "STUDY") {
          showState("ALLOWED");

          // Update search query fallback if active subject known
          if (response.activeSubject && btnSearch) {
            btnSearch.href = `https://www.youtube.com/results?search_query=${encodeURIComponent(
              response.activeSubject + " IIT JEE lectures"
            )}`;
          }

          // Auto-navigate to original YouTube URL
          const navTimeout = setTimeout(() => {
            window.location.replace(targetUrl);
          }, 450);

          if (btnOpenNow) {
            btnOpenNow.onclick = () => {
              clearTimeout(navTimeout);
              window.location.replace(targetUrl);
            };
          }
          return;
        }

        // 3. Decision: REVIEW (Held for student verification)
        if (response.decision === "REVIEW") {
          showState("REVIEW");
          if (elReviewSubject) {
            elReviewSubject.textContent = response.subject || response.activeSubject || "Academic Study";
          }
          if (elReviewTopic) {
            elReviewTopic.textContent = response.chapter
              ? `${response.chapter}: ${response.topic || "Core Concept"}`
              : (response.topic || "General Curriculum Topic");
          }
          if (elReviewCode) {
            elReviewCode.textContent = Array.isArray(response.reasonCodes) && response.reasonCodes.length > 0
              ? response.reasonCodes.join(", ")
              : "INSUFFICIENT_EVIDENCE";
          }
          if (elReviewReason) {
            elReviewReason.textContent =
              response.reason || "Content held at gateway for curriculum verification.";
          }
          if (btnReviewSearch && response.activeSubject) {
            btnReviewSearch.href = `https://www.youtube.com/results?search_query=${encodeURIComponent(
              response.activeSubject + " lectures"
            )}`;
          }

          if (btnConfirmStudy) {
            btnConfirmStudy.onclick = () => {
              chrome.runtime.sendMessage(
                {
                  type: "APPROVE_STUDY_VIDEO",
                  videoId,
                  title: response.title || "",
                  channelName: response.channelName || "",
                },
                () => {
                  window.location.replace(targetUrl);
                }
              );
            };
          }
          return;
        }

        // 4. Decision: BLOCK / NON_STUDY
        if (response.decision === "BLOCK" || response.decision === "NON_STUDY") {
          showState("BLOCKED");
          if (elBlockedVidDisplay) {
            elBlockedVidDisplay.textContent = videoId || "YouTube Video";
          }
          if (elBlockedReason) {
            elBlockedReason.textContent =
              response.reason || "This video is outside your configured IIT-JEE / CBSE study syllabus.";
          }
          if (response.activeSubject && btnSearch) {
            btnSearch.href = `https://www.youtube.com/results?search_query=${encodeURIComponent(
              response.activeSubject + " IIT JEE lectures"
            )}`;
          }
          return;
        }

        // 5. Default / Uncertain: Fail closed (protect focus)
        showState("ERROR");
      }
    );
  }

  if (btnRetry) {
    btnRetry.addEventListener("click", () => {
      verifyDestination();
    });
  }

  // Initial trigger
  verifyDestination();
})();
