# Contributing to FocusForge

Thank you for your interest in contributing to **FocusForge** — the elite, dark-mode Study Operating System and Academic Planner for IIT-JEE aspirants!

This guide outlines the guidelines, workflows, and standards for contributing to the repository.

---

## 📋 Table of Contents

1. [Code of Conduct](#-code-of-conduct)
2. [Getting Started](#-getting-started)
3. [Development Environment & Prerequisites](#-development-environment--prerequisites)
4. [Branching & Workflow Strategy](#-branching--workflow-strategy)
5. [Commit Message Conventions](#-commit-message-conventions)
6. [Coding & Architecture Standards](#-coding--architecture-standards)
7. [Chrome Extension Development](#-chrome-extension-development)
8. [Firebase & Backend Guidelines](#-firebase--backend-guidelines)
9. [Submitting Pull Requests](#-submitting-pull-requests)
10. [Documentation Guidelines](#-documentation-guidelines)

---

## 🤝 Code of Conduct

We are committed to providing a welcoming, inclusive, and respectful environment for all contributors. Please ensure all communication in pull requests, issues, and discussions remains professional and constructive.

---

## 🚀 Getting Started

1. **Fork the Repository**: Create your personal fork of [ilham786/JEE](https://github.com/ilham786/JEE).
2. **Clone your Fork**:
   ```bash
   git clone https://github.com/YOUR_USERNAME/JEE.git
   cd JEE
   ```
3. **Add Upstream Remote**:
   ```bash
   git remote add upstream https://github.com/ilham786/JEE.git
   ```

---

## 🛠 Development Environment & Prerequisites

### Prerequisites
* **Node.js**: `v18.0.0` or higher (v20+ recommended).
* **npm**: `v9.x` or higher.
* **Google Chrome**: (or any Chromium browser) for testing the Companion Extension.

### Setup Commands
```bash
# 1. Install dependencies
npm install

# 2. Configure environment variables
cp .env.example .env

# 3. Start local Next.js development server
npm run dev

# 4. (Optional) Run standalone Express login server
npm run server
```

Open [http://localhost:3000](http://localhost:3000) to view the Next.js application.

---

## 🌿 Branching & Workflow Strategy

* `main`: The stable production branch.
* `feature/<feature-name>`: Topic branches for new feature development.
* `fix/<bug-name>`: Topic branches for bug fixes.
* `docs/<topic>`: Branches dedicated to documentation updates.

Always pull the latest changes from `upstream/main` before starting a new feature branch:
```bash
git checkout main
git pull upstream main
git checkout -b feature/amazing-new-feature
```

---

## 📝 Commit Message Conventions

We follow the [Conventional Commits](https://www.conventionalcommits.org/) specification:

```
<type>(<scope>): <short description>
```

### Supported Types
* `feat`: A new user-facing feature.
* `fix`: A bug fix.
* `docs`: Documentation only changes.
* `style`: Changes that do not affect code logic (formatting, spacing, CSS variables).
* `refactor`: Code changes that neither fix a bug nor add a feature.
* `perf`: Performance improvements.
* `test`: Adding or correcting unit/integration tests.
* `chore`: Maintenance tasks, dependency updates, or build configuration changes.

### Examples
```bash
git commit -m "feat(study): add monk mode keyboard shortcut toggle"
git commit -m "fix(revisions): resolve supermemo interval date calculation edge case"
git commit -m "docs(extension): document chrome extension message passing architecture"
```

---

## 🎨 Coding & Architecture Standards

### Next.js & React Conventions
* **App Router**: Feature pages reside in `src/app/` (`/study`, `/mistakes`, `/revisions`, `/jee`, etc.).
* **Hydration Guards**: Wrap client-only browser state renders in `useIsClient` to avoid SSR hydration mismatches.
* **Tailwind v4 Styling**: Use Tailwind v4 theme variables defined in `src/app/globals.css`. Never use hardcoded inline hex colors.
* **Glassmorphic Design**: Apply `.glass-panel` utility classes for visual cards and translucent overlays.

### State Management
* Client state is managed via **Zustand** stores (`useStudyStore` and `useMistakeStore`) with `localStorage` persistence.
* Cloud synchronization is handled by **Firebase Firestore** service modules (`src/services/`).

---

## 🧩 Chrome Extension Development

The Companion Chrome Extension source files are located in `public/extension/`:
* `manifest.json`: Extension Manifest V3 configuration.
* `background.js`: Service worker handling website blocking and messaging.
* `content.js`: Content script injected into blocked tabs.
* `popup/`: Extension popup UI.

To package the Chrome Extension into a downloadable ZIP archive:
```bash
npm run package:extension
```
This executes `scripts/package-extension.js` and outputs `public/FocusForge-Extension-v1.2.0.zip`.

---

## 🔥 Firebase & Backend Guidelines

* All Firebase Firestore database interactions MUST go through dedicated service modules in `src/services/` (e.g., `userService.ts`, `studySessionService.ts`, `blockerService.ts`).
* Do NOT write raw Firestore calls inside component pages.
* Ensure all new collections comply with security constraints defined in `firestore.rules`.

---

## 📥 Submitting Pull Requests

1. Run code quality checks:
   ```bash
   npm run lint
   ```
2. Ensure project builds cleanly:
   ```bash
   npm run build
   ```
3. Push your branch to GitHub:
   ```bash
   git push origin feature/amazing-new-feature
   ```
4. Open a **Pull Request** against `upstream/main`.
5. Provide a clear summary of changes, screenshots/recordings for UI changes, and link related issues.

---

## 📚 Documentation Guidelines

If your pull request introduces a new feature, route, Firestore collection, or extension capability:
* Update relevant files in `docs/` (`ARCHITECTURE.md`, `COMPONENTS.md`, `FIREBASE.md`, `EXTENSION.md`, `API.md`).
* Update `README.md` if user-facing setup or features change.
* Add a entry to `docs/CHANGELOG.md`.

---

Thank you for helping build **FocusForge**! 🚀
